# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
"""Bo may do: dung danh sach viec, chay tung viec mot, cham diem.

CACH DO
  1. WARMUP  — mot lan render bo di. Lan render dau tien cua mot phien con
               phai bien dich kernel GPU va dung BVH. Khong bo lan nay thi
               bo thong so nao chay dau se bi cham oan.
  2. REF     — anh CHUAN: chinh thiet lap hien tai cua khach nhung cho hoi tu
               (nhieu sample, nguong thap) va TAT denoise. Day la "su that"
               de doi chieu.
  3. BASE    — thiet lap hien tai, nguyen ven. Diem xuat phat.
  4. AXIS    — tung phuong an cua tung truc, moi lan chi doi DUNG MOT truc.
  5. COMBO   — gop cac phuong an thang lai roi do lai. Bat buoc phai do:
               hai thay doi tot rieng le khong dam bao tot khi di cung nhau.

Anh chuan la thiet lap HIEN TAI da hoi tu, khong phai mot chuan tuyet doi
nao khac. Nghia la moi con so `diff` tra loi dung mot cau: "lech bao nhieu
so voi thu anh se nhan duoc neu cu render nhu bay gio". Doi bounces xuong
thap se lech nhieu — dung nhu the, vi no LAM DOI anh that.
"""
import os
import time

import bpy

from . import metrics, settings

# Cac trong CHINH PHEP DO tu tay doi (viec REF tat denoise, keo sample len).
# Chung PHAI nam trong baseline, neu khong thi sau viec REF moi bien the deu
# render voi denoise tat va sample cua anh chuan — moi ket qua giong het
# nhau va bang do trong nhu that. Da dinh dung loi nay ngay 05/08/2026:
# ca 23 phep kiem van xanh trong khi phep do khong do gi ca.
BENCH_OWNED = ('cycles.use_denoising', 'cycles.samples',
               'cycles.use_adaptive_sampling', 'cycles.adaptive_threshold')


def _tmp(name):
    return os.path.join(bpy.app.tempdir, "dpopt_%s" % name)


class Runner:
    """Giu trang thai mot lan do. Modal operator goi `step()` tung nhip."""

    def __init__(self, scene, st):
        self.scene = scene
        self.st = st
        self.jobs = []
        self.results = []          # dict: label, group, key, option, secs, m
        self.ref_rgb = None
        self.ref_noise = 0.0
        self.ref_secs = 0.0
        self.base_secs = None
        self.index = 0
        self._timed = 0
        self._warm = []
        self.spreads = []
        self.snap = None
        self.img_snap = {}
        self.baseline = {}
        self.error = None
        self._combo_added = False

    # ---------------------------------------------------------------- setup
    def build_jobs(self):
        """Xen ke cac lan do lai DIEM XUAT PHAT giua cac phep do.

        VI SAO: may khong chay o mot toc do co dinh suot buoi. Do that
        05/08/2026 tren cung mot bo thong so, 10 lan lien tiep:
        2.49 2.50 2.53 2.50 2.52 2.48 2.55 2.49 1.18 1.23 — den lan thu 9 no
        tut mot nua roi giu nguyen. Bo thong so nao roi vao doan dau se cham
        gap doi ma khong phai loi cua no.

        Nen moi phuong an KHONG duoc so voi mot con so mocdo tu dau buoi, ma
        so voi diem xuat phat do duoc GAN NO NHAT ve thoi gian. Xem `ratio()`.
        """
        scene, st = self.scene, self.st
        enabled = {a.key for a in st.axes if a.enabled}
        self.jobs = [dict(kind='WARMUP', label="Warm-up (discarded)",
                          group='', key='', option='', overrides={}),
                     dict(kind='REF', label="Reference (converged)",
                          group='', key='', option='', overrides={}),
                     dict(kind='BASE', label="Current settings",
                          group='', key='', option='', overrides={})]
        every = max(2, st.rebase_every)
        since = 0
        for axis, ok in settings.available_axes(scene):
            if not ok or axis['key'] not in enabled:
                continue
            for name, ov in axis['options']:
                if since >= every:
                    self.jobs.append(dict(kind='BASEP',
                                          label="Current settings (check)",
                                          group='', key='', option='',
                                          overrides={}))
                    since = 0
                self.jobs.append(dict(kind='AXIS',
                                      label="%s: %s" % (axis['label'], name),
                                      group=axis['group'], key=axis['key'],
                                      option=name, overrides=ov))
                since += 1
        return len(self.jobs)

    def start(self):
        scene = self.scene
        paths = tuple(settings.ALL_PATHS) + settings.BENCH_PATHS
        self.snap = settings.Snapshot(scene, paths)
        ims = scene.render.image_settings
        self.img_snap = dict(file_format=ims.file_format,
                             color_depth=ims.color_depth,
                             color_mode=ims.color_mode)

        # Gia tri XUAT PHAT cua moi trong ma phep do co the cham vao. Truoc
        # moi lan do phai tra ve day, neu khong thi lan do thu ba se mang
        # theo thay doi cua lan thu hai — do mot truc ma hoa ra do hai.
        self.baseline = {p: settings.get(scene, p)
                         for p in tuple(settings.ALL_PATHS) + BENCH_OWNED
                         if settings.exists(scene, p)}

        ims.file_format = 'OPEN_EXR'
        ims.color_depth = '32'
        ims.color_mode = 'RGBA'
        scene.render.use_compositing = False   # do BO MAY RENDER, khong do compositor
        scene.cycles.use_animated_seed = False
        scene.cycles.seed = self.st.seed
        self._set_region()

    def _set_region(self):
        """Vung do.

        MAC DINH LA KHUNG DAY, va do la lua chon duy nhat dung. Do that
        05/08/2026 tren cung mot scene, so voi khung day 1920x1080:

                            o cat 17%   thu nho 60%   khung day
            threshold 0.02      -9%         -8%         -45%
            scrambling 0.5      -4%         -1%         -40%
            bounces 6/3/3       -6%         +1%         -40%

        Anh nho lam chi phi co dinh (dung BVH, dong bo scene, khoi dong bo
        khu nhieu) lan at phan do tia, nen moi thiet lap cat chi phi do tia
        deu bi cham diem gan bang khong. Thu hang dao lon hoan toan: tren o
        cat, `denoise quality Fast` dung hang hai; tren khung day no dung
        BET. Ap ket qua do vao file that la lam RENDER CHAM DI.
        """
        scene, st = self.scene, self.st
        if st.region_mode == 'FULL':
            scene.render.use_border = False
            scene.render.resolution_percentage = 100
        elif st.region_mode == 'CROP':
            half = max(0.02, min(0.5, st.region_size / 200.0))
            r = scene.render
            r.use_border = True
            r.use_crop_to_border = True
            r.border_min_x = 0.5 - half
            r.border_max_x = 0.5 + half
            r.border_min_y = 0.5 - half
            r.border_max_y = 0.5 + half
            r.resolution_percentage = 100
        else:
            scene.render.use_border = False
            scene.render.resolution_percentage = max(1, min(100, int(st.region_size)))

    def finish(self):
        if self.snap:
            self.snap.restore()
        ims = self.scene.render.image_settings
        for k, v in self.img_snap.items():
            try:
                setattr(ims, k, v)
            except Exception:
                pass

    # ----------------------------------------------------------------- run
    def _reset_to_baseline(self):
        for p, v in self.baseline.items():
            try:
                settings.put(self.scene, p, v)
            except Exception:
                pass

    def _render(self, name):
        scene = self.scene
        path = _tmp(name)
        scene.render.filepath = path
        t0 = time.perf_counter()
        bpy.ops.render.render(write_still=True)
        secs = time.perf_counter() - t0
        real = path if os.path.isfile(path) else path + '.exr'
        if not os.path.isfile(real):
            raise RuntimeError("khong tim thay anh vua render: %s" % real)
        return secs, real

    def step(self):
        """Chay mot viec. Tra ve False khi het viec."""
        if self.index >= len(self.jobs):
            if self._combo_added:
                return False
            self._append_combo()
            if self.index >= len(self.jobs):
                return False

        job = self.jobs[self.index]
        self.index += 1
        scene, st = self.scene, self.st

        self._reset_to_baseline()

        if job['kind'] == 'COMBO' and job['overrides'] is None:
            # Chi den luc nay moi biet ai thang, vi BASE2 vua chay xong va
            # sai so dong ho moi tinh duoc.
            merged = {}
            for res in self.winners().values():
                merged.update(res['overrides'])
            job['overrides'] = merged
            if not merged:
                return False        # khong co gi nhanh hon — het viec

        if job['kind'] == 'REF':
            scene.cycles.use_denoising = False
            scene.cycles.samples = st.ref_samples
            scene.cycles.use_adaptive_sampling = True
            scene.cycles.adaptive_threshold = st.ref_threshold
        else:
            settings.apply(scene, job['overrides'])

        # DO LAP ROI LAY LAN NHANH NHAT.
        # Nhieu cua phep bam gio la mot chieu: cai gi chen ngang deu chi lam
        # CHAM lai, khong bao gio lam nhanh len. Nen lan nhanh nhat la lan
        # gan su that nhat. Do that 05/08/2026: do mot lan thi mot phuong an
        # y het thiet lap hien tai bao "nhanh hon 18%" — addon trao giai cho
        # mot thay doi khong lam gi ca.
        if job['kind'] in ('WARMUP', 'REF'):
            reps = 1
        elif job['kind'] == 'COMBO':
            # Bo gop cuoi la thu DUY NHAT se duoc ap dung vao file cua khach,
            # nen no phai chiu phep do nghiem nhat trong ca vong.
            reps = max(1, self.st.combo_repeats)
        else:
            reps = max(1, self.st.repeats)
        times = []
        keep = None
        for k in range(reps):
            try:
                secs, path = self._render("%03d_%d" % (self.index, k))
            except Exception as exc:                   # noqa: BLE001
                self.error = "%s: %s" % (job['label'], exc)
                return False
            times.append(secs)
            if k == 0:
                keep = path
            else:
                # Cung seed, cung thong so -> anh giong het. Chi can mot cai.
                self._safe_unlink(path)
        secs = min(times)
        if len(times) > 1 and min(times) > 1e-9:
            self.spreads.append((max(times) - min(times)) / min(times))
        path = keep

        if job['kind'] == 'WARMUP':
            # WARM-UP CHAY DEN KHI MAY ON DINH, khong phai dung mot lan.
            # Do that 05/08/2026: mot may vua khoi dong chay 8 lan render
            # dau o 2,5s roi tut xuong 1,18s va giu nguyen. Cu tut do la mot
            # BAC THANG, khong phai mot doc thoai — phep chua troi bang noi
            # suy khong voi toi duoc, no chi bien cac phep do quanh do thanh
            # nhung con so nhu "+120%". Nen phai doi may xuong den muc on
            # dinh TRUOC KHI bat dau bam gio.
            self._warm.append(secs)
            self._safe_unlink(path)
            if (not self.warm_stable()
                    and len(self._warm) < max(1, self.st.warmup_max)):
                self.jobs.insert(self.index,
                                 dict(kind='WARMUP', label="Warm-up (discarded)",
                                      group='', key='', option='', overrides={}))
            return True

        try:
            rgb, _w, _h = metrics.load(path)
        finally:
            self._safe_unlink(path)

        if job['kind'] == 'REF':
            self.ref_rgb = rgb
            self.ref_noise = metrics.noise_floor(rgb, flat_pct=st.flat_percentile)
            self.ref_secs = secs
            return True

        if self.ref_rgb is None:
            self.error = "thieu anh chuan — viec REF da khong chay"
            return False
        # Thu tu doi so la (CHUAN, THU). Dao lai la `detail` lat nguoc y nghia.
        m = metrics.compare(self.ref_rgb, rgb, edge_pct=st.edge_percentile,
                            flat_pct=st.flat_percentile)

        if job['kind'] == 'BASE':
            self.base_secs = secs

        self._timed += 1
        self.results.append(dict(kind=job['kind'], label=job['label'],
                                 group=job['group'], key=job['key'],
                                 option=job['option'], secs=secs, m=m,
                                 ord=self._timed,
                                 overrides=dict(job['overrides'])))
        return True

    @staticmethod
    def _safe_unlink(path):
        try:
            os.unlink(path)
        except OSError:
            pass

    # ------------------------------------------------------------- ket luan
    def _append_combo(self):
        """Do lai diem xuat phat mot lan nua, roi do bo gop cac phuong an thang.

        LAN DO LAI (`BASE2`) LA BAT BUOC, khong phai thu xa xi. Do that ngay
        05/08/2026: hai lan render y het nhau cua cung mot bo thong so lech
        nhau toi 6%, trong khi nguong "coi la nhanh hon" mac dinh chi 3%.
        Khong co lan do lai thi addon se bao mot thay doi khong lam gi ca la
        "nhanh hon 6%". Hieu so giua hai lan chinh la sai so cua chinh cai
        dong ho — va no tro thanh san toi thieu de duoc goi la thang.
        """
        self._combo_added = True
        self.jobs.append(dict(kind='BASE2', label="Current settings (repeat)",
                              group='', key='', option='', overrides={}))
        # COMBO phai duoc dung SAU khi BASE2 chay xong, vi luc do moi biet sai
        # so dong ho. Nen day chi la cho giu cho; `step()` se dien noi dung.
        self.jobs.append(dict(kind='COMBO', label="Combined winners",
                              group='', key='', option='', overrides=None))

    def warm_stable(self):
        """Ba lan render bo di gan nhat da sat nhau chua?"""
        if len(self._warm) < 3:
            return False
        last = self._warm[-3:]
        lo = min(last)
        if lo <= 1e-9:
            return True
        return (max(last) - lo) / lo <= max(0.001, self.st.warmup_tolerance)

    @property
    def warmup_count(self):
        return len(self._warm)

    # ---------------------------------------------------- chong troi toc do
    BASE_KINDS = ('BASE', 'BASEP', 'BASE2')

    def base_curve(self):
        """[(thu tu, giay)] cua moi lan do DIEM XUAT PHAT, theo thu tu chay."""
        return sorted(((r['ord'], r['secs']) for r in self.results
                       if r['kind'] in self.BASE_KINDS), key=lambda t: t[0])

    def base_at(self, ordinal):
        """Diem xuat phat 'dang le phai la bao nhieu' vao dung luc do."""
        curve = self.base_curve()
        if not curve:
            return None
        if ordinal <= curve[0][0]:
            return curve[0][1]
        if ordinal >= curve[-1][0]:
            return curve[-1][1]
        for (o0, s0), (o1, s1) in zip(curve, curve[1:]):
            if o0 <= ordinal <= o1:
                if o1 == o0:
                    return s0
                t = (ordinal - o0) / (o1 - o0)
                return s0 + t * (s1 - s0)
        return curve[-1][1]

    def ratio(self, r):
        """Thoi gian cua mot phuong an CHIA CHO diem xuat phat cung thoi diem.

        1.00 = khong nhanh hon gi. 0.70 = nhanh hon 30%. Dung ty so nay chu
        khong dung giay tho: giay tho con dinh ca phan may chay nhanh dan
        len hay cham dan di trong buoi do.
        """
        b = self.base_at(r.get('ord', 0))
        if not b:
            return 1.0
        return r['secs'] / b

    @property
    def drift(self):
        """Do troi toc do may trong ca buoi do: nhanh nhat / cham nhat."""
        curve = self.base_curve()
        if len(curve) < 2:
            return 0.0
        vals = [s for _o, s in curve]
        lo, hi = min(vals), max(vals)
        return (hi - lo) / lo if lo > 1e-9 else 0.0

    @staticmethod
    def _median(xs):
        if not xs:
            return 0.0
        xs = sorted(xs)
        mid = len(xs) // 2
        return xs[mid] if len(xs) % 2 else (xs[mid - 1] + xs[mid]) / 2.0

    def base_residual(self):
        """Sai so CON LAI sau khi da chua troi toc do.

        Cach do: bo tung moc di roi doan lai no tu hai moc ke ben. Doan trat
        bao nhieu thi do dung la phan ma phep chua troi khong voi toi duoc.

        Vi sao can: do tan giua cac lan lap lien tiep (`spreads`) chi bat
        duoc nhieu trong VAI GIAY. Con hai phep do cach nhau vai phut thi
        lech nhieu hon han. Do that 05/08/2026: do tan giua cac lan lap la
        1,2%, nhung mot phuong an Y HET thiet lap hien tai van doc ra -4%.
        """
        curve = self.base_curve()
        if len(curve) < 3:
            return 0.0
        res = []
        for i in range(1, len(curve) - 1):
            (o0, s0), (oi, si), (o1, s1) = curve[i - 1], curve[i], curve[i + 1]
            if o1 == o0 or si <= 1e-9:
                continue
            pred = s0 + (oi - o0) / (o1 - o0) * (s1 - s0)
            res.append(abs(si - pred) / si)
        return self._median(res)

    @property
    def timing_noise(self):
        """Sai so cua phep bam gio: lay cai LON HON trong hai cach do.

        Bao thap sai so thi addon se trao giai cho nhung thay doi khong lam
        gi ca. Nen o day lay muc cao hon giua "do tan giua cac lan lap" va
        "sai so con lai giua cac moc".
        """
        by_repeat = self._median(self.spreads)
        by_base = self.base_residual()
        if by_repeat or by_base:
            return max(by_repeat, by_base)
        base = self.base()
        rep = next((r for r in self.results if r['kind'] == 'BASE2'), None)
        if not base or not rep or not base['secs']:
            return 0.0
        return abs(rep['secs'] - base['secs']) / base['secs']

    def effective_gain(self):
        """Nguong "hon han" that su: khong the thap hon sai so dong ho."""
        return max(self.st.min_gain, self.timing_noise)

    # ---------------------------------------------------------------- luat chon
    #
    # LUAT NAY DA DOI NGAY 06/08/2026, VA DAY LA DIEU QUAN TRONG NHAT CUA
    # CA ADDON.
    #
    # Truoc: trong cac phuong an khong lam anh te hon, lay cai NHANH NHAT.
    #        Chat luong chi la mot cai SAN de loai, khong bao gio la cai de
    #        thang. Nghia la mot thiet lap GIU DUOC VAN GO MA KHONG CHAM HON
    #        thi addon nhin thay roi bo qua — no khong duoc lap trinh de muon
    #        thu do.
    #
    # Nay:   trong cac phuong an KHONG CHAM HON va KHONG NHIEU HON, lay cai
    #        GIU DUOC NHIEU VAN VAT LIEU NHAT. Thoi gian tro thanh rang buoc,
    #        van vat lieu tro thanh muc tieu.
    #
    # HAI CAI BAY:
    #
    #   1. KHONG duoc lay `diff` hay `detail` lam muc tieu — khong phai vi
    #      chung sai, ma vi chung KHONG TACH DUOC cac ung vien. Do
    #      06/08/2026: ba muc denoise quality cho ra detail 0.941 / 0.938 /
    #      0.940, va hai muc input passes cho ra 0.926 / 0.926 — HOA NHAU.
    #      Cung nhung ung vien do, `texture` cho 0.838 / 0.839 / 0.829 va
    #      0.801 / 0.777. Mot thuoc ma moi phuong an deu bang nhau thi khong
    #      chon duoc gi, va cai duoc chon se la nhieu cua phep do.
    #
    #   2. KHONG duoc lay `texture` lam muc tieu MA KHONG CHAN NHIEU. Nhieu
    #      lam tang do doc cua anh nen no day `texture` len: anh khong khu
    #      nhieu do duoc detail 1.075, cao hon MOI cach khu nhieu. Bo chan
    #      thi thuat toan se hoc duoc rang cach "giu van go" tot nhat la TAT
    #      KHU NHIEU DI. Cai chan la `blotch` — nhieu con sot o vung phang.
    #      Mot phuong an giu van go that thi giu duoc ma khong lam ban vung
    #      phang; mot phuong an chi don thuan de nhieu lai thi truot o day.

    def texture_gain(self, r):
        """Phuong an nay giu them duoc bao nhieu phan van vat lieu.

        0.10 = giu them mot phan muoi so voi thiet lap hien tai. Am la ca mo
        hon. Do o dai giua — van go, soi vai — xem `metrics.compare`.
        """
        base = self.base()
        if not base:
            return 0.0
        b = float(base['m'].get('texture', 0.0))
        if b <= 1e-9:
            return 0.0
        return (float(r['m'].get('texture', 0.0)) - b) / b

    def not_slower(self, r):
        """Khong cham hon, trong pham vi cai dong ho nay phan biet duoc.

        Dung `timing_noise` chu khong dung `effective_gain()`: o day cau hoi
        la "co phan biet duoc no cham hon khong", va cau tra loi do sai so
        phep do quyet dinh — khong phai do nguong "dang de bam" cua nguoi
        dung. Moi nut mot viec.
        """
        return self.ratio(r) <= 1.0 + max(0.0, self.timing_noise)

    def not_noisier(self, r):
        """Khong de lai nhieu hon thiet lap hien tai o vung phang.

        DAY LA CAI CHAN quan trong nhat cua luat chon. Thieu no thi phuong
        an "thang" se luon la phuong an khu nhieu it nhat.
        """
        base = self.base()
        if not base:
            return True
        b = float(base['m'].get('blotch', 0.0))
        if b <= 1e-9:
            return float(r['m'].get('blotch', 0.0)) <= 1e-9
        return float(r['m'].get('blotch', 0.0)) <= b * (1.0 + self.st.blotch_slack)

    def is_win(self, r):
        """Giu them van vat lieu du nhieu, ma khong cham hon, khong ban hon."""
        return (self.not_slower(r) and self.not_noisier(r)
                and self.texture_gain(r) > self.st.min_gain)

    def winners(self):
        """Phuong an thang cua tung truc.

        Trong so cac phuong an KHONG CHAM HON, KHONG NHIEU HON va khong rot
        san chat luong, lay cai GIU DUOC NHIEU VAN VAT LIEU NHAT.
        """
        base = self.base()
        base_m = base['m'] if base else None
        st = self.st
        by_axis = {}
        for r in self.results:
            if r['kind'] != 'AXIS':
                continue
            by_axis.setdefault(r['key'], []).append(r)

        out = {}
        for key, rows in by_axis.items():
            good = [r for r in rows
                    if metrics.passes(r['m'], base_m, st.detail_floor,
                                      st.diff_ceiling)
                    and self.not_slower(r) and self.not_noisier(r)]
            if not good:
                continue
            best = max(good, key=lambda x: float(x['m'].get('texture', 0.0)))
            if self.texture_gain(best) <= st.min_gain:
                continue
            out[key] = best
        return out

    def combo(self):
        for r in self.results:
            if r['kind'] == 'COMBO':
                return r
        return None

    def base(self):
        for r in self.results:
            if r['kind'] == 'BASE':
                return r
        return None
