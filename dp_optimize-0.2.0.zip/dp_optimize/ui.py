# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
"""Bang dieu khien trong Properties > Render.

CHU TREN GIAO DIEN LA TIENG ANH — addon nay ban ra.
"""
import bpy
from bpy.types import Panel

from . import comp, ops, props, settings


def _estimate(scene, st):
    """So lan render se chay. Phai tinh ca so lan lap, neu khong thi con so
    hien ra be bang mot nua thuc te."""
    timed = 1 + 1 + 1               # current, current-repeat, combined
    opts = 0
    for axis, ok in settings.available_axes(scene):
        if not ok:
            continue
        row = next((a for a in st.axes if a.key == axis['key']), None)
        if row is not None and row.enabled:
            opts += len(axis['options'])
    timed += opts
    timed += opts // max(2, st.rebase_every)   # cac lan do lai diem xuat phat
    # Warm-up chay den khi may on dinh nen chi biet duoc khoang: it nhat 3.
    return (3 + 1 + timed * max(1, st.repeats),
            max(1, st.warmup_max) + 1 + timed * max(1, st.repeats))


class _Base:
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = "render"


class _CyclesOnly(_Base):
    """Bang con chi co nghia khi dang dung Cycles."""

    @classmethod
    def poll(cls, context):
        return context.engine == 'CYCLES'


class DPOPT_PT_main(_Base, Panel):
    bl_label = "DP Optimize"
    bl_idname = "DPOPT_PT_main"

    # KHONG loc theo engine o day. Bang cha ma tu an di thi nguoi dung bat
    # addon xong khong thay gi ca va tuong la deploy hong — dung cai bay ma
    # Path Guiding cua Blender dang mac. Thay vi bien mat, no phai NOI RA
    # ly do va dua san nut de sua.

    def draw(self, context):
        scene = context.scene
        layout = self.layout

        if context.engine != 'CYCLES':
            box = layout.box()
            box.label(text="This add-on measures Cycles renders.", icon='INFO')
            box.label(text="The current engine is %s."
                           % scene.render.engine.replace('BLENDER_', '')
                             .replace('_', ' ').title())
            box.operator("dpopt.use_cycles", icon='SHADING_RENDERED')
            return

        # CHI DUOC DOC TRONG `draw`, KHONG DUOC GHI.
        # Blender cam ghi vao du lieu ID (Scene) trong luc ve giao dien. Goi
        # `ensure_axes()` o day — no them dong vao CollectionProperty cua
        # Scene — la Blender nem loi ngay tai dong do, va ket qua la khung
        # bang HIEN RA NHUNG RONG RUOT, chi con may bang con. Nhin vao tuong
        # addon hong. Danh sach truc duoc dung san boi handler khi mo file va
        # boi cac operator, xem `props.ensure_axes`.
        st = scene.dpopt

        if st.running:
            box = layout.box()
            box.label(text="Working… %s" % st.progress, icon='TIME')
            box.label(text="Press Esc to stop. Your settings are kept safe.")
            return

        # NUT CHINH BAM PHAT XONG, KHONG RENDER LAN NAO.
        # Truoc day nut chinh la vong do 17 lan render full — mot cong cu
        # tang toc ma bat cho ca buoi thi khong con la tang toc. Nhung thu
        # trong day khong phu thuoc scene nen khong can do; xem
        # `ops._instant_wins`.
        todo = ops._instant_wins(scene)
        col = layout.column()
        col.scale_y = 2.0
        col.enabled = bool(todo)
        col.operator("dpopt.speedup", icon='CHECKMARK')

        if todo:
            box = layout.box()
            box.label(text="Ready to switch on, no rendering needed:",
                      icon='INFO')
            for _p, _v, msg in todo:
                box.label(text="    %s" % msg)
        else:
            layout.label(text="Nothing left to switch on for free.",
                         icon='CHECKMARK')

        # CYCLES CHON SAO THI TOOL CHAY VAY.
        # Addon KHONG dat lai thiet bi tinh toan. Nguoi dung da chon CPU /
        # GPU / ca hai trong Cycles roi, va lua chon do la cua ho — mot cong
        # cu toi uu ma tu doi thiet bi render la lam hong cai ho vua can.
        # Dong nay chi DOC ra de ho thay tool dang di theo cai gi.
        dev = settings.device_label(scene)
        if dev:
            layout.label(text="Following Cycles: rendering on %s." % dev,
                         icon='MEMORY')

        if scene.camera is None:
            layout.label(text="This scene has no camera.", icon='ERROR')

        if st.last_summary:
            box = layout.box()
            box.label(text=st.last_summary, icon='INFO')


class DPOPT_PT_advanced(_CyclesOnly, Panel):
    """Cho cat moi thu ma nguoi dung binh thuong khong can biet."""
    bl_label = "Advanced"
    bl_idname = "DPOPT_PT_advanced"
    bl_parent_id = "DPOPT_PT_main"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        scene = context.scene
        st = scene.dpopt          # chi doc, xem chu thich o DPOPT_PT_main
        layout = self.layout

        layout.label(text="These are chosen for you when you press Optimize.")

        col = layout.column(align=True)
        col.prop(st, "region_mode")
        col.prop(st, "region_size")

        col = layout.column(align=True)
        col.prop(st, "ref_samples")
        col.prop(st, "ref_threshold")
        col.prop(st, "repeats")
        col.prop(st, "rebase_every")
        col.prop(st, "warmup_max")
        col.prop(st, "warmup_tolerance")
        col.prop(st, "seed")

        if st.repeats < 2:
            box = layout.box()
            box.alert = True
            box.label(text="With one run per setting, a change that costs",
                      icon='ERROR')
            box.label(text="time can still measure as free, and get accepted.")

        lo, hi = _estimate(scene, st)
        layout.label(text="%d to %d test renders with these" % (lo, hi),
                     icon='RENDER_STILL')

        # VONG DO DAY DU — o day chu khong o ngoai. No ton bang chung ay lan
        # render that, nen no la mot viec nguoi dung CHU DONG chon lam luc
        # ranh may, khong phai thao tac hang ngay.
        box = layout.box()
        box.label(text="Full measurement", icon='SEQ_HISTOGRAM')
        box.label(text="Renders this scene about %d times at full size."
                       % props.AUTO_RENDERS)
        box.label(text="Small test renders were measured to rank settings")
        box.label(text="wrongly, so there is no fast shortcut. Esc stops it.")
        box.operator("dpopt.benchmark", text="Measure and Apply",
                     icon='PLAY').auto = True
        op = box.operator("dpopt.benchmark", text="Measure Only, Apply Nothing",
                          icon='SEQ_HISTOGRAM')
        op.auto = False

        # NOI RUOT CUA "Protect Texture Detail". Bang chinh chi co mot nut va
        # addon tu quyet dinh het; ai muon soi hay chinh thi vao day.
        box = layout.box()
        box.label(text="Split denoise internals", icon='NODETREE')
        col = box.column(align=True)
        col.prop(st, "split_prefilter")
        col.prop(st, "split_quality")
        col.prop(st, "split_denoise_volume")
        col = box.column(align=True)
        col.label(text="Check the rebuild is exact — a correct graph differs")
        col.label(text="from an ordinary render only by rounding error.")
        col.prop(st, "split_verify_samples")
        col.operator("dpopt.split_verify", icon='CHECKMARK')

        if st.ref_noise > st.ref_noise_warn:
            box = layout.box()
            box.alert = True
            box.label(text="Reference image is still noisy (%.4f)."
                           % st.ref_noise, icon='ERROR')
            box.label(text="Its own leftover grain counts as texture, so")
            box.label(text="every result is scored against a moving target.")
            box.label(text="Raise Reference Samples or lower its threshold.")


class DPOPT_PT_axes(_CyclesOnly, Panel):
    bl_label = "What To Measure"
    bl_parent_id = "DPOPT_PT_advanced"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        scene = context.scene
        st = scene.dpopt          # chi doc, xem chu thich o DPOPT_PT_main
        layout = self.layout

        row = layout.row(align=True)
        row.operator("dpopt.axes_set", text="All").mode = 'ALL'
        row.operator("dpopt.axes_set", text="Default").mode = 'DEFAULT'
        row.operator("dpopt.axes_set", text="None").mode = 'NONE'

        groups = []
        for axis, _ok in settings.available_axes(scene):
            if axis['group'] not in groups:
                groups.append(axis['group'])

        for group in groups:
            box = layout.box()
            box.label(text=group)
            for axis, ok in settings.available_axes(scene):
                if axis['group'] != group:
                    continue
                r = next((a for a in st.axes if a.key == axis['key']), None)
                if r is None:
                    continue
                line = box.row(align=True)
                line.enabled = ok
                line.prop(r, "enabled", text="")
                label = axis['label']
                if not ok:
                    label += "  (not available in this scene)"
                line.label(text=label)


class DPOPT_PT_results(_CyclesOnly, Panel):
    bl_label = "What Was Measured"
    bl_parent_id = "DPOPT_PT_main"
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return (context.engine == 'CYCLES'
                and len(context.scene.dpopt.results) > 0)

    def draw(self, context):
        st = context.scene.dpopt
        layout = self.layout

        if not len(st.results):
            layout.label(text="Nothing measured yet.")
            return

        head = layout.row(align=True)
        head.label(text="Setting")
        sub = head.row(align=True)
        sub.alignment = 'RIGHT'
        sub.label(text="Time")
        sub.label(text="Texture")
        sub.label(text="Detail")
        sub.label(text="Diff")

        base = next((r for r in st.results if r.kind == 'BASE'), None)

        for i, r in enumerate(st.results):
            box = layout.box() if r.kind in ('BASE', 'COMBO') else layout
            line = box.row(align=True)

            if r.kind == 'COMBO':
                icon = 'SOLO_ON'
            elif r.kind == 'BASE':
                icon = 'DOT'
            elif r.winner:
                icon = 'CHECKMARK'
            elif r.passed:
                icon = 'BLANK1'
            else:
                icon = 'X'
            line.label(text=r.label, icon=icon)

            sub = line.row(align=True)
            sub.alignment = 'RIGHT'
            # Phan tram lay tu `ratio` — da chuan hoa theo diem xuat phat do
            # duoc gan no nhat ve thoi gian, khong phai chia cho giay tho.
            if r.kind == 'BASE':
                sub.label(text="%.1fs" % r.secs)
            else:
                sub.label(text="%.1fs (%+.0f%%)"
                               % (r.secs, (r.ratio - 1.0) * 100.0))
            sub.label(text="%.3f" % r.texture)
            sub.label(text="%.2f" % r.detail)
            sub.label(text="%.4f" % r.diff)

            if r.kind != 'BASE':
                op = sub.operator("dpopt.apply", text="", icon='IMPORT')
                op.index = i

        if any(r.kind == 'COMBO' for r in st.results):
            layout.operator("dpopt.apply_combined", icon='CHECKMARK')

        col = layout.column(align=True)
        col.label(text="Texture is fine material detail — wood grain, weave.")
        col.label(text="It is what the denoiser blurs away first, so it is what")
        col.label(text="a setting has to keep in order to be accepted.")
        if st.timing_noise:
            col.label(text="Timing spread on this machine: %.0f%%"
                           % (st.timing_noise * 100.0),
                      icon='TIME')
        if st.warmup_used:
            col.label(text="Warm-up: %d renders discarded." % st.warmup_used,
                      icon='TIME')
        if not st.warmup_ok:
            col.label(text="The machine never settled within the warm-up limit.",
                      icon='ERROR')
            col.label(text="Treat these times as rough. Raise Warm-up Limit.")
        if st.drift > 0.15:
            col.label(text="This machine changed speed by %.0f%% during the run;"
                           % (st.drift * 100.0), icon='INFO')
            col.label(text="times are corrected against nearby baselines.")


class DPOPT_PT_thresholds(_CyclesOnly, Panel):
    bl_label = "Accept / Reject"
    bl_parent_id = "DPOPT_PT_advanced"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        st = context.scene.dpopt
        col = self.layout.column(align=True)
        col.prop(st, "detail_floor")
        col.prop(st, "diff_ceiling")
        col.prop(st, "min_gain")
        col.prop(st, "blotch_slack")
        col = self.layout.column(align=True)
        col.prop(st, "edge_percentile")
        col.prop(st, "flat_percentile")
        col.prop(st, "ref_noise_warn")


class DPOPT_PT_split(_CyclesOnly, Panel):
    bl_label = "Split Light Channels"
    bl_parent_id = "DPOPT_PT_main"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        scene = context.scene
        st = scene.dpopt
        layout = self.layout

        # Bang cha ve chu "Working…" roi `return`, nhung bang CON van duoc ve
        # tiep — Blender khong dung ve con vi cha da dung. Khong chan o day
        # thi giua lan do, khach van thay day du nut Build/Measure/Verify va
        # bam duoc chong len lan do dang chay.
        if st.running:
            layout.label(text="Working… %s" % st.progress, icon='TIME')
            return

        if comp.is_active(scene):
            box = layout.box()
            box.label(text="Texture is protected.", icon='CHECKMARK')
            box.label(text="The denoiser only ever sees smooth light;")
            box.label(text="material colour is multiplied back afterwards.")
            box.operator("dpopt.split_clear", icon='X')
            return

        col = layout.column(align=True)
        col.label(text="Stops the denoiser blurring wood grain, fabric")
        col.label(text="weave and fine grain: light is denoised on its own,")
        col.label(text="then the material colour is multiplied back in.")

        # MOT NUT, KHONG O CHINH. Cai gi suy ra duoc tu scene thi addon tu
        # suy — xem `comp.needed`. Bay cho khach ba o de chinh la bat ho tra
        # loi ba cau hoi ma chinh ho khong co cach nao tra loi.
        want = comp.needed(scene)
        chans = ["diffuse", "glossy"]
        if want.get('transmission'):
            chans.append("transmission")
        if want.get('volume'):
            chans.append("volume")
        col = layout.column()
        col.scale_y = 2.0
        col.operator("dpopt.split_build", icon='NODETREE')
        layout.label(text="This scene needs %d channels: %s."
                          % (len(chans), ", ".join(chans)), icon='INFO')


CLASSES = (DPOPT_PT_main, DPOPT_PT_results, DPOPT_PT_split,
           DPOPT_PT_advanced, DPOPT_PT_axes, DPOPT_PT_thresholds)
