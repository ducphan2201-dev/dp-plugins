# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
"""Do chenh lech giua anh thu va anh chuan.

BA CON SO, khong phai mot. Mot con so gop lai se giau mat dieu quan trong
nhat: nhanh hon ma bet mat van go thi khong phai la thang.

    diff    — lech tong the so voi anh chuan (cang nho cang giong)
    detail  — giu duoc bao nhieu phan chi tiet o VUNG CANH CUNG
              (1.00 = giu nguyen, 0.80 = mat mot phan nam)
    texture — giu duoc bao nhieu phan VAN VAT LIEU o dai giua: van go, soi
              vai, hat son. DAY LA CON SO MA KHACH QUAN TAM.
    blotch  — nhieu/vet con lai o VUNG PHANG (cang nho cang sach)

Vi sao phai tach vung: nhieu lam TANG do doc cua anh. Neu do do doc tren
toan anh thi mot anh day nhieu se "nhieu chi tiet" hon anh sach — nguoc
hoan toan. Nen ba thuoc tren deu do o dung mot dai do doc cua anh CHUAN.

VI SAO MUC TIEU LA `texture` CHU KHONG PHAI `detail` HAY `diff`: vi no TACH
DUOC cac ung vien, hai thuoc kia thi khong. Do 06/08/2026 tren canh kiem:

    thuoc     quality High/Balanced/Fast   passes Albedo / none
    detail        0.941  0.938  0.940        0.926  0.926   <- HOA NHAU
    texture       0.838  0.839  0.829        0.801  0.777   <- tach ro

Va tren hai ung vien gia lap (mot cai lam min nhe, mot cai lam min manh),
`detail` tach chung ra 9%, `diff` 11%, con `texture` 47%. Cai gi tach ro hon
thi it bi sai so phep do nuot mat hon.

Con so quan trong nhat trong bang tren: bo khu nhieu giu duoc 94% nang luong
o CANH CUNG nhung chi 84% o VAN NHO. Do dung la dieu khach phan nan, va thuoc
cu khong nhin thay.

KHONG noi rang `diff` thien vi anh mo — da thu do 06/08/2026 va KHONG thay
nhu vay. `diff` chi don gian la mot con so gop, khong noi duoc mat mat nam o
dau; no van dung de bao cao va de lam tran (`diff_ceiling`).

ANH DOC VAO LA EXR 32-bit -> `image.pixels` tra ve TUYEN TINH.
Doc anh 8-bit se ra sRGB va moi con so duoi day sai het.
"""
import numpy as np

import bpy

# Tone-map Reinhard truoc khi so sanh. Anh render la HDR: mot dom firefly
# 500.0 se nuot toan bo sai so cua phan con lai neu so sanh trang tren gia
# tri tho. Nen o day nen ve [0..1) theo dung cach mat nguoi nhin.
_LUMA = np.array([0.2126, 0.7152, 0.0722], dtype=np.float32)


def load(path):
    """Doc EXR -> (rgb float32 [h, w, 3] TUYEN TINH, w, h)."""
    img = bpy.data.images.load(path, check_existing=False)
    try:
        w, h = img.size
        buf = np.empty(w * h * 4, dtype=np.float32)
        img.pixels.foreach_get(buf)
    finally:
        bpy.data.images.remove(img)
    rgb = buf.reshape(h, w, 4)[:, :, :3]
    # Anh render co the co gia tri am rat nho do sai so dau cham dong.
    np.clip(rgb, 0.0, None, out=rgb)
    return rgb, w, h


def _tonemap(rgb):
    return rgb / (1.0 + rgb)


def _luma(rgb):
    return rgb @ _LUMA


def _grad(gray):
    """Do lon gradient, dung sai phan tien — du de bat canh va van vat lieu."""
    gy = np.zeros_like(gray)
    gx = np.zeros_like(gray)
    gy[:-1, :] = np.abs(gray[1:, :] - gray[:-1, :])
    gx[:, :-1] = np.abs(gray[:, 1:] - gray[:, :-1])
    return gx + gy


def _box3(gray):
    """Trung binh 3x3, khong can scipy.

    Chen bien bang cach LAP LAI pixel bien. KHONG dung `np.roll`: roll quan
    vong tu canh phai sang canh trai, nen moi pixel sat bien deu co phan du
    gia rat lon va bi tinh nham la nhieu.
    """
    h, w = gray.shape
    p = np.pad(gray, 1, mode='edge')
    s = np.zeros_like(gray)
    for dy in range(3):
        for dx in range(3):
            s += p[dy:dy + h, dx:dx + w]
    return s / 9.0


_LAPLACE = np.array([[1.0, -2.0, 1.0],
                     [-2.0, 4.0, -2.0],
                     [1.0, -2.0, 1.0]], dtype=np.float32)
_LAPLACE_NORM = 6.0        # sqrt(tong binh phuong he so) = sqrt(36)
_MAD_TO_SIGMA = 1.4826     # trung vi tri tuyet doi -> do lech chuan


def noise_floor(rgb, flat_pct=40.0):
    """Uoc luong nhieu con lai trong ANH CHUAN (Immerkaer, lay TRUNG VI).

    VI SAO PHAI DO: `detail` do bang do lon gradient o vung co chi tiet. Nhieu
    CUNG lam tang gradient. Neu anh chuan chua hoi tu thi phan gradient do
    nhieu sinh ra bi tinh nham la "chi tiet", va moi anh da khu nhieu se bi
    cham diem thap oan — bang ket qua noi rang khong bo thong so nao dat,
    trong khi thu sai that ra la anh chuan.

    KHONG DUOC do bang cach lay "vung phang roi xem con du bao nhieu": vung
    phang duoc chon theo gradient thap, ma trong anh NHIEU thi khong o dau
    gradient thap ca. Mat na rong -> tra ve 0 -> anh cang nhieu cang bao la
    cang sach. Da dinh dung loi nay ngay 05/08/2026.

    Nhan chap Laplace 3x3 gan nhu triet tieu tren vung muot va tren doc
    tuyen tinh, chi con lai tan so cao. Lay TRUNG VI thay vi trung binh de
    mot so it pixel o canh vat the khong keo ket qua len.

    `flat_pct` giu lai cho tuong thich, khong con dung den.
    """
    lin = _luma(_tonemap(rgb))
    h, w = lin.shape
    if h < 3 or w < 3:
        return 0.0
    p = np.pad(lin, 1, mode='edge')
    resp = np.zeros_like(lin)
    for dy in range(3):
        for dx in range(3):
            k = _LAPLACE[dy, dx]
            if k:
                resp += k * p[dy:dy + h, dx:dx + w]
    med = float(np.median(np.abs(resp)))
    return med * _MAD_TO_SIGMA / _LAPLACE_NORM


def _dilate3(g):
    """Lay gia tri lon nhat trong o 3x3.

    VUNG PHANG phai cach moi canh it nhat 1 pixel, dung bang tam voi cua bo
    loc 3x3. `_grad` chi lay sai phan TIEN, nen pixel nam ngay phia sau mot
    canh van co gradient bang 0 va bi ke nham vao vung phang — trong khi bo
    loc 3x3 tai do van hut gia tri tu ben kia canh. No ra mot phan du to
    tuong, va phan du do bi doc nham thanh "nhieu".
    """
    h, w = g.shape
    p = np.pad(g, 1, mode='edge')
    out = np.zeros_like(g)
    for dy in range(3):
        for dx in range(3):
            np.maximum(out, p[dy:dy + h, dx:dx + w], out=out)
    return out


def compare(ref_rgb, var_rgb, edge_pct=80.0, flat_pct=40.0):
    """So anh thu voi anh chuan. Tra ve dict ba con so + vai so phu."""
    if ref_rgb.shape != var_rgb.shape:
        return dict(ok=False, reason="kich thuoc khac nhau: %s vs %s"
                    % (ref_rgb.shape, var_rgb.shape))

    r = _tonemap(ref_rgb)
    v = _tonemap(var_rgb)

    diff = float(np.sqrt(np.mean((v - r) ** 2)))

    lr = _luma(r)
    lv = _luma(v)
    gr = _grad(lr)
    gv = _grad(lv)

    # Vung co chi tiet / vung phang, ca hai deu xac dinh tren ANH CHUAN.
    hi = np.percentile(gr, edge_pct)
    lo = np.percentile(gr, flat_pct)
    edge = gr >= hi
    # Vung phang phai cach canh 1 pixel — xem `_dilate3`. Neu khong, vet bet
    # cua bo khu nhieu ngay canh cua vat the se bi tinh vao `blotch` va lam
    # con so do vo nghia.
    flat = _dilate3(gr) <= lo

    # VAN VAT LIEU — DO BANG TAN SO, KHONG BANG DO DOC.
    #
    # Da thu chia dai theo phan tram do doc (van nam giua "phang" va "canh")
    # va do 06/08/2026: no cho ra gan y het `detail` — 0.940 so voi 0.941.
    # Ly do: trong mot khung noi that day texture thi nhom 20% pixel doc nhat
    # VON DA la van vat lieu roi, khong phai duong bao vat the. Chia theo
    # phan tram do doc khong tach duoc hai thu ra.
    #
    # Thu tach duoc chung la TAN SO. Van go, soi vai, hat son la dao dong
    # vai pixel; duong bao vat the va do doc anh sang la thanh phan tan so
    # thap. Bo khu nhieu an dung phan tan so cao. Nen:
    #
    #     hp = anh - chinh no da lam min 3x3        (giu lai phan tan so cao)
    #     texture = nang luong hp con lai / nang luong hp cua anh chuan
    #
    # do o dung nhung cho anh CHUAN von co chi tiet nho — cho von tron thi
    # khong co gi de mat, dua vao chi lam loang con so.
    hr = np.abs(lr - _box3(lr))
    hv = np.abs(lv - _box3(lv))
    fine = hr >= np.percentile(hr, edge_pct)

    if edge.sum() < 16 or flat.sum() < 16 or fine.sum() < 16:
        # Anh qua nho hoac phang tuyet doi (vd. khung hinh trong).
        return dict(ok=True, diff=diff, detail=1.0, texture=1.0, blotch=0.0,
                    edge_px=int(edge.sum()), flat_px=int(flat.sum()),
                    fine_px=int(fine.sum()), thin=True)

    ref_energy = float(gr[edge].mean())
    detail = float(gv[edge].mean() / ref_energy) if ref_energy > 1e-9 else 1.0

    fine_energy = float(hr[fine].mean())
    texture = (float(hv[fine].mean() / fine_energy)
               if fine_energy > 1e-9 else 1.0)

    blotch = float(np.sqrt(np.mean((lv[flat] - lr[flat]) ** 2)))

    return dict(ok=True, diff=diff, detail=detail, texture=texture,
                blotch=blotch, edge_px=int(edge.sum()), flat_px=int(flat.sum()),
                fine_px=int(fine.sum()), thin=False)


def passes(m, base_m, detail_floor, diff_ceiling):
    """Dat nguong chat luong chua? Nguong la NUT CUA NGUOI DUNG.

    SO VOI THIET LAP HIEN TAI, khong so voi anh chuan.

    Vi sao: BAT KY anh nao da qua khu nhieu cung mat mot it tan so cao so voi
    anh chuan da hoi tu — do that tren scene kiem, moi phuong an deu ra
    detail ~0.851. Lay nguong tuyet doi 0.90 thi loai sach, ke ca phuong an
    nhanh hon 28% ma mat mat khong dang ke. Cau hoi dung la "so voi thu toi
    dang co, cai nay co te hon khong", chu khong phai "so voi su that tuyet
    doi". Con so tuyet doi van hien tren bang de nguoi dung tu nhin.
    """
    if not m.get('ok'):
        return False
    base_detail = (base_m or {}).get('detail', 1.0)
    base_diff = (base_m or {}).get('diff', 0.0)
    rel = m['detail'] / base_detail if base_detail > 1e-6 else 1.0
    return rel >= detail_floor and (m['diff'] - base_diff) <= diff_ceiling
