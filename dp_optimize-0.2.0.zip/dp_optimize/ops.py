# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
"""Cac nut bam.

Docstring cua moi lop Operator LA TOOLTIP tren giao dien — nen chung phai la
tieng Anh, khong phai tieng Viet. Day la cho rat de quen.
"""
import json
import time

import bpy
from bpy.props import IntProperty, StringProperty

from . import bench, comp, metrics, props, settings


def _redraw():
    for win in bpy.context.window_manager.windows:
        for area in win.screen.areas:
            if area.type == 'PROPERTIES':
                area.tag_redraw()


def _store(st, runner):
    """Do ket qua tu Runner vao CollectionProperty de giao dien ve."""
    st.results.clear()
    winners = runner.winners()
    win_ids = {id(r) for r in winners.values()}
    base_row = runner.base()
    base_m = base_row['m'] if base_row else None
    for r in runner.results:
        row = st.results.add()
        row.kind = r['kind']
        row.label = r['label']
        row.group = r['group']
        row.key = r['key']
        row.option = r['option']
        row.secs = r['secs']
        row.ratio = runner.ratio(r)
        m = r['m']
        row.diff = float(m.get('diff', 0.0))
        row.detail = float(m.get('detail', 0.0))
        row.texture = float(m.get('texture', 0.0))
        row.blotch = float(m.get('blotch', 0.0))
        row.passed = metrics.passes(m, base_m, st.detail_floor, st.diff_ceiling)
        row.winner = id(r) in win_ids
        row.overrides = json.dumps(r['overrides'] or {})

    st.ref_noise = float(getattr(runner, 'ref_noise', 0.0))
    st.ref_secs = float(getattr(runner, 'ref_secs', 0.0))
    st.timing_noise = float(runner.timing_noise)
    st.drift = float(runner.drift)
    st.warmup_used = int(runner.warmup_count)
    st.warmup_ok = bool(runner.warm_stable())

    base = base_row
    combo = runner.combo()
    if base and combo:
        st.last_summary = ("Combined: %+.0f%% material texture kept, "
                           "%+.0f%% render time"
                           % (runner.texture_gain(combo) * 100.0,
                              (runner.ratio(combo) - 1.0) * 100.0))
        # CHOT CHAN CUOI. Neu gop het cac phuong an "thang" lai ma anh khong
        # con dep hon, hoac gop lai thi hoa ra cham di, thi chung khong thang
        # that. Phai noi thang ra, vi nguoi dung sap bam nut Apply.
        if winners and not runner.is_win(combo):
            st.last_summary += (" — these did not hold up when measured "
                                "together, so nothing here is worth applying")
    elif base:
        st.last_summary = ("Nothing kept more material texture without costing "
                           "render time or leaving more noise. Your settings "
                           "are already the best of what was measured.")
    else:
        st.last_summary = ""


def _auto_setup(scene, st):
    """Tu chon thong so do. Nguoi dung KHONG phai biet gi ve phep do.

    Moi con so o day deu suy ra tu chinh scene, khong phai gu cua ai. Ai
    muon can thiep thi mo bang Advanced — con mac dinh la mot nut bam.
    """
    # KHUNG DAY. Khong co duong tat nao ca — xem `bench.Runner._set_region`.
    # Do tren anh nho nhanh that, nhung xep hang sai, va ap ket qua sai vao
    # file cua khach thi render CHAM DI. Tha lau con hon sai.
    st.region_mode = 'FULL'

    cy = scene.cycles
    # Anh chuan phai sach hon han anh thuong, neu khong thi chinh no lam
    # moi ket qua bi cham diem oan. Nhung no cung la lan render dat nhat,
    # nen chan tren 384 chu khong 1024.
    st.ref_samples = int(max(192, min(384, max(1, cy.samples) * 2)))
    st.ref_threshold = max(0.0005, (cy.adaptive_threshold or 0.01) / 4.0)

    # MOI PHEP DO CHAY MOT LAN. Chong nhieu bang cach khac, re hon nhieu:
    # xen ke do lai diem xuat phat de chua troi toc do, roi bat buoc bo gop
    # cuoi cung phai do LAI 3 LAN moi duoc ap dung. Cai gi lot qua vong dau
    # do nhieu thi chet o vong xac nhan.
    st.repeats = 1
    st.combo_repeats = 2
    # Moi lan render bay gio la MOT KHUNG DAY DU, dat bang dung mot lan
    # render that cua khach. Bo di 4 lan de "lam nong may" la doi cua ho 4
    # lan render khong de lam gi.
    st.warmup_max = 1

    keys = _auto_axes(scene)
    for row in st.axes:
        row.enabled = row.available and row.key in keys


def _auto_axes(scene):
    """Truc nao dang do tren scene NAY.

    Nhom khu nhieu chi hien ra khi dang dung OpenImageDenoise. Ai de OptiX
    thi ba trong do khong ton tai, va mot che do mot nut khong con truc nao
    de do thi chi la mot nut bam cho vui — nen luc do do nhom phan bo mau.
    """
    if settings.is_oidn(scene):
        return props.AUTO_AXES_DENOISE
    return props.AUTO_AXES_SAMPLING


class DPOPT_OT_benchmark(bpy.types.Operator):
    """Measure this scene and keep whatever holds on to the most material texture.

    Everything is chosen for you. Nothing is changed unless it keeps more
    fine texture without costing render time or leaving more noise
    """
    bl_idname = "dpopt.benchmark"
    bl_label = "Optimize This Scene"
    bl_options = {'REGISTER', 'UNDO'}

    auto: bpy.props.BoolProperty(
        default=True,
        description="Pick the measurement settings automatically and apply the "
                    "result when it holds up")

    _timer = None
    _t0 = 0.0
    runner = None

    @classmethod
    def poll(cls, context):
        return (context.scene is not None
                and context.scene.render.engine == 'CYCLES'
                and context.scene.camera is not None)

    def _begin(self, context):
        scene = context.scene
        settings.refresh_devices()      # ngoai `draw` moi duoc lam viec nay
        st = props.ensure_axes(scene)
        if self.auto:
            _auto_setup(scene, st)
        st.results.clear()
        st.last_summary = ""
        self.runner = bench.Runner(scene, st)
        total = self.runner.build_jobs()
        self.runner.start()
        self._t0 = time.perf_counter()
        st.running = True
        st.progress = "0 / %d" % total
        return total

    def _tick(self, context):
        st = context.scene.dpopt
        alive = self.runner.step()
        done = min(self.runner.index, len(self.runner.jobs))
        total = len(self.runner.jobs)
        # Bao con bao lau nua. Mot thanh dem "12 / 31" khong noi len dieu gi;
        # nguoi dung can biet co nen di pha ca phe hay khong.
        left = ""
        if self._t0 and done > 0:
            per = (time.perf_counter() - self._t0) / done
            secs = per * max(0, total - done)
            left = ("  ~%d min left" % round(secs / 60.0) if secs >= 90
                    else "  ~%d s left" % round(secs))
        st.progress = "%d / %d%s" % (done, total, left)
        _redraw()
        return alive

    def _end(self, context, cancelled=False):
        st = context.scene.dpopt
        try:
            _store(st, self.runner)
        finally:
            self.runner.finish()
        st.running = False
        st.progress = ""

        if self.runner.error:
            self.report({'ERROR'}, self.runner.error)
        elif cancelled:
            self.report({'WARNING'}, "Cancelled — your settings are unchanged")
        elif self.auto:
            self._auto_apply(context, st)
        else:
            self.report({'INFO'}, st.last_summary or "Measurement finished")
        _redraw()

    def _auto_apply(self, context, st):
        """Tu ap dung — nhung CHI KHI ket qua tru duoc khi do chung.

        Neu gop cac phuong an thang lai ma anh khong con dep hon, hoac gop
        lai thi hoa ra cham di, thi chung khong thang that. Luc do KHONG
        duoc doi gi cua khach het.
        """
        combo = self.runner.combo()
        if combo and self.runner.is_win(combo):
            ov = combo['overrides'] or {}
            settings.apply(context.scene, ov)
            pct = self.runner.texture_gain(combo) * 100.0
            secs = (self.runner.ratio(combo) - 1.0) * 100.0
            st.last_summary = ("Keeps %.0f%% more material texture at %+.0f%% "
                               "render time. Changed %d settings. Press "
                               "Ctrl+Z to undo." % (pct, secs, len(ov)))
            self.report({'INFO'}, st.last_summary)
        else:
            st.last_summary = ("Nothing kept more material texture without "
                               "costing render time. Nothing changed.")
            self.report({'INFO'}, st.last_summary)

    # --- chay dong bo: dung cho --background va cho ban khong co cua so ---
    def execute(self, context):
        self._begin(context)
        try:
            while self._tick(context):
                pass
        finally:
            self._end(context)
        return {'CANCELLED'} if self.runner.error else {'FINISHED'}

    def invoke(self, context, event):
        if bpy.app.background:
            return self.execute(context)
        self._begin(context)
        wm = context.window_manager
        self._timer = wm.event_timer_add(0.05, window=context.window)
        wm.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type in {'ESC'}:
            self._cleanup(context)
            self._end(context, cancelled=True)
            return {'CANCELLED'}
        if event.type == 'TIMER':
            if not self._tick(context):
                self._cleanup(context)
                self._end(context)
                return {'FINISHED'}
        return {'PASS_THROUGH'}

    def _cleanup(self, context):
        if self._timer is not None:
            context.window_manager.event_timer_remove(self._timer)
            self._timer = None


class DPOPT_OT_apply(bpy.types.Operator):
    """Apply this measured setting to the scene"""
    bl_idname = "dpopt.apply"
    bl_label = "Apply"
    bl_options = {'REGISTER', 'UNDO'}

    index: IntProperty(default=-1)

    def execute(self, context):
        st = context.scene.dpopt
        if not (0 <= self.index < len(st.results)):
            self.report({'ERROR'}, "No such result")
            return {'CANCELLED'}
        row = st.results[self.index]
        try:
            ov = json.loads(row.overrides or "{}")
        except ValueError:
            self.report({'ERROR'}, "Result data is unreadable")
            return {'CANCELLED'}
        if not ov:
            self.report({'INFO'}, "Nothing to change — this is your current setting")
            return {'FINISHED'}
        settings.apply(context.scene, ov)
        self.report({'INFO'}, "Applied: %s" % settings.describe(context.scene, ov))
        return {'FINISHED'}


class DPOPT_OT_apply_combined(bpy.types.Operator):
    """Apply every winning setting from the last measurement at once"""
    bl_idname = "dpopt.apply_combined"
    bl_label = "Apply Combined Winners"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        st = context.scene.dpopt
        for row in st.results:
            if row.kind == 'COMBO':
                try:
                    ov = json.loads(row.overrides or "{}")
                except ValueError:
                    ov = {}
                if ov:
                    settings.apply(context.scene, ov)
                    self.report({'INFO'}, "Applied %d settings" % len(ov))
                    return {'FINISHED'}
        self.report({'WARNING'}, "No combined result to apply")
        return {'CANCELLED'}


class DPOPT_OT_axes_set(bpy.types.Operator):
    """Turn every measurable setting on or off"""
    bl_idname = "dpopt.axes_set"
    bl_label = "Set Axes"
    bl_options = {'REGISTER', 'UNDO'}

    mode: StringProperty(default='ALL')

    def execute(self, context):
        st = props.ensure_axes(context.scene)
        for row in st.axes:
            if self.mode == 'ALL':
                row.enabled = row.available
            elif self.mode == 'NONE':
                row.enabled = False
            else:
                row.enabled = row.available and row.key in props.DEFAULT_ON
        return {'FINISHED'}


def _instant_wins(scene):
    """Nhung thay doi nhanh hon MA KHONG CAN DO tren tung scene.

    Trong day chi duoc chua thu nao nhanh hon vi LY DO CAU TRUC, khong phai
    vi may man voi mot scene cu the. Do o khung day 1920x1080 ngay
    05/08/2026, kem cham chat luong so voi ban hoi tu:

        nguyen trang        9.05s          detail 0.776   diff 0.0015
        bat khu nhieu GPU   3.55s  -61%    detail 0.777   diff 0.0015

    Khu nhieu chay bang CPU trong khi may co GPU khong phai la mot lua chon
    ve chat luong — no chi la dung sai phan cung. Nen no la mot NUT BAM,
    khong phai mot vong do 17 lan render.

    Da THU va DA LOAI: `scrambling Auto` chi -2%, nam trong sai so. Cai gi
    khong chac thi khong duoc tu bat cho khach.
    """
    todo = []
    cy = scene.cycles
    # CHI KHI CYCLES DANG DUNG CARD. Nguoi dung de scene o CPU thi ho co ly
    # do — dang dung card cho viec khac, driver do chung, VRAM khong du. Bat
    # khu nhieu chay card luc do la tu y keo card vao mot cong viec ma ho da
    # chon khong dung no. Cycles chon sao thi tool chay vay.
    if (settings.is_oidn(scene) and settings.uses_gpu(scene)
            and settings.has_oidn_gpu(scene) and not cy.denoising_use_gpu):
        todo.append(('cycles.denoising_use_gpu', True,
                     "Denoising moved to the GPU, alongside the render"))
    if (scene.frame_end > scene.frame_start
            and not scene.render.use_persistent_data):
        todo.append(('render.use_persistent_data', True,
                     "Scene data kept between frames"))
    return todo


class DPOPT_OT_speedup(bpy.types.Operator):
    """Apply the speed-ups that do not depend on this scene.

    These are settled questions about using your hardware properly, not
    trade-offs, so nothing has to be rendered to find out
    """
    bl_idname = "dpopt.speedup"
    bl_label = "Speed Up This Scene"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        scene = context.scene
        return scene is not None and scene.render.engine == 'CYCLES'

    def execute(self, context):
        scene = context.scene
        settings.refresh_devices()
        todo = _instant_wins(scene)
        if not todo:
            self.report({'INFO'}, "Already set — nothing left to switch on")
            scene.dpopt.last_summary = ("Already set. Nothing here needed "
                                        "changing.")
            return {'FINISHED'}
        for path, value, _msg in todo:
            settings.put(scene, path, value)
        msg = "; ".join(m for _p, _v, m in todo)
        scene.dpopt.last_summary = msg + ". Press Ctrl+Z to undo."
        self.report({'INFO'}, msg)
        return {'FINISHED'}


class DPOPT_OT_use_cycles(bpy.types.Operator):
    """Switch this scene to the Cycles render engine"""
    bl_idname = "dpopt.use_cycles"
    bl_label = "Switch to Cycles"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.scene and context.scene.render.engine != 'CYCLES'

    def execute(self, context):
        context.scene.render.engine = 'CYCLES'
        self.report({'INFO'}, "Render engine set to Cycles")
        return {'FINISHED'}


class DPOPT_OT_denoise_gpu(bpy.types.Operator):
    """Turn on GPU denoising for OpenImageDenoise.

    Enabling OptiX in Preferences does not do this: it is a separate switch
    and it is off by default
    """
    bl_idname = "dpopt.denoise_gpu"
    bl_label = "Enable GPU Denoising"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        scene = context.scene
        return (scene and scene.render.engine == 'CYCLES'
                and settings.is_oidn(scene) and settings.has_oidn_gpu(scene)
                and not scene.cycles.denoising_use_gpu)

    def execute(self, context):
        context.scene.cycles.denoising_use_gpu = True
        self.report({'INFO'}, "GPU denoising enabled")
        return {'FINISHED'}


class DPOPT_OT_split_build(bpy.types.Operator):
    """Protect material texture from the denoiser.

    Diffuse, glossy and transmission light are denoised on their own, before
    their colour pass is multiplied back in — so wood grain, fabric weave and
    fine grain are never something the denoiser has to guess at. Set up for
    you: only the channels this scene actually uses are built
    """
    bl_idname = "dpopt.split_build"
    bl_label = "Protect Texture Detail"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.scene and context.scene.render.engine == 'CYCLES'

    def execute(self, context):
        scene = context.scene
        st = scene.dpopt
        want = comp.needed(scene)
        comp.build(scene, context.view_layer, use_denoise=True,
                   prefilter=st.split_prefilter, quality=st.split_quality,
                   denoise_volume=st.split_denoise_volume)

        # Denoise trong Cycles va denoise trong compositor cung luc la khu
        # nhieu HAI LAN — cham hon va bet hon. Tat cai trong Cycles di.
        was = scene.cycles.use_denoising
        scene.cycles.use_denoising = False
        scene.render.use_compositing = True

        # COMPOSITOR DI THEO CYCLES, khong tu chon.
        # Cycles dang render bang bo xu ly ma bat compositor chay tren card
        # la tu y dung mot thiet bi ma nguoi dung da chon KHONG dung. Con
        # dang render bang card thi compositor cung nen o do: anh vua render
        # xong da nam san trong bo nho card.
        moved = None
        want_dev = settings.compositor_device_for(scene)
        if ('compositor_device' in scene.render.bl_rna.properties
                and scene.render.compositor_device != want_dev):
            scene.render.compositor_device = want_dev
            moved = want_dev

        bits = ["Texture protected"]
        chans = ["diffuse", "glossy"]
        if want.get('transmission'):
            chans.append("transmission")
        if want.get('volume'):
            chans.append("volume")
        bits.append("%s denoised separately" % ", ".join(chans))
        if was:
            bits.append("scene denoising turned off")
        if moved:
            bits.append("compositor follows Cycles onto the %s"
                        % ("GPU" if moved == 'GPU' else "CPU"))
        msg = "; ".join(bits)
        st.last_summary = msg + ". Press Ctrl+Z to undo."
        self.report({'INFO'}, msg)
        return {'FINISHED'}


class DPOPT_OT_split_clear(bpy.types.Operator):
    """Remove the split denoise graph and turn scene denoising back on"""
    bl_idname = "dpopt.split_clear"
    bl_label = "Remove Split Denoise"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.scene and comp.is_active(context.scene)

    def execute(self, context):
        scene = context.scene
        comp.clear(scene)
        scene.cycles.use_denoising = True
        self.report({'INFO'}, "Split denoise removed")
        return {'FINISHED'}


class DPOPT_OT_split_verify(bpy.types.Operator):
    """Render twice with denoising off and check the split graph rebuilds the
    image exactly.

    A correct rebuild differs from the ordinary render only by floating point
    error. A large difference means a pass is missing, not that it is close
    enough
    """
    bl_idname = "dpopt.split_verify"
    bl_label = "Verify Split Denoise"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return (context.scene and context.scene.render.engine == 'CYCLES'
                and context.scene.camera is not None)

    def execute(self, context):
        scene = context.scene
        st = scene.dpopt
        out = comp.verify(scene, region_size=st.region_size,
                          samples=st.split_verify_samples,
                          view_layer=context.view_layer)
        if not out.get('ok'):
            self.report({'ERROR'}, "Verification failed: %s"
                        % out.get('reason', 'unknown'))
            return {'CANCELLED'}
        md = out['max_diff']
        # ALPHA DUOC BAO RIENG. Gop chung vao mot con so thi mot cai nen trong
        # suot bi dac lai chi keo trung binh len chut xiu roi lot qua — dung
        # cai bay da xay ra that ngay 06/08/2026.
        amd = out.get('alpha_max_diff', 0.0)
        msg = ("Rebuild matches: max difference %.7f, mean %.7f, alpha %.7f "
               "(%.1fs)" % (md, out['mean_diff'], amd, out['secs']))
        ok_rgb, ok_alpha = md < 1e-3, amd < 1e-3
        if ok_rgb and ok_alpha:
            self.report({'INFO'}, msg)
        elif ok_rgb:
            msg = ("Colour matches but ALPHA does not (%.5f). A transparent "
                   "background would come out solid. %s" % (amd, msg))
            self.report({'WARNING'}, msg)
        else:
            msg = "Rebuild does NOT match — %s" % msg
            self.report({'WARNING'}, msg)
        st.last_summary = msg
        return {'FINISHED'}


CLASSES = (DPOPT_OT_benchmark, DPOPT_OT_apply, DPOPT_OT_apply_combined,
           DPOPT_OT_axes_set, DPOPT_OT_speedup, DPOPT_OT_use_cycles,
           DPOPT_OT_denoise_gpu, DPOPT_OT_split_build, DPOPT_OT_split_clear,
           DPOPT_OT_split_verify)
