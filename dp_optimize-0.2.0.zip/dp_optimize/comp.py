# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
"""Tach anh thanh tung kenh anh sang, khu nhieu rieng tung kenh, roi ghep lai.

PHEP GHEP DUNG (da do 05/08/2026, lech 0.000000 so voi anh Combined):

    Combined = (DiffDir + DiffInd) * DiffColor
             + (GlossDir + GlossInd) * GlossColor
             + (TransDir + TransInd) * TransColor
             + Emission + Environment + VolumeDir + VolumeInd

Cac pass Direct/Indirect KHONG chua mau vat lieu — mau nam o pass Color.
Bo phep nhan voi pass Color di (kieu "cong 4 kenh roi Mix Add" hay thay tren
mang) thi anh mat sach texture: do that tren cung mot khung hinh, lech max
0.671. Xem `tools/probe_recombine.py`.

VI SAO TACH RA LAI GIU DUOC CHI TIET HON
    Denoise chay tren pass Direct/Indirect la chay tren ANH SANG THUAN, da bo
    van vat lieu ra ngoai. Anh sang thi muot, nen bo khu nhieu khong con phai
    doan xem mot vet dam la nhieu hay la van go. Van go quay lai o buoc nhan
    pass Color, va pass Color gan nhu khong co nhieu.

CAI GIA PHAI TRA
    Nhieu pass hon = nhieu bo nho hon va nhieu lan chay denoise hon. Co scene
    tach ra khong hon gi ca — do tren phong kiem 06/08/2026 no CHAM HON 2,5
    LAN. Nen o day khong chot ho ai: `verify()` kiem phep ghep co dung khong,
    con `verify()` la cho duy nhat kiem dieu do — bang phep so, khong bang
    mot vong do bat khach ngoi cho.

ALPHA. Cac pass anh sang deu co alpha = 1 o moi diem, ke ca noi khong co gi
ca. Cong/nhan chung lai thi ket qua cung alpha = 1 khap noi — NEN TRONG SUOT
BIEN MAT. Do that 06/08/2026 tren `film_transparent`:

    alpha anh Combined  min 0.000  trung binh 0.841
    alpha anh ghep lai  min 1.000  trung binh 1.000   <- nen da dac lai

RGB thi khop den 2e-6, nen `verify()` cu BAO DAT trong khi anh xuat ra da
hong — no doc anh qua `metrics.load`, ma ham do CAT MAT kenh alpha. Nay alpha
duoc lay tu pass Alpha va dat lai o cuoi bang mot node Set Alpha, con
`verify()` doc RGBA day du (`_load_rgba`) va bao RIENG hai con so.

CHU Y node Set Alpha: socket 'Type' mac dinh la 'Apply Mask', kieu do NHAN
RGB voi alpha (vien anh toi di). Phai dat 'Replace Alpha'.

BLENDER 5.2: `scene.node_tree` KHONG CON. Cay compositor la mot node group
gan vao `scene.compositing_node_group`, ket qua di ra qua NodeGroupOutput
theo socket khai bao trong `tree.interface`. `CompositorNodeMath`,
`CompositorNodeMix`, `CompositorNodeComposite` deu da bi xoa — dung
`ShaderNodeMix` (chay duoc trong cay compositor).
"""
import json
import os
import time

import bpy
import numpy as np

from . import metrics, settings

GROUP_NAME = "DP_SplitDenoise"

# Cho cat trang thai pass TRUOC KHI addon bat chung len, de `clear()` tra lai.
# Khoa nam tren Scene chu khong nam trong bien Python: nguoi dung dung cay
# nay, luu file, tat Blender, hom sau mo lai bam Remove — bien Python da mat
# tu doi nao, con thuoc tinh tren Scene thi di theo file .blend.
SAVED_KEY = "dpopt_split_saved_passes"

# Pass phai bat tren view layer. Thieu mot cai la ghep ra sai anh.
#
# LUON CAN — moi scene deu co anh sang khuech tan va phan xa.
CORE_PASSES = (
    'use_pass_diffuse_direct', 'use_pass_diffuse_indirect', 'use_pass_diffuse_color',
    'use_pass_glossy_direct', 'use_pass_glossy_indirect', 'use_pass_glossy_color',
    'use_pass_emit', 'use_pass_environment', 'use_pass_normal',
)
# CHI KHI SCENE CO KINH / NUOC / LA CAY. Bat thua thi ton bo nho va them mot
# lan chay khu nhieu tren mot buc anh DEN THUI.
TRANSMISSION_PASSES = (
    'use_pass_transmission_direct', 'use_pass_transmission_indirect',
    'use_pass_transmission_color',
)
# CHI KHI SCENE CO KHOI / SUONG.
CYCLES_LAYER_PASSES = ('use_pass_volume_direct', 'use_pass_volume_indirect')

# Moi pass ma addon nay co the dong vao — de chup lai va tra lai cho du.
VIEW_LAYER_PASSES = CORE_PASSES + TRANSMISSION_PASSES


def snapshot_passes(view_layer):
    """Trang thai hien tai cua moi pass ma addon nay se dong vao."""
    out = {}
    for p in VIEW_LAYER_PASSES:
        if p in view_layer.bl_rna.properties:
            out[p] = bool(getattr(view_layer, p))
    for p in CYCLES_LAYER_PASSES + ('denoising_store_passes',):
        if p in view_layer.cycles.bl_rna.properties:
            out['cycles.' + p] = bool(getattr(view_layer.cycles, p))
    return out


def restore_passes(view_layer, saved):
    """Tra lai dung nhung pass da chup. Bo qua cai nao khong con ton tai."""
    for key, value in (saved or {}).items():
        try:
            if key.startswith('cycles.'):
                name = key.split('.', 1)[1]
                if name in view_layer.cycles.bl_rna.properties:
                    setattr(view_layer.cycles, name, value)
            elif key in view_layer.bl_rna.properties:
                setattr(view_layer, key, value)
        except Exception:                                  # noqa: BLE001
            pass


def needed(scene):
    """Scene nay CAN nhung nhanh nao. Day la cho quyet dinh toc do.

    Truoc 06/08/2026 cay luon dung du 5 node Denoise — ke ca tren mot phong
    khong co lay mot manh kinh nao va khong co ti khoi nao. Ba trong nam node
    do chay khu nhieu tren nhung buc anh DEN THUI, va khach tra tien bang
    thoi gian render cho ca ba.

    Khong doan bang cach render thu roi nhin: doc thang cay vat lieu va danh
    sach object ra la biet. Xem `settings.has_transmission` / `has_volume`.
    """
    return dict(transmission=settings.has_transmission(scene),
                volume=settings.has_volume(scene))


def enable_passes(view_layer, scene=None, want=None):
    """Bat dung nhung pass can. TRA VE trang thai truoc do de con tra lai.

    LUAT 2 CUA ADDON: khong de lai dau vet trong file cua khach. Do that
    06/08/2026 truoc khi sua: mot lan bam Verify bat len 13 pass tren view
    layer cua khach va KHONG BAO GIO tat lai. Khach khong nhin vao bang
    Passes thi khong ai biet, chi thay tu do moi lan render deu ton them bo
    nho va thoi gian — mot cong cu toi uu render lam render nang them.

    KHONG bat `denoising_store_passes`. No sinh ra ca 'Denoising Albedo' lan
    'Denoising Normal', ma cay nay khong dung den albedo do: no dan thang
    pass Color cua tung kenh vao lam huong dan, sat hon nhieu. Chi con can
    phap tuyen, va `use_pass_normal` re hon.
    """
    scene = scene or bpy.context.scene
    want = want if want is not None else needed(scene)

    saved = snapshot_passes(view_layer)
    on = list(CORE_PASSES)
    if want.get('transmission'):
        on += list(TRANSMISSION_PASSES)
    # CHI BAT THEM, KHONG TAT CUA AI. Mot pass dang bat co the la khach tu
    # bat cho viec cua ho; tat no di la lang le lam hong mot thu khac trong
    # file. Cai loi toc do o day den tu viec KHONG bat thua, chu khong phai
    # tu viec tat bot cua nguoi khac.
    for p in on:
        if p in view_layer.bl_rna.properties:
            setattr(view_layer, p, True)
    if want.get('volume'):
        for p in CYCLES_LAYER_PASSES:
            if p in view_layer.cycles.bl_rna.properties:
                setattr(view_layer.cycles, p, True)
    return saved


class _Builder:
    def __init__(self, tree):
        self.tree = tree
        self.x = 0

    def mix(self, blend, a, b):
        n = self.tree.nodes.new('ShaderNodeMix')
        n.data_type = 'RGBA'
        n.blend_type = blend
        n.location = (self.x, 0)
        self.x += 180
        n.inputs['Factor'].default_value = 1.0
        ia = [s for s in n.inputs if s.name == 'A' and s.enabled][0]
        ib = [s for s in n.inputs if s.name == 'B' and s.enabled][0]
        self.tree.links.new(a, ia)
        self.tree.links.new(b, ib)
        return [s for s in n.outputs if s.enabled][0]

    def add(self, a, b):
        return self.mix('ADD', a, b)

    def mul(self, a, b):
        return self.mix('MULTIPLY', a, b)


def build(scene, view_layer=None, use_denoise=True, prefilter='Accurate',
          quality='Follow Scene', denoise_volume=True):
    """Dung cay compositor tach kenh. Tra ve node group vua tao."""
    view_layer = view_layer or bpy.context.view_layer
    want = needed(scene)

    old = scene.compositing_node_group
    was_ours = old is not None and old.name.startswith(GROUP_NAME)

    saved = enable_passes(view_layer, scene, want)
    # CHI GHI LAN DAU. Dung lai cay (doi Prefilter roi bam Build lai) ma ghi
    # de thi thu duoc cat lai la trang thai DA BAT SAN cua chinh addon —
    # luc bam Remove se tra ve dung nhung pass thua ma no vua bat.
    if SAVED_KEY not in scene.keys() or not was_ours:
        scene[SAVED_KEY] = json.dumps({'layer': view_layer.name, 'passes': saved})

    if was_ours:
        scene.compositing_node_group = None
        try:
            bpy.data.node_groups.remove(old)
        except Exception:
            pass

    tree = bpy.data.node_groups.new(GROUP_NAME, "CompositorNodeTree")
    scene.compositing_node_group = tree
    tree.interface.new_socket(name="Image", in_out='OUTPUT',
                              socket_type="NodeSocketColor")

    rl = tree.nodes.new('CompositorNodeRLayers')
    rl.scene = scene
    rl.layer = view_layer.name
    rl.location = (-900, 0)
    out = rl.outputs

    b = _Builder(tree)

    albedo = out['Denoising Albedo'] if 'Denoising Albedo' in out else None
    normal = out['Denoising Normal'] if 'Denoising Normal' in out else (
        out['Normal'] if 'Normal' in out else None)

    def denoise(sock, guide_albedo=None, label=""):
        if not use_denoise:
            return sock
        n = tree.nodes.new('CompositorNodeDenoise')
        n.location = (b.x, 220)
        n.label = label
        b.x += 180
        tree.links.new(sock, n.inputs['Image'])
        g = guide_albedo if guide_albedo is not None else albedo
        if g is not None:
            tree.links.new(g, n.inputs['Albedo'])
        if normal is not None:
            tree.links.new(normal, n.inputs['Normal'])
        # 5.2: Prefilter/Quality la NodeSocketMenu, nhan CHUOI HIEN THI.
        for name, value in (('Prefilter', prefilter), ('Quality', quality)):
            if name in n.inputs:
                try:
                    n.inputs[name].default_value = value
                except TypeError:
                    pass
        return n.outputs['Image']

    total = None

    def acc(sock):
        nonlocal total
        total = sock if total is None else b.add(total, sock)

    # (Direct + Indirect) khu nhieu tren ANH SANG, roi moi nhan pass mau.
    #
    # DAY LA CHO VAN VAT LIEU DUOC CUU. Bo khu nhieu chi nhin thay anh sang
    # — da bo van go, soi vai ra ngoai — nen no khong con phai doan xem mot
    # vet dam la nhieu hay la van. Van quay lai NGUYEN VEN o buoc nhan pass
    # Color, va pass Color thi gan nhu khong co nhieu.
    #
    # Nhanh Transmission chi dung khi scene co kinh/nuoc/la cay. Dung thua no
    # la bat bo khu nhieu chay tren mot buc anh den thui, tra bang thoi gian
    # render cua khach.
    groups = [('Diffuse Direct', 'Diffuse Indirect', 'Diffuse Color', "Diffuse"),
              ('Glossy Direct', 'Glossy Indirect', 'Glossy Color', "Glossy")]
    if want.get('transmission'):
        groups.append(('Transmission Direct', 'Transmission Indirect',
                       'Transmission Color', "Transmission"))

    for direct, indirect, color, tag in groups:
        if direct not in out or indirect not in out or color not in out:
            continue
        light = b.add(out[direct], out[indirect])
        light = denoise(light, guide_albedo=out[color], label=tag)
        acc(b.mul(light, out[color]))

    # Emission va Environment KHONG qua khu nhieu: chung khong phai anh sang
    # dung tia ma ra, chung la gia tri doc thang. Cong vao la xong.
    for name in ('Emission', 'Environment'):
        if name in out:
            acc(out[name])

    if want.get('volume'):
        for name in ('Volume Direct', 'Volume Indirect'):
            if name in out:
                sock = out[name]
                if denoise_volume:
                    sock = denoise(sock, label=name)
                acc(sock)

    # ALPHA. Moi pass anh sang co alpha = 1 o khap noi, ke ca cho trong. Cong
    # va nhan chung lai thi ket qua cung alpha = 1 khap noi, va nen trong suot
    # bien mat — do that 06/08/2026, xem chu thich dau file. Nen phai lay
    # alpha THAT tu pass Alpha va dat de len o buoc cuoi.
    if total is not None and 'Alpha' in out:
        sa = tree.nodes.new('CompositorNodeSetAlpha')
        sa.location = (b.x + 40, 0)
        b.x += 180
        tree.links.new(total, sa.inputs['Image'])
        tree.links.new(out['Alpha'], sa.inputs['Alpha'])
        # 'Type' la NodeSocketMenu nhan chuoi hien thi. Phai la thay the han
        # alpha, khong phai nhan them mot lop mask nua.
        if 'Type' in sa.inputs:
            try:
                sa.inputs['Type'].default_value = 'Replace Alpha'
            except TypeError:
                pass
        total = sa.outputs['Image']

    go = tree.nodes.new('NodeGroupOutput')
    go.location = (b.x + 200, 0)
    if total is not None:
        tree.links.new(total, go.inputs[0])
    return tree


def clear(scene):
    """Go cay cua addon ra VA tra lai cac pass no da bat.

    KHONG dung vao cay do khach tu dung. Va go cay khong thoi la chua xong:
    13 pass van con bat tren view layer, moi lan render sau do deu ton them
    bo nho ma khach khong hieu tai sao.
    """
    tree = scene.compositing_node_group
    if tree is None:
        return False
    if not tree.name.startswith(GROUP_NAME):
        return False
    scene.compositing_node_group = None
    try:
        bpy.data.node_groups.remove(tree)
    except Exception:
        pass
    restore_saved_passes(scene)
    return True


def restore_saved_passes(scene):
    """Tra lai cac pass da cat o `SAVED_KEY`, roi xoa cho cat di.

    Khong tim thay cho cat thi khong doi gi ca — tha de thua vai pass con hon
    tat nham mot pass ma khach dang can cho cay compositor cua rieng ho.
    """
    raw = scene.get(SAVED_KEY)
    if not raw:
        return False
    try:
        data = json.loads(raw)
    except (ValueError, TypeError):
        del scene[SAVED_KEY]
        return False
    name = data.get('layer')
    vl = scene.view_layers.get(name) if name else None
    if vl is None:
        vl = bpy.context.view_layer
    restore_passes(vl, data.get('passes') or {})
    try:
        del scene[SAVED_KEY]
    except (KeyError, TypeError):
        pass
    return True


def is_active(scene):
    tree = scene.compositing_node_group
    return tree is not None and tree.name.startswith(GROUP_NAME)


# --------------------------------------------------------------------------
# Kiem chung: ghep lai co dung bang anh Combined khong?
# --------------------------------------------------------------------------

def _load_rgba(path):
    """Doc EXR ra RGBA DAY DU.

    `metrics.load` cat mat alpha, va chinh cho cat do da giau mot loi that:
    ngay 06/08/2026 `verify()` bao dat trong khi anh ghep lai da mat sach nen
    trong suot. Muon bat lai loi ay thi phai doc ca kenh thu tu.
    """
    img = bpy.data.images.load(path, check_existing=False)
    try:
        w, h = img.size
        buf = np.empty(w * h * 4, dtype=np.float32)
        img.pixels.foreach_get(buf)
    finally:
        bpy.data.images.remove(img)
    return buf.reshape(h, w, 4)


def verify(scene, region_size=40.0, samples=32, view_layer=None):
    """Render hai lan roi doi chieu. TAT denoise de doi chieu TOAN HOC.

    Tra ve dict: max_diff, mean_diff, alpha_max_diff, alpha_mean_diff, secs.
    `max_diff` phai o muc sai so dau cham dong (~1e-6). Lech lon nghia la
    thieu mot pass, khong phai "gan dung".

    KHONG DE LAI DAU VET. Ke ca cac pass tren view layer — cai nay tung bi bo
    sot va bat len 13 pass vinh vien tren file cua khach.
    """
    r = scene.render
    cy = scene.cycles
    ims = r.image_settings
    vl = view_layer or bpy.context.view_layer
    saved_passes = snapshot_passes(vl)
    had_key = SAVED_KEY in scene.keys()
    saved_key = scene.get(SAVED_KEY) if had_key else None
    saved = dict(
        use_border=r.use_border, bx0=r.border_min_x, bx1=r.border_max_x,
        by0=r.border_min_y, by1=r.border_max_y, crop=r.use_crop_to_border,
        comp=r.use_compositing, path=r.filepath, ff=ims.file_format,
        cd=ims.color_depth, cm=ims.color_mode, den=cy.use_denoising,
        smp=cy.samples, adapt=cy.use_adaptive_sampling, seed=cy.seed,
        aseed=cy.use_animated_seed, group=scene.compositing_node_group)
    out = {}
    made = None
    try:
        # THAO cay dang gan ra TRUOC, dung de `build()` gap no. `build()` xoa
        # han cay cu neu do la cay cua addon — nghia la bam Verify trong luc
        # Split dang bat se XOA cay cua khach, roi `finally` gan lai mot con
        # tro da chet. Thao ra truoc thi `build()` khong thay gi de xoa.
        scene.compositing_node_group = None

        half = max(0.02, min(0.5, region_size / 200.0))
        r.use_border = True
        r.use_crop_to_border = True
        r.border_min_x, r.border_max_x = 0.5 - half, 0.5 + half
        r.border_min_y, r.border_max_y = 0.5 - half, 0.5 + half
        ims.file_format, ims.color_depth, ims.color_mode = 'OPEN_EXR', '32', 'RGBA'
        cy.use_denoising = False
        cy.use_adaptive_sampling = False
        cy.samples = samples
        cy.use_animated_seed = False
        cy.seed = 7

        t0 = time.perf_counter()

        # a) anh Combined, khong qua compositor
        r.use_compositing = False
        beauty = _render(scene, "verify_beauty")

        # b) anh ghep lai tu cac pass, denoise TAT
        made = build(scene, vl, use_denoise=False)
        r.use_compositing = True
        recomb = _render(scene, "verify_recomb")

        a = _load_rgba(beauty)
        c = _load_rgba(recomb)
        for p in (beauty, recomb):
            try:
                os.unlink(p)
            except OSError:
                pass

        if a.shape != c.shape:
            out = dict(ok=False, reason="kich thuoc khac nhau")
        else:
            # RGB va ALPHA do RIENG. Gop lai thi mot cai nen trong suot bi
            # dac lai chi keo trung binh chung len mot chut va lot qua het.
            d = np.abs(a[:, :, :3] - c[:, :, :3])
            da = np.abs(a[:, :, 3] - c[:, :, 3])
            out = dict(ok=True, max_diff=float(d.max()),
                       mean_diff=float(d.mean()),
                       alpha_max_diff=float(da.max()),
                       alpha_mean_diff=float(da.mean()),
                       transparent=bool(r.film_transparent),
                       secs=time.perf_counter() - t0)
    finally:
        if made is not None:
            scene.compositing_node_group = None
            try:
                bpy.data.node_groups.remove(made)
            except Exception:
                pass
        r.use_border = saved['use_border']
        r.border_min_x, r.border_max_x = saved['bx0'], saved['bx1']
        r.border_min_y, r.border_max_y = saved['by0'], saved['by1']
        r.use_crop_to_border = saved['crop']
        r.use_compositing = saved['comp']
        r.filepath = saved['path']
        ims.file_format, ims.color_depth, ims.color_mode = (
            saved['ff'], saved['cd'], saved['cm'])
        cy.use_denoising = saved['den']
        cy.samples = saved['smp']
        cy.use_adaptive_sampling = saved['adapt']
        cy.seed = saved['seed']
        cy.use_animated_seed = saved['aseed']
        scene.compositing_node_group = saved['group']
        # `build()` o tren da bat 13 pass va ghi cho cat cua no. Tra lai het,
        # roi tra lai luon cai cho cat — neu khach dang co cay Split cua addon
        # song san thi cho cat do la CUA HO, khong duoc de phep kiem nay lam
        # mat: mat no la lan bam Remove sau nay khong biet duong ma tra lai.
        restore_passes(vl, saved_passes)
        if had_key:
            scene[SAVED_KEY] = saved_key
        elif SAVED_KEY in scene.keys():
            del scene[SAVED_KEY]
    return out


def _render(scene, name):
    path = os.path.join(bpy.app.tempdir, "dpopt_%s" % name)
    scene.render.filepath = path
    bpy.ops.render.render(write_still=True)
    return path if os.path.isfile(path) else path + '.exr'
