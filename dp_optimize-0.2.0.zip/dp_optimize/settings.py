# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
"""Danh sach TRUC DO va co che chup/tra lai thiet lap.

Moi trong day deu lay tu ban Blender 5.2 DANG CAI (do 05/08/2026, xem
`tools/probe_knobs.py`), khong lay tu bai viet tren mang. Mo ta cua tung
trong la mo ta GOC cua Blender, khong phai loi dien giai cua ai.

LUAT: khong co gia tri nao trong day la "gia tri dung". Chung chi la cac
diem de DO. Ai thang la do phep do quyet dinh, tren scene cua khach.
"""
import bpy

# --------------------------------------------------------------------------
# Doc/ghi theo duong dan chuoi, vi mot trong co the nam o nhieu noi khac nhau
# --------------------------------------------------------------------------


def _owner(scene, path):
    head, _, tail = path.partition('.')
    if head == 'cycles':
        return scene.cycles, tail
    if head == 'render':
        return scene.render, tail
    if head == 'curves':
        return scene.cycles_curves, tail
    if head == 'prefs':
        return bpy.context.preferences.addons['cycles'].preferences, tail
    raise KeyError("duong dan la: %s" % path)


def get(scene, path):
    owner, attr = _owner(scene, path)
    return getattr(owner, attr)


def put(scene, path, value):
    owner, attr = _owner(scene, path)
    setattr(owner, attr, value)


def exists(scene, path):
    try:
        owner, attr = _owner(scene, path)
    except KeyError:
        return False
    return attr in owner.bl_rna.properties


class Snapshot:
    """Chup lai gia tri cu roi tra lai nguyen ven.

    LUAT 2 CUA ADDON: phep do khong duoc de lai dau vet trong file cua khach.
    Dung kieu `with Snapshot(scene, paths):` de du thoat bang loi hay bang
    Esc thi van tra lai.
    """

    def __init__(self, scene, paths):
        self.scene = scene
        self.saved = {}
        for p in paths:
            if exists(scene, p):
                try:
                    self.saved[p] = get(scene, p)
                except Exception:
                    pass

    def restore(self):
        for p, v in self.saved.items():
            try:
                put(self.scene, p, v)
            except Exception:
                pass

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.restore()
        return False


# --------------------------------------------------------------------------
# Dieu kien co the do duoc
# --------------------------------------------------------------------------

def is_gpu(scene):
    prefs = bpy.context.preferences.addons['cycles'].preferences
    return scene.cycles.device == 'GPU' and prefs.compute_device_type != 'NONE'


def is_cpu(scene):
    return not is_gpu(scene)


def refresh_devices():
    """Nap lai danh sach thiet bi. GOI NGOAI `draw`, khong goi trong luc ve."""
    try:
        bpy.context.preferences.addons['cycles'].preferences.get_devices()
    except Exception:
        pass


# --------------------------------------------------------------------------
# CYCLES CHON SAO THI TOOL CHAY VAY
#
# Addon nay KHONG dat lai thiet bi tinh toan. Nguoi dung da chon CPU, GPU hay
# ca hai trong Cycles roi — do la lua chon cua ho, thuong vi mot ly do ma
# addon khong biet (dang dung card cho viec khac, driver do chung, VRAM
# khong du cho canh nay). Mot cong cu toi uu ma tu doi thiet bi render la
# lam hong dung cai ho vua can.
#
# Nen cac ham duoi day chi DOC ra Cycles dang chay bang gi, roi phan con lai
# cua addon di theo — nhat la `render.compositor_device`, xem `ops`.
# --------------------------------------------------------------------------

def uses_cpu(scene):
    """Cycles co dung bo xu ly cho scene nay khong."""
    if scene.cycles.device == 'CPU':
        return True
    prefs = bpy.context.preferences.addons['cycles'].preferences
    if getattr(prefs, 'compute_device_type', 'NONE') == 'NONE':
        return True                      # khong co backend nao: rot ve CPU
    try:
        # Che do 'GPU' van keo them bo xu ly vao neu no duoc tick trong
        # Preferences — do chinh la lua chon "ca hai".
        return any(d.use and d.type == 'CPU' for d in prefs.devices)
    except Exception:                                      # noqa: BLE001
        return False


def uses_gpu(scene):
    """Cycles co dung card do hoa cho scene nay khong."""
    return is_gpu(scene)


def device_label(scene):
    """Cau chu cho giao dien: dang chay bang gi. CHI DOC."""
    gpu, cpu = uses_gpu(scene), uses_cpu(scene)
    if gpu and cpu:
        return "the graphics card and the processor"
    if gpu:
        return "the graphics card"
    return "the processor"


def compositor_device_for(scene):
    """Compositor nen chay o dau, DE DI THEO Cycles.

    Cycles dang render bang bo xu ly ma bat compositor chay tren card la tu
    y dung mot thiet bi ma nguoi dung da chon KHONG dung. Con dang render
    bang card thi compositor cung nen o do — anh da nam san trong bo nho
    card, khong phai chuyen di chuyen ve.
    """
    return 'GPU' if uses_gpu(scene) else 'CPU'


def has_oidn_gpu(scene):
    """OIDN chi chay GPU duoc khi co thiet bi GPU dang bat.

    Blender dung dung phep thu nay trong `cycles/ui.py` (`has_oidn_gpu_devices`)
    de lam mo dong 'Use GPU'.

    CHI DOC. `get_devices()` nam o `refresh_devices()` va duoc goi tu operator
    hoac handler — goi no trong `draw` la ghi du lieu trong luc ve.
    """
    prefs = bpy.context.preferences.addons['cycles'].preferences
    if prefs.compute_device_type == 'NONE':
        return False
    return any(d.use and d.type not in ('CPU',) for d in prefs.devices)


def is_oidn(scene):
    return scene.cycles.denoiser == 'OPENIMAGEDENOISE' and scene.cycles.use_denoising


def has_volume(scene):
    for ob in scene.objects:
        if ob.type == 'VOLUME':
            return True
        for md in getattr(ob, 'modifiers', ()):
            if md.type in ('FLUID', 'SMOKE'):
                return True
    # Suong mu ca phong nam o World, khong nam o object nao ca.
    world = scene.world
    tree = getattr(world, 'node_tree', None) if world else None
    if tree is not None:
        for node in tree.nodes:
            if node.bl_idname in ('ShaderNodeVolumeScatter',
                                  'ShaderNodeVolumeAbsorption',
                                  'ShaderNodeVolumePrincipled'):
                return True
    return False


# Node cho ra anh sang di XUYEN QUA vat the — tuc la co pass Transmission.
_TRANSMISSIVE = frozenset((
    'ShaderNodeBsdfGlass', 'ShaderNodeBsdfRefraction',
    'ShaderNodeBsdfTranslucent', 'ShaderNodeBsdfTransparent',
    'ShaderNodeSubsurfaceScattering', 'ShaderNodeBsdfHair',
    'ShaderNodeBsdfHairPrincipled', 'ShaderNodeVolumePrincipled',
))


def scene_materials(scene):
    """Moi vat lieu ma scene nay thuc su dung."""
    out = []
    seen = set()
    for ob in scene.objects:
        for slot in getattr(ob, 'material_slots', ()):
            mat = slot.material
            if mat is not None and mat.name not in seen:
                seen.add(mat.name)
                out.append(mat)
    return out


def has_transmission(scene):
    """Scene nay co gi cho anh sang xuyen qua khong: kinh, nuoc, ruou, la cay.

    DOAN THUA THI CHI TON THEM CHUT THOI GIAN, DOAN THIEU THI SAI ANH. Nen
    o day nghieng han ve phia "co": khong doc duoc cay node cua mot vat lieu
    thi coi nhu no co truyen sang. Bo mot nhanh dang le phai co la thieu han
    mot phan anh sang trong anh ghep lai — `comp.verify()` se bat duoc, nhung
    khong nen de no phai bat.
    """
    for mat in scene_materials(scene):
        tree = getattr(mat, 'node_tree', None)
        if tree is None:
            continue                    # vat lieu khong dung node: khong xuyen
        try:
            for node in tree.nodes:
                if node.bl_idname in _TRANSMISSIVE:
                    return True
                if node.bl_idname == 'ShaderNodeGroup':
                    return True         # khong soi vao trong: cu coi la co
                if node.bl_idname == 'ShaderNodeBsdfPrincipled':
                    for name in ('Transmission Weight', 'Transmission'):
                        sock = node.inputs.get(name)
                        if sock is None:
                            continue
                        if sock.is_linked:
                            return True
                        if float(getattr(sock, 'default_value', 0.0)) > 0.0:
                            return True
        except Exception:               # noqa: BLE001
            return True                 # doc khong duoc thi coi nhu co
    return False


def has_curves(scene):
    return any(ob.type in ('CURVES', 'HAIR') for ob in scene.objects)


def _always(scene):
    return True


# --------------------------------------------------------------------------
# CAC TRUC DO
#
# key      : dinh danh, dung luu ket qua
# label    : chu tren giao dien (TIENG ANH — addon nay ban ra)
# group    : gom nhom tren bang
# options  : [(ten, {duong dan: gia tri})] — phuong an DAU TIEN khong duoc
#            ap dat gi ma la "giu nguyen thiet lap hien tai" neu de {}
# avail    : ham noi truc nay co do duoc tren scene nay khong
# note     : cau giai thich ngan, hien trong tooltip
# --------------------------------------------------------------------------

AXES = (
    # ---- denoise -------------------------------------------------------
    dict(key='denoise_gpu', label="Denoise on GPU", group='Denoise',
         avail=lambda s: is_oidn(s) and has_oidn_gpu(s),
         note="OpenImageDenoise runs on the GPU. This is a separate switch: "
              "enabling OptiX in Preferences does NOT turn it on.",
         options=[("Off", {'cycles.denoising_use_gpu': False}),
                  ("On", {'cycles.denoising_use_gpu': True})]),

    dict(key='denoise_quality', label="Denoise Quality", group='Denoise',
         avail=is_oidn, note="Overall OpenImageDenoise quality.",
         options=[("High", {'cycles.denoising_quality': 'HIGH'}),
                  ("Balanced", {'cycles.denoising_quality': 'BALANCED'}),
                  ("Fast", {'cycles.denoising_quality': 'FAST'})]),

    dict(key='denoise_prefilter', label="Denoise Prefilter", group='Denoise',
         avail=is_oidn,
         note="Prefilters the guiding (albedo/normal) passes — NOT the beauty "
              "image. Turning it off does not make the render sharper by itself.",
         options=[("Accurate", {'cycles.denoising_prefilter': 'ACCURATE'}),
                  ("Fast", {'cycles.denoising_prefilter': 'FAST'}),
                  ("None", {'cycles.denoising_prefilter': 'NONE'})]),

    dict(key='denoise_passes', label="Denoise Input Passes", group='Denoise',
         avail=is_oidn,
         note="Guiding passes that let the denoiser tell noise from wood grain "
              "or fabric weave.",
         options=[("Albedo + Normal",
                   {'cycles.denoising_input_passes': 'RGB_ALBEDO_NORMAL'}),
                  ("Albedo", {'cycles.denoising_input_passes': 'RGB_ALBEDO'}),
                  ("None", {'cycles.denoising_input_passes': 'RGB'})]),

    dict(key='denoiser', label="Denoiser", group='Denoise',
         avail=lambda s: s.cycles.use_denoising,
         note="OpenImageDenoise keeps more detail; OptiX is usually faster.",
         options=[("OpenImageDenoise", {'cycles.denoiser': 'OPENIMAGEDENOISE'}),
                  ("OptiX", {'cycles.denoiser': 'OPTIX'})]),

    # ---- sampling ------------------------------------------------------
    dict(key='pattern', label="Sampling Pattern", group='Sampling',
         avail=_always,
         note="In 5.2 'Automatic' already uses blue noise for final renders. "
              "'Classic' is the old tabulated Sobol.",
         options=[("Automatic", {'cycles.sampling_pattern': 'AUTOMATIC'}),
                  ("Blue-Noise", {'cycles.sampling_pattern': 'BLUE_NOISE'}),
                  ("Classic", {'cycles.sampling_pattern': 'TABULATED_SOBOL'})]),

    dict(key='scrambling', label="Scrambling Distance", group='Sampling',
         avail=is_gpu,
         note="Correlates rays between nearby pixels so the GPU cache is used "
              "better. Too low and you get visible artifacts.",
         options=[("1.0 (off)", {'cycles.scrambling_distance': 1.0,
                                 'cycles.auto_scrambling_distance': False}),
                  ("Auto", {'cycles.auto_scrambling_distance': True}),
                  # 0.1 da bo: do 05/08/2026 no cham hon 0.5 (-7% so voi
                  # -14%) va la muc de sinh vet loi nhat. Do them mot phuong
                  # an la them thoi gian cho cua khach.
                  ("0.5", {'cycles.scrambling_distance': 0.5,
                           'cycles.auto_scrambling_distance': False}),
                  ("0.3", {'cycles.scrambling_distance': 0.3,
                           'cycles.auto_scrambling_distance': False})]),

    dict(key='threshold', label="Noise Threshold", group='Sampling',
         avail=lambda s: s.cycles.use_adaptive_sampling,
         note="Adaptive sampling stops at this noise level. Higher is faster "
              "and noisier.",
         options=[("0.01", {'cycles.adaptive_threshold': 0.01}),
                  ("0.02", {'cycles.adaptive_threshold': 0.02}),
                  ("0.005", {'cycles.adaptive_threshold': 0.005})]),

    dict(key='min_samples', label="Min Samples", group='Sampling',
         avail=lambda s: s.cycles.use_adaptive_sampling,
         note="Minimum samples before adaptive sampling may stop, so noisy "
              "features are discovered first. 0 lets Blender choose.",
         options=[("Auto (0)", {'cycles.adaptive_min_samples': 0}),
                  ("32", {'cycles.adaptive_min_samples': 32}),
                  ("64", {'cycles.adaptive_min_samples': 64})]),

    dict(key='light_sampling', label="Light Sampling Threshold", group='Sampling',
         avail=_always,
         note="Drops light samples whose contribution is below this. Higher is "
              "faster and noisier; zero never skips a light.",
         options=[("0.01", {'cycles.light_sampling_threshold': 0.01}),
                  ("0.05", {'cycles.light_sampling_threshold': 0.05}),
                  ("0.0 (never skip)", {'cycles.light_sampling_threshold': 0.0})]),

    dict(key='light_tree', label="Light Tree", group='Sampling',
         avail=_always,
         note="Samples many lights by estimated contribution. It costs time per "
              "sample, so on scenes with few lights it can be a net loss.",
         options=[("On", {'cycles.use_light_tree': True}),
                  ("Off", {'cycles.use_light_tree': False})]),

    dict(key='direct_light', label="Direct Light Sampling", group='Sampling',
         avail=_always,
         note="The strategy used for direct light. This is the core sampling "
              "algorithm, not a quality slider.",
         options=[("Multiple Importance",
                   {'cycles.direct_light_sampling_type': 'MULTIPLE_IMPORTANCE_SAMPLING'}),
                  ("Next Event Estimation",
                   {'cycles.direct_light_sampling_type': 'NEXT_EVENT_ESTIMATION'}),
                  ("Forward Path Tracing",
                   {'cycles.direct_light_sampling_type': 'FORWARD_PATH_TRACING'})]),

    dict(key='guiding', label="Path Guiding", group='Sampling',
         avail=is_cpu,
         note="Learns where the light comes from and steers rays there. CPU "
              "rendering only — Blender hides the panel on GPU.",
         options=[("Off", {'cycles.use_guiding': False}),
                  ("On", {'cycles.use_guiding': True})]),

    # ---- light paths ---------------------------------------------------
    dict(key='bounces', label="Light Path Bounces", group='Light Paths',
         avail=_always,
         note="Fewer bounces render faster but lose indirect light — rooms get "
              "darker. Watch the difference column, not just the time.",
         options=[("Keep current", {}),
                  ("Total 8 / Diff 4 / Gloss 4",
                   {'cycles.max_bounces': 8, 'cycles.diffuse_bounces': 4,
                    'cycles.glossy_bounces': 4}),
                  ("Total 6 / Diff 3 / Gloss 3",
                   {'cycles.max_bounces': 6, 'cycles.diffuse_bounces': 3,
                    'cycles.glossy_bounces': 3}),
                  ("Total 4 / Diff 2 / Gloss 2",
                   {'cycles.max_bounces': 4, 'cycles.diffuse_bounces': 2,
                    'cycles.glossy_bounces': 2})]),

    dict(key='clamp_indirect', label="Clamp Indirect", group='Light Paths',
         avail=_always,
         note="Caps the energy of an indirect sample, which kills fireflies. "
              "5.2 already defaults to 10.",
         options=[("10.0", {'cycles.sample_clamp_indirect': 10.0}),
                  ("5.0", {'cycles.sample_clamp_indirect': 5.0}),
                  ("2.0", {'cycles.sample_clamp_indirect': 2.0}),
                  ("0.0 (off)", {'cycles.sample_clamp_indirect': 0.0})]),

    dict(key='blur_glossy', label="Filter Glossy", group='Light Paths',
         avail=_always,
         note="Blurs glossy reflections after a blurry bounce to cut caustic "
              "noise, at the cost of accuracy.",
         options=[("1.0", {'cycles.blur_glossy': 1.0}),
                  ("2.0", {'cycles.blur_glossy': 2.0}),
                  ("0.0 (off)", {'cycles.blur_glossy': 0.0})]),

    dict(key='caustics', label="Caustics", group='Light Paths',
         avail=_always,
         note="Reflective and refractive caustics are a large noise source in "
              "interiors with glass.",
         options=[("Both on", {'cycles.caustics_reflective': True,
                               'cycles.caustics_refractive': True}),
                  ("Both off", {'cycles.caustics_reflective': False,
                                'cycles.caustics_refractive': False}),
                  ("Reflective only", {'cycles.caustics_reflective': True,
                                       'cycles.caustics_refractive': False})]),

    dict(key='fast_gi', label="Fast GI Approximation", group='Light Paths',
         avail=_always,
         note="Replaces diffuse indirect light past N bounces with tinted "
              "ambient occlusion. Fast, and it does change the look.",
         options=[("Off", {'cycles.use_fast_gi': False}),
                  ("Replace after 1 bounce",
                   {'cycles.use_fast_gi': True, 'cycles.fast_gi_method': 'REPLACE',
                    'cycles.ao_bounces_render': 1}),
                  ("Replace after 2 bounces",
                   {'cycles.use_fast_gi': True, 'cycles.fast_gi_method': 'REPLACE',
                    'cycles.ao_bounces_render': 2})]),

    dict(key='min_light_bounces', label="Min Light Bounces", group='Light Paths',
         avail=_always,
         note="Guarantees a minimum number of light bounces, which cuts noise "
              "in the first bounces but can be wasteful on curves and volumes.",
         options=[("0", {'cycles.min_light_bounces': 0}),
                  ("1", {'cycles.min_light_bounces': 1}),
                  ("2", {'cycles.min_light_bounces': 2})]),

    # ---- film ----------------------------------------------------------
    dict(key='filter_width', label="Pixel Filter Width", group='Film',
         avail=_always,
         note="Narrower is sharper but aliases more. Blender defaults to 1.5 px "
              "Blackman-Harris.",
         options=[("1.5", {'cycles.filter_width': 1.5}),
                  ("1.3", {'cycles.filter_width': 1.3}),
                  ("1.15", {'cycles.filter_width': 1.15}),
                  ("1.0", {'cycles.filter_width': 1.0})]),

    # ---- performance ---------------------------------------------------
    dict(key='bvh', label="Acceleration Structure", group='Performance',
         avail=_always,
         note="Spatial splits and a static BVH take longer to build but trace "
              "faster. Pays off on heavy geometry.",
         options=[("Default", {'cycles.debug_use_spatial_splits': False,
                               'cycles.debug_bvh_type': 'DYNAMIC_BVH'}),
                  ("Spatial splits", {'cycles.debug_use_spatial_splits': True}),
                  ("Static BVH", {'cycles.debug_bvh_type': 'STATIC_BVH'}),
                  ("Spatial splits + Static",
                   {'cycles.debug_use_spatial_splits': True,
                    'cycles.debug_bvh_type': 'STATIC_BVH'})]),

    dict(key='texture_limit', label="Texture Limit", group='Performance',
         avail=_always,
         note="Caps texture size at render time to free VRAM. Only helps when "
              "you are actually short on memory.",
         options=[("No limit", {'cycles.texture_limit_render': 'OFF'}),
                  ("4096", {'cycles.texture_limit_render': '4096'}),
                  ("2048", {'cycles.texture_limit_render': '2048'})]),

    dict(key='tile_size', label="Tile Size", group='Performance',
         avail=_always,
         note="Tiles are cached to disk to save memory. Larger tiles mean less "
              "overhead when memory allows.",
         options=[("2048", {'cycles.tile_size': 2048}),
                  ("4096", {'cycles.tile_size': 4096}),
                  ("1024", {'cycles.tile_size': 1024})]),

    dict(key='kernel_opt', label="Kernel Optimization", group='Performance',
         avail=is_gpu,
         note="Compiles GPU kernels for the features this scene actually uses. "
              "Costs a one-off compile, then traces faster.",
         options=[("Full", {'prefs.kernel_optimization_level': 'FULL'}),
                  ("Intersection only",
                   {'prefs.kernel_optimization_level': 'INTERSECT'}),
                  ("Off", {'prefs.kernel_optimization_level': 'OFF'})]),

    dict(key='culling', label="Culling", group='Performance',
         avail=_always,
         note="Skips objects outside the camera frustum or beyond a distance. "
              "Only safe when nothing off-screen reflects into frame.",
         options=[("Off", {'cycles.use_camera_cull': False,
                           'cycles.use_distance_cull': False}),
                  ("Camera cull", {'cycles.use_camera_cull': True,
                                   'cycles.camera_cull_margin': 0.1}),
                  ("Camera + distance", {'cycles.use_camera_cull': True,
                                         'cycles.use_distance_cull': True})]),

    # ---- volume --------------------------------------------------------
    dict(key='volume', label="Volume Sampling", group='Volume',
         avail=has_volume,
         note="5.0 renders volumes with unbiased null scattering. Ray marching "
              "is biased but can be faster on some scenes.",
         options=[("Null scattering", {'cycles.volume_biased': False}),
                  ("Ray marching", {'cycles.volume_biased': True}),
                  ("Ray marching, step 2",
                   {'cycles.volume_biased': True, 'cycles.volume_step_rate': 2.0})]),

    # ---- curves --------------------------------------------------------
    dict(key='curves', label="Curve BVH", group='Curves',
         avail=has_curves,
         note="A curve-specific BVH uses more memory and traces hair faster.",
         options=[("On", {'cycles.debug_use_hair_bvh': True}),
                  ("Off", {'cycles.debug_use_hair_bvh': False})]),
)

AXIS_BY_KEY = {a['key']: a for a in AXES}

# Moi duong dan bat cu truc nao dung den — de chup lai truoc khi do.
ALL_PATHS = sorted({p for a in AXES for _, ov in a['options'] for p in ov})

# Duong dan phep do TU no phai doi (do o vung cat, tat denoise cho anh chuan...).
BENCH_PATHS = (
    'render.use_border', 'render.border_min_x', 'render.border_min_y',
    'render.border_max_x', 'render.border_max_y', 'render.use_crop_to_border',
    'render.resolution_percentage', 'render.filepath', 'render.use_compositing',
    'cycles.samples', 'cycles.adaptive_threshold', 'cycles.use_denoising',
    'cycles.use_adaptive_sampling', 'cycles.seed', 'cycles.use_animated_seed',
)


def available_axes(scene):
    """Cac truc do duoc tren scene nay, kem ly do neu khong."""
    out = []
    for a in AXES:
        try:
            ok = bool(a['avail'](scene))
        except Exception:
            ok = False
        out.append((a, ok))
    return out


def apply(scene, overrides):
    for path, value in overrides.items():
        if exists(scene, path):
            put(scene, path, value)


def describe(scene, overrides):
    """Chuoi doc duoc cua mot bo ghi de, de ghi vao bao cao."""
    if not overrides:
        return "keep current"
    bits = []
    for path, value in sorted(overrides.items()):
        bits.append("%s=%s" % (path.split('.', 1)[1], value))
    return ", ".join(bits)
