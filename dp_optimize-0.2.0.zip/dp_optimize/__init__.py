# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
bl_info = {
    "name": "DP-OptimizeRender",
    "author": "Ducphan",
    "version": (0, 2, 0),
    "blender": (5, 2, 0),
    "location": "Properties > Render > DP Optimize",
    "description": "Stop the denoiser blurring material texture. Builds a "
                   "compositor graph that denoises light on its own, then "
                   "multiplies wood grain and fabric weave back in.",
    "warning": "",
    "category": "Render",
}

# ===========================================================================
# DU AN MOI, 05/08/2026
# ---------------------------------------------------------------------------
# LY DO ADDON NAY TON TAI
#   Moi bai huong dan "toi uu Cycles" tren mang deu la mot bo so co dinh, do
#   tren scene cua NGUOI KHAC. Da do tren Blender 5.2 ngay 05/08/2026, hon
#   nua so bo so pho bien la VO NGHIA hoac SAI:
#
#     - "Tick OptiX thi OIDN tu chay GPU"  -> SAI. `denoising_use_gpu` la mot
#       cong tac RIENG, mac dinh False.
#     - "Chuyen Automatic sang Blue Noise" -> 5.2 AUTOMATIC DA la blue-noise.
#     - "Clamp Indirect xuong 10"          -> mac dinh 5.2 DA la 10.0.
#     - "Noise Threshold 0.02-0.01"        -> mac dinh DA la 0.01.
#     - "Input passes Albedo + Normal"     -> mac dinh DA la RGB_ALBEDO_NORMAL.
#     - "Prefilter Accurate"               -> mac dinh DA la ACCURATE.
#     - "Bat Path Guiding"                 -> CPU-only. Bang UI co
#       `poll = use_cpu(context)`. Render GPU thi no khong hien ra.
#     - "Denoise 4 kenh roi Mix Add"       -> SAI PHEP TOAN. Do that ngay
#       05/08/2026: bo pass Color di thi lech max 0.67. Phep dung phai la
#       (Dir + Ind) * Color cho tung nhom, cong Emission + Environment +
#       Volume. Do lai bang `comp.verify()` -> lech 0.000000.
#
#   Nen addon nay KHONG ban so. No DO tren scene dang mo roi bao so.
#
# ===========================================================================
# LUAT CUA DU AN — Ducphan chot 06/08/2026
#
#   Nang cap ve mat CHAT LUONG TEXTURE va ANH SANG, bang COMPOSITION,
#   TU DONG HOA, CHAT LUONG CAO NHAT, THOI GIAN PHAT SINH IT NHAT.
#
# Doc tung ve, vi moi ve deu da co mot lan lam sai:
#
#   CHAT LUONG TEXTURE, ANH SANG — muc tieu la giu chi tiet nho ma bo khu
#     nhieu hay ca mo: van go, soi vai, hat son. KHONG phai lam render nhanh
#     hon. Ten du an la "Optimize render" nen rat de truot ve toc do.
#
#   BANG COMPOSITION — don bay chinh la cay compositor tach kenh: khu nhieu
#     tren anh sang thuan roi nhan pass Color tro lai, nen bo khu nhieu khong
#     bao gio nhin thay van vat lieu. Xem `comp.build`.
#
#   TU DONG HOA — addon tu doc scene ma quyet dinh, KHONG DO DAC. Quet cay
#     vat lieu de biet co kinh/khoi (`comp.needed`), dung render thu roi nhin.
#     Va DUNG THEM NUT: gia tri phai nam trong duong tu dong.
#
#   CHAT LUONG CAO NHAT — khong danh doi hinh anh lay toc do. Cai gi LAM DOI
#     anh (bot bounces, Fast GI, ha clamp) thi khong duoc tu bat cho khach.
#
#   THOI GIAN PHAT SINH IT NHAT — chi dung nhanh nao scene that su dung.
#     Nguong chap nhan duoc: cham hon 2-3 giay thi van OK (do 1920x1080 tren
#     RTX 3090: 1,85s -> 2,65s).
#
# VA: CYCLES CHON SAO THI TOOL CHAY VAY. Khong dat lai thiet bi tinh toan cua
# nguoi dung — xem `settings.compositor_device_for`.
# ===========================================================================
#
# LUAT KY THUAT
#   1. KHONG CO HANG SO GU. Moi nguong deu la nut cua nguoi dung. Bo so
#      mac dinh chi la diem xuat phat cua phep do, khong phai ket luan.
#   2. DO XONG PHAI TRA LAI NGUYEN TRANG. Phep do khong duoc de lai dau vet
#      trong file cua khach. Xem `settings.Snapshot`.
#   3. CHU TREN GIAO DIEN LA TIENG ANH.
#
# ADDON NAY MIEN PHI, CHIA SE RONG RAI (Ducphan chot 06/08/2026).
# TUYET DOI KHONG gan `dp_license`: khong co ma kich hoat nao duoc cap cho no,
# nen mot cua khoa o day se chan vinh vien chinh nguoi duoc tang.
#
# CAP NHAT 07/08/2026 — Ducphan chot dua no LEN DP_Hub nhu do tang. Cau tren
# ("KHONG dang ky vao projects.json, KHONG day len kho") DA HET HIEU LUC. Nay
# no CO trong so dang ky voi khoa `"free": true`, va khoa do doi ca ba viec:
# dong goi khong cam khoa · gia phai bang 0 · goi cai len kho CONG KHAI chu
# khong vao kho zip rieng tu sau cua kiem ma.
#
# VAN LA NGOAI LE, chi la mot ngoai le CO TEN: `rollout.py --audit` doc file
# nay bang `ast` va bao do neu no goi toi cua khoa, con `run_accept.py` do
# rang KHONG co ma nao ma addon van chay. Xem `note_tang` trong projects.json.
# ===========================================================================

import bpy
from bpy.app.handlers import persistent

from . import bench, comp, metrics, ops, props, settings, ui


class DPOPT_Preferences(bpy.types.AddonPreferences):
    bl_idname = __name__

    def draw(self, context):
        col = self.layout.column()
        col.label(text="DP-OptimizeRender measures on the open scene.",
                  icon='INFO')
        col.label(text="No preset numbers are applied without a measurement.")


CLASSES = (DPOPT_Preferences,) + props.CLASSES + ops.CLASSES + ui.CLASSES


def _prepare(_dummy=None):
    """Dung san danh sach truc cho MOI scene.

    Phai lam o day chu khong lam trong `draw`: Blender cam ghi vao du lieu
    Scene trong luc ve giao dien, va neu ghi thi bang chi hien ra cai khung
    rong. Chay luc bat addon va moi lan mo file .blend.

    LUC BLENDER DANG KHOI DONG THI `bpy.data` CHUA MO. No la mot doi tuong
    `_RestrictData` khong co `.scenes`, va cham vao la:

        '_RestrictData' object has no attribute 'scenes'

    Chay tay giua phien thi khong sao, nhung addon duoc bat san trong
    Preferences se chay `register()` NGAY LUC KHOI DONG — va chet o day.
    Gap luc do thi lui lai: handler `load_post` va bo hen gio phia duoi se
    lam not khi du lieu da mo.
    """
    try:
        scenes = list(bpy.data.scenes)
    except AttributeError:
        return None

    settings.refresh_devices()
    for scene in scenes:
        try:
            st = props.ensure_axes(scene)
            # Lan do truoc bi cat ngang (tat Blender giua chung) se de lai co
            # `running` bat — bang se ket o chu "Working..." mai mai.
            st.running = False
            st.progress = ""
        except Exception:
            pass


@persistent
def _on_load(_dummy):
    _prepare()


def _register_class(cls):
    """Dang ky mot lop, don sach ban cu neu no con ket lai.

    Tat roi bat lai addon thi Blender NAP LAI module: moi lop tro thanh mot
    doi tuong Python MOI, trong khi lop cu van con dang ky duoi cung mot ten.
    Luc do `register_class` bao:

        already registered as a subclass 'DPOPT_Axis'

    va addon chet ngay tu buoc bat. Chuyen nay xay ra vi vong go dang ky
    truoc day nuot loi bang `except: pass` — no giau su co thay vi bao, roi
    lan bat sau moi vo ra. Nen o day phai chu dong don truoc khi dang ky.
    """
    old = getattr(bpy.types, cls.__name__, None)
    if old is not None and old is not cls:
        try:
            bpy.utils.unregister_class(old)
        except Exception:
            pass
    bpy.utils.register_class(cls)


def register():
    for cls in CLASSES:
        _register_class(cls)
    props.register()
    if _on_load not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_on_load)

    # Thu ngay; neu dang khoi dong thi `_prepare` tu lui lai va bo hen gio
    # duoi day se lam lai sau khi Blender mo xong du lieu.
    _prepare()
    try:
        if not bpy.app.timers.is_registered(_prepare):
            bpy.app.timers.register(_prepare, first_interval=0.2)
    except Exception:
        pass


def unregister():
    if _on_load in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_on_load)
    try:
        if bpy.app.timers.is_registered(_prepare):
            bpy.app.timers.unregister(_prepare)
    except Exception:
        pass
    props.unregister()

    # Go nguoc thu tu: lop chua PointerProperty/CollectionProperty phai di
    # truoc lop ma no tro toi, neu khong Blender tu choi go.
    failed = []
    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except Exception as exc:                       # noqa: BLE001
            failed.append("%s: %s" % (cls.__name__, exc))
    if failed:
        # KHONG im lang. Go khong sach ma khong ai biet thi lan bat sau se
        # bao "already registered" va nguoi dung khong hieu tu dau ra.
        print("[DP-OptimizeRender] go dang ky khong sach: %s" % "; ".join(failed))


if __name__ == "__main__":
    register()
