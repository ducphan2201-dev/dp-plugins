# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
"""Thiet lap va ket qua. CHU TREN GIAO DIEN LA TIENG ENGLISH — addon ban ra.

Moi nguong o day la NUT CUA NGUOI DUNG. Gia tri mac dinh chi la diem xuat
phat cua phep do, khong phai ket luan cua ai.
"""
import bpy
from bpy.props import (BoolProperty, CollectionProperty, EnumProperty,
                       FloatProperty, IntProperty, PointerProperty,
                       StringProperty)
from bpy.types import PropertyGroup

from . import settings

# Cac truc bat san khi bam nut "Default". Chon theo "hay doi duoc VAN VAT
# LIEU nhat", khop voi muc tieu cua luat chon — xem `bench.winners`. Ai cung
# do duoc het neu muon, chi ton thoi gian.
DEFAULT_ON = {
    'denoise_passes', 'denoise_quality', 'denoise_prefilter', 'denoiser',
    'pattern', 'min_samples', 'light_tree',
}

# --------------------------------------------------------------------------
# CHE DO MOT NUT DO NHUNG TRUC NAO
#
# Muc tieu cua che do mot nut la ANH DEP HON MA KHONG CHAM HON (xem luat chon
# trong `bench.winners`). Nen bo truc phai chon theo cau truc, khong phai theo
# so do tren mot canh mau nao ca:
#
#   CHI CO MOT LOAI TRUC THANG DUOC. Anh chuan la chinh thiet lap cua khach
#   da hoi tu, nen `diff` do dung mot cau: "con cach cai anh dang le phai ra
#   bao xa". Cai gi LAM DOI anh dang le phai ra — bot bounces, doi filter
#   width, bat Fast GI, ha clamp — thi theo dinh nghia deu di XA anh chuan
#   hon, khong bao gio thang duoc. Con cai gi chi doi CACH HOI TU ve dung
#   cai anh do — cach phan bo mau va cach khu nhieu — thi thang duoc.
#
#   Nen bo truc tu dong = nhom khu nhieu (khi dang dung OIDN), va nhom phan
#   bo mau (khi khong). Khong truc nao trong day danh doi hinh anh de lay
#   toc do, va khong truc nao ton them thoi gian do tia.
#
# Bo dung 9 phuong an nhu bo cu, de so lan render KHONG TANG.

# Dang dung OpenImageDenoise: ba trong nay quyet dinh bo khu nhieu phan biet
# van vat lieu voi nhieu tot den dau. Chung gan nhu khong ton them gio.
AUTO_AXES_DENOISE = {'denoise_passes', 'denoise_quality', 'denoise_prefilter'}

# Khong dung OIDN (vd. dang de OptiX): luc do ba trong tren khong hien ra.
# Do nhom phan bo mau — cung mot so tia, chia khac di thi anh sach hon.
AUTO_AXES_SAMPLING = {'denoiser', 'min_samples', 'light_tree'}

# Giu ten cu cho ma ngoai con goi den. Khong dung de quyet dinh nua —
# `ops._auto_axes()` chon theo scene.
AUTO_AXES = AUTO_AXES_DENOISE

# `denoise_gpu` DA RA KHOI vong do: no la mot lua chon ve PHAN CUNG, khong
# phai ve hinh anh, nen no da nam o nut "Optimize This Scene" (truoc 14/09/2026 ten "Speed Up This Scene") — bam phat
# xong, khong render lan nao. Xem `ops._instant_wins`.
#
# `scrambling` va `threshold` cung ra khoi vong do: ca hai deu doi TOC DO
# lay ANH, ma vong do bay gio khong con di tim toc do nua.

# So lan render xap xi cua che do mot nut, de bao truoc cho nguoi dung:
# 1 lam nong + 1 anh chuan + 1 diem xuat phat + 9 phuong an
# + 2 lan do lai moc + 1 do lai cuoi + 2 lan xac nhan bo gop.
AUTO_RENDERS = 17


class DPOPT_Axis(PropertyGroup):
    key: StringProperty()
    label: StringProperty()
    group: StringProperty()
    note: StringProperty()
    enabled: BoolProperty(
        name="Measure", default=False,
        description="Include this setting in the next measurement run")
    available: BoolProperty(default=True)
    reason: StringProperty()


class DPOPT_Result(PropertyGroup):
    kind: StringProperty()
    label: StringProperty()
    group: StringProperty()
    key: StringProperty()
    option: StringProperty()
    secs: FloatProperty()
    ratio: FloatProperty(default=1.0)
    diff: FloatProperty()
    detail: FloatProperty()
    texture: FloatProperty(default=1.0)
    blotch: FloatProperty()
    passed: BoolProperty()
    winner: BoolProperty()
    overrides: StringProperty()


class DPOPT_Settings(PropertyGroup):
    # ---- vung do ------------------------------------------------------
    region_mode: EnumProperty(
        name="Region",
        description="What the test renders look like. Full Frame is the only "
                    "one whose timings match your real render",
        items=[('FULL', "Full Frame",
                "Render exactly what you would render. Slow, and the only "
                "setting whose result you can trust"),
               ('CROP', "Centre Crop",
                "Render a centred region at full resolution. Noise and detail "
                "keep their real per-pixel scale, so denoiser behaviour is "
                "judged fairly"),
               ('SCALE', "Lower Resolution",
                "Render the whole frame at a lower resolution. Faster, but "
                "measured 05/08/2026 to rank settings wrongly at every scale "
                "tried")],
        default='FULL')
    region_size: FloatProperty(
        name="Region Size", default=40.0, min=5.0, max=100.0, subtype='PERCENTAGE',
        description="Crop: side of the centred region as a percentage of the "
                    "frame. Lower Resolution: the resolution percentage")

    # ---- anh chuan ----------------------------------------------------
    ref_samples: IntProperty(
        name="Reference Samples", default=512, min=16, soft_max=4096,
        description="Samples for the converged reference image. Every result is "
                    "measured against this, so it must be clean enough to trust")
    ref_threshold: FloatProperty(
        name="Reference Noise Threshold", default=0.002, min=0.0, max=1.0,
        precision=4,
        description="Noise threshold for the reference image. Lower is cleaner "
                    "and slower")
    warmup_max: IntProperty(
        name="Warm-up Limit", default=12, min=1, max=40,
        description="Discard up to this many renders before timing starts. A "
                    "cold machine can spend its first several renders at twice "
                    "the speed it settles at, and whatever is measured in that "
                    "window is measured wrong")
    warmup_tolerance: FloatProperty(
        name="Warm-up Tolerance", default=0.05, min=0.005, max=0.5,
        subtype='FACTOR',
        description="Timing starts once three discarded renders in a row agree "
                    "within this much")
    rebase_every: IntProperty(
        name="Re-check Baseline Every", default=5, min=2, max=20,
        description="Re-measure your current settings this often during the "
                    "run. Machines do not hold one speed for a whole session, "
                    "so each setting is compared against a baseline measured "
                    "near it in time rather than one taken at the start")
    combo_repeats: IntProperty(
        name="Confirmation Runs", default=3, min=1, max=8,
        description="How many times the final combination is re-measured "
                    "before anything is applied. This is the gate that stops a "
                    "lucky timing from being sold to you as a speed-up")
    repeats: IntProperty(
        name="Repeats", default=2, min=1, max=5,
        description="Render each setting this many times and keep the fastest "
                    "run. Anything else on the machine can only make a render "
                    "slower, so the fastest run is the honest one. Set to 1 and "
                    "a setting that changes nothing can still look 18% faster")
    seed: IntProperty(
        name="Seed", default=7, min=0,
        description="Fixed seed for every test render, so two runs differ "
                    "because of the setting and not because of the noise pattern")

    # ---- nguong chon ---------------------------------------------------
    detail_floor: FloatProperty(
        name="Detail Floor", default=0.98, min=0.0, max=1.5,
        description="Reject a setting that keeps less detail than this share of "
                    "what your current settings keep. 1.00 means it must be no "
                    "softer than what you have now")
    diff_ceiling: FloatProperty(
        name="Difference Ceiling", default=0.005, min=0.0, max=1.0, precision=4,
        description="Reject a setting that drifts this much further from the "
                    "reference than your current settings already do. Raise it "
                    "if you accept a changed look in exchange for speed")
    min_gain: FloatProperty(
        name="Minimum Gain", default=0.03, min=0.0, max=0.9, subtype='FACTOR',
        description="Ignore a setting unless it keeps at least this much more "
                    "material texture than your current settings")
    blotch_slack: FloatProperty(
        name="Noise Allowance", default=0.05, min=0.0, max=1.0, subtype='FACTOR',
        description="How much more leftover noise a setting may leave in flat "
                    "areas and still be accepted. This is what stops the "
                    "measurement from 'keeping texture' by simply denoising "
                    "less: raise it and grain starts counting as detail")
    edge_percentile: FloatProperty(
        name="Detail Region", default=80.0, min=50.0, max=99.0,
        subtype='PERCENTAGE',
        description="Pixels above this gradient percentile in the reference "
                    "count as textured area, where detail is measured")
    flat_percentile: FloatProperty(
        name="Flat Region", default=40.0, min=1.0, max=60.0, subtype='PERCENTAGE',
        description="Pixels below this gradient percentile in the reference "
                    "count as flat area, where leftover blotching is measured")

    # ---- trang thai ----------------------------------------------------
    axes: CollectionProperty(type=DPOPT_Axis)
    results: CollectionProperty(type=DPOPT_Result)
    active_result: IntProperty(default=0)
    running: BoolProperty(default=False)
    progress: StringProperty(default="")
    last_summary: StringProperty(default="")
    ref_secs: FloatProperty(default=0.0)
    ref_noise: FloatProperty(default=0.0)
    timing_noise: FloatProperty(default=0.0)
    drift: FloatProperty(default=0.0)
    warmup_used: IntProperty(default=0)
    warmup_ok: BoolProperty(default=True)
    ref_noise_warn: FloatProperty(
        name="Reference Noise Limit", default=0.004, min=0.0, max=1.0,
        precision=4,
        description="Warn when the reference image is still this noisy. A noisy "
                    "reference makes every denoised result look worse than it "
                    "is, because noise counts as detail")

    # ---- tach kenh anh sang --------------------------------------------
    split_prefilter: EnumProperty(
        name="Prefilter",
        items=[('Accurate', "Accurate", "Prefilter the guiding passes fully"),
               ('Fast', "Fast", "Cheaper prefiltering of the guiding passes"),
               ('None', "None", "Use the guiding passes as they are")],
        default='Accurate',
        description="Applies to the albedo and normal guiding passes, not to "
                    "the beauty image")
    split_quality: EnumProperty(
        name="Quality",
        items=[('Follow Scene', "Follow Scene", "Use the scene denoising quality"),
               ('High', "High", "Highest denoising quality"),
               ('Balanced', "Balanced", "Balance of quality and speed"),
               ('Fast', "Fast", "Fastest denoising")],
        default='Follow Scene')
    split_denoise_volume: BoolProperty(
        name="Denoise Volume Passes", default=True,
        description="Also denoise the volume passes. They carry no colour pass, "
                    "so they are denoised directly")
    split_verify_samples: IntProperty(
        name="Verify Samples", default=32, min=4, soft_max=256,
        description="Samples used by the verification render. Denoising is off "
                    "for that check, so the two images must match exactly")


CLASSES = (DPOPT_Axis, DPOPT_Result, DPOPT_Settings)


def ensure_axes(scene):
    """Dong bo danh sach truc voi `settings.AXES`, giu lai o tick cua khach."""
    st = scene.dpopt
    have = {a.key: a for a in st.axes}
    wanted = [a['key'] for a in settings.AXES]

    for axis, ok in settings.available_axes(scene):
        row = have.get(axis['key'])
        if row is None:
            row = st.axes.add()
            row.key = axis['key']
            row.enabled = axis['key'] in DEFAULT_ON
        row.label = axis['label']
        row.group = axis['group']
        row.note = axis['note']
        row.available = ok

    # Xoa dong thua (vd. doi tu ban cu sang ban moi bo bot truc).
    for i in range(len(st.axes) - 1, -1, -1):
        if st.axes[i].key not in wanted:
            st.axes.remove(i)
    return st


def register():
    bpy.types.Scene.dpopt = PointerProperty(type=DPOPT_Settings)


def unregister():
    try:
        del bpy.types.Scene.dpopt
    except AttributeError:
        pass
