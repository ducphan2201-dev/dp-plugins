# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
"""Lop DO — quet scene ra so lieu cho `chinh_sach.py`.

Day la lop duy nhat biet ve hinh hoc. Voi moi tam anh no tra loi DUNG HAI
cau hoi, dung hai dieu kien Ducphan chot:

    1. Cho GAN NHAT ma tam anh nay xuat hien, cach ong kinh bao nhieu?
    2. O cho DOI HOI DO NET CAO NHAT, no trai bao nhieu texel len bao
       nhieu pixel man hinh?

Ca hai deu do tren TAM GIAC, khong phai tren hop bao vat the. Hop bao la
sai o dung cai truong hop hay gap nhat cua noi that: mot san go trai ca
phong thi hop bao cua no cham ong kinh, nhung goc xa cua no thi khong.

=========================================================================
BON DIEU LOP NAY CO Y LAM SAI VE MOT PHIA
=========================================================================
Doan sai theo huong GIU NHIEU hon la an toan (chi ton VRAM). Doan sai theo
huong HA NHIEU hon la anh mo, va nguoi dung khong bao gio doan ra thu phai
la addon nay. Nen o bon cho khong chac, no luon nga ve phia giu:

  1. Tam giac chi HE mot goc vao khung hinh van duoc tinh TRON dien tich.
     Cat cho dung thi phai xen da giac, dat ma loi it.
  2. Tam giac co MOT dinh sau ong kinh thi bo qua ca tam giac — vat the
     kieu do gan sat ong kinh, giu nguyen la dung.
  3. KHONG tinh che khuat. Tam anh nam sau buc tuong van duoc giu nguyen.
  4. Vat the AN TRONG VIEWPORT nhung HIEN khi render thi khong do duoc
     hinh hoc cua no — moi anh cua no bi danh dau "khong do duoc" va giu
     nguyen co. So luong duoc BAO CAO ra bang, khong nuot lang.

Va mot cho thu nam, la cho co the an tien nhat nhung chua dam lam: anh chi
nam tren vat the NGOAI KHUNG HINH van duoc giu nguyen co. Ly do la GUONG
va PHAN XA — mot cai tu sau lung ong kinh van hien trong mat kinh ban an.
So luong cung duoc dem va bao ra (`anh_ngoai_khung`).

=========================================================================
CACH CHIEU — VA VI SAO KHONG DUNG `world_to_camera_view`
=========================================================================
`bpy_extras.object_utils.world_to_camera_view` chay tren TUNG diem mot.
Mot scene noi that 2 trieu tam giac la 6 trieu lan goi python. O day dung
`Object.calc_matrix_camera()` lay thang ma tran chieu roi nhan ca mang
bang numpy — cung mot phep toan, mot lan goi.
"""

import numpy as np

import bpy

# Ten khong gian mau Blender dung cho map DU LIEU (khong phai mau nhin
# thay). Doc theo TEN chu khong theo `is_float`: mot map bump 8-bit cung
# la map noi.
_PHI_MAU = {"Non-Color", "Raw", "Linear", "Generic Data", "Data"}


def _ma_tran(scene, depsgraph, cam_obj, rw, rh):
    """(PV, V) — PV doi sang toa do cat, V doi sang toa do ONG KINH.

    Can ca hai: PV de biet mat nam dau tren khung hinh, V de biet no cach
    ong kinh bao xa (trong toa do ong kinh, ong kinh nam o goc toa do).

    ⛔ `calc_matrix_camera` nam tren OBJECT, khong nam tren Camera data.
    Go `cam.data.calc_matrix_camera(...)` chay tron loi cu phap, tron ca
    bo kiem python tran, va chi chet luc render tren may khach.
    """
    r = scene.render
    P = np.array(cam_obj.calc_matrix_camera(
        depsgraph, x=rw, y=rh,
        scale_x=r.pixel_aspect_x, scale_y=r.pixel_aspect_y),
        dtype=np.float64)
    V = np.array(cam_obj.matrix_world.inverted(), dtype=np.float64)
    return P @ V, V


def _do_phan_giai(scene):
    r = scene.render
    k = r.resolution_percentage / 100.0
    return max(1, int(r.resolution_x * k)), max(1, int(r.resolution_y * k))


# ---------------------------------------------------------------------------
# Vat lieu -> nhung tam anh no dung, kem he so keo UV cua node Mapping
# ---------------------------------------------------------------------------
def _he_so_mapping(nut, sau=0):
    """Di nguoc tu o Vector cua node anh, tim node Mapping gan nhat.

    Tra ve (sx, sy). Mapping keo UV len k lan thi tren MOT MAT co ngan ay
    lan lap map, tuc so texel trai ra tren mat do nhan len k*k. Bo qua khau
    nay la doc mot san go lat 20 vien thanh mot vien.
    """
    if sau > 8:
        return 1.0, 1.0
    o = nut.inputs.get("Vector")
    if o is None or not o.is_linked:
        return 1.0, 1.0
    tu = o.links[0].from_node
    if tu.bl_idname == "ShaderNodeMapping":
        s = tu.inputs.get("Scale")
        if s is not None and not s.is_linked:
            v = s.default_value
            return abs(v[0]) or 1.0, abs(v[1]) or 1.0
        return 1.0, 1.0
    return _he_so_mapping(tu, sau + 1)


def _anh_cua_cay(cay, da_qua, ra):
    if cay is None or cay in da_qua:
        return
    da_qua.add(cay)
    for nut in cay.nodes:
        if nut.bl_idname == "ShaderNodeTexImage" and nut.image is not None:
            ra.append((nut.image, _he_so_mapping(nut)))
        elif nut.bl_idname == "ShaderNodeGroup":
            _anh_cua_cay(nut.node_tree, da_qua, ra)


def anh_cua_vat_lieu(mat):
    """[(image, (sx, sy)), ...] — ke ca anh nam trong node group."""
    if mat is None or mat.node_tree is None:
        return []
    ra = []
    _anh_cua_cay(mat.node_tree, set(), ra)
    return ra


# ---------------------------------------------------------------------------
# Quet mot vat the
# ---------------------------------------------------------------------------
def _dien_tich_tam_giac(diem, chi_so):
    """Dien tich tung tam giac tu mang diem 2 chieu. chi_so: (n, 3)."""
    a = diem[chi_so[:, 0]]
    b = diem[chi_so[:, 1]]
    c = diem[chi_so[:, 2]]
    return 0.5 * np.abs((b[:, 0] - a[:, 0]) * (c[:, 1] - a[:, 1]) -
                        (c[:, 0] - a[:, 0]) * (b[:, 1] - a[:, 1]))


def _hop_bao_ngoai_khung(ob, mtx, PV, rw, rh):
    """Tam dinh hop bao co nam TRON ngoai khung hinh khong.

    Tra ve False khi khong dam chac — day la mot cua sang loc, va mot cua
    sang loc doan bua la mot vat the bien mat khoi phep do trong im lang.
    """
    try:
        bb = ob.bound_box
    except (AttributeError, RuntimeError):
        return False
    M = np.array(mtx, dtype=np.float64)
    d = np.ones((8, 4), dtype=np.float64)
    d[:, :3] = np.array(bb, dtype=np.float64)
    cat = d @ (PV @ M).T
    w = cat[:, 3]
    if not (w > 1e-9).all():
        return False                    # co dinh sau ong kinh -> khong dam
    x = ((cat[:, 0] / w) * 0.5 + 0.5) * rw
    y = ((cat[:, 1] / w) * 0.5 + 0.5) * rh
    return bool(x.max() < 0 or x.min() > rw or y.max() < 0 or y.min() > rh)


def _quet_mesh(me, mtx, PV, V, rw, rh):
    """{chi_so_vat_lieu: (px_dinh, uv_dinh, kc, px_tong, uv_tong)}.

    NAM so, va chung tra loi BA cau hoi khac nhau — dung gop lai:

    `px_dinh`, `uv_dinh` — lay tu MOT tam giac: cai co ti so px/uv lon
        nhat, tuc CHO DOI HOI DO NET CAO NHAT. Tra ve ca hai so chu khong
        tra ve ti so, vi so texel con phu thuoc co tung tam anh — phep chia
        lam sau, o `chinh_sach.ti_le_can()`.

    `px_tong`, `uv_tong` — CONG DON tren moi tam giac co gop mat: tong
        dien tich vat lieu do chiem TREN KHUNG HINH, va tong dien tich cua
        chinh TAM ANH ma no bay ra. Ducphan chot 22/08/2026: dieu kien 2
        *"phai tinh toan dua so luong dien tich anh ma vat lieu hien thi
        nua"*. Mot tam giac dinh khong noi duoc chuyen do: mot san go co
        MOT o gan chan ong kinh va nghin o chay ve chan troi thi tam giac
        dinh chi ke ve cai o gan nhat.

    `kc` — dinh GAN NHAT trong so cac tam giac co gop mat.

    Ba nhom so nay co the den tu ba tam giac khac nhau, va do la dung.
    """
    try:
        me.calc_loop_triangles()
    except (AttributeError, RuntimeError):
        pass
    n_tri = len(me.loop_triangles)
    if n_tri == 0 or len(me.vertices) == 0:
        return {}

    lop = None
    for u in me.uv_layers:
        if u.active_render:
            lop = u
            break
    if lop is None and len(me.uv_layers):
        lop = me.uv_layers[0]
    if lop is None:
        return {}

    v = np.empty(len(me.vertices) * 3, dtype=np.float64)
    me.vertices.foreach_get("co", v)
    v = v.reshape(-1, 3)

    M = np.array(mtx, dtype=np.float64)
    thuan = np.empty((v.shape[0], 4), dtype=np.float64)
    thuan[:, :3] = v
    thuan[:, 3] = 1.0

    cat = thuan @ (PV @ M).T                  # toa do cat
    ong = thuan @ (V @ M).T                   # toa do ong kinh
    kc_dinh = np.linalg.norm(ong[:, :3], axis=1)

    w = cat[:, 3]
    truoc_ong_kinh = w > 1e-9
    w_an_toan = np.where(truoc_ong_kinh, w, 1.0)
    man = np.empty((v.shape[0], 2), dtype=np.float64)
    man[:, 0] = ((cat[:, 0] / w_an_toan) * 0.5 + 0.5) * rw
    man[:, 1] = ((cat[:, 1] / w_an_toan) * 0.5 + 0.5) * rh

    tri_v = np.empty(n_tri * 3, dtype=np.int32)
    me.loop_triangles.foreach_get("vertices", tri_v)
    tri_v = tri_v.reshape(-1, 3)

    tri_l = np.empty(n_tri * 3, dtype=np.int32)
    me.loop_triangles.foreach_get("loops", tri_l)
    tri_l = tri_l.reshape(-1, 3)

    tri_m = np.empty(n_tri, dtype=np.int32)
    me.loop_triangles.foreach_get("material_index", tri_m)

    uv = np.empty(len(me.loops) * 2, dtype=np.float64)
    lop.uv.foreach_get("vector", uv)
    uv = uv.reshape(-1, 2)

    # Dieu 2: bo ca tam giac neu co mot dinh sau ong kinh
    du_dinh = truoc_ong_kinh[tri_v].all(axis=1)

    # Nam tron ngoai khung hinh thi khong doi hoi gi, cung khong tinh
    # khoang cach — mot cai tu ngoai khung khong duoc ghim cho san trong
    # khung o muc "giu nguyen".
    tx = man[tri_v][:, :, 0]
    ty = man[tri_v][:, :, 1]
    trong_khung = ~((tx.max(axis=1) < 0) | (tx.min(axis=1) > rw) |
                    (ty.max(axis=1) < 0) | (ty.min(axis=1) > rh))

    dung = du_dinh & trong_khung
    if not dung.any():
        return {}

    dt_man = _dien_tich_tam_giac(man, tri_v)
    dt_uv = _dien_tich_tam_giac(uv, tri_l)
    kc_tri = kc_dinh[tri_v].min(axis=1)

    ok = dung & (dt_uv > 1e-12) & (dt_man > 0.0)
    if not ok.any():
        return {}

    ti = np.where(ok, dt_man / np.maximum(dt_uv, 1e-12), -1.0)
    ra = {}
    for mi in np.unique(tri_m[ok]):
        chon = ok & (tri_m == mi)
        if not chon.any():
            continue
        k = int(np.argmax(np.where(chon, ti, -1.0)))
        # ⛔ HAI CACH DO KHOANG CACH, va chung khac nhau RAT XA tren file
        # that. Xem ghi chu dau file.
        #   `min`  — dinh gan nhat. Mot goc san sat chan ong kinh la ghim
        #            CA tam map san o 1/1, du 99% cai san nam tit dang xa.
        #   `w`    — trung binh CO TRONG SO theo dien tich tren khung hinh:
        #            phan nao chiem nhieu pixel thi tieng noi nang hon.
        dt = dt_man[chon]
        kc = kc_tri[chon]
        ra[int(mi)] = (float(dt_man[k]), float(dt_uv[k]),
                       float(kc.min()), float(dt.sum()),
                       float(dt_uv[chon].sum()),
                       # tra ve TONG kc*dien_tich chu khong tra ve trung
                       # binh: cong don qua nhieu vat the thi phai cong hai
                       # tong roi moi chia, khong duoc trung binh cua
                       # trung binh.
                       float((kc * dt).sum()))
    return ra


# ---------------------------------------------------------------------------
def quet_scene(context):
    """Quet ca scene. Tra ve (danh_sach_anh, ghi_chu).

    `danh_sach_anh` la dau vao dung khuon cua `chinh_sach.quyet_dinh()`.
    `ghi_chu` dem nhung cho phep do PHAI BO QUA — bang se noi ra, khong
    nuot lang.
    """
    scene = context.scene
    ghi_chu = {"khong_co_camera": False, "an_viewport_hien_render": 0,
               "vat_the_da_quet": 0, "tam_giac": 0,
               "anh_khong_tren_mat": 0, "anh_ngoai_khung": 0,
               "bo_qua_khong_map": 0, "bo_qua_ngoai_khung": 0}

    doi_hoi = {}          # ten anh -> [px_man, uv_hieu_dung, khoang_cach]
    tren_mat = set()      # ten anh -> co nam tren mot vat the nao khong

    px_khung = None
    cam = scene.camera
    if cam is None or cam.type != "CAMERA":
        ghi_chu["khong_co_camera"] = True
    else:
        depsgraph = context.evaluated_depsgraph_get()
        rw, rh = _do_phan_giai(scene)
        px_khung = rw * rh
        ghi_chu["khung_px"] = px_khung
        PV, V = _ma_tran(scene, depsgraph, cam, rw, rh)

        # Dieu 4: vat the an trong viewport ma van render thi khong co
        # hinh hoc da danh gia de do -> bao ve moi anh cua no.
        hien = {inst.object.original for inst in depsgraph.object_instances
                if inst.object is not None}
        can_bao_ve = set()
        for ob in scene.objects:
            if ob.type != "MESH" or ob.hide_render or ob in hien:
                continue
            ghi_chu["an_viewport_hien_render"] += 1
            for khe in ob.material_slots:
                for img, _ in anh_cua_vat_lieu(khe.material):
                    can_bao_ve.add(img.name)

        for inst in depsgraph.object_instances:
            ob = inst.object
            if ob is None or ob.type != "MESH" or ob.original.hide_render:
                continue
            me = ob.data
            if me is None or not len(me.polygons):
                continue

            # ⛔ HAI CUA SANG LOC RE, DAT TRUOC MOI PHEP TINH DAT.
            # Chung khong lam ket qua khac di mot chut nao — chung chi
            # khong lam nhung viec cho ra so 0. Ducphan render BATCH, moi
            # tam anh mot lan quet, nen giay o day nhan len hang tram lan.
            #
            # Cua 1: vat lieu khong co tam anh nao thi hinh hoc cua no
            # khong tra loi cau hoi nao ca.
            khe_anh = {}
            co_anh = False
            for mi, khe in enumerate(ob.material_slots):
                khe_anh[mi] = anh_cua_vat_lieu(khe.material)
                if khe_anh[mi]:
                    co_anh = True
                for img, _ in khe_anh[mi]:
                    tren_mat.add(img.name)
            if not co_anh:
                ghi_chu["bo_qua_khong_map"] += 1
                continue

            # Cua 2: hop bao nam tron ngoai khung hinh. Tam giac trong mot
            # hop bao ngoai khung thi cung ngoai khung — nen tam giac nao
            # cung se bi loai o `trong_khung`, chi la loai SAU khi da chieu
            # het ca trieu dinh. Tam dinh cua hop bao la du de biet truoc.
            #
            # Chi dam ket luan khi CA TAM dinh deu truoc ong kinh: mot dinh
            # sau ong kinh la phep chia cho w doi dau, va hop bao "ngoai
            # khung" co the dang om lay ca man hinh.
            if _hop_bao_ngoai_khung(ob, inst.matrix_world, PV, rw, rh):
                ghi_chu["bo_qua_ngoai_khung"] += 1
                continue

            ghi_chu["vat_the_da_quet"] += 1
            ghi_chu["tam_giac"] += len(me.loop_triangles)

            for mi, (px, uv_dt, kc, px_t, uv_t, kcdt) in _quet_mesh(
                    me, inst.matrix_world, PV, V, rw, rh).items():
                for img, (sx, sy) in khe_anh.get(mi, ()):
                    # Mapping keo UV k lan -> mat trai ra k*k lan so texel
                    k_uv = sx * sy
                    uv_hd = uv_dt * k_uv
                    cu = doi_hoi.get(img.name)
                    if cu is None:
                        doi_hoi[img.name] = [px, uv_hd, kc,
                                             px_t, uv_t * k_uv, kcdt]
                    else:
                        # doi hoi do net: giu tam giac co px/uv lon nhat
                        if px * cu[1] > cu[0] * uv_hd:
                            cu[0], cu[1] = px, uv_hd
                        # khoang cach gan nhat: giu cho GAN NHAT
                        if kc < cu[2]:
                            cu[2] = kc
                        # tong dien tich va tong kc*dien_tich: CONG DON
                        cu[3] += px_t
                        cu[4] += uv_t * k_uv
                        cu[5] += kcdt

        for ten in can_bao_ve:
            doi_hoi.pop(ten, None)

    ra = []
    for img in bpy.data.images:
        if img.type != "IMAGE" or img.size[0] <= 0 or img.size[1] <= 0:
            continue
        sua_duoc = (img.source == "FILE" and not img.packed_file
                    and not img.is_dirty)
        d = doi_hoi.get(img.name)
        so_texel = img.size[0] * img.size[1]
        if d is None:
            px_man = texel_co = kc = px_tong = texel_tong = kc_w = None
            if img.name in tren_mat:
                ghi_chu["anh_ngoai_khung"] += 1
            else:
                ghi_chu["anh_khong_tren_mat"] += 1
        else:
            px_man = d[0]
            texel_co = d[1] * so_texel
            kc = d[2]
            px_tong = d[3]
            texel_tong = d[4] * so_texel
            # trung binh co trong so theo dien tich: cong hai TONG roi chia
            kc_w = (d[5] / d[3]) if d[3] > 0 else d[2]
        ra.append({
            "ten": img.name,
            "w": img.size[0],
            "h": img.size[1],
            "so_kenh": img.channels or 4,
            "byte_kenh": 4 if img.is_float else 1,
            # `khoang_cach` la cai dung de xep vanh: trung binh CO TRONG SO
            # theo dien tich. `khoang_cach_min` giu lai de doi chieu.
            "khoang_cach": kc_w,
            "khoang_cach_min": kc,
            # cho doi hoi do net cao nhat — MOT tam giac
            "px_man": px_man,
            "texel_co": texel_co,
            # tong tren moi tam giac co gop mat vao khung hinh
            "px_tong": px_tong,
            "texel_tong": texel_tong,
            # de tinh "map nay phu bao nhieu phan khung hinh"
            "px_khung": px_khung,
            # map NOI (bump/normal/roughness) — Blender danh dau bang
            # colorspace "Non-Color". Xem `chinh_sach.TRAN_PHI_MAU`.
            "phi_mau": img.colorspace_settings.name in _PHI_MAU,
            "sua_duoc": sua_duoc,
        })
    return ra, ghi_chu
