# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
"""O nhap cua DP_RAMchill.

CHU TREN BANG LA TIENG ANH — addon ban ra. Ngoai le duy nhat la tooltip
cua o nhap: song ngu, tieng Anh truoc, tieng Viet CO DAU sau.

BON MOC KHOANG CACH DUNG `subtype="DISTANCE"`, va do la mot quyet dinh co
y. Nha DP co ba quy uoc don vi khac nhau — CAD la 1 unit = 1 mm, SketchUp
mang vao la 1 unit = 1 m, DP_sketch la 1 unit = 1 unit. Addon nay lat len
scene cua nguoi khac nen no KHONG DUOC DOAN. `DISTANCE` de Blender tu hien
so theo he don vi cua chinh file do; con muon dat cho dung thi bam nut
`Fit To Scene`, no DO chu khong doan.
"""

import bpy
from bpy.props import (BoolProperty, EnumProperty, FloatProperty,
                       IntProperty,
                       PointerProperty, StringProperty)
from bpy.types import PropertyGroup

from . import chinh_sach

# ⛔ DANH SACH NAY BAT DAU TU 512, khong phai tu 128. San cung cua Ducphan
# (`chinh_sach.SAN_TUYET_DOI`) chan o lop quyet dinh roi, nhung mot o chon
# van bay ra "256" thi nguoi dung chon 256, addon tra ve 512, va ho doc
# len la addon hong. Chan hai cua, va cua nay la cua nguoi dung nhin thay.
_CO_EP = tuple(
    (str(n), str(n), "%d px" % n)
    for n in (512, 1024, 2048, 4096)
    if n >= chinh_sach.SAN_TUYET_DOI
)


class DPRAMCHILL_Props(PropertyGroup):

    che_do: EnumProperty(
        name="Mode",
        items=(
            (chinh_sach.CHE_DO_TAT, "Off",
             "Do nothing. Render uses every map at full size.\n"
             "Khong lam gi. Render dung moi map o co goc"),
            (chinh_sach.CHE_DO_TU_DONG, "Auto (distance + screen area)",
             "STILL IMAGES. Shrink each map by 1/2, 1/4, 1/6 or 1/8 - the "
             "step must be allowed by BOTH the distance ring AND the "
             "screen area it covers. Planned once, from the frame you are "
             "on.\n"
             "ANH TINH. Thu nho tung map theo bac 1/2, 1/4, 1/6, 1/8 - "
             "bac nao cung phai duoc CA HAI dieu kien cho phep: vanh "
             "khoang cach VA dien tich no chiem tren khung hinh. Ke hoach "
             "lap mot lan, o khung hinh dang dung"),
            (chinh_sach.CHE_DO_EP_CO, "Force one size",
             "Every map in the scene down to one size. This is the mode "
             "for ANIMATION: one size, every frame. Maps already smaller "
             "are left alone.\n"
             "Ep moi map trong scene ve mot co. Day la che do danh cho "
             "ANIMATION: mot co, dung cho moi khung hinh. Map von nho hon "
             "thi de yen"),
        ),
        default=chinh_sach.CHE_DO_TAT,
    )

    moc_tu_dong: BoolProperty(
        name="Fit rings to the scene", default=True,
        description="Measure how deep the scene actually is and place the "
                    "four rings on that spread, every scan. Turn off to "
                    "type your own distances.\n"
                    "Do xem canh sau bao nhieu roi tu dat bon moc theo do, "
                    "moi lan quet. Tat di de tu go so cua minh")

    moc_1: FloatProperty(
        name="1/2 beyond", default=chinh_sach.MOC_MAC_DINH[0], min=0.0,
        subtype="DISTANCE",
        description="Past this distance from the camera a map may drop to "
                    "1/2.\nQua khoang cach nay tinh tu camera, map duoc "
                    "phep ha xuong 1/2")
    moc_2: FloatProperty(
        name="1/4 beyond", default=chinh_sach.MOC_MAC_DINH[1], min=0.0,
        subtype="DISTANCE",
        description="Past this distance a map may drop to 1/4.\n"
                    "Qua khoang cach nay, map duoc phep ha xuong 1/4")
    moc_3: FloatProperty(
        name="1/6 beyond", default=chinh_sach.MOC_MAC_DINH[2], min=0.0,
        subtype="DISTANCE",
        description="Past this distance a map may drop to 1/6.\n"
                    "Qua khoang cach nay, map duoc phep ha xuong 1/6")
    moc_4: FloatProperty(
        name="1/8 beyond", default=chinh_sach.MOC_MAC_DINH[3], min=0.0,
        subtype="DISTANCE",
        description="Past this distance a map may drop to 1/8, the "
                    "smallest step.\nQua khoang cach nay, map duoc phep ha "
                    "xuong 1/8, bac nho nhat")

    du_phong: FloatProperty(
        name="Texels per pixel", default=chinh_sach.DU_PHONG_MAC_DINH,
        min=0.25, max=8.0, soft_min=1.0, soft_max=4.0, step=25, precision=2,
        description="Second condition: how many texels to keep for each "
                    "rendered pixel. 1.0 is exactly enough; raise it if "
                    "surfaces look soft.\n"
                    "Dieu kien thu hai: giu bao nhieu texel cho moi pixel "
                    "render. 1,0 la vua khit; thay be mat nhoe thi tang len")

    nguong_to: FloatProperty(
        name="Big on screen", default=chinh_sach.NGUONG_TO_MAC_DINH,
        min=0.01, max=1.0, subtype="FACTOR", precision=2,
        description="A map covering at least this much of the frame is "
                    "never shrunk past 1/2, whatever the two conditions "
                    "say.\n"
                    "Map phu tu ngan nay khung hinh tro len thi khong bao "
                    "gio bi ha qua 1/2, du hai dieu kien co dong y den may")

    san_duoi: IntProperty(
        name="Never below", default=chinh_sach.SAN_TUYET_DOI,
        min=chinh_sach.SAN_TUYET_DOI, max=4096,
        description="A map's long edge is never taken below this. A step "
                    "that would go under it backs off one step. 512 is a "
                    "hard floor - this can only be raised.\n"
                    "Canh lon cua map khong bao gio bi ha duoi muc nay. Bac "
                    "nao vuot qua thi lui lai mot bac. 512 la san cung - o "
                    "nay chi chinh LEN duoc")

    canh_ep: EnumProperty(
        name="Force to", items=_CO_EP, default="1024",
        description="Long edge every map is forced down to.\n"
                    "Canh lon ma moi map bi ep xuong")

    bo_qua: StringProperty(
        name="Keep at full size", default="",
        description="Image names to leave alone, separated by commas.\n"
                    "Ten cac anh de nguyen, cach nhau bang dau phay")

    bao_cao: StringProperty(name="", default="")


def dang_ky():
    bpy.utils.register_class(DPRAMCHILL_Props)
    bpy.types.Scene.dp_ramchill = PointerProperty(type=DPRAMCHILL_Props)


def go():
    del bpy.types.Scene.dp_ramchill
    bpy.utils.unregister_class(DPRAMCHILL_Props)
