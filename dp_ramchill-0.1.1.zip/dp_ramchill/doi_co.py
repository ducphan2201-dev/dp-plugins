# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
"""Lop RA TAY — ha co map ngay truoc khi render, tra lai ngay sau.

=========================================================================
CO CHE, VA SO DO CHUNG MINH NO
=========================================================================
`bpy.types.Image.scale()` doi co tam anh TRONG BO NHO. File tren dia khong
bi dong toi mot byte, va `.blend` chi giu duong dan chu khong giu pixel —
nen `reload()` la du de tra lai nguyen trang.

Do that, Blender 5.2, RTX 3090, 8 tam 4096x4096, render OptiX
(`tools/do_vram.py`, hai vong ra so giong nhau den tung byte):

    khong dung gi        Cycles bao  512,13 MB   (dinh 512,23 MB)
    ha xuong 256         Cycles bao    2,13 MB   (dinh  24,07 MB)

Sau render, ca 8 tam doc lai la 4096x4096.

=========================================================================
DAT MOC O DAU — VA VI SAO KHONG PHAI `render_init`
=========================================================================
`render_pre` / `render_post` no MOI KHUNG HINH; `render_init` /
`render_complete` no mot lan cho ca cong viec render. Nghe thi
init/complete moi la cap dung cho anh doi.

Nhung so do o tren la do bang `render_pre`, va do la cap DA CHUNG MINH.
Nen o day dung `render_pre` de RA TAY, kem mot cai chot "da ra tay roi"
cho no thanh viec vo hai tu khung hinh thu hai tro di, va tra lai o
`render_complete` / `render_cancel`. Duoc ca hai: duong da do, va anh doi
khong bi thao ra lap lai 250 lan.

⛔ BA CAI CHOT AN TOAN, ca ba deu tra loi mot cau: *neu Blender chet giua
render thi map co ket lai o co nho khong?*

  1. `save_pre` — tra lai truoc khi ghi file. Anh nguon FILE thi `.blend`
     khong giu pixel, nhung tra lai truoc khi ghi la mot dong code de
     khoi phai chung minh dieu do lai moi lan Blender doi.
  2. `load_post` — don so ghi chep khi doi file, khong thi ten anh cua
     file cu se di theo sang file moi.
  3. CHI DUNG TOI anh nguon FILE, khong packed, khong dang sua
     (`is_dirty`). Anh packed ma `scale()` roi `reload()` la MAT DU LIEU
     THAT — no khong co file de doc lai.
"""

import bpy

from . import chinh_sach
from . import do_canh

# ten anh -> (w, h) truoc khi ha. Rong = dang khong ra tay.
_TRUOC = {}
_BAO_CAO = {"so_anh": 0, "byte_truoc": 0, "byte_sau": 0, "loi": "",
            "quet_lai": True}

# ⛔ DAU VAN CUA CANH — de RENDER BATCH khong quet di quet lai.
#
# Ducphan render hang loat anh mot lot, va moi lan render la mot lan quet.
# Do duoc tren scene 2,1 trieu tam giac: quet het 2,64 s. Nhan len mot tram
# tam anh la gan nam phut chi de tra loi lai dung cau hoi cu.
#
# Nen truoc khi quet, hoi mot cau RE hon nhieu: co gi doi khong? Neu khong
# thi dung lai ke hoach lan truoc, khong dung toi mot tam giac nao.
#
# ⛔ DAU VAN PHAI OM DU MOI THU LAM DOI KET QUA, va thieu mot thu la addon
# dung ke hoach cu cho mot canh moi — tuc anh ra sai ma khong ai keu. Nen
# no om: ma tran camera, ong kinh, do phan giai, va CA BO SO cua nguoi
# dung. Cai nao khong chac thi cu cho vao: mot dau van rong tay chi ton
# them mot lan quet, con mot dau van thieu la mot tam anh hong.
_VAN = [None]
_KE_HOACH = [None]


def _dau_van(context):
    sc = context.scene
    p = sc.dp_ramchill
    cam = sc.camera
    if cam is None:
        return None
    r = sc.render
    return (
        tuple(round(v, 6) for hang in cam.matrix_world for v in hang),
        getattr(cam.data, "lens", 0.0), getattr(cam.data, "type", ""),
        getattr(cam.data, "sensor_width", 0.0),
        getattr(cam.data, "sensor_fit", ""),
        getattr(cam.data, "shift_x", 0.0), getattr(cam.data, "shift_y", 0.0),
        getattr(cam.data, "ortho_scale", 0.0),
        r.resolution_x, r.resolution_y, r.resolution_percentage,
        r.pixel_aspect_x, r.pixel_aspect_y,
        p.che_do, p.moc_tu_dong,
        # ⛔ BON O MOC CHI VAO DAU VAN KHI NGUOI DUNG TU GO. Bat `moc_tu_dong`
        # thi ke hoach do tu canh, bon o nay khong tham gia mot phep tinh
        # nao — de chung trong dau van la moi lan bang ghi so vua do NGUOC
        # lai vao o (de nguoi dung nhin thay so THAT thay vi so mac dinh)
        # lai lam dau van doi, va lan render ngay sau do quet lai tu dau.
        (0, 0, 0, 0) if p.moc_tu_dong
        else (p.moc_1, p.moc_2, p.moc_3, p.moc_4),
        p.du_phong, p.san_duoi, p.canh_ep, p.bo_qua, p.nguong_to,
        len(sc.objects),
        # co cua tung tam anh: doi mot tam la ke hoach cu het dung
        tuple(sorted((i.name, i.size[0], i.size[1])
                     for i in bpy.data.images if i.type == "IMAGE")),
    )


def dang_ra_tay():
    return bool(_TRUOC)


def bao_cao_lan_cuoi():
    return dict(_BAO_CAO)


# ---------------------------------------------------------------------------
def lap_ke_hoach(context, dung_van=False):
    """Quet scene + hoi lop quyet dinh. Tra ve (ket_qua, ghi_chu).

    `dung_van=True` cho phep dung lai ke hoach lan truoc khi dau van cua
    canh khong doi — duong nay danh cho RENDER BATCH. Nut `Scan Scene`
    KHONG di duong nay: nguoi dung bam Scan la ho muon do lai that.
    """
    if dung_van:
        van = _dau_van(context)
        if van is not None and van == _VAN[0] and _KE_HOACH[0] is not None:
            _BAO_CAO["quet_lai"] = False
            return _KE_HOACH[0], {"dung_lai_ke_hoach_cu": True}
    p = context.scene.dp_ramchill
    anh, ghi_chu = do_canh.quet_scene(context)

    # BON MOC: do tu chinh canh nay, hay lay so nguoi dung go?
    moc = (p.moc_1, p.moc_2, p.moc_3, p.moc_4)
    if p.moc_tu_dong:
        m = chinh_sach.moc_tu_canh(
            [a.get("khoang_cach") for a in anh])
        if m is not None:
            moc = m
            ghi_chu["moc_da_do"] = m
        else:
            ghi_chu["moc_khong_do_duoc"] = True

    ket_qua = chinh_sach.quyet_dinh(
        anh,
        che_do=p.che_do,
        moc=moc,
        canh_ep=int(p.canh_ep),
        san_duoi=int(p.san_duoi),
        du_phong=p.du_phong,
        nguong_to=p.nguong_to,
        bo_qua=set(t.strip() for t in p.bo_qua.split(",") if t.strip()),
    )
    if dung_van:
        _VAN[0] = _dau_van(context)
        _KE_HOACH[0] = ket_qua
        _BAO_CAO["quet_lai"] = True
    return ket_qua, ghi_chu


def _ha_co(ket_qua):
    _TRUOC.clear()
    so = 0
    for k in ket_qua:
        if not k["doi"]:
            continue
        img = bpy.data.images.get(k["ten"])
        if img is None or img.source != "FILE" or img.packed_file:
            continue
        if img.is_dirty:
            continue
        _TRUOC[img.name] = (img.size[0], img.size[1])
        img.scale(k["moi_w"], k["moi_h"])
        so += 1
    return so


def tra_lai():
    """Tra moi tam ve co goc. Goi duoc nhieu lan, lan thu hai vo hai."""
    for ten in list(_TRUOC):
        img = bpy.data.images.get(ten)
        if img is not None:
            try:
                img.reload()
            except RuntimeError:
                pass
    _TRUOC.clear()


# ---------------------------------------------------------------------------
# Handler
# ---------------------------------------------------------------------------
@bpy.app.handlers.persistent
def _truoc_render(scene, *a):
    if _TRUOC:
        return                      # khung hinh thu hai tro di: khong lam gi
    p = getattr(scene, "dp_ramchill", None)
    if p is None or p.che_do == chinh_sach.CHE_DO_TAT:
        return
    _BAO_CAO["loi"] = ""
    try:
        # `dung_van=True`: render batch thi khong quet lai canh khong doi
        ket_qua, _ = lap_ke_hoach(bpy.context, dung_van=True)
    except Exception as e:                       # noqa: BLE001
        # ⛔ MOT NGOAI LE O DAY LA HONG CA LAN RENDER. Nuot no, ghi lai, va
        # de scene nguyen ven — mat VRAM con hon mat ban render. Ducphan
        # render batch qua dem; mot lan quet hong khong duoc phep lam dut
        # ca me anh.
        _BAO_CAO["loi"] = "%s: %s" % (type(e).__name__, e)
        print("[DP_RAMchill] quet that bai, giu nguyen scene:",
              _BAO_CAO["loi"])
        return
    truoc, sau, _ = chinh_sach.tong_ket(ket_qua)
    try:
        so = _ha_co(ket_qua)
    except Exception as e:                       # noqa: BLE001
        # Cung ly do nhu tren, va o day con nang hon: `_ha_co` da doi mot
        # so tam anh roi moi chet giua chung. Tra lai het truoc khi bo cuoc.
        _BAO_CAO["loi"] = "%s: %s" % (type(e).__name__, e)
        print("[DP_RAMchill] ha co that bai, tra lai het:", _BAO_CAO["loi"])
        tra_lai()
        return
    _BAO_CAO.update(so_anh=so, byte_truoc=truoc, byte_sau=sau)
    if so:
        print("[DP_RAMchill] ha %d map: %s -> %s" % (
            so, chinh_sach.doc_byte(truoc), chinh_sach.doc_byte(sau)))


@bpy.app.handlers.persistent
def _xong_render(scene, *a):
    tra_lai()


@bpy.app.handlers.persistent
def _truoc_khi_ghi(*a):
    tra_lai()


@bpy.app.handlers.persistent
def _sau_khi_mo(*a):
    _TRUOC.clear()


_CAP = (
    ("render_pre", _truoc_render),
    ("render_complete", _xong_render),
    ("render_cancel", _xong_render),
    ("save_pre", _truoc_khi_ghi),
    ("load_post", _sau_khi_mo),
)


def dang_ky():
    for ten, ham in _CAP:
        ds = getattr(bpy.app.handlers, ten)
        if ham not in ds:
            ds.append(ham)


def go():
    tra_lai()
    for ten, ham in _CAP:
        ds = getattr(bpy.app.handlers, ten)
        if ham in ds:
            ds.remove(ham)
