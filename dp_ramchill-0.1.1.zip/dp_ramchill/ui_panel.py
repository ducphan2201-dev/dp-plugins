# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
"""Bang ben phai — View3D > N > DP_RAMchill.

BON LUAT CUA BANG, ca bon deu da tra gia o cac addon truoc:
  * MOI HANG MOT NUT CHU. Thanh ben rong ~420 px; nhet hai nut mot hang la
    chia doi va cat chu.
  * KHONG `scale_y` cho hang chu.
  * O KHONG DUNG THI LAM MO (`active = False`), KHONG AN. An di la nguoi
    dung bao "tinh nang bien mat".
  * NHOM IT DUNG THI `DEFAULT_CLOSED`. Bang dai qua man hinh = nguoi dung
    bao "khong co tinh nang do".

Chu tren bang la TIENG ANH — addon ban ra.
"""

import bpy
from bpy.types import Panel

from . import chinh_sach
from . import doi_co


class _Nen:
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "DP_RAMchill"


class DPRAMCHILL_PT_chinh(_Nen, Panel):
    bl_idname = "DPRAMCHILL_PT_chinh"
    bl_label = "DP_RAMchill"

    def draw(self, context):
        lo = self.layout
        p = context.scene.dp_ramchill

        lo.prop(p, "che_do", text="")

        if p.che_do == chinh_sach.CHE_DO_EP_CO:
            lo.prop(p, "canh_ep")
        elif p.che_do == chinh_sach.CHE_DO_TU_DONG:
            k = lo.box()
            k.label(text="1 - Distance rings", icon="CON_DISTLIMIT")
            k.prop(p, "moc_tu_dong")
            c = k.column(align=True)
            # O KHONG DUNG THI LAM MO, KHONG AN — an di la nguoi dung bao
            # "tinh nang bien mat".
            c.active = not p.moc_tu_dong
            c.prop(p, "moc_1")
            c.prop(p, "moc_2")
            c.prop(p, "moc_3")
            c.prop(p, "moc_4")
            hang = k.row()
            hang.active = not p.moc_tu_dong
            hang.operator("dpramchill.moc_tu_scene",
                          icon="DRIVER_DISTANCE")

            k = lo.box()
            k.label(text="2 - Screen area", icon="MOD_UVPROJECT")
            c = k.column(align=True)
            c.prop(p, "du_phong")
            c.prop(p, "nguong_to")

        lo.separator()
        lo.operator("dpramchill.quet", icon="VIEWZOOM")

        # ⛔ LUAT Ducphan chot 22/08/2026: TU DONG LA CHO ANH TINH. Ke
        # hoach lap MOT LAN, o khung hinh dang dung, nen camera bay qua ca
        # can phong thi khung 250 van dung bo tri cua khung 1. Duong cho
        # animation la EP CO — nguoi dung tu chon mot co, va no dung cho
        # moi khung hinh.
        #
        # Cho nay CO Y khong tu doan xem lan render la tinh hay dong:
        # `frame_start != frame_end` KHONG phai dau hieu cua animation —
        # gan nhu moi file .blend deu de san dai 1-250 du nguoi dung chi
        # bam Render Image. Tu tat Tu dong theo dau hieu do la addon chet
        # lang voi gan nhu moi nguoi dung.
        if (p.che_do == chinh_sach.CHE_DO_TU_DONG
                and context.scene.frame_start != context.scene.frame_end):
            k = lo.box()
            # ⛔ HAI DONG NAY PHAI NGAN. Ban dau chung la "Animation:
            # measured at the first frame only" / "Moving camera - check
            # the last frame too", va anh chup lo ra ca hai deu bi CAT
            # CUT giua chung. Bo do 26 phep khong thay — ban ve gia doc
            # duoc NOI DUNG chu khong do duoc BE RONG.
            k.label(text="Auto is for stills", icon="ERROR")
            k.label(text="Animation: use Force")

        if p.bao_cao:
            k = lo.box()
            for dong in p.bao_cao.split("\n"):
                k.label(text=dong,
                        icon="ERROR" if dong.startswith("!") else "NONE")

        if doi_co.dang_ra_tay():
            lo.separator()
            k = lo.box()
            k.label(text="Maps are shrunk right now", icon="ERROR")
            k.operator("dpramchill.tra_lai", icon="FILE_REFRESH")


class DPRAMCHILL_PT_them(_Nen, Panel):
    bl_idname = "DPRAMCHILL_PT_them"
    bl_parent_id = "DPRAMCHILL_PT_chinh"
    bl_label = "More"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        lo = self.layout
        p = context.scene.dp_ramchill
        lo.active = p.che_do != chinh_sach.CHE_DO_TAT
        lo.prop(p, "san_duoi")
        lo.prop(p, "bo_qua")
        lo.operator("dpramchill.tra_lai", icon="FILE_REFRESH")


_LOP = (DPRAMCHILL_PT_chinh, DPRAMCHILL_PT_them)


def dang_ky():
    for c in _LOP:
        bpy.utils.register_class(c)


def go():
    for c in reversed(_LOP):
        bpy.utils.unregister_class(c)
