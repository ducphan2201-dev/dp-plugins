# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
"""Doc file DXF -> cung mot BanVe ma giao_thuc.py sinh ra.

KHONG import bpy.

VI SAO CO FILE NAY: nua CAD viet bang AutoLISP khong ghi file nhanh duoc. Do
tren VinaCAD 13/08/2026: mot lan (write-line) ton 560 ms va gia dat theo BINH
PHUONG kich thuoc file — ca ban ve 7,6 MB thi khong bao gio xong. Gom bo dem
chi doi duoc vai lan roi vap tran khac (strcat cung dat theo binh phuong).

Nen bo xuat C++ CUA CHINH PHAN MEM CAD lam viec ghi, con AutoLISP chi con ghi
vai KB danh sach handle cua phan da chon. Doc DXF la cai gia phai tra cho viec
do — va no doi lai them mot thu: addon doc duoc file DXF bat ky, khong can cai
gi ben CAD.

Dau ra la giao_thuc.BanVe y het, nen phang_hoa.py va dung_canh.py khong phai
sua mot dong.
"""

import math

from . import giao_thuc
from .giao_thuc import BanVe, Block, ChuaGhiXong, Layer, LoiDocFile

# ---------------------------------------------------------------------------
# Ma nhom DXF dung toi
# ---------------------------------------------------------------------------
# DXF van ban la tung CAP dong: dong le la ma nhom (so nguyen), dong chan la
# gia tri. Khong co dau phan cach nao khac, nen doc lech mot dong la lech het.

_BANG_MA_LUI = ("utf-8", "cp1258", "cp1252", "latin-1")

# Ma nhom mang so thuc. Ma khac de nguyen chuoi — doi het sang so la chet o
# nhung truong nhu ten layer "123".
_MA_THUC = frozenset(
    list(range(10, 60)) + list(range(110, 150)) + list(range(210, 240))
    + list(range(1010, 1060))
)
_MA_NGUYEN = frozenset(
    list(range(60, 80)) + list(range(90, 100)) + list(range(160, 180))
    + list(range(270, 290)) + list(range(370, 390)) + list(range(400, 410))
)


def _giai_ma(raw):
    for ma in _BANG_MA_LUI:
        try:
            return raw.decode(ma)
        except (UnicodeDecodeError, LookupError):
            continue
    return raw.decode("latin-1", "replace")


def doc_cap(raw):
    """bytes cua file DXF -> list[(ma, gia_tri)]."""
    # DXF nhi phan bat dau bang chuoi nay. No KHONG doc duoc bang duong nay, va
    # bao ro con hon de nguoi dung nhin mot canh rong khong hieu vi sao.
    # Ban ve .dwg tro tay nham vao day (nguoi dung doi duoi file, hoac CAD ghi
    # ra .dwg): tra ve dung cau nhu ben .cadblend, khong phai "khong thay
    # SECTION nao" o cuoi ham.
    if giao_thuc.la_dwg(raw):
        raise LoiDocFile(giao_thuc.LOI_DWG)
    if raw.startswith(b"AutoCAD Binary DXF"):
        raise LoiDocFile(
            "Binary DXF is not supported yet. Export the drawing again as "
            "ASCII DXF.")

    van_ban = _giai_ma(raw)
    dong = van_ban.splitlines()
    cap = []
    i = 0
    n = len(dong)
    while i + 1 < n:
        s = dong[i].strip()
        i += 1
        if not s:
            continue
        try:
            ma = int(s)
        except ValueError:
            # Rac giua chung: bo qua dong nay chu khong bo ca file. Doc DXF that
            # bao gio cung gap it nhat mot thu ngoai du kien.
            continue
        gt = dong[i]
        i += 1
        if ma in _MA_THUC:
            try:
                gt = float(gt.strip())
            except ValueError:
                gt = 0.0
        elif ma in _MA_NGUYEN:
            try:
                gt = int(float(gt.strip()))
            except ValueError:
                gt = 0
        else:
            gt = gt.strip()
        cap.append((ma, gt))
    return cap


# ---------------------------------------------------------------------------
# Gom cap thanh tung thuc the
# ---------------------------------------------------------------------------

class _Tho:
    """Mot thuc the tho: ma nhom 0 kem toan bo cap di theo no."""

    __slots__ = ("loai", "cap")

    def __init__(self, loai):
        self.loai = loai
        self.cap = []

    def mot(self, ma, mac_dinh=None):
        for m, v in self.cap:
            if m == ma:
                return v
        return mac_dinh

    def diem(self, goc=10):
        return (self.mot(goc, 0.0), self.mot(goc + 10, 0.0),
                self.mot(goc + 20, 0.0))

    def day(self):
        """Vector day (210/220/230). Thieu thi la truc Z."""
        if self.mot(210) is None:
            return (0.0, 0.0, 1.0)
        return (self.mot(210, 0.0), self.mot(220, 0.0), self.mot(230, 1.0))


def _tach(cap):
    """list cap -> list[_Tho], moi lan gap ma 0 la mo mot thuc the moi."""
    ra = []
    hien = None
    for ma, gt in cap:
        if ma == 0:
            hien = _Tho(gt)
            ra.append(hien)
        elif hien is not None:
            hien.cap.append((ma, gt))
    return ra


# ---------------------------------------------------------------------------
# Doi mot thuc the tho sang tuple ma phang_hoa an
# ---------------------------------------------------------------------------

def _dinh_lwpol(tho):
    """LWPOLYLINE: cac cap 10/20 xen ke, 42 (bulge) chi co khi khac 0.

    Phai bam theo THU TU cap, khong duoc gom rieng tung ma: gap 10 la mo mot
    dinh moi, bulge mac dinh 0. Gom rieng thi bulge cua dinh nay nhay sang dinh
    khac va cung tron nam nham cho — cung cai bay da xu ly o nua LISP.
    """
    dinh = []
    x = y = None
    bulge = 0.0
    for ma, gt in tho.cap:
        if ma == 10:
            if x is not None:
                dinh.append((x, y, bulge))
            x, y, bulge = gt, 0.0, 0.0
        elif ma == 20 and x is not None:
            y = gt
        elif ma == 42 and x is not None:
            bulge = gt
    if x is not None:
        dinh.append((x, y, bulge))
    return dinh


def _ent(tho, lay_idx, h):
    loai = tho.loai

    if loai == "LINE":
        return ("LINE", lay_idx, h, tho.diem(10), tho.diem(11))

    if loai == "CIRCLE":
        return ("CIRCLE", lay_idx, h, tho.diem(10), tho.mot(40, 0.0),
                tho.day())

    if loai == "ARC":
        # DXF ghi goc cua ARC bang DO. Nua LISP ghi bang RADIAN. phang_hoa an
        # radian — quen doi la cung nam sai cho ma khong bao gi.
        return ("ARC", lay_idx, h, tho.diem(10), tho.mot(40, 0.0),
                math.radians(tho.mot(50, 0.0)),
                math.radians(tho.mot(51, 360.0)), tho.day())

    if loai == "POINT":
        return ("POINT", lay_idx, h, tho.diem(10))

    if loai == "ELLIPSE":
        # Rieng ELLIPSE thi 41/42 la RADIAN san (khac ARC). Doi them lan nua la
        # sai.
        return ("ELLIPSE", lay_idx, h, tho.diem(10), tho.diem(11),
                tho.mot(40, 1.0), tho.mot(41, 0.0),
                tho.mot(42, 2.0 * math.pi), tho.day())

    if loai == "LWPOLYLINE":
        co = tho.mot(70, 0) or 0
        return ("LWPOL", lay_idx, h, bool(co & 1), tho.mot(38, 0.0),
                tho.day(), _dinh_lwpol(tho))

    if loai == "INSERT":
        return ("INS", lay_idx, h, tho.mot(2, ""), tho.diem(10),
                tho.mot(41, 1.0), tho.mot(42, 1.0), tho.mot(43, 1.0),
                math.radians(tho.mot(50, 0.0)), tho.day())

    return None


# ---------------------------------------------------------------------------

def doc_byte(raw, chi_handle=None):
    """raw: bytes cua file DXF.

    chi_handle: tap handle (chuoi hoa) chi giu lai. None = giu tat ca.
      Loc ngay o day chu khong loc sau: day la cach giu duoc yeu cau "chi dong
      bo phan da chon" trong khi van de CAD xuat ca ban ve bang bo xuat C++.
      Loc CHI ap cho thuc the o ENTITIES; ruot block thi khong, vi giu mot
      INSERT ma vut ruot cua no la ra mot cho trong.
    """
    bv = BanVe()
    bv.version = "dxf"
    tho_ds = _tach(doc_cap(raw))
    if not tho_ds:
        raise LoiDocFile("Empty file, or not an ASCII DXF file.")

    # DXF ket bang mot nhom 0/EOF. Thieu no = phan mem CAD CON DANG GHI.
    #
    # Day la vai tro ma dong "END" dam nhiem ben duong .cadblend, chi khac la
    # DXF co san trong dac ta. Khong kiem thi Blender doc mot file viet do dang
    # va dung ra nua canh, roi lan sau doc lai ra canh khac — dung kieu chong
    # cheo ban moi ban cu.
    if tho_ds[-1].loai != "EOF":
        raise ChuaGhiXong("DXF chua co EOF")

    chi_muc = {}          # ten layer -> chi so

    def lay_idx(ten):
        if not ten:
            ten = "0"
        i = chi_muc.get(ten)
        if i is None:
            i = len(bv.layers)
            chi_muc[ten] = i
            bv.layers.append(Layer(ten, 7))
        return i

    khu = None            # HEADER / TABLES / BLOCKS / ENTITIES
    khoi = None           # block dang mo
    poly = None           # POLYLINE dang gom VERTEX
    poly_dinh = None
    thay_khu = False

    for tho in tho_ds:
        loai = tho.loai

        if loai == "SECTION":
            khu = tho.mot(2, "")
            thay_khu = True
            continue
        if loai == "ENDSEC":
            khu = None
            continue

        if khu == "TABLES":
            # Mau layer nam o day. Am = layer dang tat; phang_hoa chi can con
            # so mau nen lay tri tuyet doi.
            if loai == "LAYER":
                ten = tho.mot(2, "")
                if ten:
                    i = lay_idx(ten)
                    bv.layers[i] = Layer(ten, abs(tho.mot(62, 7) or 7))
            continue

        if khu == "BLOCKS":
            if loai == "BLOCK":
                khoi = Block(tho.mot(2, ""), tho.diem(10))
                bv.blocks[khoi.ten] = khoi
                continue
            if loai == "ENDBLK":
                khoi = None
                continue
        elif khu != "ENTITIES":
            continue

        # --- POLYLINE nang: dinh nam o cac thuc the VERTEX di sau ---------
        if loai == "POLYLINE":
            co = tho.mot(70, 0) or 0
            # Bo qua luoi (16 = polygon mesh, 64 = polyface): chi lam net.
            if co & 16 or co & 64:
                poly = None
                continue
            poly = tho
            poly_dinh = []
            continue
        if loai == "VERTEX" and poly is not None:
            co = tho.mot(70, 0) or 0
            if not (co & 16):     # bo dinh dieu khien cua spline-fit
                p = tho.diem(10)
                poly_dinh.append((p[0], p[1], p[2], tho.mot(42, 0.0)))
            continue
        if loai == "SEQEND" and poly is not None:
            co = poly.mot(70, 0) or 0
            ent = ("POLY", lay_idx(poly.mot(8, "0")), str(poly.mot(5, "0")),
                   bool(co & 1), poly.day(), poly_dinh)
            if khoi is not None:
                khoi.ents.append(ent)
            elif chi_handle is None or ent[2].upper() in chi_handle:
                bv.ents.append(ent)
            poly = None
            continue

        h = str(tho.mot(5, "0"))
        ent = _ent(tho, lay_idx(tho.mot(8, "0")), h)
        if ent is None:
            # Loai chua lam (TEXT/MTEXT/DIMENSION/HATCH/SPLINE...). Dem lai
            # chu khong im lang.
            if loai not in ("ENDTAB", "TABLE", "EOF", "CLASS", "VERTEX",
                            "SEQEND", "ATTRIB", "ATTDEF"):
                bv.dong_hong.append((0, "loai la: " + loai))
            continue

        if khoi is not None:
            khoi.ents.append(ent)
        elif chi_handle is None or h.upper() in chi_handle:
            bv.ents.append(ent)

    if not thay_khu:
        raise LoiDocFile("No SECTION found - this file is not a DXF file.")

    bv.so_bao = len(bv.ents)
    return bv


def doc_file(duong_dan, chi_handle=None):
    with open(duong_dan, "rb") as f:
        return doc_byte(f.read(), chi_handle)
