# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
"""Doc file .cadblend do nua CAD ghi ra.

KHONG import bpy — de chay duoc bo kiem ngoai Blender, la cho bat loi parser
nhanh nhat. Moi thu dung cham vao Blender nam o dung_canh.py.

Dinh dang (moi ban ghi mot dong, cac truong cach nhau bang dau cach):

    DPCAD 1
    VER 0.1.0
    CAD <hex>                       <- ACADVER, de biet khach dung CAD nao
    DWG <hex>
    INSUNITS <n>
    L <idx> <hexten> <aci>
    B <hexten> <bx> <by> <bz>       <- mo dinh nghia block
      E ...                            (cac thuc the trong block)
    BEND                            <- dong dinh nghia block
    E ...                           <- thuc the model space
    X <hexkhoa> <hexgiatri>         <- thuoc tinh them cho thuc the LIEN TRUOC
    END <so doi tuong>              <- DAU HIEU GHI XONG

Ten viet duoi dang hex vi ten layer that co dau cach ("VYD - Wall"). Xem phan
dau CAD/dp_cadsync.lsp.

LUAT MO RONG — thu giu cho dinh dang nay con lon them duoc:
  - Ma ban ghi LA khong lam chet lan doc, chi ghi vao `dong_hong`.
  - Khoa `X` la cung vay.
  Nho hai dieu do, nua CAD moi hon van chay duoc voi ban Blender cu.
"""

import os
import zlib

# GIAO UOC voi nua CAD. Doi o day thi phai doi ca dp:out-path trong
# CAD/dp_cadsync.lsp — hai dau khong tu bao nhau duoc.
TEN_FILE = "dp_cadsync_scene.cadblend"


def thu_muc_tam():
    tmp = os.environ.get("TEMP") or os.environ.get("TMP")
    if not tmp:
        # TEMP/TMP la quy uoc cua RIENG Windows. Nua CAD chi chay tren Windows,
        # nhung nua Blender thi khong — va duong lui phai la duong TUYET DOI,
        # neu khong no thanh duong tuong doi tinh tu thu muc lam viec cua
        # Blender va moi thu hong lang le.
        tmp = os.environ.get("TMPDIR") or "/tmp"
    return tmp


# ---------------------------------------------------------------------------
# CHON NGUON — chi duoc co MOT
# ---------------------------------------------------------------------------
# Tu khi co duong nhanh, nua CAD ghi ra MOT TRONG HAI dang:
#   dp_cadsync_<dau>.dxf        do chinh phan mem CAD ghi (duong nhanh)
#   dp_cadsync_scene.cadblend   do AutoLISP ghi (duong lui, cham)
#
# Ca hai deu nam trong %TEMP% va deu song lau. Neu Blender cu thay file nao
# doi thi doc file do, no se nhay qua nhay lai giua ban moi va ban cu — dung
# cai "chong cheo ban moi ban cu" ma Ducphan bao.
#
# Luat: chi lay file MOI NHAT, va sau khi nhap xong thi DON HET nhung file
# nguon con lai. Da don thi khong con gi de nham nua.

def tim_nguon(thu_muc=None):
    """Tra ve (duong_dan, danh_sach_file_cu). None neu chua co file nao."""
    tm = thu_muc or thu_muc_tam()
    ds = []
    try:
        for ten in os.listdir(tm):
            t = ten.lower()
            if t == TEN_FILE or (t.startswith("dp_cadsync_")
                                 and t.endswith(".dxf")):
                p = os.path.join(tm, ten)
                try:
                    ds.append((os.stat(p).st_mtime, p))
                except OSError:
                    pass
    except OSError:
        return None, []
    if not ds:
        return None, []
    ds.sort()
    moi = ds[-1][1]
    return moi, [p for _, p in ds[:-1]]


def don_nguon_cu(giu, ds_cu):
    """Xoa cac file nguon khong dung toi. Loi khi xoa thi bo qua."""
    for p in ds_cu:
        if os.path.normcase(p) == os.path.normcase(giu):
            continue
        try:
            os.remove(p)
        except OSError:
            # File dang bi giu (phan mem quet, hoac CAD chua nha). Khong sao:
            # lan sau no van cu hon file moi nen khong bao gio duoc chon.
            pass


def duong_mac_dinh():
    tmp = os.environ.get("TEMP") or os.environ.get("TMP")
    if not tmp:
        # TEMP/TMP la quy uoc cua RIENG Windows. Nua CAD chi chay tren Windows,
        # nhung nua Blender thi khong — va duong lui phai la duong TUYET DOI,
        # neu khong no thanh duong tuong doi tinh tu thu muc lam viec cua
        # Blender va moi thu hong lang le.
        tmp = os.environ.get("TMPDIR") or "/tmp"
    return os.path.join(tmp, TEN_FILE)


# ---------------------------------------------------------------------------
# Giai ma ten
# ---------------------------------------------------------------------------
# Nua LISP hex hoa ten theo UTF-8. Nhung mot so ban CAD tra ve BYTE cua bang ma
# he thong (cp1258 tren Windows tieng Viet) chu khong tra ve ma Unicode — luc
# do chuoi hex khong phai UTF-8 hop le. Chuoi hoi lui de ten xau con hon ca lan
# doc file do vi mot cai ten.
_BANG_MA_LUI = ("utf-8", "cp1258", "cp1252", "latin-1")


def giai_ma_ten(hex_str):
    """Chuoi hex -> ten. Khong bao gio nem loi: ten chi la thu de nhin."""
    try:
        raw = bytes.fromhex(hex_str)
    except ValueError:
        return hex_str
    for ma in _BANG_MA_LUI:
        try:
            return raw.decode(ma)
        except (UnicodeDecodeError, LookupError):
            continue
    return raw.decode("latin-1", "replace")


class LoiDocFile(Exception):
    """File khong phai .cadblend, hoac hong den muc khong doc tiep duoc."""


class ChuaGhiXong(Exception):
    """File co that nhung chua ket bang dong END — CAD dang con viet do dang.

    KHONG phai loi: ben theo doi bat rieng ngoai le nay va cho them mot nhip.
    Gop no vao LoiDocFile la moi lan Sync ban ve lon deu nhay mot thong bao
    loi gia, roi vai giay sau lai chay dung.
    """


class Layer:
    __slots__ = ("ten", "aci")

    def __init__(self, ten, aci):
        self.ten = ten
        self.aci = aci


class Block:
    __slots__ = ("ten", "goc", "ents")

    def __init__(self, ten, goc):
        self.ten = ten
        self.goc = goc          # diem goc cua block (base point)
        self.ents = []


class BanVe:
    def __init__(self):
        self.version = ""
        self.cad = ""
        self.dwg = ""
        self.insunits = 0
        self.layers = []        # list[Layer], tra cuu bang chi so
        self.blocks = {}        # ten -> Block
        self.ents = []          # thuc the model space
        self.mo_rong = {}       # handle -> {khoa: giatri}  (ban ghi X)
        self.so_bao = 0         # con so o dong END
        self.dong_hong = []     # (so dong, ly do) — de bao chu khong de chet

    def ten_layer(self, idx):
        if 0 <= idx < len(self.layers):
            return self.layers[idx].ten
        return "0"

    def mau_layer(self, idx):
        if 0 <= idx < len(self.layers):
            return self.layers[idx].aci
        return 7


# ---------------------------------------------------------------------------
# Doc mot ban ghi thuc the
# ---------------------------------------------------------------------------
# Thuc the la mot tuple: (loai, lay, handle, ...) — dung tuple chu khong phai
# class vi mot ban ve co the co hang chuc nghin cai, va tuple nhe hon nhieu.
#
# Truong `handle` la ma dinh danh trong ban ve, "0" khi ban ve khong cho.
# Chua dung toi o v0.1; no co mat de ban sau lam dong bo TANG DAN.
#
# LINE     ("LINE",    lay, h, (x1,y1,z1), (x2,y2,z2))
# CIRCLE   ("CIRCLE",  lay, h, tam, r, ext)
# ARC      ("ARC",     lay, h, tam, r, a0, a1, ext)
# POINT    ("POINT",   lay, h, p)
# ELLIPSE  ("ELLIPSE", lay, h, tam, vec_lon, ti_so, a0, a1, ext)
# LWPOL    ("LWPOL",   lay, h, kin, cao_do, ext, [(x, y, bulge), ...])
# POLY     ("POLY",    lay, h, kin, ext, [(x, y, z, bulge), ...])
# INS      ("INS",     lay, h, ten_block, p, sx, sy, sz, goc_xoay, ext)


def _f(t, i):
    return float(t[i])


def _pt(t, i):
    return (float(t[i]), float(t[i + 1]), float(t[i + 2]))


def _doc_ent(t):
    """t = danh sach truong sau chu 'E'. Tra ve tuple thuc the, hoac None."""
    loai = t[0]
    lay = int(t[1])
    h = t[2]

    if loai == "LINE":
        return ("LINE", lay, h, _pt(t, 3), _pt(t, 6))

    if loai == "CIRCLE":
        return ("CIRCLE", lay, h, _pt(t, 3), _f(t, 6), _pt(t, 7))

    if loai == "ARC":
        return ("ARC", lay, h, _pt(t, 3), _f(t, 6), _f(t, 7), _f(t, 8),
                _pt(t, 9))

    if loai == "POINT":
        return ("POINT", lay, h, _pt(t, 3))

    if loai == "ELLIPSE":
        return ("ELLIPSE", lay, h, _pt(t, 3), _pt(t, 6), _f(t, 9),
                _f(t, 10), _f(t, 11), _pt(t, 12))

    if loai == "LWPOL":
        co = int(t[3])
        cao_do = _f(t, 4)
        ext = _pt(t, 5)
        n = int(t[8])
        dinh = []
        i = 9
        for _ in range(n):
            dinh.append((float(t[i]), float(t[i + 1]), float(t[i + 2])))
            i += 3
        # bit 1 cua DXF code 70 = duong khep kin
        return ("LWPOL", lay, h, bool(co & 1), cao_do, ext, dinh)

    if loai == "POLY":
        co = int(t[3])
        ext = _pt(t, 4)
        n = int(t[7])
        dinh = []
        i = 8
        for _ in range(n):
            dinh.append((float(t[i]), float(t[i + 1]), float(t[i + 2]),
                         float(t[i + 3])))
            i += 4
        return ("POLY", lay, h, bool(co & 1), ext, dinh)

    if loai == "INS":
        return ("INS", lay, h, giai_ma_ten(t[3]), _pt(t, 4),
                _f(t, 7), _f(t, 8), _f(t, 9), _f(t, 10), _pt(t, 11))

    return None


# ---------------------------------------------------------------------------

def doc_van_ban(noi_dung):
    """noi_dung: str. Tra ve BanVe."""
    bv = BanVe()
    # NGAN XEP block dang mo, KHONG phai mot bien don.
    #
    # Nua CAD sinh ra B long trong B: gap mot INSERT ben trong dinh nghia block
    # thi no mo dinh nghia cua block con ngay tai do. Giu mot bien don thi
    # BEND cua block con dong luon ca block cha, va moi thuc the con lai cua
    # block cha roi thang ra model space — hinh hoc van "co", chi nam sai cho,
    # nen mat rat lau moi nhin ra.
    ngan_xep = []
    handle_cuoi = None   # de gan ban ghi X vao dung thuc the

    dong_dau = noi_dung.lstrip().split("\n", 1)[0].strip()
    if not dong_dau.startswith("DPCAD"):
        raise LoiDocFile(
            "Khong phai file .cadblend (dong dau: %r)" % dong_dau[:40])

    thay_end = False

    for so, dong in enumerate(noi_dung.splitlines(), 1):
        dong = dong.strip()
        if not dong:
            continue
        t = dong.split(" ")
        ma = t[0]

        try:
            if ma == "E":
                ent = _doc_ent(t[1:])
                if ent is None:
                    bv.dong_hong.append((so, "loai la: " + t[1]))
                    handle_cuoi = None
                else:
                    handle_cuoi = ent[2]
                    if ngan_xep:
                        ngan_xep[-1].ents.append(ent)
                    else:
                        bv.ents.append(ent)

            elif ma == "L":
                idx = int(t[1])
                # Chi so tu nua LISP luon tang deu tu 0. Van chen cho trong neu
                # co lo hong: doc theo chi so ma tin vao thu tu la mot ngay nao
                # do lech mot cai va MOI layer ve sau mang ten sai.
                while len(bv.layers) <= idx:
                    bv.layers.append(Layer("0", 7))
                bv.layers[idx] = Layer(giai_ma_ten(t[2]), int(t[3]))

            elif ma == "B":
                khoi = Block(giai_ma_ten(t[1]), _pt(t, 2))
                bv.blocks[khoi.ten] = khoi
                ngan_xep.append(khoi)
                handle_cuoi = None

            elif ma == "BEND":
                if ngan_xep:
                    ngan_xep.pop()
                else:
                    bv.dong_hong.append((so, "BEND thua"))
                handle_cuoi = None

            elif ma == "X":
                # Ban ghi mo rong. Khoa la thi VAN NHAN va cat vao mo_rong —
                # cho ben dung tu quyet, dung tu vut o day.
                if handle_cuoi and handle_cuoi != "0":
                    bv.mo_rong.setdefault(handle_cuoi, {})[
                        giai_ma_ten(t[1])] = giai_ma_ten(t[2])

            elif ma == "VER":
                bv.version = t[1]
            elif ma == "CAD":
                bv.cad = giai_ma_ten(t[1])
            elif ma == "DWG":
                bv.dwg = giai_ma_ten(t[1])
            elif ma == "INSUNITS":
                bv.insunits = int(t[1])
            elif ma == "END":
                bv.so_bao = int(t[1])
                thay_end = True
            elif ma == "DPCAD":
                pass
            else:
                bv.dong_hong.append((so, "ma la: " + ma))

        except (ValueError, IndexError) as e:
            # Mot dong hong KHONG duoc lam hong ca lan Sync: ban ve 38.000 doi
            # tuong ma vut het vi mot dong loi thi nguoi dung khong con duong
            # nao lan ra dong nao. Ghi lai roi di tiep.
            bv.dong_hong.append((so, "%s: %s" % (type(e).__name__, e)))

    if not thay_end:
        raise ChuaGhiXong("thieu dong END")

    for khoi in ngan_xep:
        bv.dong_hong.append((0, "thieu BEND cho block " + khoi.ten))

    return bv


def doc_byte(raw):
    """raw: bytes tho tu file. Tu nhan goi nen."""
    # DUONG DE NGO CHO SAU NAY: hom nay nua CAD la AutoLISP nen khong nen duoc
    # (khong co zlib trong AutoLISP). Ngay nao viet bo xuat bang .NET/ObjectARX
    # thi no nen duoc, va nhanh nay nhan ra ngay — khong phai doi hai dau cung
    # mot luc.
    if not raw.startswith(b"DPCAD"):
        try:
            raw = zlib.decompress(raw)
        except zlib.error:
            pass  # de doc_van_ban bao loi cho ro rang
    # Phan ten da hex hoa nen than file luon la ASCII: 'replace' chi cham vao
    # rac, khong bao gio cham vao so.
    return doc_van_ban(raw.decode("utf-8", "replace"))


def doc_file(duong_dan):
    with open(duong_dan, "rb") as f:
        return doc_byte(f.read())
