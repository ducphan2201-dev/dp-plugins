# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
"""Phep bien hinh CAD -> toa do that. KHONG import bpy (de kiem ngoai Blender).

Ba viec: he truc tuy y (OCS), cung tron tu bulge, va ma tran cho INSERT.
"""

import math

# ---------------------------------------------------------------------------
# HE TRUC TUY Y (Arbitrary Axis Algorithm)
# ---------------------------------------------------------------------------
# CIRCLE / ARC / LWPOLYLINE khong luu toa do that: chung luu toa do PHANG trong
# mot mat phang rieng, kem mot vector day (DXF code 210) cho biet mat phang do
# quay huong nao. Bo qua vector day thi 99% ban ve van dung — vi no thuong la
# (0,0,1) — roi mot ngay gap doi tuong da bi LAY DOI XUNG (vector day thanh
# (0,0,-1)) va rieng no ra nam nguoc, khong bao gi.
#
# Thuat toan nay la cach DXF chot mot he truc tu vector day. Nguong 1/64 khong
# phai con so lam tron cho dep — no nam trong dac ta, doi la lech voi CAD.

_NGUONG = 1.0 / 64.0


def _chuan_hoa(v):
    d = math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2])
    if d < 1e-12:
        return (0.0, 0.0, 1.0)
    return (v[0] / d, v[1] / d, v[2] / d)


def _tich_co_huong(a, b):
    return (a[1] * b[2] - a[2] * b[1],
            a[2] * b[0] - a[0] * b[2],
            a[0] * b[1] - a[1] * b[0])


def he_truc(ext):
    """Vector day -> ba truc (ax, ay, az) cua he toa do phang."""
    az = _chuan_hoa(ext)
    if abs(az[0]) < _NGUONG and abs(az[1]) < _NGUONG:
        ax = _tich_co_huong((0.0, 1.0, 0.0), az)
    else:
        ax = _tich_co_huong((0.0, 0.0, 1.0), az)
    ax = _chuan_hoa(ax)
    ay = _chuan_hoa(_tich_co_huong(az, ax))
    return ax, ay, az


def ra_toa_do_that(p, truc):
    """Diem trong he phang -> toa do that."""
    ax, ay, az = truc
    return (p[0] * ax[0] + p[1] * ay[0] + p[2] * az[0],
            p[0] * ax[1] + p[1] * ay[1] + p[2] * az[1],
            p[0] * ax[2] + p[1] * ay[2] + p[2] * az[2])


# ---------------------------------------------------------------------------
# CHIA NHO CUNG TRON
# ---------------------------------------------------------------------------
# So doan tinh theo SAI SO CUNG (khoang ho lon nhat giua day cung va cung
# that), khong theo "moi doan bao nhieu do".
#
# VI SAO: mot ban ve noi that co ca goc luon R2 lan cung tuong R5000. Chia deu
# theo goc thi cai R2 nhan 40 doan thua thai con cai R5000 van gay khuc. Chia
# theo sai so thi ca hai deu min vua du, va con so nguoi dung chinh ("do min")
# la mot do dai tinh bang don vi ban ve — thu ho hieu ngay.

# TRAN DOAN — mot cai chan, khong phai mot con so cho dep.
#
# Khong co tran thi "do min = 0.001" tren mot cung R5000 doi 4.970 doan cho
# MOT duong, va ban ve co hang nghin duong nhu the.
#
# NHUNG TRAN NAY BE GAY LOI HUA cua o "Arc detail": khi cham tran, khoang ho
# thuc te LON HON con so nguoi dung dat, va khong co gi bao. Da chon 1024 vi
# no du cho moi thiet lap hop ly (R5000 voi do min 0.05 mm can 703 doan); chi
# nhung gia tri cuc doan moi cham toi. Ranh gioi nay duoc khoa bang phep do
# `kiem_sai_so_cung` — cho nao no bao "cham tran" la cho do o Arc detail dang
# noi khong dung.
TRAN_DOAN = 1024


def so_doan(r, goc, sai_so, toi_da=TRAN_DOAN):
    goc = abs(goc)
    if r <= 0.0 or goc <= 0.0:
        return 1
    if sai_so <= 0.0 or sai_so >= r:
        n = 8
    else:
        # sai_so = r(1 - cos(nua goc moi doan))  ->  goc moi doan
        buoc = 2.0 * math.acos(1.0 - sai_so / r)
        if buoc <= 1e-9:
            n = toi_da
        else:
            n = int(math.ceil(goc / buoc))
    return max(2, min(int(n), toi_da))


def diem_cung(tam, r, a0, a1, sai_so):
    """Cac diem tren cung, TINH CA hai dau. Mat phang XY, tam la (x, y)."""
    goc = a1 - a0
    n = so_doan(r, goc, sai_so)
    ra = []
    for i in range(n + 1):
        a = a0 + goc * (i / float(n))
        ra.append((tam[0] + r * math.cos(a), tam[1] + r * math.sin(a)))
    return ra


# ---------------------------------------------------------------------------
# BULGE  ->  CUNG TRON
# ---------------------------------------------------------------------------
# bulge = tan(goc_chan / 4). DUONG SUY RA DUOC DAT TREN DUNG MOT DIEU trong dac
# ta DXF: "bulge DUONG nghia la cung di NGUOC CHIEU KIM DONG HO tu dau nay sang
# dau kia". Moi thu con lai la hinh hoc bat buoc, khong phai lua chon:
#
#   goc = 4*atan(b);  r = L / (2 sin(goc/2));  t = (L/2) * cot(goc/2)
#   tam = trung diem + t * phap tuyen trai
#
# HE QUA DE NHAM: voi day cung huong sang phai, bulge DUONG lam cung vong
# XUONG, khong phai len. Nghe nguoc voi cac hinh minh hoa hay gap, nhung no la
# he qua cua "nguoc chieu kim dong ho" — di nguoc chieu kim dong ho thi tam nam
# ben TRAI huong di, ma tam ben trai thi duong cong phinh sang PHAI.
#
# Bat bien nay duoc khoa bang phep kiem `test_bulge_nguoc_chieu_kim`: xoay diem
# dau quanh tam mot goc `goc` phai ra dung diem cuoi. Neu mot ngay ban ve that
# cho ra goc luon NGUOC BEN, doi dau `goc` o day va phep kiem do se noi ngay.

def diem_tu_bulge(p0, p1, b, sai_so):
    """Hai dinh + bulge -> cac diem TRUNG GIAN (khong gom p0, p1)."""
    if abs(b) < 1e-12:
        return []
    dx = p1[0] - p0[0]
    dy = p1[1] - p0[1]
    L = math.hypot(dx, dy)
    if L < 1e-12:
        return []

    goc = 4.0 * math.atan(b)
    nua = goc / 2.0
    s = math.sin(nua)
    if abs(s) < 1e-12:
        return []
    r = L / (2.0 * s)
    t = (L / 2.0) * (math.cos(nua) / s)

    # Phap tuyen TRAI cua day cung
    nx = -dy / L
    ny = dx / L
    cx = (p0[0] + p1[0]) / 2.0 + t * nx
    cy = (p0[1] + p1[1]) / 2.0 + t * ny

    a0 = math.atan2(p0[1] - cy, p0[0] - cx)
    n = so_doan(abs(r), goc, sai_so)
    ra = []
    for i in range(1, n):
        a = a0 + goc * (i / float(n))
        ra.append((cx + abs(r) * math.cos(a), cy + abs(r) * math.sin(a)))
    return ra


def tam_va_goc_tu_bulge(p0, p1, b):
    """Dung cho phep kiem: tra ve (tam, ban_kinh, goc_chan). None neu thang."""
    if abs(b) < 1e-12:
        return None
    dx = p1[0] - p0[0]
    dy = p1[1] - p0[1]
    L = math.hypot(dx, dy)
    if L < 1e-12:
        return None
    goc = 4.0 * math.atan(b)
    nua = goc / 2.0
    s = math.sin(nua)
    r = L / (2.0 * s)
    t = (L / 2.0) * (math.cos(nua) / s)
    nx = -dy / L
    ny = dx / L
    return ((p0[0] + p1[0]) / 2.0 + t * nx,
            (p0[1] + p1[1]) / 2.0 + t * ny), abs(r), goc


# ---------------------------------------------------------------------------
# ELLIPSE
# ---------------------------------------------------------------------------

def diem_ellipse(tam, vec_lon, ti_so, a0, a1, sai_so):
    """Diem tren cung ellipse, trong he PHANG. vec_lon la (x, y) nua truc lon."""
    ra = math.hypot(vec_lon[0], vec_lon[1])
    rb = ra * ti_so
    if ra < 1e-12:
        return []
    goc_quay = math.atan2(vec_lon[1], vec_lon[0])
    if a1 <= a0:
        a1 += 2.0 * math.pi
    # Lay ban kinh LON de tinh so doan: doan min theo phia cong nhat thi phia
    # kia du min. Lam nguoc lai se de lo mep thang o dau nhon cua ellipse.
    n = so_doan(ra, a1 - a0, sai_so)
    c = math.cos(goc_quay)
    s = math.sin(goc_quay)
    ket = []
    for i in range(n + 1):
        a = a0 + (a1 - a0) * (i / float(n))
        x = ra * math.cos(a)
        y = rb * math.sin(a)
        ket.append((tam[0] + x * c - y * s, tam[1] + x * s + y * c))
    return ket


# ---------------------------------------------------------------------------
# MA TRAN CHO INSERT
# ---------------------------------------------------------------------------
# Ma tran 4x4 la list 16 so, hang truoc (row-major).

def ma_tran_don_vi():
    return [1.0, 0.0, 0.0, 0.0,
            0.0, 1.0, 0.0, 0.0,
            0.0, 0.0, 1.0, 0.0,
            0.0, 0.0, 0.0, 1.0]


def nhan(m, n):
    ra = [0.0] * 16
    for i in range(4):
        for j in range(4):
            ra[i * 4 + j] = (m[i * 4] * n[j] + m[i * 4 + 1] * n[4 + j] +
                             m[i * 4 + 2] * n[8 + j] + m[i * 4 + 3] * n[12 + j])
    return ra


def ap(m, p):
    x, y, z = p
    return (m[0] * x + m[1] * y + m[2] * z + m[3],
            m[4] * x + m[5] * y + m[6] * z + m[7],
            m[8] * x + m[9] * y + m[10] * z + m[11])


def ma_tran_insert(goc_block, diem_chen, sx, sy, sz, goc_xoay, ext):
    """Ma tran dua diem trong DINH NGHIA block ra toa do that.

    Thu tu BAT BUOC (dac ta DXF), doi la sai het khi block bi xoay + co gian
    khong deu:  OCS · T(diem_chen) · Rz(goc) · S(sx,sy,sz) · T(-goc_block)

    Dac biet luu y T(-goc_block) nam TRONG CUNG: diem goc cua block phai bi tru
    TRUOC khi co gian, khong phai sau. Lam nguoc thi block nao co diem goc khac
    (0,0,0) se nhay cho khi ti le khac 1 — ma so block do it nen de lot luooi.
    """
    ax, ay, az = he_truc(ext)
    ocs = [ax[0], ay[0], az[0], 0.0,
           ax[1], ay[1], az[1], 0.0,
           ax[2], ay[2], az[2], 0.0,
           0.0, 0.0, 0.0, 1.0]
    tt = ma_tran_don_vi()
    tt[3], tt[7], tt[11] = diem_chen

    c = math.cos(goc_xoay)
    s = math.sin(goc_xoay)
    rz = [c, -s, 0.0, 0.0,
          s, c, 0.0, 0.0,
          0.0, 0.0, 1.0, 0.0,
          0.0, 0.0, 0.0, 1.0]

    # Ti le 0 lam bep hinh hoc thanh mot diem va khong lay lai duoc. Ban ve that
    # co block ti le 0 do go nham; coi nhu 1 de con nhin thay ma sua.
    sc = ma_tran_don_vi()
    sc[0] = sx if abs(sx) > 1e-12 else 1.0
    sc[5] = sy if abs(sy) > 1e-12 else 1.0
    sc[10] = sz if abs(sz) > 1e-12 else 1.0

    tb = ma_tran_don_vi()
    tb[3] = -goc_block[0]
    tb[7] = -goc_block[1]
    tb[11] = -goc_block[2]

    return nhan(nhan(nhan(nhan(ocs, tt), rz), sc), tb)
