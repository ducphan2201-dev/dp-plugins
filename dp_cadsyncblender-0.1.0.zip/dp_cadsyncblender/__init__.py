# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
bl_info = {
    "name": "DP_CadSyncBlender",
    "author": "Ducphan",
    "version": (0, 1, 0),
    "blender": (3, 0, 0),
    "location": "View3D > Sidebar (N) > DP CAD Sync",
    "description": "Sync 2D linework from AutoCAD / VinaCAD / BricsCAD / "
                   "ZWCAD / GstarCAD into Blender",
    "category": "Import-Export",
}

# ---------------------------------------------------------------------------
# ADDON MIEN PHI — KHONG GAN KHOA BAN QUYEN
# ---------------------------------------------------------------------------
# Ducphan chot 13/08/2026: san pham nay khong khoa. Nghia la:
#   - KHONG co thu muc dp_license/, khong co PRODUCT, khong co lic_gate;
#   - KHONG dang ky vao projects.json cua DP_Hub;
#   - file .cadblend la van ban thuong, khong nen khong ma hoa.
# Dung "lam cho giong cac addon khac" ma gan khoa vao — do la mot buoc lui.
# Truong hop tuong tu da co: DP-OptimizeRender.

import os
import traceback

import bpy
from bpy.app.handlers import persistent

from . import doc_dxf, dung_canh, giao_thuc, phang_hoa

# Trang thai cua bo canh file. De o cap module chu khong tren Scene: day la
# chuyen cua PHIEN LAM VIEC, khong phai cua file .blend — luu vao .blend thi mo
# file cu ra la Blender tuong minh vua nhan duoc mot ban Sync tu nam ngoai.
_canh = {"mtime": None, "size": None, "cho": 0}
NHIP = 1.0      # giay giua hai lan ngo file


# ---------------------------------------------------------------------------
# Thuoc tinh
# ---------------------------------------------------------------------------

class DPCAD_Props(bpy.types.PropertyGroup):
    tu_dong: bpy.props.BoolProperty(
        name="Auto sync",
        description="Watch the export file and rebuild automatically after "
                    "each DPSYNC in CAD",
        default=True,
    )
    # TEN VA MO TA PHAI NOI RO DAY KHONG PHAI CHO NHAP BAN VE. Ten cu la
    # "File", va mot khach dung BricsCAD da tro no vao chinh file .dwg cua ho —
    # doc mot chu "File" ngay duoi dong "In CAD: type DPSYNC" thi doan the la
    # dung. Hop chon file cua Blender khong loc duoi duoc tu mot StringProperty,
    # nen cai duy nhat can nhau o day la CHU.
    duong: bpy.props.StringProperty(
        name="Export file",
        description="Leave this empty. The addon finds the file DPSYNC writes "
                    "by itself. Set it only to read a .cadblend or .dxf from "
                    "somewhere else - a .dwg drawing cannot be read",
        subtype="FILE_PATH",
        default="",
    )
    # ---------------------------------------------------------------------
    # TI LE — cho sai o day la sai DUNG 1000 LAN
    # ---------------------------------------------------------------------
    # Addon nay TAO hinh hoc moi tu nguon ngoai, nen mac dinh la kich thuoc
    # that: 1 Blender Unit = 1 m. Ban ve CAD cua Ducphan ve bang mm, nen he so
    # la 0.001.
    #
    # Quy uoc "1 unit = 1 mm" cua cac addon Blender khac trong CODEAPP KHONG
    # ap vao day: quy uoc do danh cho addon dat thong so len hinh hoc DA CO
    # san. Ap nham chieu nay la loi da tra gia o SU2Blender Sync v3.0.6 —
    # model to len 1000 lan.
    #
    # Va KHONG doc scene.unit_settings.scale_length de suy ti le: nguoi dung bo
    # han o do, no luon la 1.0.
    ti_le: bpy.props.EnumProperty(
        name="Scale",
        description="How drawing units map to Blender units",
        items=[
            ("M", "Drawing mm -> 1 unit = 1 m", "Real-world size (recommended)"),
            ("MM", "Drawing mm -> 1 unit = 1 mm", "Keep raw drawing numbers"),
            ("CM", "Drawing cm -> 1 unit = 1 m", "For drawings made in cm"),
        ],
        default="M",
    )
    do_min: bpy.props.FloatProperty(
        name="Arc detail",
        description="Largest gap allowed between a curve and its segments, "
                    "in drawing units. Smaller = smoother = heavier",
        default=1.0, min=0.001, max=1000.0, soft_max=20.0,
    )
    bao: bpy.props.StringProperty(name="", default="")


HE_SO = {"M": 0.001, "MM": 1.0, "CM": 0.01}


def _props(scene):
    return scene.dp_cadsync


def _duong(pr):
    """Duong dan nguon dang dung, va cac file nguon cu can don.

    Nguoi dung tro tay vao mot file thi theo file do. Khong tro thi tu tim
    file MOI NHAT trong %TEMP% — xem giao_thuc.tim_nguon.
    """
    if pr.duong:
        d = bpy.path.abspath(pr.duong)
        if d:
            return d, []
    moi, cu = giao_thuc.tim_nguon()
    return (moi or giao_thuc.duong_mac_dinh()), cu


# Nhung duoi file doc duoc. Rong = file khong co duoi, van thu doc nhu .cadblend.
DUOI_DOC_DUOC = (".cadblend", ".dxf", "")


def _duong_sai(pr):
    """Duong dan nguoi dung tro tay vao co dung duoc khong. [] = dung duoc.

    VI SAO KIEM O DAY chu khong doi bo doc bao loi: bo doc chi len tieng luc
    NHAP, ma duong tu dong thi mot phut moi nhap mot lan va thong bao loi nam
    goi trong mot dong chu hep. Bang phai noi ngay khi nguoi dung vua chon
    nham file, va noi kem duong di tiep.
    """
    if not pr.duong:
        return []
    d = bpy.path.abspath(pr.duong)
    duoi = os.path.splitext(d)[1].lower()
    if duoi == ".dwg":
        return ["DWG cannot be read.",
                "Type DPSYNC in CAD, then clear this field."]
    if duoi not in DUOI_DOC_DUOC:
        return ["Only .cadblend and .dxf can be read.",
                "Clear this field to use the DPSYNC export."]
    return []


# ---------------------------------------------------------------------------
# Nhap
# ---------------------------------------------------------------------------

def nhap(scene, duong, ds_cu=()):
    """Doc file va dung lai canh. Nem ngoai le de ben goi tu bao.

    ds_cu: cac file nguon cu, xoa SAU khi nhap xong.
    """
    pr = _props(scene)
    # Chon bo doc theo duoi file. Hai duong cho ra CUNG mot BanVe nen moi thu
    # phia sau khong biet va khong can biet no den tu dau.
    if duong.lower().endswith(".dxf"):
        bv = doc_dxf.doc_file(duong)
    elif duong.lower().endswith(".dwg"):
        # Chan TRUOC khi mo file: mot ban ve .dwg thuong nang vai chuc MB, doc
        # het no vao bo nho roi moi noi "khong phai file cua minh" la mot cai
        # dung hinh vo co. Byte dau van duoc kiem o giao_thuc.doc_byte, cho
        # truong hop file .dwg da bi doi duoi.
        raise giao_thuc.LoiDocFile(giao_thuc.LOI_DWG)
    else:
        bv = giao_thuc.doc_file(duong)
    kq = phang_hoa.phang_hoa(bv, sai_so=pr.do_min,
                             ti_le=HE_SO.get(pr.ti_le, 0.001))
    so_ob, so_dinh, so_canh, giu = dung_canh.dung(kq, scene)

    # DON NGUON CU NGAY SAU KHI NHAP XONG, khong som hon: nhap that bai giua
    # chung ma da xoa file thi khong con gi de thu lai.
    #
    # Day la thu chan "chong cheo ban moi ban cu": con file nguon cu nam do la
    # con duong cho bo canh doc lai no.
    if ds_cu:
        giao_thuc.don_nguon_cu(duong, ds_cu)

    bao = "%d layers - %d verts - %d edges" % (so_ob, so_dinh, so_canh)
    # PHAI noi ra: layer bi giu thi khong nhan ban moi, va im lang o day nghia
    # la nguoi dung sua ben CAD roi ngoi doi mai khong thay gi doi.
    if giu:
        bao += " - kept %d (%s)" % (len(giu), ", ".join(sorted(giu)[:3]))
    if kq.thieu_block:
        bao += " - %d missing blocks" % len(kq.thieu_block)
    if bv.dong_hong:
        bao += " - %d skipped lines" % len(bv.dong_hong)
    pr.bao = bao

    # In ra console: khi khach bao "thieu do", dong nay la thu duy nhat noi
    # duoc thieu o khau nao — doc file, hay dung hinh.
    print("[DP_CadSync] %s | CAD=%s | plugin=%s | %s"
          % (bao, bv.cad, bv.version, os.path.basename(duong)))
    if kq.thieu_block:
        print("[DP_CadSync] block khong co dinh nghia:",
              ", ".join(sorted(kq.thieu_block)[:10]))
    return bao


# ---------------------------------------------------------------------------
# Bo canh file
# ---------------------------------------------------------------------------

def _nhip():
    """Chay moi NHIP giay. Tra ve so giay den lan sau, hoac None de dung han."""
    try:
        scene = bpy.context.scene
    except AttributeError:
        scene = bpy.data.scenes[0] if bpy.data.scenes else None
    if scene is None or not hasattr(scene, "dp_cadsync"):
        return NHIP

    pr = _props(scene)
    if not pr.tu_dong:
        return NHIP

    # Dung hinh giua luc nguoi dung dang o Edit Mode se lam Blender bo het thay
    # doi chua thoat cua ho. Doi den khi ve Object Mode — file van con do.
    try:
        if bpy.context.mode != "OBJECT":
            return NHIP
    except AttributeError:
        pass

    duong, ds_cu = _duong(pr)
    try:
        st = os.stat(duong)
    except OSError:
        return NHIP

    moi = (st.st_mtime, st.st_size)
    if _canh["mtime"] is None:
        # Lan dau nhin thay: GHI NHO CHU KHONG NHAP. Bat Blender len ma no tu
        # nap ban ve cua hom qua thi nguoi dung khong hieu chuyen gi.
        _canh["mtime"], _canh["size"] = moi
        _canh["cho"] = 0
        return NHIP

    if moi != (_canh["mtime"], _canh["size"]):
        # File VUA DOI. Chua doc voi: CAD co the con dang ghi do dang. Ghi lai
        # dau moi va treo co cho — nhip sau thay van y nguyen thi moi la xong.
        _canh["mtime"], _canh["size"] = moi
        _canh["cho"] = 1
        return NHIP

    # Den day: file KHONG doi so voi nhip truoc.
    #
    # LOI CU (vá 13/08/2026): nhanh nay tung `cho = 0` roi tra ve luon, tuc la
    # dung cai truong hop can nhap thi lai bo qua. File ghi xong roi nam yen se
    # khong bao gio duoc doc — nguoi dung phai bam Sync Now bang tay, va do la
    # dung nhung gi Ducphan bao. Bam tay chay duoc vi no di duong khac.
    if not _canh["cho"]:
        return NHIP

    _canh["cho"] = 0
    try:
        nhap(scene, duong, ds_cu)
    except giao_thuc.ChuaGhiXong:
        # File nam yen ma van thieu dong END: CAD ghi do dang roi bo giua chung
        # (bi tat, hoac nguoi dung huy). Quen dau di de lan ghi sau con duoc
        # nhan ra — giu dau cu thi file do coi nhu chet han voi bo canh.
        _canh["mtime"] = None
    except giao_thuc.LoiDocFile as e:
        # SAI FILE, khong phai su co. "Error - see System Console" o day la mot
        # cai bay: khach mo Console ra doc mot vet lui Python ma cai can noi
        # chi la "anh dang tro tay vao ban ve, khong phai vao file xuat".
        # Bang chi hien duoc mot dong hep nen cat ngan; cau day in ra Console.
        pr.bao = "Wrong file - see the File field below"
        print("[DP_CadSync]", e)
    except Exception:
        pr.bao = "Error - see System Console"
        traceback.print_exc()
    return NHIP


@persistent
def _sau_khi_mo_file(_dummy):
    # Mo mot file .blend khac la mot phien khac: quen file cu di, khong thi
    # ban Sync tu lan truoc bi coi la "moi" va do vao canh vua mo.
    _canh["mtime"] = None
    _canh["size"] = None
    _canh["cho"] = 0


# ---------------------------------------------------------------------------
# Lenh + bang
# ---------------------------------------------------------------------------

class DPCAD_OT_nhap(bpy.types.Operator):
    """Read the CAD export file now and rebuild the linework"""
    bl_idname = "dp_cadsync.nhap"
    bl_label = "Sync Now"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        pr = _props(context.scene)
        duong, ds_cu = _duong(pr)
        if not os.path.exists(duong):
            self.report({"ERROR"},
                        "No export file yet. Run DPSYNC in your CAD first.")
            return {"CANCELLED"}
        try:
            bao = nhap(context.scene, duong, ds_cu)
        except giao_thuc.ChuaGhiXong:
            self.report({"WARNING"}, "CAD is still writing the file. "
                                     "Try again in a moment.")
            return {"CANCELLED"}
        except giao_thuc.LoiDocFile as e:
            # CHI CAU CHU, KHONG KEM TEN LOP. `type(e).__name__` cua nhanh duoi
            # la de danh cho loi khong luong truoc — nem no vao mat khach thi ho
            # doc duoc "LoiDocFile:" roi khong biet lam gi tiep. Cau nay thi da
            # noi san phai lam gi.
            self.report({"ERROR"}, str(e))
            return {"CANCELLED"}
        except Exception as e:
            traceback.print_exc()
            self.report({"ERROR"}, "%s: %s" % (type(e).__name__, e))
            return {"CANCELLED"}
        # Nho lai dau file de bo canh khong nhap lai ngay cai vua nhap tay.
        try:
            st = os.stat(duong)
            _canh["mtime"], _canh["size"], _canh["cho"] = (
                st.st_mtime, st.st_size, 0)
        except OSError:
            pass
        self.report({"INFO"}, bao)
        return {"FINISHED"}


class DPCAD_OT_xoa_duong(bpy.types.Operator):
    """Forget the file below and use the export written by DPSYNC"""

    bl_idname = "dp_cadsync.xoa_duong"
    bl_label = "Use DPSYNC Export"
    bl_options = {"REGISTER", "UNDO"}

    # VI SAO CAN MOT CAI NUT cho mot viec xoa mot o chu: nguoi dung tro nham
    # vao ban ve .dwg cua ho thi bang bao loi, va cach thoat la BOI TRANG mot o
    # duong dan — mot thao tac khong ai doan ra. Da xay ra that voi mot khach
    # dung BricsCAD ngay 13/08/2026.
    def execute(self, context):
        pr = _props(context.scene)
        pr.duong = ""
        pr.bao = ""
        # Quen dau file cu di: file xuat that co the da nam san trong %TEMP% tu
        # truoc, va giu dau cu thi bo canh coi no la "da nhin thay roi" va
        # khong bao gio nhap.
        _canh["mtime"] = None
        _canh["size"] = None
        _canh["cho"] = 0
        self.report({"INFO"}, "Now reading the DPSYNC export file.")
        return {"FINISHED"}


class DPCAD_OT_nha(bpy.types.Operator):
    """Let sync overwrite the selected objects again.

    Use this when you want fresh linework for a layer you have already built
    on. Whatever you modelled on that object will be replaced.
    """
    bl_idname = "dp_cadsync.nha"
    bl_label = "Release Selected"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return any(ob.get(dung_canh.KHOA_GIU)
                   for ob in context.selected_objects)

    def execute(self, context):
        n = 0
        for ob in context.selected_objects:
            if ob.get(dung_canh.KHOA_GIU):
                del ob[dung_canh.KHOA_GIU]
                n += 1
        # Object van con MAT thi lan Sync sau lai tu dong giu no lai. Noi thang
        # ra, khong de nguoi dung bam nut roi tuong xong.
        con_mat = sum(1 for ob in context.selected_objects
                      if ob.type == "MESH" and len(ob.data.polygons) > 0)
        if con_mat:
            self.report({"WARNING"},
                        "Released %d, but %d still have faces and will be "
                        "kept again. Delete the faces to get fresh linework."
                        % (n, con_mat))
        else:
            self.report({"INFO"}, "Released %d object(s)." % n)
        return {"FINISHED"}


class DPCAD_PT_bang(bpy.types.Panel):
    bl_label = "DP CAD Sync"
    bl_idname = "DPCAD_PT_bang"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "DP CAD Sync"

    def draw(self, context):
        pr = _props(context.scene)
        lo = self.layout

        lo.operator("dp_cadsync.nhap", icon="FILE_REFRESH")
        lo.prop(pr, "tu_dong")
        lo.prop(pr, "ti_le", text="")
        lo.prop(pr, "do_min")

        if pr.bao:
            lo.label(text=pr.bao, icon="INFO")

        # Chi hien khi co viec de lam: bang N-Panel 420px hep, moi hang phai
        # doi cho duoc cho.
        giu = [ob for ob in context.selected_objects
               if ob.get(dung_canh.KHOA_GIU)]
        if giu:
            h = lo.box()
            h.label(text="Kept - sync will not touch these", icon="LOCKED")
            h.operator("dp_cadsync.nha", icon="UNLOCKED")

        hop = lo.box()
        hop.label(text="In CAD: type DPSYNC, select, OK.")
        if not os.path.exists(_duong(pr)[0]):
            hop.label(text="No export file yet.", icon="ERROR")

        # Duong dan de cuoi cung: gan nhu khong ai phai dung toi, vi hai dau da
        # hen san mot cho trong %TEMP%.
        lo.prop(pr, "duong")

        # NOI NGAY KHI CHON NHAM, dung doi den luc nhap. Khong nhet nut vao
        # cung hang voi o duong dan: bang N-Panel 420px chia doi la cat chu.
        sai = _duong_sai(pr)
        if sai:
            h = lo.box()
            for i, d in enumerate(sai):
                h.label(text=d, icon="ERROR" if i == 0 else "NONE")
            h.operator("dp_cadsync.xoa_duong", icon="FILE_REFRESH")


LOP = (DPCAD_Props, DPCAD_OT_nhap, DPCAD_OT_xoa_duong, DPCAD_OT_nha,
       DPCAD_PT_bang)


def register():
    for c in LOP:
        bpy.utils.register_class(c)
    bpy.types.Scene.dp_cadsync = bpy.props.PointerProperty(type=DPCAD_Props)
    if not bpy.app.timers.is_registered(_nhip):
        bpy.app.timers.register(_nhip, first_interval=NHIP, persistent=True)
    if _sau_khi_mo_file not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_sau_khi_mo_file)


def unregister():
    if _sau_khi_mo_file in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_sau_khi_mo_file)
    if bpy.app.timers.is_registered(_nhip):
        bpy.app.timers.unregister(_nhip)
    del bpy.types.Scene.dp_cadsync
    for c in reversed(LOP):
        bpy.utils.unregister_class(c)
