# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
"""Thuc the CAD -> net ve (danh sach diem) theo tung layer.

KHONG import bpy: day la noi de xay ra sai ti le va sai he truc, nen no phai
kiem duoc ngoai Blender. dung_canh.py chi con viec do diem vao mesh.
"""

import math

from . import hinh_hoc as hh

# Duoi sau nay thi coi la ban ve hong. Block long nhau that su hiem khi qua 5
# tang; con block tu chua chinh no thi de quy khong day se treo Blender CUNG
# — khong phai cham, ma treo han, va nguoi dung chi con duong tat may.
SAU_TOI_DA = 12


class KetQua:
    def __init__(self):
        # ten_layer -> list[(diem, kin)] ; diem la list[(x, y, z)]
        self.net = {}
        self.mau = {}          # ten_layer -> ma mau ACI
        self.so_net = 0
        self.so_diem = 0
        self.thieu_block = {}  # ten block -> so lan gap ma khong co dinh nghia
        self.qua_sau = 0

    def them(self, layer, aci, diem, kin):
        if len(diem) < 2:
            return
        self.net.setdefault(layer, []).append((diem, kin))
        self.mau.setdefault(layer, aci)
        self.so_net += 1
        self.so_diem += len(diem)


def _diem_lwpol(dinh, kin, cao_do, sai_so):
    """dinh: [(x, y, bulge), ...] -> [(x, y, z), ...] trong he PHANG."""
    n = len(dinh)
    ra = []
    for i in range(n):
        x, y, b = dinh[i]
        ra.append((x, y))
        # Doan cuoi chi ton tai khi duong khep kin.
        if i == n - 1 and not kin:
            break
        j = (i + 1) % n
        if abs(b) > 1e-12:
            ra.extend(hh.diem_tu_bulge((x, y), (dinh[j][0], dinh[j][1]),
                                       b, sai_so))
    return [(p[0], p[1], cao_do) for p in ra]


def _phang_ent(ent, bv, kq, mt, sai_so, sau, lay_cha=None, aci_cha=7):
    loai = ent[0]
    lay = bv.ten_layer(ent[1])
    aci = bv.mau_layer(ent[1])

    # LAYER "0" BEN TRONG BLOCK THUA KE LAYER CUA CAI INSERT.
    #
    # Day la luat cua DXF, khong phai tuy chon: layer "0" trong dinh nghia block
    # co nghia la "theo layer cua cho dat", giong het mau BYBLOCK. Cong cu ve
    # CAD gan nhu luon dung layer 0 khi tao block, nen bo luat nay la gan het
    # noi that do vao mot object ten "0".
    #
    # Do tren ban ve that 13/08/2026: bo luat -> layer "0" om 1.598 tren 1.925
    # net, con "VYD - Furniture" chi con 81.
    if lay_cha is not None and lay == "0":
        lay = lay_cha
        aci = aci_cha

    def dua_ra(diem_phang, ext, kin):
        truc = hh.he_truc(ext)
        that = [hh.ap(mt, hh.ra_toa_do_that(p, truc)) for p in diem_phang]
        kq.them(lay, aci, that, kin)

    if loai == "LINE":
        # LINE luu toa do THAT san, khong qua he phang — dung ap he truc vao
        # no, se lam duong thang nam sai cho tren ban ve co vector day.
        kq.them(lay, aci, [hh.ap(mt, ent[3]), hh.ap(mt, ent[4])], False)

    elif loai == "CIRCLE":
        tam, r, ext = ent[3], ent[4], ent[5]
        d = hh.diem_cung((tam[0], tam[1]), r, 0.0, 2.0 * math.pi, sai_so)
        # diem_cung tra ca hai dau, ma hai dau cua duong tron TRUNG NHAU. Giu
        # ca hai thi mesh co mot canh dai 0 — Blender khong bao gi, den luc
        # nguoi dung Extrude moi thay mot mat rac.
        dua_ra([(p[0], p[1], tam[2]) for p in d[:-1]], ext, True)

    elif loai == "ARC":
        tam, r, a0, a1, ext = ent[3], ent[4], ent[5], ent[6], ent[7]
        if a1 <= a0:
            a1 += 2.0 * math.pi
        d = hh.diem_cung((tam[0], tam[1]), r, a0, a1, sai_so)
        dua_ra([(p[0], p[1], tam[2]) for p in d], ext, False)

    elif loai == "ELLIPSE":
        tam, vlon, ti, a0, a1, ext = (ent[3], ent[4], ent[5], ent[6],
                                      ent[7], ent[8])
        d = hh.diem_ellipse((tam[0], tam[1]), (vlon[0], vlon[1]), ti,
                            a0, a1, sai_so)
        kin = abs((a1 - a0) - 2.0 * math.pi) < 1e-6
        if kin:
            d = d[:-1]
        dua_ra([(p[0], p[1], tam[2]) for p in d], ext, kin)

    elif loai == "LWPOL":
        kin, cao_do, ext, dinh = ent[3], ent[4], ent[5], ent[6]
        dua_ra(_diem_lwpol(dinh, kin, cao_do, sai_so), ext, kin)

    elif loai == "POLY":
        kin, ext, dinh = ent[3], ent[4], ent[5]
        # POLYLINE nang giu ca Z tren tung dinh. Bulge chi co nghia khi duong
        # nam phang, nen chi uon khi ca hai dinh cung cao do.
        n = len(dinh)
        ra = []
        for i in range(n):
            x, y, z, b = dinh[i]
            ra.append((x, y, z))
            if i == n - 1 and not kin:
                break
            j = (i + 1) % n
            if abs(b) > 1e-12 and abs(dinh[j][2] - z) < 1e-9:
                for p in hh.diem_tu_bulge((x, y), (dinh[j][0], dinh[j][1]),
                                          b, sai_so):
                    ra.append((p[0], p[1], z))
        dua_ra(ra, ext, kin)

    elif loai == "POINT":
        pass   # mot diem khong thanh net; bo qua co y

    elif loai == "INS":
        ten, p, sx, sy, sz, goc, ext = (ent[3], ent[4], ent[5], ent[6],
                                        ent[7], ent[8], ent[9])
        khoi = bv.blocks.get(ten)
        if khoi is None:
            kq.thieu_block[ten] = kq.thieu_block.get(ten, 0) + 1
            return
        if sau >= SAU_TOI_DA:
            kq.qua_sau += 1
            return
        mt2 = hh.nhan(mt, hh.ma_tran_insert(khoi.goc, p, sx, sy, sz, goc, ext))
        # Truyen layer cua CHINH INSERT nay xuong. Neu ban than INSERT lai nam
        # tren layer 0 trong mot block khac thi `lay` o tren da duoc thay bang
        # layer cua block cha — nen luat thua ke di duoc qua nhieu tang.
        for con in khoi.ents:
            _phang_ent(con, bv, kq, mt2, sai_so, sau + 1, lay, aci)


def phang_hoa(bv, sai_so=1.0, ti_le=0.001):
    """BanVe -> KetQua, toa do da nhan `ti_le`.

    sai_so tinh bang DON VI BAN VE (mm), do nguoi dung dat.
    ti_le mac dinh 0.001: ban ve mm -> Blender met. Xem README muc "Ti le".
    """
    kq = KetQua()
    mt = hh.ma_tran_don_vi()
    for ent in bv.ents:
        _phang_ent(ent, bv, kq, mt, sai_so, 0)

    if ti_le != 1.0:
        for lay, ds in kq.net.items():
            kq.net[lay] = [([(p[0] * ti_le, p[1] * ti_le, p[2] * ti_le)
                             for p in diem], kin) for diem, kin in ds]
    return kq
