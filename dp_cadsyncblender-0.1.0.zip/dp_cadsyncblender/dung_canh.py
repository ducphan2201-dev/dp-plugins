# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
"""Do net ve tu phang_hoa vao Blender: moi layer mot object mesh."""

import colorsys

import bpy

TEN_COLLECTION = "DP_CAD"
KHOA_LAYER = "dp_cad_layer"     # dau tren object: no dung cho layer nao
KHOA_COL = "dp_cad_col"         # dau tren collection: day la collection layer
KHOA_GIU = "dp_cad_giu"         # dau tren object: DUNG DUNG VAO NUA

# ---------------------------------------------------------------------------
# GIU LAI THU NGUOI DUNG DA DUNG
# ---------------------------------------------------------------------------
# Object nhap ve duoc dung lai TAI CHO bang clear_geometry(). Nen neu nguoi
# dung extrude ngay tren no de len khoi, lan Sync sau xoa sach cong do.
#
# Cach nhan biet khong can hoi ai: NET NHAP TU CAD KHONG BAO GIO CO MAT — chi
# co dinh va canh, dung theo cach dung_canh dung no. Vay mot object mang mat
# la chac chan co nguoi da dung tay vao. Luc do dong dau KHOA_GIU va buong ra:
# khong ghi de, khong xoa, ke ca khi layer do bien mat khoi ban ve.
#
# Dong dau chu khong chi kiem mat moi lan: nguoi dung co the xoa mat di roi
# lam tiep, va addon van phai nho rang object nay da khong con thuoc ve no.
#
# Layer bi giu thi KHONG nhap net moi vao dau ca — de mot object thu hai ben
# canh la sinh ra dung cai "chong cheo ban moi ban cu" da bo cong don. Muon
# lay ban moi thi bam "Release" trong bang N-Panel.


def _da_dung(ob):
    """Object nay da bi nguoi dung dung tay vao chua."""
    if ob.get(KHOA_GIU):
        return True
    return ob.type == "MESH" and len(ob.data.polygons) > 0

# ---------------------------------------------------------------------------
# CAY: DP_CAD > <mot collection cho moi layer> > object mesh gop
# ---------------------------------------------------------------------------
# Layer thanh COLLECTION chu khong phai chi thanh ten object: nguoi dung tat/bat
# tung layer bang Outliner, va do la cach ho da quen tu SU2Blender Sync (tag
# cua SketchUp cung thanh collection con).
#
# Ben trong moi collection layer van la MOT object mesh gop, khong tach moi net
# mot object: ban ve that ra 38.000 net, ma 38.000 object thi Blender bo ngay o
# khau chon va ve khung hinh. Tach theo block la mot cong tac rieng, chua lam.
#
# Collection va object CUA ADDON deu mang dau rieng. Thu khong mang dau la cua
# nguoi dung — khong bao gio dung toi, ke ca khi no nam ngay trong DP_CAD.


# ---------------------------------------------------------------------------
# MAU THEO CHI SO MAU CUA CAD (ACI)
# ---------------------------------------------------------------------------
# 1-9 va 250-255 la nhung gia tri co dinh, dung y bang mau cua CAD.
# 10-249 duoc SUY RA theo cau truc 24 tong mau x 10 sac do cua bang ACI.
#
# NOI THANG: khoang suy ra khong doi chieu voi bang goc bao gio, nen no GIONG
# chu khong PHAI bang mau cua CAD. Day la addon nhap net 2D mien phi, mau chi
# de nhin cho de phan biet layer trong viewport — khong ai lay no di in.
# Muon dung tuyet doi thi phai nhung ca bang 256 dong, va phai do lai.
_CO_DINH = {
    1: (1.0, 0.0, 0.0), 2: (1.0, 1.0, 0.0), 3: (0.0, 1.0, 0.0),
    4: (0.0, 1.0, 1.0), 5: (0.0, 0.0, 1.0), 6: (1.0, 0.0, 1.0),
    7: (1.0, 1.0, 1.0), 8: (0.5, 0.5, 0.5), 9: (0.75, 0.75, 0.75),
    250: (0.2, 0.2, 0.2), 251: (0.35, 0.35, 0.35), 252: (0.5, 0.5, 0.5),
    253: (0.65, 0.65, 0.65), 254: (0.8, 0.8, 0.8), 255: (1.0, 1.0, 1.0),
}


def mau_aci(aci):
    if aci in _CO_DINH:
        return _CO_DINH[aci]
    if aci < 10 or aci > 249:
        return (1.0, 1.0, 1.0)
    i = aci - 10
    tong = (i // 10) * 15.0          # 24 tong mau, moi tong cach nhau 15 do
    buoc = i % 10
    v = 1.0 - (buoc // 2) * 0.18
    s = 1.0 if (buoc % 2 == 0) else 0.55
    return colorsys.hsv_to_rgb((tong % 360.0) / 360.0, s, max(0.15, v))


def _vat_lieu(ten, rgb):
    ten_vl = "DPCAD_" + ten
    vl = bpy.data.materials.get(ten_vl)
    if vl is None:
        vl = bpy.data.materials.new(ten_vl)
    vl.diffuse_color = (rgb[0], rgb[1], rgb[2], 1.0)
    return vl


# ---------------------------------------------------------------------------

def _collection(scene):
    col = bpy.data.collections.get(TEN_COLLECTION)
    if col is None:
        col = bpy.data.collections.new(TEN_COLLECTION)
    if col.name not in scene.collection.children:
        # Nguoi dung co the da keo collection nay vao cho khac trong cay. Chi
        # noi vao goc khi no CHUA nam o dau ca, khong thi moi lan Sync no lai
        # nhay ve goc va pha cach sap xep cua ho.
        da_noi = False
        for c in bpy.data.collections:
            if col.name in c.children:
                da_noi = True
                break
        if not da_noi:
            scene.collection.children.link(col)
    return col


def _col_cua_layer(goc, ten_layer):
    """Collection cua mot layer; tao neu chua co."""
    for c in goc.children:
        if c.get(KHOA_COL) == ten_layer:
            return c
    # Ten collection trong Blender la duy nhat toan file, nen mot ten layer
    # trung voi collection san co cua nguoi dung se bi Blender doi thanh
    # "VYD - Wall.001". Vi vay phai doi chieu bang DAU chu khong bang ten.
    c = bpy.data.collections.new(ten_layer)
    c[KHOA_COL] = ten_layer
    goc.children.link(c)
    return c


def _object_cua_layer(goc, ten_layer):
    """Tim object cu cua layer nay, TIM CA CAY con cua DP_CAD.

    Doi chieu bang DAU tren object, khong bang ten: nguoi dung doi ten object
    la lan Sync sau khong nhan ra no nua va de ra mot ban thu hai chong len ban
    cu.

    Tim ca cay vi hai le: object co the con nam thang trong DP_CAD tu ban cu
    (truoc khi co collection cho tung layer), va layer co the vua duoc doi ten
    ben CAD nen object cu dang nam trong collection cua ten khac.
    """
    for ob in goc.objects:
        if ob.get(KHOA_LAYER) == ten_layer:
            return ob
    for c in goc.children:
        ob = _object_cua_layer(c, ten_layer)
        if ob is not None:
            return ob
    return None


def _doi_cho(ob, dich):
    """Dua object ve dung collection, go khoi moi cho cu."""
    if dich.name in [c.name for c in ob.users_collection]:
        return
    for c in list(ob.users_collection):
        c.objects.unlink(ob)
    dich.objects.link(ob)


def _do_mesh(me, ds_net):
    """Do net vao mesh bang duong nhanh (foreach_set), khong from_pydata.

    Ban ve that co 31.000 duong: from_pydata dung Python thuan cho tung dinh,
    cham hang chuc lan. Duong nay do thang vao vung nho cua Blender.
    """
    me.clear_geometry()

    toa_do = []
    canh = []
    goc = 0
    for diem, kin in ds_net:
        n = len(diem)
        if n < 2:
            continue
        for p in diem:
            toa_do.extend((p[0], p[1], p[2]))
        for i in range(n - 1):
            canh.extend((goc + i, goc + i + 1))
        if kin:
            canh.extend((goc + n - 1, goc))
        goc += n

    if goc == 0:
        me.update()
        return 0, 0

    me.vertices.add(goc)
    me.vertices.foreach_set("co", toa_do)
    me.edges.add(len(canh) // 2)
    me.edges.foreach_set("vertices", canh)
    # Bo update() la mesh nam trong bo nho nhung khong hien ra, va khong bao gi.
    me.update()
    return goc, len(canh) // 2


def dung(kq, scene, xoa_layer_vang=True):
    """kq: phang_hoa.KetQua. Tra ve (so object, so dinh, so canh, so giu)."""
    goc = _collection(scene)
    con_lai = set()
    so_dinh = 0
    so_canh = 0
    giu = []

    for ten_layer, ds_net in kq.net.items():
        col = _col_cua_layer(goc, ten_layer)
        ob = _object_cua_layer(goc, ten_layer)

        # Da co nguoi dung tay vao: buong ra han. Van tinh la "con lai" de
        # nhanh don ben duoi khong dung toi no.
        if ob is not None and _da_dung(ob):
            ob[KHOA_GIU] = 1
            giu.append(ten_layer)
            con_lai.add(ten_layer)
            continue

        if ob is None or ob.type != "MESH":
            me = bpy.data.meshes.new("DPCAD_" + ten_layer)
            ob = bpy.data.objects.new(ten_layer, me)
            ob[KHOA_LAYER] = ten_layer
            col.objects.link(ob)
        else:
            me = ob.data
            # Object cu co the dang nam thang trong DP_CAD (ban truoc khi co
            # collection cho tung layer). Dua no ve dung cho.
            _doi_cho(ob, col)

        nv, ne = _do_mesh(me, ds_net)
        so_dinh += nv
        so_canh += ne

        vl = _vat_lieu(ten_layer, mau_aci(kq.mau.get(ten_layer, 7)))
        if not me.materials:
            me.materials.append(vl)
        else:
            me.materials[0] = vl
        # Mau hien trong viewport lay tu object, khong phai tu vat lieu, khi
        # che do to bong dang la Solid > Object. Dat ca hai cho de nhin thay
        # mau dung du nguoi dung de che do nao.
        ob.color = tuple(vl.diffuse_color)

        con_lai.add(ten_layer)

    if xoa_layer_vang:
        _don(goc, con_lai)

    return len(kq.net), so_dinh, so_canh, giu


def _don(goc, con_lai):
    """Don layer khong con net trong lan Sync nay.

    CHI dung toi thu MANG DAU cua addon. Object nguoi dung tu tao roi keo vao
    day thi khong co dau, va collection ho tu tao cung vay — hai thu do khong
    bao gio bi xoa, ke ca khi chung rong.
    """
    for ob in list(goc.objects):
        # Thu nguoi dung da dung thi khong xoa, KE CA khi layer do khong con
        # trong ban ve nua. Do la cong cua ho, khong phai ban sao cua file CAD.
        if _da_dung(ob):
            continue
        dau = ob.get(KHOA_LAYER)
        if dau is not None and dau not in con_lai:
            me = ob.data
            bpy.data.objects.remove(ob, do_unlink=True)
            if me is not None and me.users == 0:
                bpy.data.meshes.remove(me)

    for c in list(goc.children):
        _don(c, con_lai)
        if c.get(KHOA_COL) is not None and not c.objects and not c.children:
            # Collection layer da rong: bo di. Neu giu lai thi sau vai lan Sync
            # Outliner day nhung collection rong mang ten layer khong con ton
            # tai, va nguoi dung khong biet cai nao con that.
            goc.children.unlink(c)
            if c.users == 0:
                bpy.data.collections.remove(c)
