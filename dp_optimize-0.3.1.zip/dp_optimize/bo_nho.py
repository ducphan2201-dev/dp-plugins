# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
"""Render xong thi tra bo nho ve cho he dieu hanh — Windows, Linux, macOS.

VI SAO PHAI CO MODULE NAY
    Render xong, Blender van giu nguyen mot dong bo nho: Python nhat duoc
    rac nhung khong tra ve he dieu hanh, va ban than bo cap phat cua C giu
    lai phan da giai phong trong dong rieng cua no ("heap"). Nhin tu ngoai
    — Task Manager, `free -m`, Activity Monitor — Blender van dang om hang
    GB trong khi ben trong no khong con dung. May chi co tung ay RAM, va
    viec tiep theo cua nguoi dung (mo file khac, render canh sau, chay 3ds
    Max) cham vao dung cho do.

=========================================================================
BA HE DIEU HANH LA BA CHUYEN KHAC NHAU — KHONG PHAI MOT HAM GOI BA NOI
=========================================================================

    Linux   `malloc_trim(0)` cua glibc
            Tra DUT phan dang trong o dau dong heap ve cho nhan, va
            MADV_DONTNEED nhung trang trong o cac arena khac. RSS TUT THAT.
            Ban Blender dung musl thi khong co ham nay.

    macOS   `malloc_zone_pressure_relief(NULL, 0)` cua libmalloc
            Bao cho moi vung cap phat rang may dang thieu bo nho. TRA VE SO
            BYTE that su nha ra — nen o day doc lay con so do, khong doc
            True/False.
            ⚠ Activity Monitor KHONG hien RSS. No hien `phys_footprint`,
            mot con so khac han (co tinh ca phan da nen). Nen so do o day
            va so tren man hinh cua nguoi dung LECH NHAU la binh thuong —
            muon doi chieu thi doi chieu bang `ps -o rss=`.

    Windows `SetProcessWorkingSetSize(h, -1, -1)`
            ⚠ CAI NAY KHAC BAN CHAT VOI HAI CAI TREN, va day la cho de noi
            doi nhat trong ca module. No KHONG giai phong bo nho. No day
            trang ra khoi working set sang danh sach standby: Task Manager
            tut xuong rat dep, ma so bo nho CAM KET (`PrivateUsage`) khong
            doi mot byte. Bo nho ay tien trinh khac dung duoc ngay — nen no
            khong vo ich — nhung noi "da giai phong X MB" la noi sai.
            Cho nen `so_do()` tra ve CA HAI con so tren Windows, va bao cao
            phai dan ca hai.

⚠ TREN MAY MAC SILICON, TRA RAM CHINH LA TRA VRAM: bo xu ly va card dung
CHUNG mot dong bo nho, khong co "VRAM rieng" de do. Nen viec nay dang gia
hon tren macOS so voi hai he kia, va do cung la ly do bai do khong co cot
VRAM cho macOS.

⚠ KHONG DUNG TOI DU LIEU CUA KHACH. Module nay khong xoa datablock, khong
purge orphan, khong doi mot thiet lap nao, khong dung toi anh nao. No chi
noi voi bo cap phat rang "cho nao khong dung nua thi tra lai". Xoa du lieu
la viec cua nguoi dung.

⚠ DA DO TREN WINDOWS. Hai he kia mo ta o day la theo tai lieu cua chinh
chung, CHUA CHAY THAT tren may Linux/macOS nao. Chay
`tools/probe_don_bo_nho.py` tren may do thi biet — no in ra dung con so cua
he dieu hanh do.
"""
import ctypes
import gc
import os
import platform

HE = platform.system()          # 'Windows' | 'Linux' | 'Darwin'


# --------------------------------------------------------------------------
# DOC RA DANG GIU BAO NHIEU — de con CHUNG MINH, khong phai de trang tri
#
# Moi he mot bo con so RIENG, goi dung ten cua no. Ep ba he vao chung mot
# chu "RAM" la cho ra mot bang so so sanh duoc cac thu khong so sanh duoc.
# --------------------------------------------------------------------------

class _PMC(ctypes.Structure):
    """PROCESS_MEMORY_COUNTERS_EX — ban MO RONG, co `PrivateUsage` o cuoi.

    Ban thuong (`PROCESS_MEMORY_COUNTERS`) khong co truong do, ma do chinh
    la truong noi len su that tren Windows.
    """
    _fields_ = [("cb", ctypes.c_uint32),
                ("PageFaultCount", ctypes.c_uint32),
                ("PeakWorkingSetSize", ctypes.c_size_t),
                ("WorkingSetSize", ctypes.c_size_t),
                ("QuotaPeakPagedPoolUsage", ctypes.c_size_t),
                ("QuotaPagedPoolUsage", ctypes.c_size_t),
                ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t),
                ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
                ("PagefileUsage", ctypes.c_size_t),
                ("PeakPagefileUsage", ctypes.c_size_t),
                ("PrivateUsage", ctypes.c_size_t)]


_MB = 1024.0 * 1024.0


def _so_do_windows():
    """⚠ PHAI KHAI `argtypes`/`restype` — khong khai thi SAI IM LANG.

    `GetCurrentProcess()` tra ve HANDLE, ma HANDLE tren may 64-bit la 64
    bit. Khong khai `restype` thi ctypes doc no ra `c_int` 32 bit: cai
    handle gia -1 bi cat con mot nua, `GetProcessMemoryInfo` tu choi, ham
    tra ve dict RONG — va bang ket qua chi thieu mat may dong RAM chu khong
    bao loi. Do that 16/09/2026: ca bang khong co lay mot con so RAM nao,
    ma khong co dong loi nao ca.
    """
    pmc = _PMC()
    pmc.cb = ctypes.sizeof(_PMC)
    k32 = ctypes.WinDLL('kernel32', use_last_error=True)
    psapi = ctypes.WinDLL('psapi', use_last_error=True)
    k32.GetCurrentProcess.restype = ctypes.c_void_p
    k32.GetCurrentProcess.argtypes = []
    psapi.GetProcessMemoryInfo.argtypes = [ctypes.c_void_p,
                                           ctypes.POINTER(_PMC),
                                           ctypes.c_uint32]
    psapi.GetProcessMemoryInfo.restype = ctypes.c_int
    if not psapi.GetProcessMemoryInfo(k32.GetCurrentProcess(),
                                      ctypes.byref(pmc), pmc.cb):
        return {'loi': 'GetProcessMemoryInfo tu choi (loi %d)'
                       % ctypes.get_last_error()}
    return {
        # Cai Task Manager hien o cot "Memory". Tut xuong khi day working set.
        'working_set': pmc.WorkingSetSize / _MB,
        # Cai KHONG tut xuong neu bo nho chua that su duoc tra. Doc cai nay
        # de biet co giai phong that hay chi lam dep man hinh.
        'cam_ket': pmc.PrivateUsage / _MB,
    }


def _so_do_linux():
    """`/proc/self/status` — doc ten truong, dung dem cot.

    VmRSS la phan dang nam trong RAM that. `malloc_trim` lam tut chinh no.
    VmData la vung du lieu/heap da xin — no cho biet con bao nhieu de trim.
    """
    ra = {}
    try:
        with open('/proc/self/status', 'r') as f:
            for dong in f:
                if dong.startswith('VmRSS:'):
                    ra['rss'] = float(dong.split()[1]) / 1024.0
                elif dong.startswith('VmData:'):
                    ra['vung_du_lieu'] = float(dong.split()[1]) / 1024.0
                elif dong.startswith('VmSize:'):
                    ra['vung_ao'] = float(dong.split()[1]) / 1024.0
    except Exception:                                      # noqa: BLE001
        pass
    if 'rss' not in ra:
        # `statm` cot 2 la so TRANG thuong tru — duong lui neu khong co status.
        try:
            with open('/proc/self/statm', 'r') as f:
                trang = int(f.read().split()[1])
            ra['rss'] = trang * os.sysconf('SC_PAGE_SIZE') / _MB
        except Exception as e:                             # noqa: BLE001
            # KHONG tra dict rong — xem chu thich cua `so_do`.
            ra['loi'] = 'khong doc duoc /proc/self: %s' % e
    return ra


def _so_do_macos():
    """`ps -o rss=`.

    KHONG dung `task_info(TASK_VM_INFO)` de lay `phys_footprint`: struct do
    doi truong theo tung doi macOS, doc lech mot truong la ra mot con so
    trong nhu that ma sai han — te hon la khong co so. `ps` thi moi doi
    macOS deu tra dung mot thu.

    Doi lai: con so nay KHONG bang cai Activity Monitor hien (xem dau file).
    """
    import subprocess
    kb = subprocess.check_output(['ps', '-o', 'rss=', '-p', str(os.getpid())])
    return {'rss': int(kb.strip()) / 1024.0}


def so_do():
    """Cac con so bo nho cua tien trinh nay, theo DUNG ten cua he dieu hanh.

    Khong doc duoc thi tra ve `{'loi': ...}` chu KHONG tra dict rong. Dict
    rong lot qua moi cho: bang bao cao chi thieu mat may dong, va khong ai
    biet la thieu vi khong do duoc hay vi khong co gi de do.
    """
    try:
        if HE == 'Windows':
            return _so_do_windows()
        if HE == 'Linux':
            return _so_do_linux()
        if HE == 'Darwin':
            return _so_do_macos()
    except Exception as e:                                 # noqa: BLE001
        return {'loi': '%s: %s' % (type(e).__name__, e)}
    return {'loi': 'he dieu hanh %s: chua co duong doc' % HE}


def _so_chinh(d):
    """Con so DAI DIEN cho moi he, de in mot dong ngan."""
    for ten in ('working_set', 'rss'):
        if ten in d:
            return d[ten]
    return None


# --------------------------------------------------------------------------
# RAM CUA CA MAY — khong phai cua rieng Blender
#
# Ducphan 16/09/2026: *"linux no don het bo nho dem vao ram nen tao moi bao
# may lam chuc nang nay"*. Cai lam ong kho chiu la RAM CUA MAY het cho, chu
# khong phai con so cua rieng mot tien trinh. Nen phai doc duoc con so do,
# va phai quyet dinh theo no.
#
# ⚠ TREN LINUX, "bo nho dem" CO HAI LOAI va chung khac han nhau:
#
#   1. Bo nho dem CUA BLENDER (BVH, anh, pass) — nam trong heap cua tien
#      trinh. `malloc_trim` tra phan da giai phong ve cho nhan. Day la cho
#      module nay lam viec.
#   2. Bo nho dem CUA NHAN, tu viec doc/ghi file (`buff/cache` trong
#      `free -h`) — cai nay nhin thi day RAM nhung nhan TU LAY LAI duoc khi
#      co ai can. `MemAvailable` da tru phan ay ra roi, nen doc
#      `MemAvailable` la doc dung cai con dung duoc THAT.
#
# Dung di "don" loai 2: khong co quyen (can root), va don xong chi lam moi
# thu cham di vi phai doc lai tu dia.
# --------------------------------------------------------------------------

class _MEMORYSTATUSEX(ctypes.Structure):
    _fields_ = [("dwLength", ctypes.c_uint32),
                ("dwMemoryLoad", ctypes.c_uint32),
                ("ullTotalPhys", ctypes.c_uint64),
                ("ullAvailPhys", ctypes.c_uint64),
                ("ullTotalPageFile", ctypes.c_uint64),
                ("ullAvailPageFile", ctypes.c_uint64),
                ("ullTotalVirtual", ctypes.c_uint64),
                ("ullAvailVirtual", ctypes.c_uint64),
                ("ullAvailExtendedVirtual", ctypes.c_uint64)]


def ram_may():
    """RAM cua CA MAY: {'tong_mb', 'con_mb'}. Rong neu khong doc duoc."""
    try:
        if HE == 'Linux':
            tong = con = None
            with open('/proc/meminfo', 'r') as f:
                for dong in f:
                    if dong.startswith('MemTotal:'):
                        tong = float(dong.split()[1]) / 1024.0
                    elif dong.startswith('MemAvailable:'):
                        con = float(dong.split()[1]) / 1024.0
                    if tong is not None and con is not None:
                        break
            if tong is None:
                return {}
            # May nhan cu khong co `MemAvailable`; luc do khong doan bua.
            return {'tong_mb': tong} if con is None else {'tong_mb': tong,
                                                          'con_mb': con}
        if HE == 'Windows':
            ms = _MEMORYSTATUSEX()
            ms.dwLength = ctypes.sizeof(_MEMORYSTATUSEX)
            k32 = ctypes.WinDLL('kernel32', use_last_error=True)
            k32.GlobalMemoryStatusEx.argtypes = [
                ctypes.POINTER(_MEMORYSTATUSEX)]
            k32.GlobalMemoryStatusEx.restype = ctypes.c_int
            if not k32.GlobalMemoryStatusEx(ctypes.byref(ms)):
                return {}
            return {'tong_mb': ms.ullTotalPhys / _MB,
                    'con_mb': ms.ullAvailPhys / _MB}
        if HE == 'Darwin':
            import subprocess
            tong = float(subprocess.check_output(
                ['sysctl', '-n', 'hw.memsize']).strip()) / _MB
            # `vm_stat` in ra so TRANG; co trang o dong dau ("page size of N").
            ra = subprocess.check_output(['vm_stat']).decode()
            co = 4096.0
            dau = ra.splitlines()[0]
            if 'page size of' in dau:
                co = float(dau.split('page size of')[1].split()[0])
            ranh = 0.0
            for dong in ra.splitlines():
                for ten in ('Pages free:', 'Pages inactive:',
                            'Pages speculative:', 'Pages purgeable:'):
                    if dong.startswith(ten):
                        ranh += float(dong.split(':')[1].strip().rstrip('.'))
            return {'tong_mb': tong, 'con_mb': ranh * co / _MB}
    except Exception:                                      # noqa: BLE001
        return {}
    return {}


# Duoi muc nay thi coi la may dang THIEU RAM va don manh tay hon.
NGUONG_THIEU_PHAN_TRAM = 20.0
NGUONG_THIEU_MB = 4096.0


def thieu_ram():
    """May co dang thieu RAM khong. None neu khong doc duoc.

    Hai dieu kien, chi can MOT: con duoi 20% tong so, hoac con duoi 4 GB.
    May 128 GB ma con 5 GB thi 20% khong bat duoc; may 16 GB ma con 3 GB thi
    4 GB khong bat duoc. Nen phai co ca hai.
    """
    d = ram_may()
    if 'con_mb' not in d or not d.get('tong_mb'):
        return None
    return (d['con_mb'] < NGUONG_THIEU_MB
            or d['con_mb'] / d['tong_mb'] * 100.0 < NGUONG_THIEU_PHAN_TRAM)


# --------------------------------------------------------------------------
# TRA VE HE DIEU HANH
# --------------------------------------------------------------------------

def _tra_linux():
    """Tra ve (True/False/None, mo ta).

    `ctypes.CDLL(None)` mo chinh tien trinh dang chay: symbol cua libc da
    nam san trong do, va cach nay khong phu thuoc vao ten file libc (mot
    so ban Linux khong co `libc.so.6`).

    ⚠ KHONG PHAI MAY LINUX NAO CUNG DUNG glibc. May render hay nap de mot
    bo cap phat khac bang `LD_PRELOAD` cho nhanh:

        tcmalloc (gperftools)  -> `MallocExtension_ReleaseFreeMemory`
        jemalloc               -> khong co ham nao goi thang duoc nhu vay
        musl (Alpine)          -> khong co `malloc_trim`

    Goi `malloc_trim` trong khi bo cap phat that su la tcmalloc thi no
    khong lam gi ca MA VAN TRA VE — bao cao se noi "da tra" trong khi
    khong tra gi. Nen hoi tcmalloc TRUOC: symbol cua no chi ton tai khi no
    dang that su duoc dung.
    """
    try:
        me = ctypes.CDLL(None)
    except Exception:                                      # noqa: BLE001
        me = None
    if me is not None:
        tc = getattr(me, 'MallocExtension_ReleaseFreeMemory', None)
        if tc is not None:
            tc.argtypes = []
            tc.restype = None
            try:
                tc()
                return True, "MallocExtension_ReleaseFreeMemory (tcmalloc)"
            except Exception as e:                         # noqa: BLE001
                return None, "tcmalloc co mat nhung goi hong: %s" % e

    loi = "khong co malloc_trim (ban Blender nay khong dung glibc?)"
    for libc in ([me] if me is not None else []) + [None]:
        if libc is None:
            try:
                libc = ctypes.CDLL('libc.so.6')
            except Exception:                              # noqa: BLE001
                continue
        ham = getattr(libc, 'malloc_trim', None)
        if ham is None:
            continue
        ham.argtypes = [ctypes.c_size_t]
        ham.restype = ctypes.c_int
        try:
            # Tra ve 1 neu CO tra duoc bo nho, 0 neu khong con gi de tra.
            return bool(ham(0)), "malloc_trim"
        except Exception as e:                             # noqa: BLE001
            loi = "malloc_trim hong: %s" % e
    return None, loi


def _tra_macos():
    """`malloc_zone_pressure_relief(NULL, 0)` — NULL nghia la MOI vung.

    Ham tra ve SO BYTE da nha ra, nen o day doc lay con so do chu khong ep
    ve True/False: "tra lai 0 byte" va "khong goi duoc" la hai chuyen khac
    nhau, va gop chung lai thi sau nay khong go ra duoc.

    Duong mo thu vien: `None` truoc. Tu macOS 11 libSystem khong con nam
    tren dia (no o trong dyld shared cache), nen mo theo duong dan file la
    duong de hong nhat — de sau cung.
    """
    libc = None
    for ten in (None, 'libSystem.B.dylib', '/usr/lib/libSystem.B.dylib'):
        try:
            libc = ctypes.CDLL(ten)
            if getattr(libc, 'malloc_zone_pressure_relief', None) is not None:
                break
            libc = None
        except Exception:                                  # noqa: BLE001
            continue
    if libc is None:
        return None, "khong tim thay malloc_zone_pressure_relief"
    ham = libc.malloc_zone_pressure_relief
    ham.argtypes = [ctypes.c_void_p, ctypes.c_size_t]
    ham.restype = ctypes.c_size_t
    try:
        byte = int(ham(None, 0))
    except Exception as e:                                 # noqa: BLE001
        return None, "malloc_zone_pressure_relief hong: %s" % e
    return True, "malloc_zone_pressure_relief (nha %.0f MB)" % (byte / _MB)


def _tra_windows():
    """`SetProcessWorkingSetSize(h, -1, -1)`.

    Tai lieu Microsoft: truyen (SIZE_T)-1 cho ca hai tham so la yeu cau cat
    working set xuong toi thieu. ⚠ Doc lai canh bao o dau file: cai nay
    KHONG giai phong bo nho, no day trang sang danh sach standby.
    """
    try:
        k32 = ctypes.WinDLL('kernel32', use_last_error=True)
        k32.SetProcessWorkingSetSize.argtypes = [ctypes.c_void_p,
                                                 ctypes.c_size_t,
                                                 ctypes.c_size_t]
        k32.SetProcessWorkingSetSize.restype = ctypes.c_int
        mot = ctypes.c_size_t(-1).value
        ok = k32.SetProcessWorkingSetSize(k32.GetCurrentProcess(), mot, mot)
        if not ok:
            return False, ("SetProcessWorkingSetSize tu choi (loi %d)"
                           % ctypes.get_last_error())
        return True, "SetProcessWorkingSetSize"
    except Exception as e:                                 # noqa: BLE001
        return None, "SetProcessWorkingSetSize hong: %s" % e


def _thu_vien_da_nap(ten):
    """Mo mot thu vien DA NAP SAN trong tien trinh, khong nap moi."""
    for n in ten:
        try:
            return ctypes.CDLL(n)
        except Exception:                                  # noqa: BLE001
            continue
    return None


def _tra_tbb():
    """⛔ BLENDER THAY `malloc` CUA CA TIEN TRINH BANG TBB.

    Blender nap `tbbmalloc_proxy`, va tu luc do moi `malloc`/`free` cua ca
    Blender lan Python deu di qua bo cap phat TBB. TBB giu vung da tha trong
    KHO RIENG cua no — nen goi `_heapmin` cua CRT hay `SetProcessWorkingSetSize`
    deu khong cham duoc vao dong do.

    Do cua du an DP_MaxImporter 13/09/2026 (Windows, Blender 5.2), sau mot lan
    render canh 20 luoi 1,3 trieu mat:

        `_heapmin`                          3,25 -> 3,25 GB  (KHONG DOI)
        TBB `scalable_allocation_command`   3,78 -> 0,29 GB  (ve muc truoc render)

    ⚠ Ban dau module nay chi goi `SetProcessWorkingSetSize` tren Windows va do
    ra "cam ket -0 MB" — dung vay, vi no goi NHAM bo cap phat. Phai hoi TBB
    TRUOC, va hoi tren CA BA he (Blender nap TBB o ca ba).

    Lenh 0 = `TBBMALLOC_CLEAN_ALL_BUFFERS`. Tra ve 0 la thanh cong.
    """
    tbb = _thu_vien_da_nap(
        ('tbbmalloc.dll',) if HE == 'Windows' else
        ('libtbbmalloc.dylib', 'libtbbmalloc.2.dylib') if HE == 'Darwin' else
        ('libtbbmalloc.so.2', 'libtbbmalloc.so'))
    if tbb is None:
        return None
    try:
        f = tbb.scalable_allocation_command
        f.argtypes = [ctypes.c_int, ctypes.c_void_p]
        f.restype = ctypes.c_int
        ma = f(0, None)
        # 0 = TBBMALLOC_OK, 2 = TBBMALLOC_NO_EFFECT ("da goi, nhung khong con
        # gi de tra"). Ca hai deu la DA GOI DUOC — do 16/09/2026 tren PN4 sau
        # render: tra ve NO_EFFECT, vi cho 7 GB kia la bo nho dem DANG SONG,
        # Blender chua tha nen TBB khong co gi trong kho de nha.
        return ma in (0, 2)
    except Exception:                                      # noqa: BLE001
        return None


def tra_ve_he_dieu_hanh():
    """Bao bo cap phat tra phan khong dung lai cho he dieu hanh.

    Tra ve (ket_qua, ten_duong): True/False/None (None = he nay khong co
    duong nao). KHONG nem loi ra ngoai — day la viec don dep, no khong duoc
    phep lam hong mot lan render da xong.

    ⛔ HOI TBB TRUOC, tren CA BA he — xem `_tra_tbb`. Blender thay `malloc`
    cua ca tien trinh bang TBB, nen duong cua he dieu hanh chi cham duoc
    phan KHONG di qua TBB. Chay ca hai: TBB tra phan lon, duong he dieu hanh
    tra phan con lai.
    """
    duong = []
    if _tra_tbb():
        duong.append("TBB scalable_allocation_command")

    if HE == 'Linux':
        ok, ten = _tra_linux()
    elif HE == 'Darwin':
        ok, ten = _tra_macos()
    elif HE == 'Windows':
        ok, ten = _tra_windows()
    else:
        ok, ten = None, "he dieu hanh la %s, khong co duong nao" % HE
    duong.append(ten)
    if duong[0].startswith("TBB"):
        return True, " + ".join(duong)
    return ok, ten


# --------------------------------------------------------------------------
# THA DONG PIXEL CUA ANH
# --------------------------------------------------------------------------

def _tha_duoc(img):
    """Tam anh nay co tha dong pixel di ma lay lai duoc khong.

    ⛔ CHI THA CAI NAO NAP LAI DUOC. Anh dang sua (`is_dirty`) thi pixel cua
    no chi con trong bo nho — khong o dia, khong trong goi packed. Tha di la
    XOA MAT viec cua nguoi dung. Anh do addon/script sinh ra ('GENERATED')
    ma khong packed cung vay.

    'Render Result' va 'Viewer Node' thi khong dung toi: do la ket qua nguoi
    dung vua render xong, ho con dang nhin no.
    """
    if img.name in ('Render Result', 'Viewer Node'):
        return False
    if getattr(img, 'is_dirty', False):
        return False
    if img.packed_file is not None:
        return True                    # nap lai duoc tu chinh goi packed
    return img.source in ('FILE', 'SEQUENCE', 'MOVIE', 'TILED')


def tha_anh():
    """Tra lai dong pixel dang giu cua cac anh nap lai duoc. So anh da tha.

    ⛔ `buffers_free` KHONG LO RA TREN LOP: `hasattr(bpy.types.Image,
    "buffers_free")` tra ve False trong khi `img.buffers_free()` chay binh
    thuong. Hoi phai hoi TAM ANH, dung hoi cai lop. (Bay nay do du an
    DP_RAMchill tim ra va tra gia truoc — xem `dp_ramchill/doi_co.py`.)
    """
    import bpy
    n = 0
    for img in list(bpy.data.images):
        try:
            if not _tha_duoc(img):
                continue
            ham = getattr(img, 'buffers_free', None)
            if ham is None:
                continue
            ham()
            n += 1
        except Exception:                                  # noqa: BLE001
            continue
    return n


def don(chi_tiet=False):
    """Don mot lan. Tra ve dict de ghi bao cao va de phep kiem soi vao.

    Thu tu co ly do: `gc.collect()` TRUOC, vi no moi la cai tha ra cac khoi
    C dang bi mot doi tuong Python giu; tra ve he dieu hanh SAU, luc dong
    heap da that su trong.
    """
    truoc = so_do()
    so_rac = gc.collect()
    ok, duong = tra_ve_he_dieu_hanh()
    sau = so_do()
    a, b = _so_chinh(truoc), _so_chinh(sau)
    ket = dict(he=HE, truoc=truoc, sau=sau, duong=duong, ok=ok, rac=so_rac,
               giam_mb=(None if (a is None or b is None) else a - b))
    # Tren Windows con so that nam o day: cam ket co tut khong.
    if 'cam_ket' in truoc and 'cam_ket' in sau:
        ket['giam_cam_ket_mb'] = truoc['cam_ket'] - sau['cam_ket']
    # RAM CUA CA MAY sau khi don — day moi la con so Ducphan nhin.
    ket['ram_sau'] = ram_may()
    if chi_tiet:
        print("[DP-OptimizeRender] don bo nho (%s): %s" % (HE, duong))
        if ket['giam_mb'] is not None:
            print("    %.0f MB roi khoi bo nho thuong tru" % ket['giam_mb'])
        if ket.get('giam_cam_ket_mb') is not None:
            print("    %.0f MB roi khoi bo nho CAM KET (day moi la phan "
                  "that su duoc tra)" % ket['giam_cam_ket_mb'])
    return ket


# --------------------------------------------------------------------------
# CHAY NGAM SAU MOI LAN RENDER
# --------------------------------------------------------------------------
#
# GIOI HAN CUA VIEC NAY — NOI TRUOC, DE KHONG AI TRONG CHO NHAM.
#
# Do 16/09/2026, PN4.blend 4000x2250, Windows, card RTX 3060:
#
#     mo file                     cam ket   682 MB   VRAM     0 MB
#     render xong (persistent ON) cam ket 12479 MB   VRAM  5913 MB
#     render xong (persistent OFF) cam ket 7378 MB   VRAM  3564 MB
#
# Da THU BAY DUONG de tra cho 3,5 GB VRAM ay ve, TAT CA deu ra 0 MB:
# `Render Result.buffers_free()`, `gl_free()` tren ca 73 anh, `gc.collect()`,
# `malloc_trim`/`SetProcessWorkingSetSize`, `orphans_purge`, doi engine sang
# EEVEE roi ve, render mot scene RONG 4x4 de ep dung phien moi, va ngoi doi.
# Blender GIU LAI cho do de dung cho lan render sau — va no KHONG PHINH LEN:
# render bon lan lien con so dung yen (5909 -> 5913 MB). Do la BO NHO DEM,
# khong phai ro ri, va Python khong co cua nao mo no.
#
# Nen cai chay ngam nay lam DUNG phan lam duoc:
#
#   * tra phan heap dang trong ve cho he dieu hanh (that tren Linux/macOS)
#   * tha dong pixel cua anh nap lai duoc — do duoc 201 MB tren canh tren,
#     nhung CHI KHI khong co ai dang nhin man hinh (xem duoi)
#
# Con phan lon nhat — 5,1 GB RAM va 2,35 GB VRAM — thi khong don duoc sau
# khi da tro tay: no phai duoc CHAN TU DAU bang `use_persistent_data = False`,
# va do la viec cua nut "Optimize This Scene".

_LAN_CUOI = {}


def sau_render(scene=None, chi_tiet=None):
    """Don mot lan, ngay sau khi mot cong viec render ket thuc.

    THA ANH: khi khong co man hinh, HOAC khi may dang thieu RAM.

    Tha dong pixel di thi lan sau ai hoi toi tam anh, Blender nap lai tu
    dia. O che do nen (`blender -b`, may render) thi khong ai hoi toi nua —
    tha la lai khong han. Nhung trong Blender co cua so, khung nhin ve lai
    NGAY sau khi dong cua so render: tha xong la nap lai ngay, va nguoi dung
    chi duoc moi cai khung hinh giat.

    ⚠ TRU KHI MAY DANG HET RAM. Luc do cai khung hinh giat re hon nhieu so
    voi viec may bat dau trao doi ra dia — hoac Blender bi giet. Ducphan
    16/09/2026: *"linux no don het bo nho dem vao ram nen tao moi bao may
    lam chuc nang nay"*. Dung ca nay thi phai don, va phai don ke ca khi dang
    co cua so.

    Nguong: xem `thieu_ram()`. Doc khong duoc RAM may thi giu luat cu (chi
    tha o che do nen) — khong doan bua rang may dang thieu.
    """
    # ⛔ NOI RA MOI LAN, MAC DINH. Ban dau ham nay chi in khi co bien moi
    # truong `DP_OPT_ON_AO` — tuc la mac dinh no lam viec trong IM LANG
    # tuyet doi. Ducphan bam nut xong, render xong, va hoi "the cai tu nha
    # ram dau?" — dung qua: khong co lay mot dau hieu nao cho thay no ton
    # tai. Mot tinh nang chay ngam ma khong de lai dau vet nao thi tu goc
    # nhin nguoi dung no KHONG CO. Dat `DP_OPT_IM_LANG=1` neu muon tat.
    if chi_tiet is None:
        chi_tiet = not os.environ.get('DP_OPT_IM_LANG')
    # ⚠ CHUP MOC O DAY, TRUOC KHI THA ANH. Ban dau ham nay tha anh xong moi
    # goi `don()`, ma `don()` tu chup moc cua no — nen phan anh vua tha ra
    # nam NGOAI khoang do va bao cao in "-0 MB" trong khi that ra da tra
    # duoc 201 MB. Mot bao cao bao it hon su that van la mot bao cao sai.
    truoc = so_do()
    ket = {'anh_da_tha': 0}
    thieu = thieu_ram()
    ket['thieu_ram'] = thieu
    ket['ram_truoc'] = ram_may()
    try:
        import bpy
        if bpy.app.background or thieu is True:
            ket['anh_da_tha'] = tha_anh()
            ket['vi_tha'] = ("chay nen" if bpy.app.background
                             else "may dang thieu RAM")
    except Exception:                                      # noqa: BLE001
        pass
    try:
        ket.update(don(chi_tiet=False))
    except Exception:                                      # noqa: BLE001
        return ket
    sau = ket.get('sau') or {}
    a, b = _so_chinh(truoc), _so_chinh(sau)
    ket['truoc'] = truoc
    ket['giam_mb'] = None if (a is None or b is None) else a - b
    if 'cam_ket' in truoc and 'cam_ket' in sau:
        ket['giam_cam_ket_mb'] = truoc['cam_ket'] - sau['cam_ket']
    _LAN_CUOI.clear()
    _LAN_CUOI.update(ket)
    if chi_tiet:
        _in_bao_cao(ket)
    return ket


def _in_bao_cao(ket):
    """Mot dong cho nhat ky may render. NOI DUNG CAI DA LAM, khong hon.

    Tren Windows phai tach hai con so ra: day trang ra khoi working set
    khong phai la giai phong. Gop lai thanh mot chu "da don X MB" la mot
    con so dep va sai.
    """
    bit = ["[DP-OptimizeRender] render xong, don bo nho (%s)" % ket.get('he')]
    if ket.get('anh_da_tha'):
        bit.append("tha dong pixel cua %d anh" % ket['anh_da_tha'])
    g = ket.get('giam_cam_ket_mb')
    if g is not None:
        bit.append("bo nho cam ket -%.0f MB" % g)
    t = ket.get('giam_mb')
    if t is not None and HE == 'Windows':
        bit.append("working set -%.0f MB (day sang standby, may khac dung "
                   "duoc ngay)" % t)
    elif t is not None:
        bit.append("thuong tru -%.0f MB" % t)
    # RAM CUA CA MAY — cai nguoi dung that su nhin, nhat la tren Linux.
    r0, r1 = ket.get('ram_truoc') or {}, ket.get('ram_sau') or {}
    if 'con_mb' in r0 and 'con_mb' in r1:
        bit.append("RAM may con %.0f -> %.0f MB / %.0f MB"
                   % (r0['con_mb'], r1['con_mb'], r1.get('tong_mb', 0.0)))
    print("; ".join(bit))


def lan_cuoi():
    """Ket qua cua lan don gan nhat, de giao dien / phep kiem doc lai."""
    return dict(_LAN_CUOI)


def dang_bat():
    """Chot don bo nho co dang gan vao Blender khong.

    Nut "Optimize This Scene" doc cai nay de noi ra rang viec nha bo nho
    dang chay — Ducphan mo ta dung nhu vay (16/09/2026): *"cai nha ram kia
    bam optimize la tu dong hoat dong luon"*. Hoi THAT chu khong tra ve True
    cho dep: chot co the da bi go (addon tat roi bat lai, hoac mot addon
    khac don danh sach chot).
    """
    try:
        import bpy
        for ten in ('render_complete', 'render_cancel'):
            ds = getattr(bpy.app.handlers, ten, None)
            if ds is None:
                return False
            if not any(getattr(h, '__name__', '') == '_sau_render' for h in ds):
                return False
        return True
    except Exception:                                      # noqa: BLE001
        return False
