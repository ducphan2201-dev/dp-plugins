# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
"""Chuyen viec cua handler render sang LUONG CHINH va cho no xong.

Bam F12 / batch render CO CUA SO thi `render_init`, `render_pre`,
`render_complete`, `render_cancel` chay tren LUONG RENDER. Handler nao doi du
lieu (luoi, modifier, anh, `hide_render`, cai dat scene) o day la doi ngay luc
luong chinh dang ve khung nhin bang chinh du lieu do -> Blender vang SEGV.
Chay nen (`-b`) render dong bo tren luong chinh nen bai do nen khong bao gio
thay.

Do 17/09/2026, Blender 5.2.2, may Duc-KAS: hai coredump batch render, luong
render dang o handler `render_pre` cua DP_RAMchill (quet scene) luc luong
chinh vang khi ve. Addon nay cung doi du lieu tren luong render nen sua cung
cach.

Handler goi `chay(ham, ...)`. O luong chinh (chay nen) thi goi thang. O luong
khac thi xep viec vao hang, luong render DUNG CHO; timer `_nhip` tren luong
chinh lam, xong moi tha. Luong chinh chua NHAN viec sau `CHO_NHAN` giay thi
bo viec, render van chay — khong bao gio treo ca lan render. Da nhan roi thi
cho toi khi xong: bo giua chung la hai luong lai cung dung du lieu.
"""

import threading

import bpy

TEN = "DP-OptimizeRender"
CHO_NHAN = 30.0
NHIP = 0.05

_HANG = []
_KHOA = threading.Lock()


class _Viec:
    __slots__ = ("ham", "doi", "xong", "dang_lam", "bo")

    def __init__(self, ham, doi):
        self.ham = ham
        self.doi = doi
        self.xong = threading.Event()
        self.dang_lam = False
        self.bo = False


def o_luong_chinh():
    return threading.current_thread() is threading.main_thread()


def chay(ham, *doi):
    """Chay `ham(*doi)` tren luong chinh; goi tu luong khac thi cho no xong."""
    if o_luong_chinh():
        ham(*doi)
        return True
    viec = _Viec(ham, doi)
    with _KHOA:
        _HANG.append(viec)
    if viec.xong.wait(CHO_NHAN):
        return True
    with _KHOA:
        if not viec.dang_lam:
            viec.bo = True
            print("[%s] main thread busy for %.0f s, skipped %s for this "
                  "render" % (TEN, CHO_NHAN, getattr(ham, "__name__", ham)))
            return False
    viec.xong.wait()
    return True


def _nhip():
    while True:
        with _KHOA:
            if not _HANG:
                break
            viec = _HANG.pop(0)
            if viec.bo:
                continue
            viec.dang_lam = True
        try:
            viec.ham(*viec.doi)
        except Exception as e:                           # noqa: BLE001
            print("[%s] %s failed: %s"
                  % (TEN, getattr(viec.ham, "__name__", viec.ham), e))
        finally:
            viec.xong.set()
    return NHIP


def dang_ky():
    if not bpy.app.timers.is_registered(_nhip):
        bpy.app.timers.register(_nhip, first_interval=NHIP, persistent=True)


def go():
    if bpy.app.timers.is_registered(_nhip):
        bpy.app.timers.unregister(_nhip)
    # Con ai dang cho thi tha ra, dung de luong render treo vinh vien.
    with _KHOA:
        for viec in _HANG:
            viec.bo = True
            viec.xong.set()
        _HANG.clear()
