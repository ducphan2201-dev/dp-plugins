# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
"""Lop QUYET DINH cua DP_RAMchill — mot map nen ha xuong co nao.

KHONG IMPORT bpy. Ca file nay chi lam viec voi so. Nho vay toan bo phep
quyet dinh kiem duoc trong MOT GIAY bang python tran, thay vi 20-30 giay
moi lan mo Blender.

=========================================================================
THANG CHIA — Ducphan chot 22/08/2026
=========================================================================
Nam bac, va CHI nam bac:

    1/1     giu nguyen
    1/2     chia doi canh
    1/4
    1/6
    1/8     nho nhat

Cai chon bac la VANH KHOANG CACH toi camera: bon moc, nam vanh. Duoi moc
dau tien la giu nguyen, tren moc cuoi cung la 1/8.

Luu y 1/6 KHONG phai luy thua cua 2. Do la co y — Ducphan doi thang
1/2 1/4 1/6 1/8, va mot bac 1/6 doc ra la "gan mot phan sau" thi ro rang
hon voi nguoi dung so voi mot con so lam tron len 1/8 hay xuong 1/4.

=========================================================================
HAI DIEU KIEN, KHOA VOI NHAU — Ducphan chot 22/08/2026
=========================================================================
Mot map chi duoc ha xuong mot bac khi CA HAI dieu kien cung cho phep:

  DIEU KIEN 1 — KHOANG CACH toi camera. Bon moc, nam vanh, ra mot bac.

  DIEU KIEN 2 — DIEN TICH CHIEM TREN KHUNG HINH. Do bang mat do texel:

        px_can   = dien tich mat tren khung hinh, tinh bang pixel
        texel_co = dien_tich_UV_cua_mat * W * H     (W,H = co anh goc)
        ti_le    = sqrt( px_can * du_phong / texel_co )

     `sqrt` vi ca hai deu la DIEN TICH, ma thu can tim la he so tren mot
     CANH. `ti_le` roi vao bac nao thi do la bac dieu kien 2 cho phep.

    bac_cuoi = min(bac_khoang_cach, bac_dien_tich)      <- BAC IT THU NHO HON

Vi sao phai co ca hai, va vi sao KHONG cai nao duoc quyen mot minh:

  * chi dung KHOANG CACH: mot buc TUONG cach 40 m van co the chiem nua
    khung hinh. Vanh khoang cach xep no vao 1/8 va mat nguoi doc ra ngay
    la map bi nhoe;
  * chi dung DIEN TICH: mot san go lat ngay duoi chan ong kinh chay hut
    ve phia chan troi — phan xa nhat cua chinh no chiem it pixel, nhung
    no la CUNG MOT tam map voi phan ngay duoi chan.

⛔ KHONG CO DUONG TAT DIEU KIEN 2. Va do khong do duoc dien tich (anh cua
World, anh khong nam tren mat nao) thi dieu kien 2 tra ve bac 0 — tuc GIU
NGUYEN. Khong do duoc thi khong ha, khong doan.

=========================================================================
TU DONG LA CHO ANH TINH — Ducphan chot 22/08/2026
=========================================================================
Nguyen van: *"chuc nang animation thi cho resized bang tay di, k can tu
dong dau, tu dong dinh muc la cho anh tinh thoi"*.

Hai dieu kien tren deu do tren MOT bo tri camera. Camera bay qua ca can
phong thi bo tri do het dung tu khung hinh thu hai. Duong cho animation la
`CHE_DO_EP_CO`: nguoi dung tu chon mot co, va co do dung cho moi khung
hinh — khong co gi phai do lai, nen khong co gi lech duoc.

Nho cho nay ma ca hai thu sau day KHONG can lam, va dung de phien sau
nghi lai: lap ke hoach tung khung hinh, va kho cache anh da thu nho. Ca
hai chi ton tai de phuc vu animation o che do tu dong.
"""

import math

# Mau so cua tung bac. Doc: chia CANH cho so nay.
BAC_CHIA = (1, 2, 4, 6, 8)

# ⛔ SAN CUNG, Ducphan chot 22/08/2026: *"resized khong bao gio duoc duoi
# 512px nhe"*. Day KHONG phai mot gia tri mac dinh — no la mot cai san,
# va moi duong ha co deu phai di qua no:
#
#   * che do tu dong: bac nao ha canh lon xuong duoi 512 thi LUI LAI mot
#     bac, chu khong kep cung ve 512 (kep cung se lam mot map 1024 va mot
#     map 8192 cung ra 512, tuc bac cua nguoi dung mat nghia);
#   * che do ep co: muc ep duoi 512 bi keo len 512;
#   * o `Never below` cua nguoi dung: chi chinh LEN duoc, khong xuong.
#
# San tinh tren CANH LON. Map 4096x1024 xuong 1/8 ra 512x128 — canh lon
# dung 512, con canh ngan nho hon la he qua cua viec giu ti le hai canh.
# Keo canh ngan len la doi ca hinh anh.
#
# Anh VON DA nho hon 512 thi khong dinh dang gi toi san nay: addon khong
# bao gio phong to, nen mot map 256 cua nguoi dung van la 256.
SAN_TUYET_DOI = 512

# ⛔ BON MOC NAY LA SO CHET, VA MOT SO CHET O DAY LA SAI GAN NHU LUON.
#
# Do la bai hoc dat nhat cua ngay 22/08/2026. Bon so 5/15/30/60 met nghe
# hop ly — cho mot canh ngoai troi. Cam vao file noi that that cua Ducphan
# thi ca can phong nam gon trong khoang **2,3 den 8,0 met**: KHONG mot tam
# map nao voi toi noi moc dau tien, nen addon khong ha mot tam nao, va
# Ducphan nhin bang thay "5000 mm" roi noi thang: *"thong so the nay thi
# no k nhan la dung r"* · *"khoang cach may tinh toan dang qua lon"*.
#
# Nen mac dinh bay gio la TU DO THEO CANH (`moc_tu_dong`, xem `props.py`):
# quet xong thi lay chinh phan bo khoang cach cua canh do ma dat bon moc.
# Bang so duoi day chi con la duong lui khi nguoi dung tat tu dong di, va
# khi ay chinh ho go so cua ho vao.
MOC_MAC_DINH = (5.0, 15.0, 30.0, 60.0)

# Bon moc tu do dat o day, tinh theo mat GAN NHAT do duoc trong canh.
#
# ⛔ CA BON DEU NAM DUOI mat gan nhat, tuc MAC DINH VANH KHOANG CACH KHONG
# PHANH GI CA. Do khong phai luoi bieng — do la ket luan cua phep do:
#
#   * xep moc theo phan vi 20/40/60/80 cua chinh cac khoang cach (cach
#     "hop ly" nhat) cho ra 19% tiet kiem tren `PN4.blend`, vi mot phan
#     nam so map roi vao vanh "giu nguyen" va dieu kien khoang cach phu
#     quyet dieu kien dien tich;
#   * de vanh mo rong thi duoc ~50%, va anh render DEM PIXEL ra 0,022%
#     pixel lech qua 16/255 — tuc mat khong phan biet duoc.
#
# Dieu kien dien tich DA tinh ca xa gan roi: vat cang xa thi cang chiem it
# pixel. Vanh khoang cach vi vay khong phai la mot phep do thu hai — no la
# CAI PHANH cho nguoi dung xiet lai khi ho muon giu chac phan tien canh.
# Keo `1/2 beyond` len la bat dau phanh.
TI_LE_MOC_MO = (0.40, 0.60, 0.80, 0.95)


def moc_tu_canh(khoang_cach):
    """Bon moc do TU CHINH canh nay — mac dinh MO RONG, xem ghi chu tren.

    Tra None khi khong du so lieu, va luc do nguoi goi phai giu nguyen bo
    moc cu chu khong duoc bia ra mot bo moi.
    """
    kc = [float(x) for x in khoang_cach if x is not None]
    if len(kc) < 2:
        return None
    gan = min(kc)
    moc = [gan * t for t in TI_LE_MOC_MO]
    # phai tang dan that su: hai moc bang nhau la mot vanh RONG
    for i in range(1, len(moc)):
        if moc[i] <= moc[i - 1]:
            moc[i] = moc[i - 1] * 1.05 + 1e-6
    return tuple(moc)

CHE_DO_TAT = "TAT"
CHE_DO_TU_DONG = "TU_DONG"
CHE_DO_EP_CO = "EP_CO"

# Bao nhieu texel cho moi pixel man hinh o dieu kien 2. 1.0 = vua
# khit. Duoi 1.0 la anh bat dau nhoe thay ro. Tren 1.0 la chua an chac,
# tra bang VRAM.
DU_PHONG_MAC_DINH = 2.0

# ⛔ DIEU KIEN 2 DO BANG HAI THUOC, VA DAY LA CHO CHON THUOC NAO CAM QUYEN.
#
#   THEO_DINH = True   lay CHO DOI HOI DO NET CAO NHAT (mot tam giac)
#   THEO_DINH = False  lay TONG dien tich tren khung hinh / TONG dien tich
#                      tam anh ma vat lieu bay ra
#
# Hai thuoc nay khong thay nhau duoc, va cho chung LECH nhau la mot cho
# that trong scene noi that: mot san go co MOT o ngay duoi chan ong kinh
# va nghin o chay ve chan troi.
#
#   * theo DINH  -> giu do net cho cai o gan nhat, nen giu ca map. An toan,
#                   nhung do la truong hop map to nhat lai it duoc thu nho
#                   nhat;
#   * theo TONG  -> tinh theo ca san, nen ha manh. Tiet kiem nhieu hon,
#                   nhung cai o ngay duoi chan ong kinh se nhoe.
#
# ⛔ CHOT: lay TONG. Do tren `PN4.blend`, giu nguyen moi thu khac va chi
# doi rieng cai nay:  DINH -> giam 50%,  TONG -> giam 59%.
#
# Va TONG khong lam nhoe nhu tuong: `SoloFlannel` phu 3,4% cua khung
# 4000x2250, tuc 306.000 pixel; ha xuong 683x683 van con 466.000 texel —
# VAN NHIEU HON so pixel no chiem. Cong them `du_phong` mac dinh 2,0.
#
# Ca hai so deu in ra trong `ly_do` cua tung map, nen bam `Scan Scene` la
# doc duoc chung lech nhau bao nhieu tren chinh file cua minh.
THEO_DINH = False

# ⛔ TRAN CHO MAP CHIEM NHIEU DIEN TICH — Ducphan chot 22/08/2026:
# *"voi nhung anh map chiem qua nhieu dien tich trong bai thi chi resized
# toi da 1/2 thoi"*.
#
# Map nao phu tu `nguong_to` khung hinh tro len thi du hai dieu kien kia
# co dong y den may cung khong duoc ha qua 1/2. Day la mot cai TRAN dat
# len tren ket qua, khong phai dieu kien thu ba: no khong bao gio lam map
# bi ha NHIEU hon, chi chan bot.
#
# ⚠ `NGUONG_TO_MAC_DINH` la mot con so DAT SAN, khong phai mot so do —
# no la o `Big on screen` tren bang, nguoi dung chinh duoc. Dung chep no
# di cho khac roi coi no la hang so vat ly.
TRAN_KHI_TO = 1                 # chi so bac 1 = 1/2
NGUONG_TO_MAC_DINH = 0.10       # 10% dien tich khung hinh

# ⛔ MAP PHI MAU (bump / normal / roughness / displacement) HA IT HON.
#
# Day la bai hoc rut ra tu viec NHIN hai tam anh render, khong phai tu
# bang so — va bang so da noi nguoc lai. Tren `PN4.blend`, tam vai
# `SoloFlannel` phu 3,4% khung hinh (306.000 pixel) va phep dem texel noi
# rat ro la 683x683 (466.000 texel) VAN THUA. Dung ve so luong texel.
#
# Nhung anh render ra thi vai MAT HET VAN DET, va mat nguoi thay ngay.
#
# Ly do: mot map MAU thi mot texel la mot mau, ha xuong la trung binh
# cong — chap nhan duoc. Mot map NOI thi tung texel la mot huong phap
# tuyen, va trung binh cong cua nhieu huong nguoc nhau la MAT PHANG. Vi
# cau truc bi xoa, den highlight tren no tat theo, va be mat doc len la
# "nhua" chu khong con la "vai". Phep dem texel khong nhin thay chuyen do
# vi no dem SO LUONG chu khong dem THU BI MAT.
#
# Nen map phi mau khong duoc ha qua 1/2, du phep dem cho phep bao nhieu.
TRAN_PHI_MAU = 1                # chi so bac 1 = 1/2

# Map phu tu ngan nay khung hinh tro len thi GIU NGUYEN han. Mot tam phu
# ca khung hinh (anh thanh pho ngoai cua so) thi no CAN du do phan giai —
# ha no mot nua la nhin thay ngay. Day khong phai so "gu": no la dinh
# nghia cua "phu het khung hinh".
NGUONG_PHU_KIN = 1.00

# ⛔ HAI DIEU KIEN GOP LAI THE NAO.
#
#   "MIN"  bac IT thu nho hon thang — mot dieu kien noi "giu" la giu.
#   "MAX"  bac NHIEU thu nho hon thang — mot dieu kien noi "ha" la ha,
#          va cai chan duy nhat la TRAN "phu nhieu khung hinh".
#
# ⛔ Do tren file THAT `PN4.blend` cua Ducphan — mot phong ngu 939 MB map,
# moi thu cach ong kinh 2,3 den 8,0 met:
#
#     MIN  ->  giam 19%      (759 MB)
#     MAX  ->  giam 59%      (388 MB)   <- va ep cung ve 2048 chi duoc 54%
#
# Ly do MIN gan nhu vo dung o noi that: trong mot CAN PHONG thi khong co
# gi o xa ca, nen dieu kien khoang cach noi "giu" trong gan het truong
# hop, va voi MIN thi mot cai "giu" la phu quyet.
#
# ⛔ VA ROI ANH RENDER BAC BO MAX. Bang so chon MAX; MAT NGUOI thi khong.
#
# Render `PN4.blend` hai lan roi DEM PIXEL (`tools/so_anh.py`), lay tam
# doi chung la hai lan render cung che do:
#
#     doi chung Off/Off   pixel lech qua 16/255:  0,000%   max  1/255
#     MAX                 pixel lech qua 16/255:  0,959%   max 74/255
#     MIN + vanh mo rong  pixel lech qua 16/255:  0,022%   max 53/255
#
# MAX lam hong tam THAM: no phu 34% khung hinh, dieu kien dien tich noi
# ro la "giu nguyen", nhung MAX lay bac cua khoang cach (1/6) roi cai tran
# chi keo lai duoc toi 1/2 — van thieu. Cai gia cua MIN chi la vai phan
# tram bo nho, con cai gia cua MAX la mot tam tham nhin thay ro.
#
# Nen: MIN. Dieu kien dien tich la CAI CHAN TREN khong duoc vuot, con vanh
# khoang cach la CAI PHANH nguoi dung xiet them neu muon — mac dinh no mo
# rong (xem `moc_tu_canh`).
CACH_GOP = "MIN"


# ---------------------------------------------------------------------------
# Vanh khoang cach -> bac
# ---------------------------------------------------------------------------
def bac_theo_khoang_cach(kc, moc=MOC_MAC_DINH):
    """Tra ve CHI SO bac trong `BAC_CHIA` (0 = giu nguyen, 4 = 1/8).

    `moc` phai tang dan. Neu nguoi dung go lon xon thi sap xep lai o day
    chu khong keu loi: mot bang nhap so ma nem loi giua `draw()` la ca
    bang bien mat, va nguoi dung doc ra la "addon hong".
    """
    if kc is None:
        return 0
    m = sorted(float(x) for x in moc)
    for i, ngach in enumerate(m):
        if kc < ngach:
            return i
    return len(m)


def chia_cua_bac(i):
    i = max(0, min(int(i), len(BAC_CHIA) - 1))
    return BAC_CHIA[i]


def bac_tu_ti_le(ti_le):
    """Bac NHO NHAT (it thu nho nhat) van du cho `ti_le` yeu cau.

    Dung cho chot ham: `ti_le` la he so canh ma mat do texel doi hoi, nen
    bac duoc chon phai co 1/chia >= ti_le.
    """
    if ti_le is None or ti_le >= 1.0:
        return 0
    for i, chia in enumerate(BAC_CHIA):
        if (1.0 / chia) <= ti_le:
            return max(0, i - 1) if i else 0
    return len(BAC_CHIA) - 1


def ti_le_can(px_man, texel_co, du_phong=DU_PHONG_MAC_DINH):
    """He so tren MOT CANH ma tam anh can, trong khoang (0, 1]."""
    if texel_co is None or px_man is None:
        return None
    if texel_co <= 0.0:
        return 1.0
    if px_man <= 0.0:
        return 0.0
    return min(1.0, math.sqrt((px_man * du_phong) / texel_co))


# ---------------------------------------------------------------------------
# Bac -> co dich
# ---------------------------------------------------------------------------
def co_dich_theo_bac(w, h, i_bac, san_duoi=SAN_TUYET_DOI):
    """Chia CA HAI CANH cho cung mot so.

    Giu nguyen ti le hai canh: map 2048x1024 xuong 1/4 phai ra 512x256,
    khong phai 512x512. Day khong phai lam dep — keo mot canh la moi toa
    do UV lech, tuc doi ca hinh anh.

    `san_duoi` la san CANH LON, va no khong bao gio duoc thap hon
    `SAN_TUYET_DOI`. Ha duoi san thi lui dan len tung bac, chu khong kep
    cung — kep cung se lam mot map 1024 va mot map 8192 cung ra 512, tuc
    bac cua nguoi dung mat nghia.
    """
    san_duoi = max(int(san_duoi), SAN_TUYET_DOI)
    chia = chia_cua_bac(i_bac)
    if chia <= 1:
        return (w, h), 0
    i = int(i_bac)
    while i > 0 and (max(w, h) / float(chia_cua_bac(i))) < san_duoi:
        i -= 1
        chia = chia_cua_bac(i)
    if chia <= 1:
        return (w, h), 0
    return (max(1, int(round(w / float(chia)))),
            max(1, int(round(h / float(chia))))), i


def co_dich_ep(w, h, canh_ep):
    """Che do EP CO — ep canh lon xuong dung `canh_ep`.

    Giu ti le hai canh, va KHONG BAO GIO phong to: anh von nho hon muc ep
    thi de yen. Phong to mot tam 256 len 2048 khong them mot chi tiet nao,
    chi them 15,7 MB VRAM.

    Muc ep duoi `SAN_TUYET_DOI` bi keo len — o day cung phai qua cai san
    do, khong thi ca luat chi con canh mot cua.
    """
    canh_ep = max(int(canh_ep), SAN_TUYET_DOI)
    canh_lon = max(w, h)
    if canh_ep >= canh_lon:
        return (w, h)
    k = canh_ep / float(canh_lon)
    return (max(1, int(round(w * k))), max(1, int(round(h * k))))


# ---------------------------------------------------------------------------
def byte_anh(w, h, so_kenh=4, byte_moi_kenh=1):
    """Bo nho mot tam anh chiem, tinh bang byte.

    Cong thuc nay DA DOI CHIEU voi so that: 8 tam 4096x4096 8-bit cho ra
    536.870.912 B, va Cycles bao "Usage: 537.011.892" — lech dung phan
    chung cua bo dung. Xem `tools/do_vram.py`.

    Anh 16 bit / EXR / HDR la 4 byte moi kenh — GAP BON LAN. Nguoi goi phai
    truyen dung `byte_moi_kenh`, dung de mac dinh roi bao cao thieu bon lan.
    """
    return int(w) * int(h) * int(so_kenh) * int(byte_moi_kenh)


def phan_khung(a):
    """Map nay phu bao nhieu PHAN khung hinh. None neu khong do duoc.

    Cong don dien tich moi tam giac co gop mat roi chia cho dien tich
    khung hinh. Co the vuot 1.0 khi cac mat CHONG LEN NHAU truoc ong kinh
    (mot buc tuong dung sau mot buc tuong khac, cung vat lieu) — khong kep
    ve 1.0, vi con so do van dung nghia "map nay bay ra nhieu tren khung".
    """
    px_t = a.get("px_tong")
    khung = a.get("px_khung")
    if px_t is None or not khung:
        return None
    return px_t / float(khung)


def quyet_dinh(anh, che_do, moc=MOC_MAC_DINH, canh_ep=1024,
               san_duoi=SAN_TUYET_DOI, du_phong=DU_PHONG_MAC_DINH,
               nguong_to=NGUONG_TO_MAC_DINH, bo_qua=()):
    """Quyet dinh cho CA SCENE mot luot.

    `anh` la danh sach dict, moi tam mot dict:
        ten          ten anh trong file .blend
        w, h         co goc
        so_kenh      3 hoac 4
        byte_kenh    1 (8 bit) hoac 4 (float / EXR)
        khoang_cach  khoang cach GAN NHAT tu camera toi mot mat dung anh
                     nay — None neu khong do duoc
        px_man       dien tich lon nhat tren khung hinh, pixel — None neu
                     khong do duoc
        texel_co     so texel trai tren chinh mat do — None neu khong do duoc
        sua_duoc     False neu la anh generated / UDIM / dang co sua chua.
                     Anh PACKED thi sua DUOC — xem `doi_co._tra_lai_packed`.

    Tra ve danh sach dict co them: `moi_w`, `moi_h`, `doi`, `bac`, `ly_do`,
    `byte_truoc`, `byte_sau`.

    ⛔ LUAT: anh KHONG DO DUOC thi GIU NGUYEN, khong doan. Mot tam HDRI cua
    World khong nam tren mat nao nen khong co khoang cach — ha bua no xuong
    la troi trong anh vo mau, va nguoi dung khong bao gio doan ra do la
    addon nay lam.
    """
    ra = []
    for a in anh:
        w, h = int(a["w"]), int(a["h"])
        moi_w, moi_h, i_bac, ly_do = w, h, 0, ""
        b_them = {}

        if not a.get("sua_duoc", True):
            ly_do = "khong sua duoc (generated / dang sua / lien ket)"
        elif a["ten"] in bo_qua:
            ly_do = "nguoi dung chon bo qua"
        elif che_do == CHE_DO_EP_CO:
            moi_w, moi_h = co_dich_ep(w, h, canh_ep)
            ly_do = "ep ca scene ve %d" % canh_ep
        elif che_do == CHE_DO_TU_DONG:
            kc = a.get("khoang_cach")
            if kc is None:
                ly_do = "khong do duoc khoang cach — giu nguyen"
            else:
                bac_kc = bac_theo_khoang_cach(kc, moc)
                # DIEU KIEN 2 do bang HAI thuoc, xem ghi chu dau file:
                #   dinh  — cho doi hoi do net cao nhat, MOT tam giac
                #   tong  — tong dien tich vat lieu chiem tren khung hinh,
                #           tren tong dien tich TAM ANH ma no bay ra
                r_dinh = ti_le_can(a.get("px_man"), a.get("texel_co"),
                                   du_phong)
                r_tong = ti_le_can(a.get("px_tong"), a.get("texel_tong"),
                                   du_phong)
                bac_dinh = bac_tu_ti_le(r_dinh)
                bac_tong = bac_tu_ti_le(r_tong)
                bac_dt = bac_dinh if THEO_DINH else bac_tong
                r_dung = r_dinh if THEO_DINH else r_tong
                if r_dung is None:
                    # ⛔ LUAT 4 — KHONG DO DUOC THI GIU NGUYEN, KHONG DOAN.
                    # Cho nay la mot cai lo do phep gop MAX vua moi mo ra:
                    # voi MIN thi "khong do duoc" tu no ra bac 0 nen luat 4
                    # duoc giu MIEN PHI, con voi MAX thi khoang cach mot
                    # minh du de ha map xuong 1/8. Mot phep do da keu.
                    i_bac = 0
                else:
                    i_bac = (min(bac_kc, bac_dt) if CACH_GOP == "MIN"
                             else max(bac_kc, bac_dt))
                ly_do = "cach %.2f -> 1/%d | dt dinh -> 1/%d | dt tong " \
                        "-> 1/%d" % (kc, chia_cua_bac(bac_kc),
                                     chia_cua_bac(bac_dinh),
                                     chia_cua_bac(bac_tong))
                if r_dinh is None:
                    ly_do += " (khong do duoc dien tich)"

                # TRAN cho map NOI: bump / normal / roughness
                if a.get("phi_mau") and i_bac > TRAN_PHI_MAU:
                    ly_do += " | map noi -> tran 1/%d" % chia_cua_bac(
                        TRAN_PHI_MAU)
                    i_bac = TRAN_PHI_MAU

                # TRAN HAI BAC: phu kin khung hinh thi giu nguyen, phu
                # nhieu thi khong qua 1/2.
                phan = phan_khung(a)
                if phan is not None and phan >= nguong_to:
                    tran = 0 if phan >= NGUONG_PHU_KIN else TRAN_KHI_TO
                    if i_bac > tran:
                        ly_do += " | phu %.0f%% khung -> tran 1/%d" % (
                            phan * 100.0, chia_cua_bac(tran))
                        i_bac = tran
                    else:
                        ly_do += " | phu %.0f%% khung" % (phan * 100.0)

                b_them = {"bac_kc": bac_kc, "bac_dinh": bac_dinh,
                          "bac_tong": bac_tong, "phan_khung": phan}
                (moi_w, moi_h), i_bac = co_dich_theo_bac(
                    w, h, i_bac, san_duoi)
        else:
            ly_do = "che do TAT"

        kenh = int(a.get("so_kenh", 4))
        bk = int(a.get("byte_kenh", 1))
        b = dict(a)
        b.update(b_them)
        b["moi_w"], b["moi_h"] = moi_w, moi_h
        b["bac"] = i_bac
        b["doi"] = (moi_w, moi_h) != (w, h)
        b["ly_do"] = ly_do
        b["byte_truoc"] = byte_anh(w, h, kenh, bk)
        b["byte_sau"] = byte_anh(moi_w, moi_h, kenh, bk)
        ra.append(b)
    return ra


def tong_ket(ket_qua):
    """(byte_truoc, byte_sau, so_anh_doi) — de bang hien mot dong that."""
    truoc = sum(k["byte_truoc"] for k in ket_qua)
    sau = sum(k["byte_sau"] for k in ket_qua)
    doi = sum(1 for k in ket_qua if k["doi"])
    return truoc, sau, doi


def doc_byte(so_byte):
    """Doi byte ra chuoi nguoi doc duoc. Dung MB/GB nhi phan, giong Blender."""
    v = float(so_byte)
    if v < 1024.0:
        return "%d B" % int(v)
    for don in ("KB", "MB", "GB"):
        v /= 1024.0
        if v < 1024.0 or don == "GB":
            return "%.1f %s" % (v, don)
    return "%.1f GB" % v
