# -*- coding: utf-8 -*-
"""Cài plugin THẲNG TỪ BỘ NHỚ — không có file zip nào chạm đĩa.

VÌ SAO KHÔNG GHI ZIP RA THƯ MỤC TẠM
-----------------------------------
Bản cũ tải zip xuống `%TEMP%` rồi mới gọi `bpy.ops.preferences.addon_install`.
Trong khoảng đó file zip nằm sờ sờ trên đĩa: ai mở thư mục tạm cũng chép được
nguyên gói. Nay gói tải về chỉ tồn tại trong RAM, giải nén thẳng vào thư mục
addons — không có lúc nào tồn tại một file zip để chép.

ĐỔI LẠI: tự làm phần `addon_install` vốn làm hộ, nên phải tự lo ba việc mà nó
lo — tắt bản cũ trước khi ghi đè, xoá sạch thư mục cũ, và nạp lại danh sách
module. Bài nghiệm thu đo cả ba trên Blender thật.

NÓI RÕ GIỚI HẠN: cài xong thì mã nguồn plugin nằm nguyên trong thư mục addons,
ai cũng nén lại thành zip được. Chỗ này chỉ chặn việc gói cài LỌT RA NGOÀI lúc
tải; việc chạy được hay không vẫn do khoá theo máy quyết định.

KIỂM ĐƯỜNG DẪN TRƯỚC KHI GIẢI NÉN
---------------------------------
Một file zip có thể chứa `../../` để ghi ra ngoài thư mục đích. `extractall`
của Python đã cắt bỏ những đường như vậy, nhưng cắt bỏ TRONG IM LẶNG — một gói
hỏng sẽ cài ra nửa vời mà không ai biết. Ở đây kiểm trước và từ chối hẳn.
"""
import io
import os
import shutil
import zipfile

import bpy
import addon_utils

from . import catalog


def addons_dir():
    """Thư mục addons mà Blender đang thực sự dùng."""
    return bpy.utils.user_resource('SCRIPTS', path='addons', create=True)


def open_zip(source):
    """ZipFile từ bytes hoặc từ đường dẫn."""
    return zipfile.ZipFile(io.BytesIO(source) if isinstance(source, bytes)
                           else source)


def top_folder(zf):
    """Tên thư mục gốc trong zip = tên module Blender sẽ dùng.

    None nếu không có đúng MỘT thư mục gốc — lúc đó `addon_enable` sẽ hỏi một
    cái tên không tồn tại và báo lỗi khó hiểu, nên chặn ngay từ đây.
    """
    tops = {n.split('/')[0] for n in zf.namelist() if '/' in n}
    return tops.pop() if len(tops) == 1 else None


def check_members(zf, module):
    """Ném ValueError nếu zip chứa đường dẫn ra ngoài `module/`."""
    for name in zf.namelist():
        if name.startswith('/') or name.startswith('\\') or ':' in name[:3]:
            raise ValueError('zip contains an absolute path: %s' % name)
        parts = name.replace('\\', '/').split('/')
        if '..' in parts:
            raise ValueError('zip contains a parent path: %s' % name)
        if parts[0] != module:
            raise ValueError('zip has files outside %s/: %s' % (module, name))


def installed_version(module):
    """(số_hiệu_phiên_bản, đã_bật) của addon `module`. (None, False) nếu chưa cài."""
    for mod in addon_utils.modules(refresh=False):
        if mod.__name__ != module:
            continue
        info = getattr(mod, 'bl_info', None) or {}
        ver = info.get('version') or (0,)
        return tuple(ver), addon_utils.check(module)[1]
    return None, False


def install_bytes(raw, expect_module=None):
    """Cài một gói addon từ BYTES. Trả (thành_công, lời_nhắn)."""
    if raw[:2] != b'PK':
        # Nhận ra ngay trang HTML "xác nhận tải" hoặc trang 404 của host, thay
        # vì để Blender báo một lỗi zip khó hiểu ở tận bước sau.
        return False, 'that download was not a zip file'
    try:
        zf = open_zip(raw)
        module = top_folder(zf)
        if module is None:
            return False, 'zip has no single root folder'
        if expect_module and module != expect_module:
            return False, 'this package is %s, not %s' % (module, expect_module)
        check_members(zf, module)
    except ValueError as exc:
        return False, 'bad package: %s' % (exc,)
    except zipfile.BadZipFile:
        return False, 'the download is not a readable zip'

    was_version, was_enabled = installed_version(module)
    if was_enabled:
        # Ghi đè lên addon đang chạy: tắt trước cho nó nhả .pyc và gỡ lớp đã
        # đăng ký, không thì bản mới nạp chồng lên bản cũ còn sống.
        try:
            bpy.ops.preferences.addon_disable(module=module)
        except Exception as exc:
            print('[DP_Hub] tat addon cu loi: %r' % (exc,))

    dest = addons_dir()
    target = os.path.join(dest, module)
    if os.path.isdir(target):
        # Xoá hẳn chứ không ghi chồng: bản mới bỏ bớt file thì file cũ còn sót
        # lại vẫn được Python nạp, và lỗi kiểu đó rất khó lần ra.
        shutil.rmtree(target, ignore_errors=True)
    try:
        zf.extractall(dest)
    except Exception as exc:
        return False, 'could not unpack: %s' % (exc,)

    addon_utils.modules(refresh=True)
    try:
        bpy.ops.preferences.addon_enable(module=module)
    except Exception as exc:
        return False, 'installed but could not enable: %s' % (exc,)
    try:
        bpy.ops.wm.save_userpref()
    except Exception as exc:
        print('[DP_Hub] ghi tuy chinh loi: %r' % (exc,))

    now, enabled = installed_version(module)
    if now is None:
        return False, 'installed but Blender cannot see module %s' % module
    msg = 'installed %s v%s%s' % (module, '.'.join(str(n) for n in now),
                                  '' if enabled else ' (not enabled)')
    if was_version is not None:
        # Ghi đè lên addon ĐANG chạy: Python giữ module cũ đã nạp, nên mã mới
        # chỉ chắc chắn có hiệu lực sau khi mở lại Blender.
        msg += ' - restart Blender'
    return True, msg


def self_update(raw, module):
    """Thay CHÍNH DP_Hub bằng gói mới. Trả (thành_công, lời_nhắn).

    KHÔNG dùng chung đường với `install_bytes`, và đây là lý do — hai chuyện,
    cả hai đều làm hỏng thật:

    1. `install_bytes` gọi `addon_disable` trước khi ghi đè. Với addon khác thì
       đúng. Với CHÍNH MÌNH thì nó gỡ đăng ký cái operator đang chạy dở dòng
       lệnh này — Blender không hứa gì về chuyện đó. Nên ở đây KHÔNG tắt, không
       bật, không nạp lại danh sách module: mã mới có hiệu lực ở lần mở Blender
       sau, và nói thẳng với khách như vậy.

    2. `install_bytes` XOÁ HẲN thư mục cũ rồi mới bung bản mới. Hỏng đúng giữa
       hai bước đó thì bảng BIẾN MẤT khỏi máy khách — đúng cái cảnh việc tự cập
       nhật sinh ra để tránh. Ở đây dời sang một chỗ khác thay vì xoá, và bung
       hỏng thì dời ngược trở lại.

    Bản cũ dời ra NGOÀI thư mục addons: để lại trong đó thì Blender quét thấy
    và cố nạp một addon thứ hai cùng tên.
    """
    if raw[:2] != b'PK':
        return False, 'that download was not a zip file'
    try:
        zf = open_zip(raw)
        top = top_folder(zf)
        if top is None:
            return False, 'zip has no single root folder'
        if top != module:
            return False, 'this package is %s, not %s' % (top, module)
        check_members(zf, module)
    except ValueError as exc:
        return False, 'bad package: %s' % (exc,)
    except zipfile.BadZipFile:
        return False, 'the download is not a readable zip'

    dest = addons_dir()
    target = os.path.join(dest, module)
    if not os.path.isdir(target):
        # Không thấy bản đang cài: cứ bung ra, không có gì để giữ.
        try:
            zf.extractall(dest)
        except Exception as exc:
            return False, 'could not unpack: %s' % (exc,)
        return True, 'installed %s - restart Blender' % module

    import tempfile
    lui = tempfile.mkdtemp(prefix='dp_hub_lui_')
    giu = os.path.join(lui, module)
    try:
        shutil.move(target, giu)
    except Exception as exc:
        # Chưa động được vào bản cũ thì nó còn nguyên. Dừng ở đây là an toàn.
        return False, 'could not set the old version aside: %s' % (exc,)
    try:
        zf.extractall(dest)
        if not os.path.isfile(os.path.join(target, '__init__.py')):
            raise RuntimeError('the new package has no __init__.py')
    except Exception as exc:
        # ĐƯỜNG LÙI. Đến đây bản cũ vẫn còn nguyên vẹn ở chỗ dời, nên khách
        # không mất gì — cùng lắm là bản mới chưa lên được.
        shutil.rmtree(target, ignore_errors=True)
        try:
            shutil.move(giu, target)
            return False, ('update failed (%s) - the old version was put back'
                           % (exc,))
        except Exception as exc2:
            # Trường hợp xấu nhất, và khách PHẢI biết đường dẫn để tự cứu.
            return False, ('update failed (%s) and the old version could not '
                           'be restored (%s). Copy it back by hand from: %s'
                           % (exc, exc2, giu))
    shutil.rmtree(lui, ignore_errors=True)
    return True, 'DP_Hub updated - restart Blender to use the new version'


def install_from_catalog(item, key=None):
    """Tải rồi cài một mục danh mục. Trả (thành_công, lời_nhắn).

    `key` chỉ cần cho mục `gated` — cửa kiểm mã trả 403 nếu thiếu.
    """
    if not item.get('zip'):
        return False, 'no download link for this plugin yet'
    try:
        raw = catalog.http_get(item['zip'], timeout=60,
                               max_bytes=200 * 1024 * 1024,
                               key=key if item.get('gated') else None)
    except Exception as exc:
        # 503 = cửa kiểm còn sống nhưng tạm thời không đọc được danh mục công
        # khai. KHÔNG phải "chưa mua". Gộp nó vào "download refused" là lời
        # nhắn tệ nhất có thể: khách đã trả tiền mà đọc ra thành mình bị từ
        # chối, rồi đi hỏi lại tác giả về một chuyện sẽ tự hết sau vài phút.
        if catalog.http_status(exc) == 503:
            return False, ('download temporarily unavailable, '
                           'try again in a few minutes')
        if item.get('gated'):
            # Các 403 còn lại: mã không mở sản phẩm này · mã hết hạn · sản phẩm
            # không còn trong danh mục · file xin không thuộc sản phẩm đã mua.
            # Thân trả về của cửa kiểm nói rõ cái nào, nên đưa nguyên nó ra.
            return False, 'download refused: %s' % (exc,)
        return False, 'download failed: %s' % (exc,)

    want = catalog.version_tuple(item['version'])
    try:
        in_zip = catalog.zip_bl_info_version(raw)
    except Exception:
        in_zip = None
    ok, msg = install_bytes(raw, item['module'])
    if ok and in_zip and in_zip[:len(want)] != want[:len(in_zip)]:
        # Không chặn việc cài — bản trong gói mới là bản thật. Chỉ nói ra, vì
        # im lặng thì nút Update sẽ không bao giờ tắt và không ai hiểu vì sao.
        msg += ' | CATALOG VERSION MISMATCH: %s vs package %s' % (
            item['version'], '.'.join(str(n) for n in in_zip))
    return ok, msg
