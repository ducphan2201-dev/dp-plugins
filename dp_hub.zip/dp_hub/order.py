# -*- coding: utf-8 -*-
"""Khối ĐƠN HÀNG đi từ DP_Hub sang bot Telegram.

Khách điền MỌI THỨ trong Hub: tick addon muốn mua, Hub tự lấy mã máy và tự
tính tổng tiền. Bấm *Copy order* là clipboard nhận đúng MỘT DÒNG:

    DPORD1.eyJvIjoiN0szUSIsIm0iOiJleUpuZFdsayIsInAiOlsiZHBtYXgiXSwidCI6NX0

Khách dán một dòng đó vào bot kèm ảnh biên lai. Bot không hỏi thêm câu nào.

VÌ SAO MỘT DÒNG BASE64, không phải mấy dòng chữ dễ đọc
------------------------------------------------------
Khối nhiều dòng thì khách copy thiếu dòng cuối là chuyện thường, và bot vẫn
đọc ra một đơn "trông hợp lệ" — thiếu mất một sản phẩm, hoặc thiếu tổng tiền.
Sai kiểu đó không ai biết cho tới lúc khách kêu. Một dòng thì hoặc dán đủ,
hoặc hỏng ngay lúc mở gói.

KHỐI NÀY KHÔNG ĐƯỢC KÝ, VÀ KHÔNG CẦN KÝ
---------------------------------------
Khách sửa được nội dung trong đó (đổi tổng tiền, thêm sản phẩm). Không sao:
thứ quyết định cấp mã hay không là TÁC GIẢ nhìn ảnh biên lai rồi bấm duyệt.
Con số trong đơn chỉ để bày ra cạnh ảnh cho dễ so. Đừng bao giờ để bot tự
duyệt dựa vào `t` — đó là con số do máy khách gửi lên.

Mã máy (`m`) thì khác: nó có sửa cũng vô ích, vì mã cấp ra buộc theo đúng ba
yếu tố trong đó — sửa là tự làm mã của mình không chạy.

EMAIL LÀ BẮT BUỘC (02/08/2026)
------------------------------
Mã kích hoạt gửi cho khách **qua email**, còn Telegram chỉ là chỗ tác giả bấm
duyệt. Nên `e` là trường bắt buộc: đơn không có email thì có duyệt cũng không
biết gửi mã đi đâu. Chặn ngay lúc mở gói, kèm câu chữ bảo khách phải làm gì —
chứ để tới lúc tác giả bấm duyệt mới phát hiện thì khách đã chuyển tiền rồi.

Địa chỉ email đi TRONG đơn chứ không để tác giả gõ tay lúc duyệt: gõ sai một
chữ là mã bay vào hư không, mà khách thì đã trả tiền.
"""
import re
import json
import base64

PREFIX = 'DPORD1.'

# Cố tình lỏng. Đây không phải chỗ phán một địa chỉ có tồn tại hay không —
# chuyện đó chỉ máy chủ thư trả lời được. Nó chỉ bắt mấy lỗi gõ thấy ngay:
# thiếu @, thiếu chấm ở phần đuôi, còn khoảng trắng.
EMAIL_RE = re.compile(r'^[^@\s]+@[^@\s]+\.[^@\s]+$')


def email_ok(text):
    """Địa chỉ có ĐÁNG gửi thử không. Không phải "có tồn tại không"."""
    return bool(text) and bool(EMAIL_RE.match(str(text).strip()))

# Giới hạn thô, chặn người dán nhầm cả một file vào bot. Mã máy đã 104 ký tự
# nên đơn 6 sản phẩm vẫn dưới 400.
MAX_LEN = 4000


class OrderError(Exception):
    """Khối đơn không đọc được. Thông điệp viết cho NGƯỜI đọc, không phải log.

    `kind` phân biệt "thiếu thứ khách BUỘC phải điền" với những lỗi khác. Bảng
    Hub báo hai loại đó ở hai mức khác nhau: thiếu email là dòng đỏ chặn hẳn,
    còn giỏ rỗng chỉ là một lời nhắc.
    """

    def __init__(self, message, kind=''):
        super(OrderError, self).__init__(message)
        self.kind = kind


def _b64e(raw):
    return base64.urlsafe_b64encode(raw).decode('ascii').rstrip('=')


def _b64d(text):
    pad = '=' * (-len(text) % 4)
    return base64.urlsafe_b64decode(text + pad)


def pack(order_id, machine, products, total=0, note='', email='',
         name='', phone=''):
    """Đóng một đơn thành một dòng. `machine` = chuỗi `machine_id.export()`."""
    if not order_id or not machine:
        raise OrderError('đơn phải có mã đơn và mã máy')
    if not products:
        raise OrderError('đơn chưa chọn sản phẩm nào')
    if not email_ok(email):
        raise OrderError('đơn phải có email để nhận mã kích hoạt')
    body = {
        'o': str(order_id),
        'm': str(machine),
        'p': [str(c) for c in products],
        't': int(total or 0),
        'e': str(email).strip(),
    }
    if note:
        body['n'] = str(note)
    if name:
        body['c'] = str(name).strip()
    if phone:
        body['h'] = str(phone).strip()
    raw = json.dumps(body, separators=(',', ':'), sort_keys=True)
    return PREFIX + _b64e(raw.encode('utf-8'))


def unpack(text):
    """Mở một dòng đơn. Trả dict `{order, machine, products, total, note}`.

    Ném OrderError với LÝ DO CỤ THỂ. Bot in thẳng lý do đó cho khách, nên câu
    chữ ở đây là thứ khách đọc: "sai định dạng" không giúp ai, "bạn dán thiếu
    phần đầu" thì khách tự sửa được.
    """
    if not isinstance(text, str):
        raise OrderError('không có nội dung đơn')
    # Khách hay copy kèm khoảng trắng, và Telegram tự xuống dòng khi dài.
    text = ''.join(text.split())
    if not text:
        raise OrderError('không có nội dung đơn')
    if len(text) > MAX_LEN:
        raise OrderError('nội dung quá dài (%d ký tự) - bạn dán nhầm gì đó '
                         'chứ không phải mã đơn' % len(text))
    if not text.startswith(PREFIX):
        raise OrderError('thiếu phần đầu "%s" - hãy bấm nút Copy order trong '
                         'DP_Hub rồi dán lại nguyên vẹn' % PREFIX)
    try:
        raw = _b64d(text[len(PREFIX):])
        body = json.loads(raw.decode('utf-8'))
    except Exception:
        raise OrderError('mã đơn bị đứt hoặc sửa dở - hãy copy lại từ DP_Hub')
    if not isinstance(body, dict):
        raise OrderError('mã đơn không đúng khuôn')
    products = body.get('p')
    if not isinstance(products, list) or not products:
        raise OrderError('đơn không có sản phẩm nào')
    if not all(isinstance(c, str) and c for c in products):
        raise OrderError('danh sách sản phẩm trong đơn bị hỏng')
    machine = body.get('m')
    if not isinstance(machine, str) or not machine:
        raise OrderError('đơn thiếu mã máy')
    order_id = body.get('o')
    if not isinstance(order_id, str) or not order_id:
        raise OrderError('đơn thiếu mã đơn')
    total = body.get('t') or 0
    if not isinstance(total, int):
        raise OrderError('tổng tiền trong đơn không phải số')
    email = body.get('e')
    if not email:
        # Đơn do bản DP_Hub cũ sinh ra. Nói rõ phải làm gì, đừng nói "đơn sai
        # định dạng" — khách không đoán được là mình cần bản Hub mới.
        raise OrderError('đơn này chưa có email nhận mã. Hãy cập nhật DP_Hub '
                         'lên bản mới, điền email rồi bấm Copy order lại')
    if not isinstance(email, str) or not email_ok(email):
        raise OrderError('email trong đơn không đúng: %r' % (email,))
    return {
        'order': order_id,
        'machine': machine,
        'products': products,
        'total': total,
        'note': body.get('n') or '',
        'email': email.strip(),
        'name': body.get('c') or '',
        'phone': body.get('h') or '',
    }


# ------------------------------------------------------- XIN CẤP LẠI MÃ
# Khách đổi máy hoặc cài lại Windows. Họ ĐÃ TRẢ TIỀN rồi, nên đây không phải
# một lần bán mới và không có biên lai nào cả.
#
# TIỀN TỐ KHÁC HẲN đơn mua hàng. Dùng chung một khuôn thì một ngày nào đó một
# yêu cầu cấp lại sẽ lọt vào đường bán hàng — hoặc ngược lại, và cái sai đó
# không kêu ở đâu cả.
#
# Khách khai EMAIL đã mua và NGÀY MUA. Cả hai đều là thứ họ gõ, nên cả hai đều
# sửa được — và không sao: thứ quyết định là TÁC GIẢ bấm duyệt, rồi bot đối
# chiếu lại với SỔ BÁN RA trên máy tác giả. Sổ chỉ có thể thu hẹp, không bao
# giờ mở rộng: không tìm thấy lần mua nào thì không ký gì hết.
REKEY_PREFIX = 'DPREK1.'


def pack_rekey(machine, email, bought=''):
    """Đóng một yêu cầu cấp lại mã thành một dòng."""
    if not machine:
        raise OrderError('thiếu mã máy', kind='empty')
    if not email_ok(email):
        raise OrderError(
            'enter the email you bought with - the key is sent there',
            kind='email')
    body = {'m': str(machine), 'e': str(email).strip()}
    if bought:
        body['d'] = str(bought).strip()[:60]
    raw = json.dumps(body, separators=(',', ':'), sort_keys=True)
    return REKEY_PREFIX + _b64e(raw.encode('utf-8'))


def unpack_rekey(text):
    """Mở một dòng xin cấp lại. Trả `{machine, email, bought}`."""
    if not isinstance(text, str):
        raise OrderError('không có nội dung')
    text = ''.join(text.split())
    if not text.startswith(REKEY_PREFIX):
        raise OrderError('không phải yêu cầu cấp lại mã')
    if len(text) > MAX_LEN:
        raise OrderError('nội dung quá dài (%d ký tự)' % len(text))
    try:
        body = json.loads(_b64d(text[len(REKEY_PREFIX):]).decode('utf-8'))
    except Exception:
        raise OrderError('yêu cầu bị đứt hoặc sửa dở')
    if not isinstance(body, dict):
        raise OrderError('yêu cầu không đúng khuôn')
    machine = body.get('m')
    if not isinstance(machine, str) or not machine:
        raise OrderError('yêu cầu thiếu mã máy')
    email = body.get('e')
    if not isinstance(email, str) or not email_ok(email):
        raise OrderError('email trong yêu cầu không đúng: %r' % (email,))
    return {'machine': machine, 'email': email.strip(),
            'bought': str(body.get('d') or '')}


# Ảnh biên lai nặng tối đa bao nhiêu. PHẢI khớp với `RECEIPT_MAX` trong
# worker/dp_gate.js: chặn ở đây thì khách biết ngay lúc chọn file, còn chặn ở
# đó thì họ chờ tải hết 8 MB lên rồi mới nhận một câu từ chối.
RECEIPT_MAX = 5 * 1024 * 1024


def receipt_bytes(path):
    """Đọc ảnh biên lai thành bytes. Ném OrderError kèm câu khách đọc được.

    ĐỌC BYTE ĐẦU chứ không nhìn đuôi file: khách hay đổi tên file, và một file
    không phải ảnh thì cửa kiểm cũng từ chối — thà nói ngay tại đây, lúc họ còn
    đang nhìn vào ô chọn file, hơn là sau một vòng mạng.
    """
    import os
    path = (path or '').strip().strip('"')
    if not path:
        raise OrderError('chưa chọn ảnh biên lai chuyển khoản')
    if not os.path.isfile(path):
        raise OrderError('không thấy file ảnh: %s' % path)
    size = os.path.getsize(path)
    if size > RECEIPT_MAX:
        raise OrderError('ảnh nặng %.1f MB, tối đa %d MB - chụp lại nhỏ hơn'
                         % (size / 1048576.0, RECEIPT_MAX // 1048576))
    if not size:
        raise OrderError('file ảnh rỗng')
    with open(path, 'rb') as fh:
        raw = fh.read()
    if not (raw[:8].startswith(b'\x89PNG') or raw[:3] == b'\xff\xd8\xff'):
        raise OrderError('file này không phải ảnh PNG hay JPG')
    return raw


def money(vnd):
    """1200000 -> '1.200.000d'. Rỗng khi chưa định giá — KHÔNG in '0d'.

    In '0d' cho thứ chưa có giá là nói với khách rằng nó miễn phí.
    """
    try:
        n = int(vnd or 0)
    except (TypeError, ValueError):
        return ''
    if n <= 0:
        return ''
    s = '{:,}'.format(n).replace(',', '.')
    return s + 'd'


def make_order_id(machine, products, salt=''):
    """Mã đơn ngắn, dễ đọc qua điện thoại: DP-XXXX.

    Tính từ chính nội dung đơn chứ không lấy ngẫu nhiên, để cùng một khách
    cùng một giỏ hàng thì bấm lại vẫn ra đúng mã đó — khách chuyển khoản xong
    mới quay lại copy lần nữa là chuyện thường, và hai mã khác nhau cho cùng
    một lần mua thì tra sổ không ra.

    Bỏ các chữ dễ đọc nhầm khi đánh vần qua điện thoại: 0/O, 1/I, S/5, Z/2.
    """
    import hashlib
    seed = '%s|%s|%s' % (machine, ','.join(sorted(products)), salt)
    digest = hashlib.sha256(seed.encode('utf-8')).digest()
    alpha = '34679ACDEFGHJKLMNPQRTUVWXY'
    return 'DP-' + ''.join(alpha[b % len(alpha)] for b in digest[:4])
