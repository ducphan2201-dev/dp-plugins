# -*- coding: utf-8 -*-
"""Bảng điều khiển DP_Hub — một chỗ duy nhất: dán mã, cài, cập nhật, mua.

MỘT MÃ MỞ NHIỀU SẢN PHẨM
------------------------
Ô dán mã ở đây không hỏi "mã này của addon nào". Nó đọc danh sách sản phẩm ghi
NGAY TRONG mã rồi lưu cho từng sản phẩm một. Khách mua trọn bộ dán một lần là
xong; khách mua lẻ dán cùng ô đó cũng đúng.

HUB KHÔNG PHẢI LÀ CỔNG KHOÁ
---------------------------
Hub chỉ ĐỌC trạng thái mã của các addon khác, nên nó gọi thẳng `verify_text`
chứ không gọi `gate.check` — `check` thoát sớm ở bản dev và sẽ hiện "DEV" cho
mọi sản phẩm, tức bảng điều khiển nói dối về máy khách. Việc khoá hay không là
việc của chính addon đó.

ĐỊA CHỈ DANH MỤC LẤY THEO THỨ TỰ
--------------------------------
biến môi trường `DP_HUB_CATALOG_URL` (dùng cho bản kiểm tra) -> ô trong
Preferences -> địa chỉ mặc định trong `catalog.py`.
"""
import os
import sys
import json
import time
import urllib.parse

import bpy

from . import catalog
from . import install
from . import order as order_mod
from .dp_license import gate
from .dp_license import ui as lic_ui
from .dp_license import toolbox

ADDON_ID = __package__.partition('.')[0]

# Trạng thái đang hiện trên bảng. Chỉ đổi khi người dùng bấm nút.
#   `gate` = địa chỉ cửa kiểm, ĐỌC TỪ DANH MỤC (xem catalog.gate_of). Rỗng khi
#            chưa lấy được danh mục, hoặc danh mục cũ chưa khai trường đó —
#            lúc đó nút "Get my key" nói thẳng là chưa với tới được, chứ không
#            đoán một địa chỉ rồi trỏ vào hư không.
#   `hub`  = bản mới của CHÍNH bảng này, đọc từ danh mục. Rỗng khi danh mục
#            chưa khai (bản cũ) — lúc đó bảng im lặng, không nhắc gì, đúng như
#            trước khi có cơ chế này.
#   `order`= đơn đang chờ tác giả duyệt, đọc từ đĩa. Khách bấm gửi đơn xong
#            tắt Blender đi ăn cơm là chuyện thường; không nhớ thì mở lại họ
#            tưởng đơn bay mất rồi chuyển khoản lần nữa.
#   `send_failed` = lượt gửi đơn vừa rồi không tới được máy chủ. CHỈ lúc đó
#            bảng mới bày ra đường copy tay — xem `draw_dashboard`.
STATE = {'products': [], 'fetched': 0.0, 'skipped': 0, 'msg': '', 'gate': '',
         'hub': {}, 'payment': {'qr': '', 'note': ''}, 'order': {},
         'send_failed': False, 'trial': 0, 'tried': {}}


# --------------------------------------------------------------------------- #
# BAN BLENDER CUA MAY NAY CO CHAY NOI PHAN LOI KHONG
#
# CHUYEN THAT 12/08/2026: khach `hungkts.toancau@` mua dpsusync luc 21:08, bat
# addon len thi Blender bao thieu phan loi. May khach chay Blender 4.2. Phan loi
# trong goi duoc dich cho DUNG MOT DOI PYTHON — doi ma Blender 5.2 dung — nen
# Blender doi khac khong thay no o dau. Do lai ca nam addon dang ban: ca nam
# deu the. Bang nay truoc do KHONG he nhin toi ban Blender, cu bay nut
# Install / Try free / Buy cho moi may, nen khach tra tien xong moi biet.
#
# HAI LUAT, CA HAI DEU CO LY DO DAT BANG MAU:
#
# 1. KIEM DOI PYTHON DANG CHAY, KHONG KIEM SO HIEU BLENDER.
#    Doi Python la thu QUYET DINH phan loi nap duoc hay khong — kiem no la do
#    thang cai dang hong. Neo vao so hieu Blender la di qua mot bang tra ma
#    khong ai kiem chung duoc (may dev chi co Blender 5.2; khong co 5.0/5.1 de
#    biet chung chay doi nao). Chinh mot cai doan nhu the da de ra loi nay.
#
# 2. KHONG DOC DUOC THI CHO QUA, KHONG CHAN.
#    Chan nham mot khach dang chay dung ban la mat mot don hang THAT. Cho lot
#    mot may Blender cu thi chi quay ve dung tinh trang truoc khi co chot nay.
#
# Doi Python mac dinh ma ban dich hien nay can. Danh muc khai `min_py` thi lay
# theo danh muc — nho vay ngay mai dung ban cho doi khac chi phai sua danh muc,
# KHONG phai phat hanh lai bang nay.
PY_BAN_DICH = (3, 13)
BLENDER_KHUYEN = '5.2'
# --------------------------------------------------------------------------- #


def _doi_python_dang_chay():
    """(major, minor) cua Python dang chay, hoac None neu khong doc noi."""
    try:
        return (int(sys.version_info[0]), int(sys.version_info[1]))
    except Exception:
        return None


def _doi_python_can(item):
    """Doi Python mon nay doi hoi, hoac None = khong doi hoi gi.

    Mon TANG khong qua buoc dich nen chay moi ban — dung chan no.
    """
    khai = item.get('min_py')
    if isinstance(khai, (list, tuple)) and len(khai) >= 2:
        try:
            return (int(khai[0]), int(khai[1]))
        except (TypeError, ValueError):
            return None            # danh muc khai hong -> CHO QUA
    if item.get('free'):
        return None
    return PY_BAN_DICH


def blender_khong_hop(item):
    """True khi mon nay chac chan KHONG chay tren ban Blender dang mo."""
    can = _doi_python_can(item)
    if not can:
        return False
    dang = _doi_python_dang_chay()
    if not dang:
        return False               # khong do duoc -> CHO QUA
    return dang != can


def cau_doi_ban(item=None):
    """Cau bao cho khach. Noi ca ban can LAN ban ho dang chay."""
    dang = _doi_python_dang_chay()
    if dang:
        return ('Needs Blender %s - this one runs Python %d.%d'
                % (BLENDER_KHUYEN, dang[0], dang[1]))
    return 'Needs Blender %s or newer' % BLENDER_KHUYEN


def co_mon_nao_khong_hop():
    """Co mon nao trong danh muc khong chay noi tren may nay khong."""
    for item in STATE['products']:
        if blender_khong_hop(item):
            return True
    return False


def load_cached_into_state():
    products, at = catalog.load_cached()
    STATE['products'], STATE['fetched'] = products, at
    STATE['payment'] = catalog.load_cached_payment()
    STATE['gate'] = catalog.load_cached_gate()
    STATE['hub'] = catalog.load_cached_hub()
    STATE['trial'] = catalog.load_cached_trial_days()
    STATE['order'] = catalog.load_pending_order()


# ----------------------------------------------------------------- ảnh QR
# Blender KHÔNG vẽ được một file ảnh thẳng vào panel: ảnh phải đi qua một bộ
# sưu tập preview rồi mới có `icon_id` để `template_icon` dùng. Bộ này phải
# được giải phóng lúc gỡ addon, không thì Blender giữ mãi và báo rò tài nguyên.
_qr = {'coll': None, 'path': '', 'icon': 0}


# LOGO từng sản phẩm. Dùng chung cơ chế với ảnh QR, và cũng phải được giải
# phóng lúc gỡ addon.
_logo = {'coll': None, 'ids': {}}


def logo_icon(item):
    """`icon_id` logo của một sản phẩm, hoặc 0 nếu chưa có.

    Nạp LƯỜI ngay trong draw(), y như ảnh QR: logo chỉ tải về sau khi có danh
    mục, mà lúc có danh mục thì bảng đã vẽ xong từ lâu.

    KHÔNG GỌI MẠNG Ở ĐÂY. `fetch_icon` chỉ đọc file đã có sẵn trên đĩa; việc
    tải nằm ở nhịp lấy danh mục. Gọi mạng trong draw() là Blender đứng hình
    mỗi lần chuột đi qua bảng.
    """
    code = item.get('code') or ''
    if not item.get('icon') or not code:
        return 0
    if code in _logo['ids']:
        return _logo['ids'][code]
    path = catalog.icon_cache_path(code)
    if not os.path.isfile(path):
        return 0
    try:
        import bpy.utils.previews
        if _logo['coll'] is None:
            _logo['coll'] = bpy.utils.previews.new()
        if code in _logo['coll']:
            del _logo['coll'][code]
        prev = _logo['coll'].load(code, path, 'IMAGE')
        _logo['ids'][code] = prev.icon_id
        return prev.icon_id
    except Exception as exc:                                   # noqa: BLE001
        print('[DP_Hub] khong nap duoc logo %s: %r' % (code, exc))
        _logo['ids'][code] = 0
        return 0


def logo_release():
    """Trả bộ sưu tập preview lại cho Blender lúc gỡ addon."""
    if _logo['coll'] is not None:
        try:
            import bpy.utils.previews
            bpy.utils.previews.remove(_logo['coll'])
        except Exception:                                      # noqa: BLE001
            pass
    _logo['coll'], _logo['ids'] = None, {}


def logo_fetch_all():
    """Tải logo của mọi sản phẩm về đĩa. Gọi SAU khi lấy danh mục xong."""
    _logo['ids'] = {}          # danh mục mới có thể đổi logo
    for it in STATE['products']:
        if it.get('icon'):
            catalog.fetch_icon(it['code'], it['icon'])


def qr_loaded():
    """Ảnh QR đã nạp vào bộ sưu tập preview chưa (kích thước thật, hay None).

    Tách khỏi `qr_icon()` vì ở CHẾ ĐỘ NỀN Blender nạp ảnh bình thường nhưng
    `icon_id` **luôn bằng 0** — đo bằng icon_id ở đó sẽ báo hỏng oan. Cái đo
    được ở mọi chế độ là ảnh có đọc ra kích thước thật hay không.
    """
    coll = _qr['coll']
    if coll is None or 'qr' not in coll:
        return None
    try:
        w, h = tuple(coll['qr'].image_size)
    except Exception:
        return None
    return (w, h) if w and h else None


def qr_icon():
    """`icon_id` của ảnh QR đã tải, hoặc 0 nếu chưa có.

    Nạp LƯỜI, ngay trong draw(): ảnh chỉ tải về sau khi lấy danh mục, mà lúc
    register() thì chưa có gì. Nạp lại khi file đổi (tác giả thay QR).

    Trả 0 KHÔNG có nghĩa là hỏng: chế độ nền không cấp icon_id bao giờ. Chỗ
    gọi phải phân biệt "chưa có ảnh" với "có ảnh mà chưa vẽ được".
    """
    path = catalog.qr_cache_path()
    if not STATE['payment'].get('qr') or not os.path.isfile(path):
        return 0
    stamp = '%s@%s' % (path, os.path.getmtime(path))
    if _qr['path'] == stamp and _qr['icon']:
        return _qr['icon']
    try:
        import bpy.utils.previews
        if _qr['coll'] is None:
            _qr['coll'] = bpy.utils.previews.new()
        # Tên cũ phải bỏ trước khi nạp lại, không thì Blender giữ ảnh CŨ và
        # tác giả đổi QR mà khách vẫn quét ra số tài khoản cũ.
        if 'qr' in _qr['coll']:
            del _qr['coll']['qr']
        prev = _qr['coll'].load('qr', path, 'IMAGE')
        # Đọc `image_size` là thứ ÉP Blender nạp ảnh ngay. Không đọc thì lỗi
        # file hỏng chỉ nổ lúc vẽ, tức là trong draw handler — chỗ tệ nhất.
        tuple(prev.image_size)
        _qr['icon'] = prev.icon_id
        _qr['path'] = stamp
        return _qr['icon']
    except Exception as exc:
        print('[DP_Hub] khong nap duoc anh QR (%s): %r' % (path, exc))
        return 0


def refresh_payment():
    """Đọc lại khối thanh toán từ đệm và tải ảnh QR nếu địa chỉ đổi.

    Gọi sau MỖI lần lấy danh mục — cả lượt người dùng bấm lẫn lượt tự động.
    Tác giả đổi mã QR thì khách thấy trong vòng một lượt lấy danh mục, không
    phải chờ bản DP_Hub mới.
    """
    STATE['payment'] = catalog.load_cached_payment()
    url = STATE['payment'].get('qr')
    if not url:
        # Tác giả GỠ mã QR: xoá luôn ảnh cũ trên đĩa, không giữ lại. Giữ lại
        # là khách vẫn quét được một số tài khoản đã bị bỏ.
        try:
            if os.path.isfile(catalog.qr_cache_path()):
                os.remove(catalog.qr_cache_path())
        except OSError as exc:
            print('[DP_Hub] khong xoa duoc anh QR cu: %r' % (exc,))
        _qr['path'], _qr['icon'] = '', 0
        logo_fetch_all()
        return
    catalog.fetch_qr(url)
    # LOGO đi cùng nhịp này, cùng một lý do: tác giả đổi logo hay thêm sản
    # phẩm mới thì khách thấy sau một lượt lấy danh mục, không phải chờ một
    # bản DP_Hub mới.
    logo_fetch_all()


def qr_release():
    if _qr['coll'] is not None:
        try:
            import bpy.utils.previews
            bpy.utils.previews.remove(_qr['coll'])
        except Exception as exc:
            print('[DP_Hub] go bo suu tap anh loi: %r' % (exc,))
        _qr['coll'], _qr['path'], _qr['icon'] = None, '', 0


def prefs(context=None):
    ctx = context or bpy.context
    try:
        return ctx.preferences.addons[ADDON_ID].preferences
    except (KeyError, AttributeError):
        return None


def catalog_url(context=None):
    from_env = os.environ.get('DP_HUB_CATALOG_URL')
    if from_env:
        return from_env.strip()
    p = prefs(context)
    return (getattr(p, 'catalog_url', '') or catalog.DEFAULT_URL).strip()


def ne_bo_dem(url):
    """Địa chỉ đó, kèm một tham số đổi theo giây để không nhận bản trong đệm.

    `raw.githubusercontent.com` giữ bản cũ vài phút, và mỗi nút mạng giữ một
    bản riêng — nên tác giả vừa đẩy danh mục xong mà khách bấm Refresh thì rất
    có thể vẫn nhận về bản cũ, bấm bao nhiêu lần cũng thế. Bộ đệm coi mỗi địa
    chỉ khác nhau là một mục khác nhau, nên thêm một con số vào đuôi là hỏi
    được bản thật.

    Tách thành hàm riêng để đo được: nối chuỗi thẳng trong operator thì phép
    đo phải mở cả Blender lẫn một máy chủ giả mới sờ tới được.
    """
    return '%s%s_=%d' % (url, '&' if '?' in url else '?', int(time.time()))


# ------------------------------------------------- tự lấy danh mục ở luồng nền
# Tác giả khai plugin mới trên máy chủ thì máy khách phải TỰ thấy, không đợi ai
# nhớ bấm nút. Nhưng lấy về là việc của MẠNG: làm trên luồng chính thì Blender
# đứng hình cho tới khi máy chủ trả lời.
#
# Luồng nền CHỈ được đụng vào thư viện chuẩn và STATE — mọi lời gọi `bpy` đều
# nằm ở luồng chính (đường dẫn file đệm tính sẵn trước khi khởi động luồng, kết
# quả do timer nhận). Gọi `bpy` từ luồng khác là cách làm Blender sập.
AUTO_EVERY = 6 * 3600           # giây — không hỏi máy chủ dày hơn mức này
# Lượt ĐẦU của mỗi lần mở Blender được hỏi sớm hơn: mở máy ra mà bảng vẫn là
# bản của hôm qua thì cơ chế tự cập nhật coi như không có. Vẫn giữ một ngưỡng
# nhỏ để người mở-đóng Blender liên tục không gửi hàng chục lượt một giờ.
FIRST_MIN = 10 * 60
# ĐANG CHỜ MỘT ĐƠN thì hỏi dày hơn hẳn — 6 tiếng ở đây nghĩa là khách trả tiền
# xong ngồi nhìn màn hình cả buổi chiều. Chỉ chạy khi CÓ đơn treo, và tắt ngay
# khi mã về, nên đây không phải một vòng lặp hỏi mãi mãi.
PENDING_POLL = 120
_auto = {'thread': None, 'result': None, 'fresh_start': True, 'key_at': 0.0}


def _fetch_worker(url, cache, machine, cho_don):
    """LUỒNG NỀN. Không được gọi `bpy` — kể cả gián tiếp."""
    ket = {'catalog': None, 'keys': None}
    try:
        ket['catalog'] = catalog.fetch(url, cache=cache) + (None,)
    except Exception as exc:
        ket['catalog'] = (None, 0, exc)
    # NGÓ HỘP LẤY MÃ ngay trong cùng lượt này, khi máy đang chờ một đơn được
    # duyệt. Khách đã trả tiền rồi thì không nên bắt họ nhớ bấm thêm nút nào.
    #
    # Địa chỉ cửa kiểm đọc từ chính file đệm vừa ghi: `load_cached_gate()` gọi
    # `cache_path()`, mà hàm đó gọi `bpy` — thứ luồng nền không được đụng vào.
    if machine and cho_don:
        try:
            with open(cache, encoding='utf-8') as fh:
                base = catalog.gate_of(json.load(fh))
        except Exception:
            base = ''
        if base:
            try:
                ket['keys'] = fetch_keys(base, machine)
            except Exception as exc:
                # Im lặng với người dùng: đây là lượt tự động họ không yêu cầu.
                print('[DP_Hub] tu ngo hop lay ma that bai: %r' % (exc,))
    _auto['result'] = ket


def start_auto_fetch(url, cache, machine='', cho_don='', force=False):
    """Khởi động một lượt lấy danh mục ở luồng nền. True nếu có chạy."""
    import threading
    if _auto['thread'] is not None and _auto['thread'].is_alive():
        return False
    if not force and time.time() - (STATE['fetched'] or 0) < AUTO_EVERY:
        return False
    _auto['result'] = None
    _auto['thread'] = threading.Thread(
        target=_fetch_worker, args=(url, cache, machine, cho_don), daemon=True)
    _auto['thread'].start()
    return True


def apply_auto_fetch():
    """Nhận kết quả luồng nền (GỌI TỪ LUỒNG CHÍNH). True nếu vừa có cập nhật."""
    ket = _auto['result']
    if ket is None:
        return False
    _auto['result'] = None
    # MÃ VỀ RỒI THÌ ÁP NGAY, kể cả khi lượt lấy danh mục hỏng: hai việc không
    # liên quan gì tới nhau, và cái khách đang chờ là cái thứ hai.
    co_ma = False
    if ket.get('keys'):
        ok, msg = apply_keys(ket['keys'])
        STATE['msg'] = msg
        co_ma = True
        if ok:
            catalog.clear_pending_order()
            STATE['order'] = {}
        print('[DP_Hub] tu lay ma: %s' % msg)
    products, skipped, exc = ket['catalog']
    if exc is not None:
        # Im lặng với người dùng: đây là lượt lấy TỰ ĐỘNG mà họ không yêu cầu,
        # mất mạng là chuyện thường. Bảng vẫn giữ danh mục cũ. Vẫn ghi console
        # để còn lần ra khi có ai báo "không thấy plugin mới".
        print('[DP_Hub] tu lay danh muc that bai: %r' % (exc,))
        # VẼ LẠI NẾU MÃ VỪA VỀ. Mất mạng lúc lấy danh mục không liên quan gì
        # tới việc bảng vừa đổi từ "chưa kích hoạt" sang "đã kích hoạt" — thoát
        # sớm ở đây là khách phải rê chuột vào panel mới thấy thứ vừa xảy ra.
        if co_ma:
            _redraw()
        return co_ma
    STATE['products'] = products
    STATE['skipped'] = skipped
    STATE['fetched'] = time.time()
    # `fetch` vừa ghi cả hai thứ này xuống đệm; đọc lại từ đó thay vì tự phân
    # tích lần nữa, để đệm và bảng không bao giờ nói hai chuyện khác nhau.
    STATE['gate'] = catalog.load_cached_gate()
    STATE['hub'] = catalog.load_cached_hub()
    STATE['trial'] = catalog.load_cached_trial_days()
    refresh_payment()
    _redraw()
    return True


def _redraw():
    """Bảo Blender vẽ lại panel. Luồng CHÍNH."""
    for win in bpy.context.window_manager.windows:
        for area in win.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()


def _auto_timer():
    """Timer của Blender: vừa châm lượt lấy mới, vừa nhận kết quả lượt cũ."""
    apply_auto_fetch()
    p = prefs()
    if p is None or getattr(p, 'auto_check', True):
        # LƯỢT ĐẦU CỦA MỖI LẦN MỞ BLENDER thì hỏi luôn, không đợi hết 6 tiếng.
        # Mở Blender là một việc rời rạc, không phải vòng lặp — chờ tới hạn ở
        # đây nghĩa là tác giả vừa đổi giá xong, khách mở máy ra vẫn thấy bảng
        # cũ và không hiểu vì sao. `FIRST_MIN` chặn ca mở-đóng liên tục.
        first = _auto['fresh_start']
        _auto['fresh_start'] = False
        now = time.time()
        stale = now - (STATE['fetched'] or 0) >= FIRST_MIN
        # ĐANG CHỜ MỘT ĐƠN: hỏi dày hơn hẳn, và hỏi luôn cả hộp lấy mã. Tác giả
        # bấm duyệt trên điện thoại lúc nào không ai biết trước; khách thì đang
        # ngồi nhìn màn hình.
        cho_don = (STATE.get('order') or {}).get('order') or ''
        dang_cho = bool(cho_don) and now - (_auto['key_at'] or 0) >= PENDING_POLL
        may = lic_ui.machine_string() if dang_cho else ''
        if start_auto_fetch(catalog_url(), catalog.cache_path(),
                            machine=may, cho_don=cho_don if dang_cho else '',
                            force=(first and stale) or dang_cho) and dang_cho:
            _auto['key_at'] = now
    # Đang chờ máy chủ thì ngó lại sau một giây; không thì nằm im.
    running = _auto['thread'] is not None and _auto['thread'].is_alive()
    return 1.0 if running else 60.0


# ------------------------------------------------------------------ trạng thái
def product_state(item):
    """Mọi thứ cần biết về một sản phẩm, gom một chỗ để đo được ngoài draw()."""
    latest = catalog.version_tuple(item['version'])
    current, enabled = install.installed_version(item['module'])
    cho_mo_lai = install.cho_mo_lai(item['module'])
    lic, payload = gate.verify_text(gate.load_key(item['code']), item['code'])
    # CHƯA PHÁT HÀNH THÌ KHÔNG CÓ GÌ ĐỂ CÀI. Tác giả khai sản phẩm trong danh
    # mục từ lúc còn đang làm — đó là cách báo trước "sắp có" — nhưng chừng nào
    # gói chưa nằm trên kho thì mọi nút bấm dẫn tới nó đều là 404.
    released = bool(item.get('released', bool(item.get('zip'))))
    return {
        'code': item['code'],
        'latest': latest,
        'current': current,
        'enabled': enabled,
        'installed': current is not None,
        'released': released,
        # `update` phải kèm điều kiện đã phát hành: số hiệu bản trong danh mục
        # của một mục chưa phát hành là bản tác giả đang làm dở, và báo "có bản
        # mới" cho một bản không tải được thì tệ hơn là không báo gì.
        'update': bool(released and current is not None and latest > current),
        # ĐÃ CÀI BẢN MỚI NHƯNG BẢN CŨ CÒN ĐANG CHẠY.
        # Cảnh này KHÔNG có nút nào chữa được - không phải "chưa cài", không
        # phải "có bản mới" - nên nếu bảng không tự nói ra thì khách không có
        # đường nào đoán. Họ thấy bảng khoe bản mới, bảng của addon khoe bản
        # cũ, và không một nút Update nào để bấm. Ca thật: 14/08/2026.
        'needs_restart': cho_mo_lai is not None,
        'restart_to': cho_mo_lai,
        'license': lic,
        'payload': payload,
        'locked': (not item.get('free')) and lic != gate.OK,
        # DÙNG THỬ MỜI ĐƯỢC KHÔNG. Ba điều kiện, thiếu một là không mời:
        #   - danh mục có khai số ngày (0 hoặc thiếu = tác giả đã tắt);
        #   - sản phẩm này có khoá (món tặng thì mời dùng thử là vô nghĩa);
        #   - máy này CHƯA có mã hợp lệ cho nó.
        # Cố ý KHÔNG hỏi "đã từng thử chưa": sổ đó nằm ở cửa kiểm chứ không ở
        # máy khách, và mọi thứ ghi ở máy khách đều xoá lại được. Bấm nút rồi
        # bị từ chối thì bảng nói ra ngày đã thử — thật hơn là giấu cái nút đi
        # dựa trên một thứ không đáng tin.
        'can_trial': bool(trial_days() and not item.get('free')
                          and lic != gate.OK),
    }


def trial_days():
    """Số ngày dùng thử theo DANH MỤC. 0 = tác giả đã tắt dùng thử.

    Đọc từ danh mục chứ không cắm cứng ở đây: con số này khai đúng một chỗ
    (`trial_days` trong sổ đăng ký), và `--publish-catalog` chở nó tới đây.
    Cắm một số ở bảng là một ngày nào đó bảng hứa 5 ngày mà mã cho 14.
    """
    try:
        return int(STATE.get('trial') or 0)
    except (TypeError, ValueError):
        return 0


def _ver(nums):
    return '.'.join(str(n) for n in nums) if nums else '?'


def _khoang(giay):
    """90 -> '1 minute'. Chữ trên GIAO DIỆN nên tiếng Anh.

    Làm tròn XUỐNG và không bao giờ in '0': người vừa bấm gửi mà thấy 'Sent 0
    minutes ago' sẽ tưởng bảng chưa nhận.
    """
    giay = max(0, int(giay))
    if giay < 60:
        return 'less than a minute'
    for chia, ten in ((86400, 'day'), (3600, 'hour'), (60, 'minute')):
        if giay >= chia:
            n = giay // chia
            return '%d %s%s' % (n, ten, '' if n == 1 else 's')
    return 'less than a minute'


# ------------------------------------------------------------------ operator
class DPHUB_OT_refresh(bpy.types.Operator):
    """Download the plugin catalog again"""
    bl_idname = 'dphub.refresh'
    bl_label = 'Refresh catalog'
    bl_options = {'REGISTER'}

    def execute(self, context):
        # HỎI BẢN MỚI THẬT, KHÔNG NHẬN BẢN CŨ TRONG BỘ ĐỆM. `raw.github…` đệm
        # vài phút và mỗi nút mạng giữ một bản riêng, nên tác giả vừa đẩy danh
        # mục xong mà khách bấm Refresh thì rất có thể vẫn nhận về bản cũ —
        # bấm mười lần cũng thế. Đã xảy ra thật 10/08/2026 với một link video.
        #
        # Một tham số đổi theo giây là đủ: bộ đệm coi mỗi địa chỉ là một mục
        # riêng. CHỈ làm ở nút bấm tay — lượt tự lấy chạy sáu tiếng một lần,
        # bản cũ vài phút không phiền ai, mà mỗi lượt né đệm là một lượt bắt
        # máy chủ dựng lại bản trả về.
        url = catalog_url(context)
        moi = ne_bo_dem(url)
        # Gọi thẳng, không đẩy sang luồng khác: nó CHỈ chạy khi người dùng bấm
        # nút, và hạn chờ đã đặt ngắn (8 giay). Đổi lấy: không có luồng nền nào
        # đụng vào bpy - thứ Blender cấm.
        try:
            products, skipped = catalog.fetch(moi, url_ghi=url)
        except Exception as exc:
            STATE['msg'] = 'Cannot download catalog'
            self.report({'WARNING'}, 'Cannot download catalog: %s' % (exc,))
            print('[DP_Hub] tai danh muc loi (%s): %r' % (url, exc))
            return {'CANCELLED'}
        STATE['products'] = products
        STATE['skipped'] = skipped
        STATE['fetched'] = time.time()
        STATE['gate'] = catalog.load_cached_gate()
        STATE['hub'] = catalog.load_cached_hub()
        # SỐ NGÀY DÙNG THỬ phải đọc lại Ở ĐÂY nữa, không chỉ ở lượt tự lấy.
        # Máy mới cài chưa có bản danh mục nào trên đĩa, nên `STATE['trial']`
        # lúc mở Blender là 0. Nếu việc đầu tiên khách làm là bấm chính nút này
        # — đúng thứ mọi bản hướng dẫn bảo họ làm — thì `fetched` được đặt là
        # BÂY GIỜ, lượt tự lấy bị chặn suốt 6 tiếng sau đó, và số ngày ở lại 0
        # tới hết phiên. Mà 0 nghĩa là "tác giả đã tắt dùng thử": nút
        # "Try free" KHÔNG hiện ra, im lặng, trên đúng cái máy vừa cài xong.
        STATE['trial'] = catalog.load_cached_trial_days()
        refresh_payment()
        news = sum(1 for it in products if product_state(it)['update'])
        STATE['msg'] = ('%d plugin updates available' % news) if news else ''
        note = ' | %d bad entries skipped' % skipped if skipped else ''
        self.report({'INFO'}, '%d plugins, %d updates%s'
                    % (len(products), news, note))
        return {'FINISHED'}


# TOOLTIP MANG TÊN ĐẦY ĐỦ VÀ CÂU MÔ TẢ ĐẦY ĐỦ CỦA SẢN PHẨM.
#
# Từ 22/08/2026 mỗi sản phẩm nằm trong một ô lưới hẹp: tên bị cắt theo từ, mô
# tả chỉ còn một dòng. Phần bị cắt KHÔNG được phép biến mất — nó là câu tác giả
# viết để bán hàng. Chỗ chứa nó không tốn chiều cao bảng là tooltip của chính
# cái nút trong ô, và nó hiện ra đúng lúc con trỏ dừng lại để hỏi.
#
# Blender gọi `description()` MỖI LẦN rê chuột, kèm theo `properties` của đúng
# cái nút đang rê — nên một hàm này phục vụ được cả chín ô.
def _tooltip(properties, mac_dinh):
    """Tên + mô tả của sản phẩm mà cái nút này thuộc về.

    Không tìm thấy sản phẩm (danh mục chưa tải, hoặc operator bị gọi tay từ
    Console) thì trả câu mặc định của lớp — tooltip rỗng đọc như addon hỏng.
    """
    code = getattr(properties, 'code', '') or ''
    item = next((p for p in STATE['products'] if p['code'] == code), None)
    if item is None:
        return mac_dinh
    ten = item.get('name') or code
    mo_ta = ' '.join((item.get('desc') or '').split())
    return '%s\n\n%s\n\n%s' % (ten, mo_ta, mac_dinh) if mo_ta \
        else '%s\n\n%s' % (ten, mac_dinh)


class DPHUB_OT_install(bpy.types.Operator):
    """Download and install the latest version"""
    bl_idname = 'dphub.install'
    bl_label = 'Install'
    bl_options = {'REGISTER'}

    code: bpy.props.StringProperty()

    @classmethod
    def description(cls, context, properties):
        return _tooltip(properties, 'Download and install the latest version')

    def execute(self, context):
        item = next((p for p in STATE['products']
                     if p['code'] == self.code), None)
        if item is None:
            self.report({'WARNING'}, '%s is not in the catalog' % self.code)
            return {'CANCELLED'}
        # Chốt thứ hai, sau chỗ bảng không bày nút ra. Operator gọi được bằng
        # tay từ cửa sổ Console, và một danh mục cũ còn nằm trên đĩa vẫn có thể
        # mang mục chưa phát hành — nên chỗ LÀM VIỆC phải tự từ chối, không
        # trông vào chỗ VẼ.
        if not product_state(item)['released']:
            msg = '%s has not been released yet' % item['name']
            STATE['msg'] = msg
            self.report({'WARNING'}, msg)
            return {'CANCELLED'}
        key = None
        if item.get('gated'):
            # Kiểm mã NGAY TẠI MÁY trước khi gọi ra cửa: chưa mua thì nói luôn
            # "chưa kích hoạt" thay vì để khách chờ một vòng mạng rồi nhận 403.
            key = gate.load_key(item['code'])
            st = gate.verify_text(key, item['code'])[0]
            if st != gate.OK:
                msg = 'Activation key needed: %s' % gate.message(st)
                STATE['msg'] = msg
                self.report({'WARNING'}, msg)
                return {'CANCELLED'}
        ok, msg = install.install_from_catalog(item, key=key)
        STATE['msg'] = msg
        self.report({'INFO'} if ok else {'WARNING'}, msg)
        return {'FINISHED'} if ok else {'CANCELLED'}


class DPHUB_OT_video(bpy.types.Operator):
    """Watch the tutorial video for this plugin"""
    bl_idname = 'dphub.video'
    bl_label = 'Watch tutorial'
    bl_options = {'REGISTER'}

    url: bpy.props.StringProperty()

    def execute(self, context):
        if not self.url:
            self.report({'WARNING'}, 'No tutorial video for this plugin yet')
            return {'CANCELLED'}
        bpy.ops.wm.url_open(url=self.url)
        return {'FINISHED'}


# NỬA KIA CỦA MỘT SẢN PHẨM KHÔNG PHẢI LÚC NÀO CŨNG LÀ SKETCHUP (13/08/2026).
#
# `dpsusync` là sản phẩm hai nửa đầu tiên nên mọi chữ ở khối này viết thẳng chữ
# "SketchUp" vào, kể cả câu hướng dẫn cài. `dpcadsync` ra sau, nửa kia của nó là
# một file AutoLISP nạp bằng APPLOAD — dùng lại nguyên bộ chữ cũ là bảo khách
# mang file .lsp sang Extension Manager của SketchUp.
#
# Khai theo `kind` — chính trường mà `projects.json` đã khai và danh mục đã
# mang sẵn. Loại lạ thì lùi về câu chung chung: nói ít mà đúng, hơn là nói rõ
# mà sai tên phần mềm.
CPN_CHU = {
    'sketchup': {
        'can': 'Needs the SketchUp half too',
        'cai': 'install it in SketchUp: Extensions > Extension Manager > '
               'Install Extension, then pick this file',
    },
    'cad': {
        'can': 'Needs the CAD half too',
        # NÓI CẢ BƯỚC GIẢI NÉN. Nửa CAD đi trong một gói zip chỉ chứa đúng một
        # file .lsp — không phải vì CAD cần thế, mà vì DP_Hub 1.6.9 trở về
        # trước từ chối mọi thứ không phải zip; xem `note_vi_sao_zip` trong
        # projects.json. Bỏ bước đó khỏi câu hướng dẫn là khách mang thẳng
        # file .zip đi APPLOAD rồi tưởng CAD hỏng.
        'cai': 'unzip it, then load dp_cadsync.lsp in your CAD: type APPLOAD '
               'and pick it, then put it in the Startup Suite so it loads '
               'every time',
    },
}
CPN_CHUNG = {
    'can': 'Needs its other half too',
    'cai': 'the file is on your disk now - install it in the program it '
           'belongs to',
}


def cpn_chu(cpn):
    """Bộ chữ hợp với nửa kia này. Không bao giờ trả None."""
    return CPN_CHU.get((cpn or {}).get('kind') or '', CPN_CHUNG)


def cpn_nhan_duoc(raw, cpn):
    """Bản vừa tải về có ĐÚNG bằng cái danh mục đã khai không?

    ĐỂ RỜI RA KHỎI OPERATOR để đo được: bản thân việc tải về và ghi ra
    ~/Downloads thì bài kiểm không đụng tới được, nhưng CÁI QUYẾT ĐỊNH thì đo
    được, và cái quyết định mới là chỗ đã sai một lần.

    Trước 13/08/2026 chỗ này hỏi `raw[:2] == b'PK'` — đúng cho đúng một loại
    nửa kia là gói `.rbz` của SketchUp. Nửa CAD của `dpcadsync` là một file
    `.lsp` VĂN BẢN THUẦN, nên chốt đó từ chối thẳng một bản tải về hoàn toàn
    lành lặn rồi đẩy khách sang trình duyệt.

    `size` do `rollout.py --publish` ghi vào sổ SAU KHI đọc ngược file từ kho
    về, nên nó là kích thước THẬT. Đòi khớp đúng số đó bắt được cả cái mà chốt
    cũ bắt (nhận nhầm trang lỗi của máy chủ) lẫn cái nó không bắt: một gói zip
    tải về thiếu đuôi thì vẫn bắt đầu bằng `PK`.

    Danh mục cũ chưa khai `size` thì chỉ đòi khác rỗng — thà nhận một file đáng
    ngờ còn hơn chặn một bản tải đúng: file đã nằm trên đĩa thì khách nhìn ra
    ngay, còn một nút bấm chết thì không.
    """
    if not raw:
        return False
    can = int((cpn or {}).get('size') or 0)
    return len(raw) == can if can else True


class DPHUB_OT_companion(bpy.types.Operator):
    """Download the other half of this plugin and show it in the file browser

    Some plugins have a half that runs inside another program. That half
    installs from a file on disk, so it is saved to your Downloads folder and
    the folder is opened for you
    """
    bl_idname = 'dphub.companion'
    bl_label = 'Download the other half'
    bl_options = {'REGISTER'}

    code: bpy.props.StringProperty()

    # NHAN TREN NUT BI O LUOI CAT NGAN, nen tooltip phai mang CAU CAI DAT DAY
    # DU - do la thu noi cho khach biet mang file di dau. Cat mat cau do la
    # khach cam mot file .lsp va khong biet lam gi voi no.
    @classmethod
    def description(cls, context, properties):
        code = getattr(properties, 'code', '') or ''
        item = next((p for p in STATE['products'] if p['code'] == code), None)
        cpn = (item or {}).get('companion') or {}
        if not cpn:
            return 'Download the other half of this plugin'
        chu = cpn_chu(cpn)
        return '%s\n\n%s' % (cpn.get('label') or chu['can'], chu['cai'])

    def execute(self, context):
        item = next((p for p in STATE['products']
                     if p['code'] == self.code), None)
        cpn = (item or {}).get('companion')
        if not cpn:
            self.report({'WARNING'}, 'No extra download for this plugin')
            return {'CANCELLED'}
        # TẢI VỀ ĐĨA, không mở trình duyệt. Khách cần một FILE để đưa cho
        # Extension Manager của SketchUp; mở trình duyệt là đẩy họ qua một
        # đoạn đường nữa (bấm tải, tìm xem nó rơi vào đâu) mà bảng này làm hộ
        # được. Hỏng thì mới lùi về trình duyệt — vẫn còn đường đi, chỉ dài hơn.
        try:
            raw = catalog.http_get(cpn['url'], timeout=120,
                                   max_bytes=200 * 1024 * 1024)
        except Exception as exc:                                  # noqa: BLE001
            bpy.ops.wm.url_open(url=cpn['url'])
            msg = 'could not download here (%s) - opened it in your browser' \
                  % (exc,)
            STATE['msg'] = msg
            self.report({'WARNING'}, msg)
            return {'FINISHED'}
        # Xem `cpn_nhan_duoc` — cái quyết định để rời ra ngoài để đo được.
        if not cpn_nhan_duoc(raw, cpn):
            bpy.ops.wm.url_open(url=cpn['url'])
            msg = 'that download did not come through in one piece - opened ' \
                  'it in your browser'
            STATE['msg'] = msg
            self.report({'WARNING'}, msg)
            return {'FINISHED'}
        try:
            dest = os.path.join(os.path.expanduser('~'), 'Downloads')
            if not os.path.isdir(dest):
                dest = os.path.expanduser('~')
            path = os.path.join(dest, cpn['file'])
            with open(path, 'wb') as fh:
                fh.write(raw)
        except OSError as exc:
            msg = 'could not save the file: %s' % (exc,)
            STATE['msg'] = msg
            self.report({'ERROR'}, msg)
            return {'CANCELLED'}
        try:
            # Mở thư mục chứa nó. Không bắt buộc phải xong: file đã nằm trên
            # đĩa rồi, và đường dẫn có trong lời nhắn.
            bpy.ops.wm.path_open(filepath=dest)
        except Exception as exc:                                  # noqa: BLE001
            print('[DP_Hub] khong mo duoc thu muc: %r' % (exc,))
        msg = 'saved %s - %s' % (path, cpn_chu(cpn)['cai'])
        STATE['msg'] = msg
        self.report({'INFO'}, msg)
        return {'FINISHED'}


def key_for(code):
    """Mã kích hoạt hợp lệ của `code` trên máy này, hoặc None."""
    text = gate.load_key(code)
    return text if gate.verify_text(text, code)[0] == gate.OK else None


def install_owned(only=None):
    """Cài (hoặc cập nhật) mọi plugin máy này CÓ QUYỀN mà chưa cài.

    Đây là chỗ nối liền hai việc vốn tách rời: dán mã và cài plugin. Khách đã
    trả tiền thì không có lý do gì bắt họ tự đi tìm từng plugin để bấm cài —
    mã đã nói rõ họ mua những gì.

    Trả (danh_sách_đã_làm, danh_sách_hỏng).
    """
    done, fail = [], []
    for item in STATE['products']:
        if only is not None and item['code'] not in only:
            continue
        state = product_state(item)
        if not state['released']:
            continue                      # chưa có trên kho thì không có gì tải
        if state['installed'] and not state['update']:
            continue
        if not item['zip']:
            continue                      # bản gửi riêng, không tự tải được
        key = None
        if item.get('gated'):
            key = key_for(item['code'])
            if key is None:
                continue                  # chưa mua thì bỏ qua, không báo lỗi
        ok, msg = install.install_from_catalog(item, key=key)
        (done if ok else fail).append('%s: %s' % (item['name'], msg))
    return done, fail


class DPHUB_OT_install_owned(bpy.types.Operator):
    """Install every plugin your key covers"""
    bl_idname = 'dphub.install_owned'
    bl_label = 'Install all my plugins'
    bl_options = {'REGISTER'}

    def execute(self, context):
        done, fail = install_owned()
        if not done and not fail:
            STATE['msg'] = 'Nothing left to install'
            self.report({'INFO'}, STATE['msg'])
            return {'FINISHED'}
        STATE['msg'] = 'Installed %d plugin%s' % (len(done),
                                                  '' if len(done) == 1 else 's')
        if fail:
            STATE['msg'] += ' | %d failed' % len(fail)
        self.report({'INFO'} if not fail else {'WARNING'},
                    ' | '.join(done + fail))
        return {'FINISHED'}


class DPHUB_OT_buy(bpy.types.Operator):
    """Open the purchase page in your browser"""
    bl_idname = 'dphub.buy'
    bl_label = 'Buy'
    bl_options = {'REGISTER'}

    url: bpy.props.StringProperty()

    def execute(self, context):
        if not self.url:
            self.report({'WARNING'}, 'No purchase link for this plugin')
            return {'CANCELLED'}
        bpy.ops.wm.url_open(url=self.url)
        return {'FINISHED'}


# ------------------------------------------------------------------ giỏ hàng
# Khách tick sản phẩm muốn mua NGAY TRONG HUB, rồi bấm *Copy order*: clipboard
# nhận đúng một dòng mang mã máy + danh sách + tổng tiền. Bot Telegram chỉ việc
# NHẬN dòng đó — khách không phải gõ gì vào Telegram, không phải tự nhớ mình đã
# mua những gì, và tác giả không phải hỏi lại "máy nào, addon nào".
#
# Giỏ để trong WindowManager: nó là thứ tạm của phiên làm việc, không được đi
# vào file .blend của khách.
def cart_codes(context):
    raw = getattr(context.window_manager, 'dphub_cart', '') or ''
    return [c for c in raw.split(',') if c]


def cart_set(context, codes):
    context.window_manager.dphub_cart = ','.join(codes)


def buyable(item, state):
    """Sản phẩm này có tick mua được không, và VÌ SAO không.

    Trả (được_không, lý_do). Lý do là chữ hiện thẳng trên bảng — "không mua
    được" mà không nói tại sao thì khách tưởng Hub hỏng.
    """
    if item.get('free'):
        return False, ''
    if state['license'] == gate.OK:
        return False, ''            # đã có mã rồi, khối này không hiện nữa
    if not int(item.get('price') or 0):
        # Chưa định giá: đừng bịa ra một ô tick rồi cộng 0 vào tổng — khách sẽ
        # chuyển đúng số tiền đó, tức là không chuyển gì.
        #
        # Hỏi TRƯỚC câu "đã phát hành chưa": một món vừa chưa ra vừa chưa có
        # giá thì lý do đáng nói vẫn là chưa có giá, và nếu trả lời câu kia
        # trước thì dòng giải thích biến mất.
        return False, 'Contact for price'
    if not state.get('released'):
        # CHƯA PHÁT HÀNH THÌ KHÔNG BÁN. Trước 04/08/2026 ô tick vẫn sáng và
        # bấm được cho món đang ghi "Coming soon": khách tick, chuyển tiền, và
        # tác giả nhận một đơn cho món CHƯA CÓ HÀNG. Lúc đó chỉ còn hai đường,
        # cả hai đều tệ: hoàn tiền, hoặc để họ chờ không hẹn ngày.
        #
        # Khối cài phía trên đã bị bôi xám, nhưng bôi xám một nửa màn hình rồi
        # để nửa kia bấm được là tự mâu thuẫn — và khách tin vào cái BẤM ĐƯỢC.
        #
        # KHÔNG kèm lý do: ngay phía trên đã có dòng "Coming soon - not
        # released yet" rồi, nói lại lần nữa là thừa.
        return False, ''
    return True, ''


class DPHUB_OT_cart_toggle(bpy.types.Operator):
    """Add or remove this plugin from your order"""
    bl_idname = 'dphub.cart_toggle'
    bl_label = 'Add to order'
    bl_options = {'REGISTER'}

    code: bpy.props.StringProperty()

    @classmethod
    def description(cls, context, properties):
        return _tooltip(properties, 'Add or remove this plugin from your order')

    def execute(self, context):
        codes = cart_codes(context)
        if self.code in codes:
            codes.remove(self.code)
        else:
            codes.append(self.code)
        cart_set(context, codes)
        return {'FINISHED'}


def cart_total(context):
    """(số món, tổng tiền). Chỉ tính món CÒN bán: trong danh mục, có giá, ĐÃ ra.

    Phải khớp từng chữ với bộ lọc trong `order_lines` — con số hiện trên bảng
    và con số đi theo đơn mà lệch nhau thì khách chuyển đúng số họ nhìn thấy,
    còn tác giả đối chiếu với một con số khác.
    """
    codes = set(cart_codes(context))
    n, total = 0, 0
    for item in STATE['products']:
        if (item['code'] in codes and int(item.get('price') or 0)
                and item.get('released')):
            n += 1
            total += int(item['price'])
    return n, total


class DPHUB_OT_copy_order(bpy.types.Operator):
    """Copy your order - paste it to the author together with the receipt"""
    bl_idname = 'dphub.copy_order'
    bl_label = 'Copy order'
    bl_options = {'REGISTER'}

    def execute(self, context):
        # CHẶN Ở ĐÂY, không để tới lúc bot đọc đơn. Lúc đó khách đã chuyển tiền
        # và đang đợi, còn tác giả thì phải đi hỏi lại địa chỉ email.
        try:
            codes, line, oid = order_lines(context)
        except order_mod.OrderError as exc:
            # 'ERROR' cho thứ khách BUỘC phải sửa (thiếu email), 'WARNING' cho
            # thứ chỉ là chưa làm (chưa tick món nào). `report({'ERROR'})` biến
            # thành RuntimeError khi gọi từ Python — trên nút bấm thì chỉ là
            # một dòng đỏ — nên phân biệt hai mức này là có thật, không phải
            # chuyện thẩm mỹ.
            self.report({'ERROR'} if exc.kind == 'email' else {'WARNING'},
                        'Cannot build the order: %s' % exc)
            return {'CANCELLED'}
        total = cart_total(context)[1]
        # In ra console TRƯỚC khi động vào clipboard: chế độ nền không dựng
        # GHOST nên `wm.clipboard` luôn rỗng, và khách chạy Blender kiểu lạ vẫn
        # phải lấy được đơn của mình từ đâu đó.
        print('[DP_Hub] DON HANG %s (%d san pham, %d d):\n%s'
              % (oid, len(codes), total, line))
        try:
            context.window_manager.clipboard = line
        except Exception as exc:
            print('[DP_Hub] clipboard loi: %r' % (exc,))
            self.report({'WARNING'},
                        'Could not copy - the order is in the System Console')
            return {'CANCELLED'}
        self.report({'INFO'}, 'Order %s copied - send it with your receipt'
                    % oid)
        return {'FINISHED'}


def fetch_keys(base, machine, timeout=30):
    """Mã đang nằm trong hộp lấy mã của máy này. [] = tác giả chưa duyệt.

    MỘT CHỖ DUY NHẤT cho cả nút "Get my key" lẫn lượt tự dò ở luồng nền. Hàm
    này KHÔNG gọi `bpy` và KHÔNG lưu gì — chạy được ở cả hai luồng.

    Ném khi mạng hỏng thật. KHÔNG ném khi 404: 404 ở đây nghĩa là *chưa có*,
    không phải *bị từ chối*, và với người vừa chuyển tiền thì hai câu đó khác
    hẳn nhau.
    """
    url = '%s/key?m=%s' % (base.rstrip('/'), urllib.parse.quote(machine))
    try:
        raw = catalog.http_get(url, timeout=timeout)
    except Exception as exc:
        if catalog.http_status(exc) == 404:
            return []
        raise
    data = json.loads(raw.decode('utf-8'))
    return [str(m.get('key') or '') for m in (data.get('keys') or [])
            if m.get('key')]


def order_lines(context):
    """(mã_sản_phẩm_đã_tick, dòng_đơn, mã_đơn). Ném OrderError nếu chưa đủ.

    Một chỗ duy nhất dựng đơn, cho cả nút *Send order* lẫn đường lùi *Copy
    order*. Hai bản là một bản sẽ quên một bước, và bước quên đó chỉ lộ ra khi
    khách đã chuyển tiền.
    """
    # CHỐT ĐẶT TẠI CHỖ ĐÓNG ĐƠN, không phải ở chỗ vẽ nút.
    #
    # Ẩn ô tick của món chưa phát hành là chưa đủ: món đó có thể đã nằm sẵn
    # trong giỏ từ hôm nó còn đang bán, rồi tác giả kéo về nấc "sắp có". Giỏ
    # được nhớ xuống đĩa, nên nó nằm đó qua cả lần khởi động lại Blender.
    #
    # Lọc ở đây thì mọi đường đóng đơn — nút Send order lẫn đường lùi Copy
    # order — đều đi qua cùng một chốt.
    ban_duoc = {p['code'] for p in STATE['products']
                if int(p.get('price') or 0) and p.get('released')}
    codes = [c for c in cart_codes(context) if c in ban_duoc]
    if not codes:
        raise order_mod.OrderError('your order is empty', kind='empty')
    p = prefs(context)
    email = (getattr(p, 'buyer_email', '') or '').strip()
    if not order_mod.email_ok(email):
        raise order_mod.OrderError(
            'enter a valid email first - your activation key is sent there',
            kind='email')
    machine = lic_ui.machine_string()
    total = cart_total(context)[1]
    oid = order_mod.make_order_id(machine, codes)
    line = order_mod.pack(oid, machine, codes, total, email=email,
                          name=(getattr(p, 'buyer_name', '') or '').strip(),
                          phone=(getattr(p, 'buyer_phone', '') or '').strip())
    return codes, line, oid


class DPHUB_OT_send_order(bpy.types.Operator):
    """Send your order and payment receipt to the author - no copy, no paste"""
    bl_idname = 'dphub.send_order'
    bl_label = 'Send order'
    bl_options = {'REGISTER'}

    def _no(self, msg):
        STATE['msg'] = msg
        self.report({'WARNING'}, msg)
        return {'CANCELLED'}

    def execute(self, context):
        try:
            codes, line, oid = order_lines(context)
        except order_mod.OrderError as exc:
            # Cùng luật với Copy order: thiếu email là dòng đỏ chặn hẳn.
            STATE['msg'] = 'Cannot send: %s' % exc
            self.report({'ERROR'} if exc.kind == 'email' else {'WARNING'},
                        STATE['msg'])
            return {'CANCELLED'}

        p = prefs(context)
        try:
            # ĐỌC ẢNH TRƯỚC KHI GỌI MẠNG. Chọn nhầm file là chuyện thường, và
            # biết ngay lúc còn đang nhìn vào ô chọn file thì sửa được; biết
            # sau một vòng tải lên thì họ chỉ thấy "gửi thất bại".
            #
            # `abspath` là bắt buộc: ô kiểu FILE_PATH trả về đường dẫn bắt đầu
            # bằng `//` khi khách chọn file nằm cạnh file .blend của họ, và
            # `open()` của Python không hiểu ký hiệu đó.
            anh = order_mod.receipt_bytes(
                bpy.path.abspath(getattr(p, 'receipt_path', '') or ''))
        except order_mod.OrderError as exc:
            return self._no('Receipt: %s' % exc)

        if not STATE.get('gate'):
            try:
                bpy.ops.dphub.refresh()
            except Exception as exc:
                print('[DP_Hub] lay danh muc truoc khi gui don loi: %r' % (exc,))
        base = STATE.get('gate') or ''
        if not base:
            STATE['send_failed'] = True
            return self._no('Cannot reach the server - check your internet '
                            'connection')

        url = '%s/order?o=%s' % (base.rstrip('/'), urllib.parse.quote(line))
        try:
            raw = catalog.http_post(url, anh)
        except Exception as exc:
            # BÀY RA ĐƯỜNG LÙI. Cửa kiểm không với tới được (mạng công ty chặn,
            # Cloudflare hỏng) thì khách vẫn phải gửi được đơn cho tác giả bằng
            # tay — nhưng chỉ LÚC NÀY mới bày ra, xem `draw_dashboard`.
            STATE['send_failed'] = True
            ma = catalog.http_status(exc)
            print('[DP_Hub] gui don that bai (%s): %r' % (url[:80], exc))
            return self._no('Could not send the order%s: %s'
                            % (' (server said %s)' % ma if ma else '', exc))

        try:
            tra = json.loads(raw.decode('utf-8'))
        except Exception:
            tra = {}
        # Máy chủ chốt mã đơn, không phải máy khách: hai bên tính cùng một cách
        # nhưng thứ tác giả nhìn thấy trên Telegram là con số của MÁY CHỦ.
        oid = str(tra.get('order') or oid)
        if not tra.get('notified'):
            # KHÔNG nói ra với khách: đơn đã lên tới nơi thật, và câu "chưa báo
            # được cho tác giả" chỉ làm người vừa trả tiền hoảng. Tác giả có
            # đường lấy lại: python tools/bot_telegram.py --donhang
            print('[DP_Hub] don %s da len kho nhung Telegram khong nhan' % oid)

        STATE['send_failed'] = False
        rec = {'order': oid, 'at': time.time(), 'products': codes,
               'total': cart_total(context)[1]}
        catalog.save_pending_order(rec)
        STATE['order'] = rec
        # BỎ TICK sau khi gửi. Để nguyên giỏ hàng là lần sau họ bấm gửi thêm
        # một đơn y hệt nữa, và tác giả nhận hai biên lai cho một lần chuyển
        # tiền.
        cart_set(context, [])
        # XOÁ Ô ẢNH. Biên lai là thứ dùng một lần; để nguyên thì lần mua sau
        # khách bấm gửi mà không để ý là tác giả nhận đúng cái biên lai cũ và
        # tưởng họ đã trả tiền.
        if p is not None:
            try:
                p.receipt_path = ''
            except Exception as exc:
                print('[DP_Hub] khong xoa duoc o anh bien lai: %r' % (exc,))
        _auto['key_at'] = 0.0          # ngó hộp lấy mã ngay ở nhịp timer sau
        # NÓI RA ĐỊA CHỈ EMAIL, VÀ NHẮC HỘP SPAM. Hai bệnh khác nhau, cùng chữa
        # bằng một câu:
        #   - thư cấp mã rơi vào Spam (đã xảy ra thật) — khách tưởng chưa được
        #     cấp và đi hỏi lại, trong khi mã đã nằm sẵn trong hộp thư của họ;
        #   - khách gõ nhầm địa chỉ (đã xảy ra thật: thiếu một chữ trong tên) —
        #     đọc thấy địa chỉ ngay lúc này thì họ tự phát hiện khi CÒN SỬA
        #     ĐƯỢC, thay vì lộ ra sau khi tiền đã chuyển.
        # Email đọc lại từ ô khai báo chứ không giữ biến từ `order_lines`: chỗ
        # trên chỉ xoá ô ẢNH BIÊN LAI, ô email vẫn nguyên.
        email = (getattr(p, 'buyer_email', '') or '').strip() if p else ''
        msg = ('Order %s sent. The author will approve it shortly - your '
               'plugins will activate by themselves.' % oid)
        if email:
            msg += (' Your activation key is also emailed to %s - if you do '
                    'not see it, look in your Spam folder.' % email)
        STATE['msg'] = msg
        self.report({'INFO'}, msg)
        return {'FINISHED'}


class DPHUB_OT_rekey(bpy.types.Operator):
    """Lost your key after changing PC or reinstalling Windows? Ask for a new one"""
    bl_idname = 'dphub.rekey'
    bl_label = 'Request a new key'
    bl_options = {'REGISTER'}

    def execute(self, context):
        p = prefs(context)
        email = (getattr(p, 'buyer_email', '') or '').strip()
        if not order_mod.email_ok(email):
            msg = ('Enter the email you bought with - the new key is sent '
                   'there')
            STATE['msg'] = msg
            self.report({'ERROR'}, msg)
            return {'CANCELLED'}

        if not STATE.get('gate'):
            try:
                bpy.ops.dphub.refresh()
            except Exception as exc:
                print('[DP_Hub] lay danh muc truoc khi xin cap lai loi: %r'
                      % (exc,))
        base = STATE.get('gate') or ''
        if not base:
            msg = 'Cannot reach the server - check your internet connection'
            STATE['msg'] = msg
            self.report({'WARNING'}, msg)
            return {'CANCELLED'}

        # MÃ MÁY ĐI TỰ ĐỘNG, khách không đọc và không dán. Đó là toàn bộ lý do
        # cơ chế này tồn tại: đường cũ bắt họ bấm "Copy machine code" rồi dán
        # vào email, và một phần khách sẽ gõ tay một dãy ngắn nào đó thay vì
        # dán — mã cấp theo dãy ngắn thì không bao giờ chạy.
        line = order_mod.pack_rekey(
            lic_ui.machine_string(), email,
            (getattr(p, 'bought_when', '') or '').strip())
        url = '%s/rekey?o=%s' % (base.rstrip('/'), urllib.parse.quote(line))
        try:
            catalog.http_post(url, b'')
        except Exception as exc:
            ma = catalog.http_status(exc)
            print('[DP_Hub] xin cap lai that bai (%s): %r' % (url[:80], exc))
            msg = ('Could not send the request%s: %s'
                   % (' (server said %s)' % ma if ma else '', exc))
            STATE['msg'] = msg
            self.report({'WARNING'}, msg)
            return {'CANCELLED'}

        # Dùng chung ô nhớ "đang chờ duyệt" với đơn mua: cùng một việc chờ, và
        # vòng tự dò hộp lấy mã đã bám vào đúng ô đó rồi.
        rec = {'order': 'CAP-LAI', 'at': time.time(), 'products': [],
               'total': 0, 'rekey': True}
        catalog.save_pending_order(rec)
        STATE['order'] = rec
        _auto['key_at'] = 0.0
        msg = ('Request sent. Once the author approves it, your plugins will '
               'activate by themselves.')
        STATE['msg'] = msg
        self.report({'INFO'}, msg)
        return {'FINISHED'}


class DPHUB_OT_trial(bpy.types.Operator):
    """Start a free trial - no payment, no receipt, nothing to fill in"""
    bl_idname = 'dphub.trial'
    bl_label = 'Try free'
    bl_options = {'REGISTER'}

    code: bpy.props.StringProperty()

    @classmethod
    def description(cls, context, properties):
        return _tooltip(properties, 'Start a free trial - no payment, no '
                                    'receipt, nothing to fill in')

    def execute(self, context):
        item = next((p for p in STATE['products']
                     if p['code'] == self.code), None)
        if item is None:
            self.report({'WARNING'}, '%s is not in the catalog' % self.code)
            return {'CANCELLED'}

        if not STATE.get('gate'):
            try:
                bpy.ops.dphub.refresh()
            except Exception as exc:                            # noqa: BLE001
                print('[DP_Hub] lay danh muc truoc khi xin dung thu loi: %r'
                      % (exc,))
        base = STATE.get('gate') or ''
        if not base:
            msg = 'Cannot reach the server - check your internet connection'
            STATE['msg'] = msg
            self.report({'WARNING'}, msg)
            return {'CANCELLED'}

        # EMAIL LÀ TUỲ CHỌN. Ducphan chốt: *"user cứ cài là dùng được"* — một ô
        # bắt buộc đứng chắn trước bản dùng thử là chỗ mất khách đông nhất. Có
        # địa chỉ thì mã được gửi kèm vào thư; không có thì nó vẫn về qua ô lấy
        # mã, và bảng này tự kích hoạt như với một đơn đã duyệt.
        p = prefs(context)
        email = (getattr(p, 'buyer_email', '') or '').strip()
        line = order_mod.pack_trial(lic_ui.machine_string(), email, self.code)
        url = '%s/trial?o=%s' % (base.rstrip('/'), urllib.parse.quote(line))
        try:
            raw = catalog.http_post(url, b'')
        except Exception as exc:                                # noqa: BLE001
            ma = catalog.http_status(exc)
            print('[DP_Hub] xin dung thu that bai (%s): %r' % (url[:80], exc))
            msg = ('Could not start the trial%s: %s'
                   % (' (server said %s)' % ma if ma else '', exc))
            STATE['msg'] = msg
            self.report({'WARNING'}, msg)
            return {'CANCELLED'}

        # CỬA KIỂM LUÔN TRẢ 200, kể cả khi từ chối — nên câu trả lời nằm trong
        # THÂN, không nằm ở mã trạng thái. Đọc nhầm chỗ là một lời từ chối bị
        # đọc thành "đã gửi xong", và khách ngồi đợi một cái mã không bao giờ
        # tới.
        try:
            tra = json.loads(raw.decode('utf-8'))
        except Exception:                                       # noqa: BLE001
            tra = {}
        if not tra.get('ok'):
            vi_sao = tra.get('why') or ''
            if vi_sao == 'used':
                khi = tra.get('at') or 0
                ngay = (time.strftime('%d/%m/%Y',
                                      time.localtime(khi / 1000.0))
                        if khi else '')
                msg = ('Your free trial of %s has ended%s'
                       % (item['name'], (' - it started on ' + ngay)
                          if ngay else ''))
            elif vi_sao == 'too_many':
                # NÓI THẲNG LÀ CHẶN THEO ĐƯỜNG MẠNG. Một văn phòng nhiều máy
                # chung một đường mạng có thể chạm trần thật, và người ngồi đó
                # không tự đoán ra được lý do — họ sẽ tưởng addon hỏng.
                msg = ('Too many trials were started from this network today. '
                       'Try again tomorrow, or contact the author.')
            elif vi_sao == 'off':
                msg = 'Free trials are turned off at the moment'
            else:
                msg = ('Could not start the trial - please try again in a '
                       'moment')
            STATE['msg'] = msg
            self.report({'WARNING'}, msg)
            return {'CANCELLED'}

        # MÃ VỀ NGAY TRONG CÂU TRẢ LỜI (13/08/2026). Cửa kiểm tự ký mã dùng
        # thử, nên đường này không còn chỗ nào phải chờ: dán mã, cài plugin,
        # xong — tất cả trong đúng cái nhấp chuột khách vừa làm.
        #
        # `apply_keys` là chỗ DUY NHẤT áp mã, dùng chung với nút dán tay và nút
        # lấy mã. Viết riêng một đường áp mã ở đây là một ngày nào đó đường này
        # quên mất bước tự cài plugin.
        ma = (tra.get('key') or '').strip()
        if ma:
            ok, msg = apply_keys([ma])
            if ok:
                # Không còn gì để chờ: xoá dòng "đang chờ duyệt" nếu lần bấm
                # trước có để lại một dòng (bấm lúc cửa chưa ký được).
                catalog.clear_pending_order()
                STATE['order'] = {}
                n = int(tra.get('days') or trial_days() or 0)
                msg = ('Trial started%s | %s'
                       % (' - %d days' % n if n else '', msg))
            STATE['msg'] = msg
            self.report({'INFO'} if ok else {'WARNING'}, msg)
            return {'FINISHED'} if ok else {'CANCELLED'}

        # ĐƯỜNG LÙI: cửa kiểm nhận đơn nhưng chưa ký được mã (chưa cắm khoá ký
        # dùng thử). Vẫn chạy được y như trước — mã về qua ô lấy mã khi bot
        # trên máy tác giả bật lên. Giữ nhánh này chứ không bỏ: nó là thứ đỡ
        # lấy cả đường dùng thử nếu một ngày nào đó khoá trên cửa kiểm hỏng.
        #
        # Dùng chung ô nhớ "đang chờ" với đơn mua và đơn cấp lại: cùng một việc
        # chờ, và vòng tự dò hộp lấy mã đã bám vào đúng ô đó rồi.
        rec = {'order': 'DUNG-THU', 'at': time.time(),
               'products': [self.code], 'total': 0, 'trial': True}
        catalog.save_pending_order(rec)
        STATE['order'] = rec
        _auto['key_at'] = 0.0
        n = trial_days()
        msg = ('Trial requested. Your %d-day key arrives by itself - you can '
               'close Blender, it will pick the key up next time.' % n) \
            if n else 'Trial requested.'

        # AI RƠI XUỐNG ĐÂY, VÀ VÌ SAO PHẢI HỎI TRƯỚC KHI NHẮC.
        # Từ 13/08/2026 cửa kiểm tự ký mã, nên một bảng ĐỜI MỚI nhận mã ngay
        # trong lượt bấm và không bao giờ đi tới dòng này. Thực tế chỉ hai hạng
        # người tới được đây, và họ cần hai câu KHÁC HẲN nhau:
        #   - người còn dùng bảng đời cũ  -> cập nhật bảng là hết chờ;
        #   - người đã ở bản mới nhất     -> khoá trên cửa kiểm đang hỏng, và
        #     bảo họ đi cập nhật là chỉ đường vào ngõ cụt, rồi họ bấm Update,
        #     thấy "đã mới nhất", và tin rằng addon nói dối mình.
        # `hub_update_ready()` là chỗ DUY NHẤT phân biệt được hai cảnh đó, và
        # nó cũng chính là thứ quyết định nút Update có hiện ra hay không - nên
        # câu nhắc này không bao giờ chỉ tới một cái nút không tồn tại.
        if hub_update_ready():
            msg += (' Tip: press Update on DP_Hub above, restart Blender, then '
                    'press Try free again - the newer panel activates the '
                    'trial straight away instead of leaving you waiting.')
        STATE['msg'] = msg
        self.report({'INFO'}, msg)
        return {'FINISHED'}


class DPHUB_OT_forget_order(bpy.types.Operator):
    """Stop waiting for this order - it does not cancel anything on the server"""
    bl_idname = 'dphub.forget_order'
    bl_label = 'Stop waiting'
    bl_options = {'REGISTER'}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event=event)

    def execute(self, context):
        # CHỈ BỎ DÒNG NHẮC trên máy này. Không gọi lên máy chủ để huỷ đơn: đơn
        # đã nằm trong hộp của tác giả và có thể sắp được duyệt, mà tiền thì
        # khách đã chuyển. Nút này chỉ dành cho người tick nhầm rồi gửi nhầm.
        catalog.clear_pending_order()
        STATE['order'] = {}
        STATE['msg'] = ('Stopped waiting. If you already paid, press "Get my '
                        'key" later or contact the author.')
        self.report({'INFO'}, STATE['msg'])
        return {'FINISHED'}


def apply_keys(texts):
    """Áp một hoặc nhiều mã kích hoạt vào máy này. Trả (được_không, lời_nhắn).

    MỘT CHỖ DUY NHẤT cho cả hai đường vào — khách dán tay, và khách bấm "Get
    my key". Hai đường phải cư xử y hệt nhau: cùng lưu mã, cùng bỏ đệm, cùng
    tự cài nốt plugin. Viết hai bản là một bản sẽ quên một bước, và bước quên
    đó chỉ lộ ra ở máy khách.

    Nhận NHIỀU mã vì hộp lấy mã có thể chứa nhiều: khách mua thêm addon vào
    tháng sau thì có mã thứ hai, và mã đó chỉ mở những thứ vừa mua.
    """
    done, fail = [], {}
    for text in texts:
        text = (text or '').strip()
        payload = gate.parse(text)[0]
        if payload is None:
            fail.setdefault(gate.BAD_KEY, [])
            continue
        # Danh sách sản phẩm nằm NGAY TRONG mã, nên không cần danh mục và
        # không cần mạng: dán mã lúc mất mạng vẫn kích hoạt được.
        for code in [str(c) for c in (payload.get('p') or [])]:
            ok, why = gate.save_key(code, text)
            if ok:
                if code not in done:
                    done.append(code)
            else:
                fail.setdefault(why, []).append(code)
    lic_ui.invalidate()
    if not done:
        why = next(iter(fail), gate.BAD_KEY)
        msg = gate.message(why)
        if why == gate.WRONG_MACHINE:
            # ĐÂY LÀ ĐÚNG LÚC phải chỉ đường. Người đọc dòng này vừa cài lại
            # máy, vừa dán lại mã cũ trong email, và nhận về một câu từ chối.
            # Không nói gì thêm thì họ tưởng mình mất tiền.
            msg += (' Your PC changed - press "Request a new key" below and '
                    'the author will issue one for this PC.')
        return False, msg
    msg = 'Activated: %s' % ', '.join(done)
    # Chỉ kể những thứ hỏng mà KHÔNG có mã nào khác cứu được. Mã thứ hai mở
    # dpmax thì việc mã thứ nhất trượt dpmax không còn là chuyện của khách.
    con_hong = sorted({c for cs in fail.values() for c in cs} - set(done))
    if con_hong:
        msg += ' | rejected: %s' % ', '.join(con_hong)

    # XONG MỘT LẦN. Chưa có danh mục thì tự lấy về — người vừa kích hoạt đang
    # có mạng, và bắt họ bấm thêm một nút nữa mới cài được thứ họ vừa trả tiền
    # là bắt họ làm việc của mình.
    if not STATE['products']:
        try:
            bpy.ops.dphub.refresh()
        except Exception as exc:
            print('[DP_Hub] tu lay danh muc sau khi kich hoat loi: %r' % (exc,))
    if STATE['products']:
        got, bad = install_owned(only=set(done))
        if got:
            msg += ' | installed %d plugin%s' % (len(got),
                                                 '' if len(got) == 1 else 's')
        if bad:
            # NÓI RA CÂU HỎNG, ĐỪNG CHỈ ĐẾM. `bad` đã mang sẵn tên plugin kèm
            # nguyên lời cửa kiểm nói, mà dòng *"1 installs failed"* thì không
            # nói được gì hơn "có chuyện gì đó" — người đọc nó vừa bấm Try free
            # xong, và họ cần biết ngay là phải chờ, phải bấm lại, hay phải đi
            # hỏi tác giả.
            msg += ' | %s' % bad[0]
            if len(bad) > 1:
                msg += ' (+%d more failed)' % (len(bad) - 1)
    return True, msg


class DPHUB_OT_paste_key(bpy.types.Operator):
    """Paste an activation key - one key can cover several plugins"""
    bl_idname = 'dphub.paste_key'
    bl_label = 'Paste activation key'
    bl_options = {'REGISTER'}

    key: bpy.props.StringProperty(
        name='Activation key',
        description='The whole key the author sent you')
    # Đặt khi bấm từ Ô DÁN MÃ CỦA MỘT PLUGIN. Để trống là ô chung ở đáy bảng.
    code: bpy.props.StringProperty(options={'HIDDEN'})

    def _name(self):
        item = next((p for p in STATE['products']
                     if p['code'] == self.code), None)
        return item['name'] if item else self.code

    def invoke(self, context, event):
        try:
            clip = (context.window_manager.clipboard or '').strip()
        except Exception:
            clip = ''
        if clip and gate.parse(clip)[0] is not None:
            self.key = clip
        return context.window_manager.invoke_props_dialog(self, width=520)

    def draw(self, context):
        col = self.layout.column()
        col.label(text='Activation key for %s:' % self._name()
                  if self.code else 'Paste the activation key sent to you:')
        col.prop(self, 'key', text='')

    def execute(self, context):
        ok, msg = apply_keys([(self.key or '').strip()])
        STATE['msg'] = msg
        self.report({'INFO'} if ok else {'WARNING'}, msg)
        return {'FINISHED'} if ok else {'CANCELLED'}


def hub_update_ready():
    """Bản mới của CHÍNH bảng này, hoặc {} nếu đang là bản mới nhất.

    So bằng SỐ chứ không bằng chuỗi: '1.10.0' lớn hơn '1.9.0', nhưng so chuỗi
    thì ngược lại — và lỗi đó chỉ lộ ra ở bản thứ mười.
    """
    hub = STATE.get('hub') or {}
    if not hub.get('zip'):
        return {}
    try:
        moi = catalog.version_tuple(hub['version'])
        dang = tuple(bl_info_version())
    except Exception:
        return {}
    return hub if moi > dang else {}


def bl_info_version():
    """Số hiệu bản của chính addon đang chạy."""
    import importlib
    mod = importlib.import_module(ADDON_ID)
    return tuple((getattr(mod, 'bl_info', None) or {}).get('version') or (0,))


class DPHUB_OT_update_hub(bpy.types.Operator):
    """Download and install the newest version of DP_Hub itself"""
    bl_idname = 'dphub.update_hub'
    bl_label = 'Update DP_Hub'
    bl_options = {'REGISTER'}

    def execute(self, context):
        hub = hub_update_ready()
        if not hub:
            msg = 'DP_Hub is already up to date'
            STATE['msg'] = msg
            self.report({'INFO'}, msg)
            return {'CANCELLED'}
        try:
            # Gói Hub nằm trên kho CÔNG KHAI, không qua cửa kiểm: Hub là cửa
            # vào và nó miễn phí. Bắt nó đi qua cửa kiểm là khách chưa có mã
            # không lấy được chính cái thứ dùng để mua mã.
            raw = catalog.http_get(hub['zip'], timeout=60,
                                   max_bytes=50 * 1024 * 1024)
        except Exception as exc:
            msg = 'Could not download DP_Hub: %s' % (exc,)
            STATE['msg'] = msg
            self.report({'WARNING'}, msg)
            return {'CANCELLED'}
        ok, msg = install.self_update(raw, hub.get('module') or ADDON_ID)
        STATE['msg'] = msg
        self.report({'INFO'} if ok else {'WARNING'}, msg)
        return {'FINISHED'} if ok else {'CANCELLED'}


class DPHUB_OT_fetch_key(bpy.types.Operator):
    """Get the activation key the author issued for this machine"""
    bl_idname = 'dphub.fetch_key'
    bl_label = 'Get my key'
    bl_options = {'REGISTER'}

    def execute(self, context):
        # Địa chỉ cửa kiểm ĐỌC TỪ DANH MỤC, không cắm cứng ở đây — xem
        # `catalog.gate_of`. Chưa có danh mục thì lấy về trước: khách vừa mua
        # xong, rất có thể đây là lần đầu họ mở bảng.
        if not STATE.get('gate'):
            try:
                bpy.ops.dphub.refresh()
            except Exception as exc:
                print('[DP_Hub] lay danh muc truoc khi lay ma loi: %r' % (exc,))
        base = STATE.get('gate') or ''
        if not base:
            msg = 'Cannot reach the catalog - check your internet connection'
            STATE['msg'] = msg
            self.report({'WARNING'}, msg)
            return {'CANCELLED'}

        try:
            # 404 = TÁC GIẢ CHƯA DUYỆT, không phải "bị từ chối" — `fetch_keys`
            # dịch nó thành danh sách rỗng. Hai chuyện đó khác hẳn nhau với
            # người vừa chuyển tiền: một cái là "đợi chút", cái kia là "anh
            # không có quyền".
            texts = fetch_keys(base, lic_ui.machine_string())
        except Exception as exc:
            msg = 'Could not fetch your key: %s' % (exc,)
            STATE['msg'] = msg
            self.report({'WARNING'}, msg)
            return {'CANCELLED'}
        if not texts:
            msg = 'No key yet - the author has not approved your order.'
            STATE['msg'] = msg
            self.report({'WARNING'}, msg)
            return {'CANCELLED'}

        ok, msg = apply_keys(texts)
        STATE['msg'] = msg
        if ok:
            # Mã về rồi thì bỏ dòng "đang chờ duyệt" đi. Để lại là bảng nói hai
            # chuyện cãi nhau: đã kích hoạt xong mà vẫn đang chờ.
            catalog.clear_pending_order()
            STATE['order'] = {}
        self.report({'INFO'} if ok else {'WARNING'}, msg)
        return {'FINISHED'} if ok else {'CANCELLED'}


class DPHUB_OT_copy_machine(bpy.types.Operator):
    """Copy this machine code so you can send it to the author"""
    bl_idname = 'dphub.copy_machine'
    bl_label = 'Copy machine code'
    bl_options = {'REGISTER'}

    def execute(self, context):
        text = lic_ui.machine_string()
        try:
            context.window_manager.clipboard = text
            self.report({'INFO'}, 'Machine code copied - send it to the author')
        except Exception as exc:
            self.report({'WARNING'}, 'Copy failed - see the Console window')
            print('[DP_Hub] clipboard loi: %r' % (exc,))
        print('[DP_Hub] MA MAY (%s): %s' % (lic_ui.fingerprint(), text))
        return {'FINISHED'}


class DPHUB_OT_clear_key(bpy.types.Operator):
    """Remove a plugin activation key from this PC"""
    bl_idname = 'dphub.clear_key'
    bl_label = 'Remove activation key'
    bl_options = {'REGISTER'}

    code: bpy.props.StringProperty()

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event=event)

    def execute(self, context):
        gate.clear_key(self.code)
        lic_ui.invalidate(self.code)
        self.report({'INFO'}, 'Activation key removed for %s' % self.code)
        return {'FINISHED'}


# ------------------------------------------------------------------ vẽ
# HAI BỘ CHỮ CHO CÙNG MỘT TRẠNG THÁI.
#
# `_LICENSE_LINE` là bộ đầy đủ, dùng ở chỗ trải hết bề ngang. `_LICENSE_O` là
# bộ rút cho vừa MỘT Ô LƯỚI (16 ký tự): "License: no key yet" là 19 ký tự, nên
# trong ô nó thành "License: no k..." — dòng đó đọc lên không còn là một câu.
#
# Thiếu một khoá trong `_LICENSE_O` thì lùi về `_LICENSE_LINE` chứ không ra
# rỗng: một dòng trống ở đây đọc như "sản phẩm này không cần mã".
_LICENSE_O = {
    gate.OK: 'Key: activated',
    gate.NO_KEY: 'Key: none yet',
    gate.BAD_KEY: 'Key: invalid',
    gate.WRONG_MACHINE: 'Key: other PC',
    gate.EXPIRED: 'Key: expired',
    gate.WRONG_PRODUCT: 'Key: wrong item',
    gate.NO_PUBKEY: 'Key: no pubkey',
}

_LICENSE_LINE = {
    gate.OK: 'License: activated',
    gate.NO_KEY: 'License: no key yet',
    gate.BAD_KEY: 'License: invalid key',
    gate.WRONG_MACHINE: 'License: other machine',
    gate.EXPIRED: 'License: expired',
    gate.WRONG_PRODUCT: 'License: wrong product',
    gate.NO_PUBKEY: 'License: public key missing',
}


def _mo_ta_dong(text, rong=30, dong_toi_da=3):
    """Câu mô tả BẺ THÀNH DÒNG cho vừa `rong` ký tự. Trả danh sách dòng.

    Blender KHÔNG tự xuống dòng trong `label`, nên chỗ nào cần nhiều dòng thì
    phải tự bẻ. Bẻ theo TỪ chứ không theo ký tự: cắt giữa từ đọc như chữ lỗi.

    KHÔNG VẼ GÌ Ở ĐÂY, và đó là chỗ khác với bản trước 22/08/2026. Lưới cần
    biết một ô cao mấy dòng TRƯỚC khi vẽ ô đầu tiên (xem `o_dong`), mà một hàm
    vừa tính vừa vẽ thì chỉ đếm được sau khi đã vẽ xong.

    `rong` PHẢI là bề ngang của ĐÚNG cái ô đang vẽ, không phải bề ngang cả
    bảng: mỗi sản phẩm nằm trong một ô lưới hẹp hơn bảng. Truyền 30 vào một ô
    hai cột là chữ cụt trên máy khách mà phép đo vẫn xanh — xem `o_ky_tu()`.

    `dong_toi_da` = 2 trong lưới: chín sản phẩm nhân ba dòng là 27 dòng chữ
    mờ, và đó chính là phần chiều cao Ducphan kêu là quá dài. Câu đầy đủ đi
    vào tooltip của nút Install / Try free trong cùng ô.
    """
    dong, cur = [], ''
    for tu in (text or '').split():
        if len(cur) + len(tu) + 1 > rong:
            if cur:
                dong.append(cur)
            cur = tu
        else:
            cur = (cur + ' ' + tu).strip()
        if len(dong) >= dong_toi_da:      # hết chỗ; phần còn lại bỏ
            break
    if cur and len(dong) < dong_toi_da:
        dong.append(cur)
    # CÒN NỮA THÌ NÓI LÀ CÒN NỮA. Cắt một câu ở giữa rồi để nó đứng như một
    # câu trọn vẹn thì khách đọc ra một câu khác hẳn — dấu ba chấm là thứ duy
    # nhất trên bảng nói rằng phần còn lại nằm trong tooltip.
    if dong and len(' '.join(dong)) < len(' '.join((text or '').split())):
        thua = rong - len(dong[-1])
        dong[-1] = (dong[-1] + '...') if thua >= 3 else (dong[-1][:rong - 3]
                                                         + '...')
    return dong


# --------------------------------------------------------------- cửa sổ toolbox
# CHỈ CÒN BA OPERATOR. Bản trước có thêm một cái để tick từng tab; bỏ rồi - addon
# tự biết khách có plugin nào (tab chỉ tồn tại khi plugin đã cài, mà đã cài nghĩa
# là đã mua), nên không có gì để hỏi.
#
# Lựa chọn duy nhất còn lại - kiểu cửa sổ - nằm trong file dùng chung
# `<CONFIG>/dp_license/toolbox.json` chứ không nằm trong Preferences của Hub: nút
# mở toolbox có mặt trong CẢ BẢY addon, mà Preferences của Hub thì sáu addon kia
# không đọc được.
class DPHUB_OT_toolbox_mode(bpy.types.Operator):
    """Choose the kind of toolbox window"""
    bl_idname = 'dphub.toolbox_mode'
    bl_label = 'Window mode'
    bl_options = {'REGISTER'}

    mode: bpy.props.StringProperty()

    # LỜI GIẢI THÍCH ĐI VÀO TOOLTIP, KHÔNG VÀO PANEL. Ba dòng chữ nằm thường
    # trực dưới hai cái nút là thứ người dùng đọc đúng một lần rồi phải cuộn qua
    # nó mãi mãi. Trong tooltip thì nó có mặt đúng lúc cần.
    @classmethod
    def description(cls, context, properties):
        if properties.mode == toolbox.MODE_TEMP:
            return ('Toolbox window without a top bar - takes less room on '
                    'screen')
        return ("Toolbox window with Blender's top bar - lets you switch "
                'workspace and scene inside it')

    def execute(self, context):
        toolbox.set_mode(self.mode)
        return {'FINISHED'}


class DPHUB_OT_toolbox_open(bpy.types.Operator):
    """Open your plugin panels side by side in a separate window you can drag to another monitor. It fits as many columns as the window is wide - widen it for more, or click a column's side tabs to switch that column to another plugin"""
    bl_idname = 'dphub.toolbox_open'
    bl_label = 'Open toolbox window'
    bl_options = {'REGISTER'}

    def execute(self, context):
        ok, msg = toolbox.open_toolbox(context)
        # WARNING chứ không ERROR: `bpy.ops` biến ERROR thành RuntimeError và
        # huỷ cả thao tác đang chạy.
        self.report({'INFO'} if ok else {'WARNING'}, msg)
        return {'FINISHED'} if ok else {'CANCELLED'}


class DPHUB_OT_toolbox_block(bpy.types.Operator):
    """Keep the toolbox window still - the panels are not a viewport"""
    bl_idname = 'dphub.toolbox_block'
    bl_label = 'Toolbox: ignore view navigation'
    bl_options = {'INTERNAL'}

    @classmethod
    def poll(cls, context):
        # CHI song trong cua so toolbox. Ngoai do `poll` tra False, va Blender
        # cho su kien roi xuong phim tat mac dinh - tuc la viewport that KHONG
        # bi anh huong mot chut nao.
        screen = getattr(context, 'screen', None)
        return bool(screen is not None and screen.get(toolbox.MARK))

    def execute(self, context):
        # Nuot su kien, khong lam gi. Do la toan bo cong viec.
        return {'FINISHED'}


# Nhung su kien lam "chay" cai nen phia sau bang. Chan o day chu khong o dau
# khac: moi cot trong toolbox la mot viewport 3D that, ma nguoi dung khong coi
# no la viewport - ho cuon chuot de doc bang, va thay canh vat phong to thu nho
# sau lung. Khong an duoc vung viewport (Blender khong cho) thi vo hieu hoa no.
_BLOCK_EVENTS = (
    ('WHEELUPMOUSE', 'PRESS'), ('WHEELDOWNMOUSE', 'PRESS'),
    ('WHEELINMOUSE', 'PRESS'), ('WHEELOUTMOUSE', 'PRESS'),
    ('MIDDLEMOUSE', 'PRESS'),
    ('TRACKPADPAN', 'ANY'), ('TRACKPADZOOM', 'ANY'),
)
_keymaps = []


def register_keymaps():
    """Dang ky o RIENG DP_Hub. Hub luon co mat, va dang ky mot cho thi khong lo
    bay addon cung cam bay muc giong het nhau vao cung mot keymap."""
    kc = bpy.context.window_manager.keyconfigs.addon
    if kc is None:
        return                          # chay nen (-b): khong co keyconfig
    km = kc.keymaps.new(name='3D View', space_type='VIEW_3D')
    for kind, value in _BLOCK_EVENTS:
        kmi = km.keymap_items.new(DPHUB_OT_toolbox_block.bl_idname, kind, value)
        _keymaps.append((km, kmi))


def unregister_keymaps():
    for km, kmi in _keymaps:
        try:
            km.keymap_items.remove(kmi)
        except Exception:
            pass
    _keymaps.clear()


class DPHUB_OT_toolbox_close(bpy.types.Operator):
    """Close the toolbox window"""
    bl_idname = 'dphub.toolbox_close'
    bl_label = 'Close toolbox window'
    bl_options = {'REGISTER'}

    def execute(self, context):
        ok, msg = toolbox.close_toolbox()
        self.report({'INFO'} if ok else {'WARNING'}, msg)
        return {'FINISHED'} if ok else {'CANCELLED'}


def draw_toolbox(layout, context):
    """Khối cửa sổ toolbox — một tiêu đề, hai nút chọn kiểu, một nút mở.

    KHÔNG lọc theo quyền ở đây. `toolbox.tabs()` quét những tab ĐANG đăng ký,
    mà một tab chỉ tồn tại khi addon đã cài và đã bật — và nút Install phía trên
    đã từ chối cài sản phẩm chưa có mã. Nói cách khác danh sách này ĐÃ LÀ danh
    sách khách sở hữu; kiểm mã lần nữa ở đây chỉ chép lại một quyết định đã có,
    và sẽ đá văng hai tab không thuộc sản phẩm nào (`DP` của chính Hub, và
    `DP_Sketch`).

    Cũng KHÔNG hỏi khách muốn hiện tab nào (bỏ 05/08/2026). Danh sách đó máy đã
    có sẵn; hỏi lại là bắt người ta khai một thứ mình đã biết.
    """
    if not toolbox.tabs():
        return
    cfg = toolbox.settings()

    # BA DÒNG, HẾT. Bản trước có bảy dòng chữ vây quanh đúng một cái nút - người
    # dùng đọc một lần rồi phải cuộn qua nó mãi mãi. Mọi lời giải thích đã dời
    # vào tooltip của chính hai operator này (`description()` ở trên), tức là nó
    # hiện ra đúng lúc con trỏ dừng lại để hỏi.
    layout.separator()
    box = layout.box()
    box.label(text='Window layout', icon='WINDOW')
    row = box.row(align=True)
    op = row.operator(DPHUB_OT_toolbox_mode.bl_idname, text='Top bar',
                      depress=cfg['mode'] == toolbox.MODE_MAIN)
    op.mode = toolbox.MODE_MAIN
    op = row.operator(DPHUB_OT_toolbox_mode.bl_idname, text='Compact',
                      depress=cfg['mode'] == toolbox.MODE_TEMP)
    op.mode = toolbox.MODE_TEMP
    row = box.row()
    row.scale_y = 1.3
    if toolbox.toolbox_window() is None:
        row.operator(DPHUB_OT_toolbox_open.bl_idname, icon='WINDOW')
    else:
        row.operator(DPHUB_OT_toolbox_close.bl_idname, icon='X')


# ----------------------------------------------------------------- lưới ô
# MỘT ADDON LÀ MỘT Ô, XẾP THÀNH LƯỚI — thay cho chín khối chồng lên nhau.
#
# Bản trước mỗi sản phẩm chiếm một khối cao chừng 250 px, chín sản phẩm là hơn
# 2200 px trong một cột N-panel cao 1756 px: khách phải cuộn qua ba màn hình
# mới tới được khối đặt đơn ở cuối. Ducphan gọi đúng tên nó ngày 22/08/2026:
# "hub đang quá dài".
#
# BỀ NGANG TỐI THIỂU MỘT Ô, tính bằng px LOGIC (chưa nhân ui_scale).
# Đo trên máy Ducphan 22/08/2026: N-panel mặc định rộng 420 px THẬT, ui_scale
# 1.5 -> 280 px logic; chia cho 135 ra 2 cột. Kéo bảng rộng ra thì số cột tự
# tăng, kéo hẹp lại thì tự về 1 cột.
#
# PHẢI CHIA CHO ui_scale. `region.width` là px thật của màn hình, còn bề ngang
# một cái nút thì co giãn theo ui_scale — không chia thì màn 2x đọc ra "bảng
# rộng gấp đôi" rồi nhét 4 cột vào đúng chỗ chỉ vừa 2, và mọi dòng chữ cụt.
O_RONG_TOI_THIEU = 135
O_SO_COT_TOI_DA = 4

# BỀ NGANG TỐI THIỂU MỘT Ô, RIÊNG CHO TỪNG SỐ CỘT — px LOGIC.
#
# MỘT NGƯỠNG CHUNG LÀ SAI, và sai đúng vào chỗ Ducphan cần. Với một ngưỡng 135
# cho mọi số cột, kéo bảng tới 810 px là lưới nhảy lên 4 cột — mà ô ở 4 cột
# (135 px) lại HẸP HƠN ô ở 3 cột lúc trước đó (180 px). Người kéo bảng rộng
# thêm để đọc được nhiều hơn lại nhận về chữ cụt hơn.
#
# Nên cột càng nhiều thì mỗi ô càng phải rộng mới được mọc thêm:
#     2 cột: 135 - chật, nhưng ở bảng mặc định 420 px thì không còn lựa chọn
#            nào khác; một cột thì chín sản phẩm dài hơn ba màn hình.
#     3 cột: 135 - mọc ngay khi vừa đủ chỗ, vì đây là cảnh Ducphan muốn.
#     4 cột: 200 - chỉ mọc khi ô vẫn còn rộng hơn ô 3 cột ở quãng thường dùng.
#
# Nhờ vậy 3 cột giữ được suốt quãng 610 -> 1200 px, và trong quãng đó ô cứ
# rộng dần: 810 px cho 17 ký tự kèm icon, 1035 px thì câu mô tả hiện lại.
O_RONG_O = {1: 0, 2: 135, 3: 135, 4: 200}

# BỀ NGANG MỘT KÝ TỰ và LỀ CỦA MỘT Ô, tính bằng px LOGIC.
#
# Đo bằng `blf.dimensions` trên chính font Blender đang chạy (22/08/2026,
# ui_scale 1.5): một ký tự chữ thường rộng 7.65 px THẬT, tức 5.1 px logic. Lấy
# 5.6 để chừa cho chữ hoa và chữ số, vốn rộng hơn trung bình.
#
# `O_LE` là phần của một ô KHÔNG dùng để in chữ: viền box, và cái icon đứng
# trước dòng tên.
# BỀ NGANG MỘT KÝ TỰ và LỀ CỦA MỘT Ô, tính bằng px LOGIC.
#
# BA CON SỐ NÀY ĐO ĐƯỢC, KHÔNG SUY. Cách đo (22/08/2026, `tools/thuoc_o.py`):
# vẽ một cái lưới thật trong Blender có cửa sổ, mỗi ô một cột chữ dài dần
# 'L10xxx...', rồi NHÌN ẢNH CHỤP xem dòng nào Blender bắt đầu thêm dấu "...".
# Hai bề ngang ô cho hai điểm, hai điểm cho một đường thẳng:
#
#       ô 140 px logic -> 16 ký tự (không icon) | 12 ký tự (có icon)
#       ô 280 px logic -> 36 ký tự (không icon) | 32 ký tự (có icon)
#
#       (280 - 140) / (36 - 16) = 7.0 px logic mỗi ký tự
#       140 - 16 * 7.0 = 28 px logic lề ô
#       12 ký tự ở ô 140 -> lề 56 px logic khi có icon (icon ăn 28 px)
#
# BẢN ĐẦU SUY RA 5.6 px/ký tự VÀ NÓ SAI. Suy từ `blf.dimensions` của một câu
# mẫu ra 5.1 px logic rồi cộng thêm chút cho chắc — con số ấy bỏ quên lề ô và
# bỏ quên cái icon, nên bảng khai 20 ký tự trong khi ô chỉ chứa 12. Chín cái
# tên sản phẩm cụt hết trên ảnh chụp đầu tiên, mà 39 phép đo headless vẫn xanh:
# chúng đếm ký tự theo đúng con số bịa ấy. Đừng sửa ba con số này bằng suy
# luận; đo lại bằng thước rồi hãy sửa.
O_KY_TU_RONG = 7.0
O_LE = 28
O_LE_ICON = 56

# TRẦN, và nó KHÔNG phải một phép đo — nó là một cái chốt cho vùng chưa đo.
# Đường thẳng ở trên dựng từ hai điểm 140 và 280 px logic; ngoài khoảng đó chưa
# ai đo bao giờ. Một người kéo bảng ra 2000 px thì công thức khai 280 ký tự
# mỗi dòng, và `lic_ui.wrap` sẽ ném ra những dòng chữ dài hết màn hình — đọc
# không nổi kể cả khi nó không hề bị cắt.
O_KY_TU_TOI_DA = 60

# Chữ trên NÚT rộng hơn chữ trên nhãn một chút (nút không có lề trái của nhãn),
# nhưng đo ra chỉ hơn 1 ký tự — không đáng một hằng số riêng, và một hằng số
# riêng là một chỗ nữa để lệch. Nút dùng chung con số của nhãn.


def grid_columns(context):
    """Số cột của lưới, theo bề ngang N-panel ĐANG CÓ.

    Đọc bề ngang trong lúc vẽ chứ không hỏi người dùng: Blender vẽ lại bảng
    mỗi lần kéo mép thanh bên, nên lưới tự sắp lại theo tay kéo.

    Không đọc được `region` (chế độ nền, bài kiểm) thì trả 2 — đúng cảnh mặc
    định trên máy khách, để phép đo headless đo cùng một thứ khách nhìn thấy.
    """
    rong = rong_logic(context)
    if rong <= 0:
        return 2
    # Lấy số cột LỚN NHẤT mà mọi ô của nó vẫn đủ rộng. Duyệt từ nhiều xuống ít
    # rồi lấy cái đầu tiên lọt, chứ không chia một phép: ngưỡng mỗi mức một
    # khác nên phép chia không trả lời được.
    for n in range(O_SO_COT_TOI_DA, 1, -1):
        if rong >= n * O_RONG_O.get(n, O_RONG_TOI_THIEU):
            return n
    return 1


def rong_logic(context):
    """Bề ngang N-panel tính bằng px LOGIC, hoặc 0 nếu không đọc được.

    PHẢI CHIA CHO ui_scale. `region.width` là px THẬT của màn hình, còn bề
    ngang một cái nút thì co giãn theo ui_scale — không chia thì màn 2x đọc ra
    "bảng rộng gấp đôi" rồi nhét 4 cột vào đúng chỗ chỉ vừa 2, và mọi dòng chữ
    trong đó cụt hết.
    """
    region = getattr(context, 'region', None)
    rong = getattr(region, 'width', 0) or 0
    if rong <= 0:
        return 0
    try:
        scale = float(context.preferences.system.ui_scale) or 1.0
    except (AttributeError, TypeError, ValueError):
        scale = 1.0
    return float(rong) / scale


def o_ky_tu(cols, rong=None, icon=False):
    """Bao nhiêu ký tự vừa MỘT ô của lưới `cols` cột.

    Tính từ bề ngang Ô THẬT, không tra một bảng số cắm cứng theo số cột. Bảng
    số đó là chỗ để lệch im lặng: nới một cột lên mà quên nới bảng là chữ cụt
    trên máy khách, còn phép đo thì vẫn xanh.

    `rong` = bề ngang CẢ BẢNG bằng px logic. Không truyền thì lấy cảnh HẸP
    NHẤT còn cho ra `cols` cột (`cols * O_RONG_TOI_THIEU`) — đó là bề ngang XẤU
    NHẤT một ô có thể có ở số cột này, và một phép đo an toàn phải đo cảnh xấu
    nhất. Vì thế `o_ky_tu(2)` và `o_ky_tu(4)` ra cùng một số: cột chỉ mọc thêm
    khi bảng đủ rộng, nên ô hẹp nhất luôn là `O_RONG_TOI_THIEU`.

    `icon=True` cho dòng chữ CÓ icon đứng trước. Cái icon ăn mất 4 ký tự, và
    đó đúng là chỗ bản đầu ngã: dòng tên sản phẩm nào cũng có logo đứng trước.
    """
    cols = max(1, int(cols))
    if not rong:
        rong = cols * O_RONG_TOI_THIEU
    o = float(rong) / cols
    le = O_LE_ICON if icon else O_LE
    # SÀN 4. Bảng kéo hẹp đến mức một ô chỉ còn vài chục px thì công thức ra
    # số ÂM; đưa số âm cho `cat_theo_tu` là mọi dòng chữ thành chuỗi rỗng, và
    # bảng đọc lên như một cái bảng trống chứ không như một cái bảng chật.
    return max(4, min(O_KY_TU_TOI_DA, int((o - le) / O_KY_TU_RONG)))


def cat_theo_tu(text, gioi_han):
    """Cắt `text` cho vừa `gioi_han` ký tự, CẮT THEO TỪ, có dấu ba chấm.

    CHỈ DÙNG CHO CHỖ MÌNH TỰ BỎ CHỮ ĐI. Blender 5.2 tự thêm "..." khi chữ dài
    hơn ô (đo được trên ảnh chụp 22/08/2026), và nó cắt theo px thật nên chính
    xác hơn mọi phép đếm ký tự ở đây — chữ một dòng cứ để Blender cắt.

    Chỗ Blender KHÔNG cứu được là lúc mình vứt bớt TỪ trước khi đưa cho nó:
    `_mo_ta` chỉ lấy một dòng đầu của câu mô tả, và Blender không có cách nào
    biết là còn nữa. Ba chấm ở đây là thứ duy nhất nói ra điều đó.
    """
    text = ' '.join(str(text or '').split())
    if len(text) <= gioi_han:
        return text
    if gioi_han <= 3:
        return text[:gioi_han]
    cut = ''
    for tu in text.split():
        thu = (cut + ' ' + tu).strip()
        if len(thu) + 3 > gioi_han:
            break
        cut = thu
    return (cut + '...') if cut else (text[:gioi_han - 3] + '...')


def sap_cap(cap):
    """Thứ tự các ô, làm trên các cặp (sản phẩm, trạng thái) đã tính sẵn.

    Ba nhóm, TRONG mỗi nhóm giữ nguyên thứ tự tác giả khai trong danh mục —
    tác giả xếp danh mục theo ý bán hàng, và một cái lưới tự xáo lại theo
    trạng thái thì mỗi lần cài xong một món là cả bảng nhảy chỗ.

        1. CÓ VIỆC PHẢI LÀM  - có bản mới, hoặc đang chờ mở lại Blender
        2. bình thường
        3. CHƯA RA MẮT       - không cài được, không mua được

    Nhóm 1 lên đầu vì đó là lý do khách mở bảng ra; nhóm 3 xuống cuối vì nó
    không có nút nào bấm được, mà một ô câm nằm giữa lưới thì đọc như một ô
    hỏng.
    """
    co_viec, thuong, chua_ra = [], [], []
    for item, st in cap:
        if not st['released']:
            chua_ra.append((item, st))
        elif st['update'] or st['needs_restart']:
            co_viec.append((item, st))
        else:
            thuong.append((item, st))
    return co_viec + thuong + chua_ra


def sap_o(items):
    """Như `sap_cap` nhưng tự đọc trạng thái. Chỉ còn dùng ngoài đường vẽ.

    Đường vẽ KHÔNG gọi hàm này: `product_state` đọc đĩa (số hiệu bản đã cài,
    mã kích hoạt), và bảng được vẽ lại mỗi lần con trỏ đi qua. Gọi nó thêm một
    vòng nữa cho việc xếp thứ tự là nhân đôi số lần đọc đĩa mỗi nhịp vẽ.
    """
    return [it for it, _st in sap_cap([(it, product_state(it))
                                       for it in items])]


# BỀ NGANG TỐI THIỂU ĐỂ CÒN BÀY CÂU MÔ TẢ RA BẢNG.
#
# Ô hai cột chỉ chứa 16 ký tự: "Import file . ma..." không nói được gì, mà vẫn
# ăn hai dòng của mọi sản phẩm. Dưới ngưỡng này câu mô tả đi vào TOOLTIP của
# nút trong ô (`_tooltip`), và khách kéo bảng rộng ra là nó hiện lại ngay trên
# bảng — đó cũng là lý do ngưỡng đặt theo BỀ NGANG chứ không theo số cột.
O_MO_TA_TU = 24


# --------------------------------------------------------------------------- #
# NỘI DUNG MỘT Ô, DƯỚI DẠNG DỮ LIỆU — CHƯA VẼ GÌ CẢ
#
# VÌ SAO PHẢI TÁCH RA. Lưới cần biết ô CAO NHẤT trước khi vẽ ô ĐẦU TIÊN, để
# đệm mọi ô cho bằng nó. Không có con số đó thì mỗi ô cao theo nội dung của
# riêng nó, và hàng nào cũng có một mảng trống dưới cái ô ngắn nhất — đúng cái
# Ducphan gọi là "hơi lộn xộn" ngày 22/08/2026.
#
# VÀ VÌ SAO KHÔNG ĐẾM BẰNG MỘT HÀM RIÊNG. Cách hiển nhiên là viết thêm một hàm
# "ô này cao mấy dòng" chạy song song với hàm vẽ. Hai hàm đọc cùng một mớ điều
# kiện `if` là hai hàm sớm muộn lệch nhau, và lúc lệch thì bảng chỉ hơi xô một
# chút — không có gì kêu lên cả. Ở đây chỉ có MỘT chỗ quyết định ô gồm những
# dòng nào; đếm là `len()` của chính danh sách sắp được vẽ.
#
# Mỗi dòng là một dict:
#   {'kieu': 'chu',   'chu': ..., 'icon': ..., 'mo': True/False}
#   {'kieu': 'nut',   'op': ..., 'chu': ..., 'icon': ..., 'dat': {...},
#    'nhan': True/False}      # `nhan` = vẽ ở trạng thái đang bấm xuống
#   {'kieu': 'trong'}         # dòng đệm cho đủ chiều cao
# --------------------------------------------------------------------------- #
def _chu(chu, icon='NONE', mo=False):
    return {'kieu': 'chu', 'chu': chu, 'icon': icon, 'mo': mo}


def _nut(op, chu='', icon='NONE', nhan=False, **dat):
    return {'kieu': 'nut', 'op': op, 'chu': chu, 'icon': icon, 'nhan': nhan,
            'dat': dat}


def o_dong(item, state, chars):
    """MỌI dòng của một ô sản phẩm, theo đúng thứ tự sẽ vẽ."""
    d = []
    # LOGO thay cho icon dựng sẵn của Blender khi tải được. Không tải được thì
    # lùi về icon cũ — thiếu một tấm ảnh không được phép làm mất dòng tên.
    #
    # TÊN ĐỂ NGUYÊN, KHÔNG TỰ CẮT. Blender 5.2 cắt theo px thật và tự thêm
    # "..." — chính xác hơn mọi phép đếm ký tự ở đây. Tự cắt trước là cắt hai
    # lần: "DP_Camera Setup & Batch Render" thành "DP_Camer..." trong khi để
    # Blender lo thì khách còn đọc được "DP_Camera Setup & B...". Tên đầy đủ
    # nằm trong tooltip của nút ngay dưới.
    ma_logo = logo_icon(item)
    d.append(_chu(item['name'],
                  icon=('CHECKMARK' if state['installed'] else 'IMPORT')
                  if not ma_logo else 'NONE'))
    if ma_logo:
        d[-1]['icon_value'] = ma_logo
    # CÂU MÔ TẢ — chỉ khi bảng đủ rộng để nó nói được một điều gì đó.
    #
    # Trước 04/08/2026 danh mục mang sẵn dòng này và `catalog.py` cũng đọc nó
    # vào, nhưng KHÔNG CHỖ NÀO VẼ NÓ RA — nên chữ tác giả viết cho từng sản
    # phẩm không bao giờ đến mắt khách. Nay nó có HAI đường tới khách: bảng
    # (khi rộng) và tooltip (luôn luôn). Bỏ đường nào cũng được, bỏ cả hai thì
    # quay lại đúng lỗi cũ.
    if item.get('desc') and chars >= O_MO_TA_TU:
        for dong in _mo_ta_dong(item['desc'], chars, 2):
            d.append(_chu(dong, mo=True))

    if not state['released']:
        # Cả khối tin tức về việc cài bị làm mờ: Blender tự vẽ xám và chặn mọi
        # nút nằm trong đó. Khách nhìn là biết ngay "cái này chưa tới lượt",
        # không phải bấm thử mới biết.
        #
        # MỘT DÒNG. Bản cũ ghi "Coming soon - not released yet" (30 ký tự) vì
        # bảng khi đó rộng cả cột; trong ô lưới 16 ký tự thì vế sau vừa bị cắt
        # vừa nói lại đúng điều vế trước đã nói.
        d.append(_chu('Coming soon', icon='TIME', mo=True))
        if state['installed']:
            d.append(_chu('Installed v%s' % _ver(state['current']), mo=True))
    elif not state['installed']:
        d.append(_chu('Not installed'))
        d.append(_chu('v%s' % item['version']))
    elif state['update']:
        d.append(_chu('Installed v%s' % _ver(state['current'])))
        # MỘT DÒNG, KHÔNG ICON. "UPDATE: v10.10.10" kèm icon là 17 ký tự
        # trong một ô chứa 12 — Blender cắt mất đúng cái số hiệu, thứ duy
        # nhất khách cần đọc. Bỏ icon đi thì ngân sách lên 16 và cả câu vừa,
        # chỉ tốn MỘT dòng thay vì hai. Chữ hoa đã đủ đập vào mắt; icon
        # ERROR còn nguyên ở dòng "for v..." của cảnh chờ mở lại Blender.
        d.append(_chu('UPDATE v%s' % item['version']))
    else:
        d.append(_chu('v%s - latest' % _ver(state['current'])))
    if state['installed'] and not state['enabled']:
        d.append(_chu('(disabled)'))
    # BẢN MỚI ĐÃ NẰM TRÊN ĐĨA NHƯNG BẢN CŨ CÒN ĐANG CHẠY.
    # Câu này phải ĐỨNG YÊN trong bảng, không được là một lời nhắn thoáng qua:
    # lúc cài xong bảng CÓ nói "restart Blender", nhưng đó là một dòng nhắn và
    # khách bấm tiếp là trôi mất. Cái còn lại với họ là hai con số vênh nhau và
    # không một nút nào để bấm - đúng ca ngày 14/08/2026.
    #
    # CHỮ "Blender" PHẢI CÒN. Ô lưới chứa 16 ký tự không icon, "Restart
    # Blender" vừa đúng 15 — nên icon ERROR phải dời xuống dòng số hiệu, chứ
    # không được rút câu thành "Restart for v2.0.0" để lấy chỗ cho cái icon.
    # Cả ngày 14/08/2026 là một người không biết phải mở lại CÁI GÌ.
    if state['needs_restart']:
        d.append(_chu('Restart Blender'))
        d.append(_chu('for v%s' % _ver(state['restart_to']), icon='ERROR'))
        d.append(_chu('old one running'))

    if state['released'] and (not state['installed'] or state['update']):
        gated_no_key = item.get('gated') and not key_for(item['code'])
        if blender_khong_hop(item):
            # KHONG bay nut Install / Try free tren mot ban Blender ma mon nay
            # chac chan khong chay. Truoc 12/08/2026 cho nay bay nut nhu thuong,
            # va khach chi biet sau khi da tra tien va cai xong.
            #
            # Bay CAU CHU chu khong phai nut bi lam mo: nut xam khong noi duoc
            # vi sao, va khach se ngoi bam thu. Cau day du ("cai them mot ban
            # Blender nua, hai ban song song duoc") nam o khoi canh bao dau
            # bang, cho do trai het be ngang nen doc duoc.
            d.append(_chu('WRONG BLENDER', icon='ERROR'))
            for line in lic_ui.wrap(cau_doi_ban(item), chars):
                d.append(_chu(line))
        elif item['zip'] and not gated_no_key:
            d.append(_nut(DPHUB_OT_install.bl_idname, icon='IMPORT',
                          chu='Update' if state['update'] else 'Install',
                          code=item['code']))
        elif item['zip']:
            # Có đường tải nhưng chưa có mã: đừng bày nút bấm rồi mới báo lỗi.
            d.append(_chu('Needs a key'))
            # DÙNG THỬ. Đặt ĐÚNG chỗ này chứ không ở đâu khác: đây là giây phút
            # khách vừa đọc "cần mã mới tải được", tức là lúc câu mời có nghĩa
            # nhất. Bày nút này cạnh nút Install của một món đã mua thì nó chỉ
            # là một nút thừa gây rối.
            #
            # KHÔNG ICON, và chữ rút còn "Try free N days". Bản đầu để "Try
            # free for %d days" kèm icon TIME: 19 ký tự trong một ô chứa 12,
            # nên trên ảnh chụp nó là "Try free for..." — Blender cắt mất đúng
            # CON SỐ NGÀY, thứ quyết định khách có bấm hay không.
            if state['can_trial']:
                d.append(_nut(DPHUB_OT_trial.bl_idname,
                              chu='Try free %d days' % trial_days(),
                              code=item['code']))
        else:
            # Danh mục nói "đã phát hành" mà lại không có đường tải — hai câu
            # cãi nhau, và tin câu nào cũng dẫn tới một nút bấm ra 404. Nói
            # thẳng là danh mục hỏng thay vì im lặng bày ra một dòng vô hại.
            d.append(_chu('BROKEN', icon='ERROR'))
            d.append(_chu('no download link'))
    elif state['released'] and state['installed'] and not state['enabled']:
        # CÀI LẠI ĐƯỢC DÙ ĐANG LÀ BẢN MỚI NHẤT — NHƯNG CHỈ KHI ADDON KHÔNG BẬT.
        #
        # 13/08/2026: một khách có bản cài hỏng (thiếu file, addon không bật
        # lên được) và KHÔNG CÓ ĐƯỜNG NÀO tự chữa — bảng chỉ bày nút Install
        # khi chưa cài, hoặc Update khi có bản mới hơn, nên với họ bảng không
        # có nút nào cả. Cách duy nhất còn lại là gỡ addon bằng tay trong
        # Preferences rồi mới quay về đây, mà chỗ đó thì khách không tự nghĩ ra.
        #
        # ĐIỀU KIỆN `not enabled` LÀ PHẦN QUAN TRỌNG, và nó là bài học ngay
        # trong ngày: bản đầu bày nút này cho MỌI addon đã cài, nên vừa bấm
        # Update xong là nút đổi chữ thành "Reinstall" và đứng nguyên đó —
        # đọc lên như "cập nhật chưa xong, bấm lại đi". Addon đang chạy tốt
        # thì không có gì để chữa, nên không bày nút. Addon cài rồi mà không
        # bật được mới là lúc khách cần một cái nút.
        gated_no_key = item.get('gated') and not key_for(item['code'])
        if item['zip'] and not gated_no_key and not blender_khong_hop(item):
            d.append(_nut(DPHUB_OT_install.bl_idname, icon='FILE_REFRESH',
                          chu='Reinstall', code=item['code']))

    # NỬA KIA của sản phẩm (DP_SU Sync: bản cài phía SketchUp). Vẽ NGAY TRONG
    # ô của sản phẩm, không thành một ô riêng trong lưới: nó không phải một
    # món bán, và tách ra là khách tưởng phải mua thêm.
    #
    # Vẽ cả khi chưa cài nửa Blender, và có lý do: khách hay cài phía SketchUp
    # trước, hoặc cài lại SketchUp rồi mất phần mở rộng trong khi Blender vẫn
    # còn nguyên. Bắt phải cài nửa này mới thấy nửa kia là khoá họ ở ngoài.
    #
    # Ô lưới hẹp nên Blender cắt bớt cả dòng nhắc lẫn chữ trên nút; câu đầy đủ
    # (kèm hướng dẫn mang file đi đâu) nằm trong tooltip của chính cái nút đó.
    cpn = item.get('companion')
    if cpn:
        d.append(_chu('%s - v%s' % (cpn_chu(cpn)['can'], cpn['version']),
                      icon='PLUGIN'))
        d.append(_nut(DPHUB_OT_companion.bl_idname, icon='IMPORT',
                      chu=cpn['label'], code=item['code']))
        # HAI NỬA PHẢI CÙNG SỐ. Nói ra ở đây vì đây là chỗ khách sửa được:
        # bấm tải bản đúng. Im lặng thì họ chỉ thấy Sync báo lệch phiên bản
        # giữa lúc đang làm việc, và không biết phải lấy bản nào ở đâu.
        if cpn['version'] and cpn['version'] != item['version']:
            d.append(_chu('MISMATCH', icon='ERROR'))
            d.append(_chu('Blender half is'))
            d.append(_chu('v%s' % item['version']))

    if item['video']:
        d.append(_nut(DPHUB_OT_video.bl_idname, icon='PLAY', chu='Tutorial',
                      url=item['video']))

    if not item.get('free'):
        # DÒNG TÌNH TRẠNG MÃ — BỎ KHI PHÍA TRÊN VỪA NÓI ĐÚNG ĐIỀU ĐÓ.
        #
        # Ô của một món có khoá mà chưa mua đang mang hai dòng nói cùng một
        # chuyện: "Needs a key" (ở khối cài) rồi "Key: none yet" (ở đây). Hai
        # dòng cho một tin, nhân chín sản phẩm, trong một cái bảng vừa bị kêu
        # là quá dài.
        #
        # CHỈ bỏ đúng cặp trùng đó. Mọi tình trạng khác — hết hạn, mã của máy
        # khác, mã hỏng — vẫn phải nói ra, vì không dòng nào khác nói hộ, và
        # đó mới là những cảnh khách cần đọc để biết phải làm gì.
        trung = (state['license'] == gate.NO_KEY
                 and any(r.get('chu') == 'Needs a key' for r in d))
        if not trung:
            d.append(_chu(_LICENSE_O.get(state['license'],
                                         _LICENSE_LINE.get(state['license'],
                                                           state['license']))))
        # MỖI SẢN PHẨM CHỈ CÒN MỘT Ô TICK. Không nút "Buy" riêng, không ô dán
        # mã riêng.
        #
        # Cả hai nút đó là tàn dư của đường cũ, từ trước khi có khối đặt đơn ở
        # cuối bảng. Nay mọi đơn đi chung một đường: tick vài sản phẩm, điền
        # email, chọn ảnh biên lai, bấm Send order MỘT lần — và nhận về MỘT mã
        # mở hết. Bày thêm một nút "Buy" cạnh mỗi món là mời khách đi một
        # đường không còn tồn tại, còn ô dán riêng thì bắt họ đoán xem mã vừa
        # dán thuộc về món nào.
        #
        # Đường dán tay VẪN CÒN, ở cuối bảng, một ô duy nhất nhận mọi mã — đó
        # là đường bảo đảm cho lúc cửa kiểm hỏng, và nó phải giữ.
        if state['license'] != gate.OK:
            ok_buy, why = buyable(item, state)
            if ok_buy:
                # Ô TICK, không phải nút "Buy now": khách gom nhiều addon vào
                # MỘT đơn rồi chuyển khoản một lần, và nhận về MỘT mã mở hết.
                in_cart = item['code'] in cart_codes(bpy.context)
                d.append(_nut(DPHUB_OT_cart_toggle.bl_idname,
                              chu=order_mod.money(item.get('price')),
                              icon='CHECKBOX_HLT' if in_cart
                              else 'CHECKBOX_DEHLT',
                              nhan=in_cart, code=item['code']))
            elif why:
                d.append(_chu(cat_theo_tu(why, chars)))
        if state['license'] in (gate.OK, gate.EXPIRED, gate.WRONG_MACHINE):
            d.append(_nut(DPHUB_OT_clear_key.bl_idname, icon='TRASH',
                          chu='Remove key', code=item['code']))
    return d


def cao_o(cap, chars):
    """Số dòng của Ô CAO NHẤT trong `cap`.

    "Nhiều thông tin nhất có thể" là đúng cái ô đang có sẵn trong danh mục,
    KHÔNG phải một con số gõ cứng. Gõ cứng thì hoặc thừa (mọi ô mang theo mấy
    dòng trống cho một cảnh chẳng bao giờ xảy ra trên máy này), hoặc thiếu
    (một ô vượt qua và lưới lại xô như cũ). Đo chính đám ô sắp vẽ thì không
    bao giờ sai cả hai chiều.
    """
    return max([len(o_dong(it, st, chars)) for it, st in cap] or [0])


def cao_tung_hang(cap, chars, cols):
    """Chiều cao cho TỪNG HÀNG của lưới — trả một số cho mỗi ô, theo thứ tự.

    ĐO THEO HÀNG, KHÔNG THEO CẢ LƯỚI. Cái xô lệch mà mắt nhìn ra là hai ô
    ĐỨNG CẠNH NHAU không bằng nhau; hai ô cách nhau ba hàng thì không ai đem
    ra so. Bắt cả lưới bằng ô cao nhất là kéo tám ô còn lại lên theo một ô
    đang có bản mới — bảng phình thêm cả trăm px trống mà không tidy hơn tí
    nào. Ducphan chỉ thẳng vào chỗ đó ngày 22/08/2026.

    Blender cũng đã tự cho mỗi hàng lưới cao bằng ô cao nhất của hàng đó; chỗ
    này chỉ kéo cái BOX cho đầy chiều cao ấy, để viền ô không hụt lên giữa
    chừng.
    """
    cols = max(1, int(cols))
    cao = []
    for dau in range(0, len(cap), cols):
        n = cao_o(cap[dau:dau + cols], chars)
        cao += [n] * len(cap[dau:dau + cols])
    return cao


def draw_product(layout, item, state, chars=None, cao=0):
    """MỘT Ô của lưới. `chars` = số ký tự vừa ô đó, `cao` = số dòng phải đủ.

    Ô này CHỈ mang những gì khách phải nhìn thấy để quyết định: logo, tên, tình
    trạng, MỘT nút việc, và giá. Câu mô tả đầy đủ và tên đầy đủ nằm trong
    tooltip của chính cái nút trong ô (`_tooltip`) — hiện ra đúng lúc con trỏ
    dừng lại để hỏi, và không tốn một px chiều cao nào của bảng.

    HAI NGÂN SÁCH CHỮ, KHÔNG PHẢI MỘT. Dòng có icon đứng trước hụt 4 ký tự so
    với dòng không icon (đo 22/08/2026), nên câu dài phải nằm ở dòng KHÔNG
    icon. Đó là lý do vài chỗ trong `o_dong` tách một câu ra hai dòng thay vì
    gắn icon vào câu đó.

    `cao` thiếu thì ô cứ cao theo nội dung của riêng nó — đúng như trước
    22/08/2026. Đường vẽ thật luôn truyền số vào; để mặc định 0 là cho phép
    một phép đo dựng ô lẻ mà không phải bịa ra chiều cao.
    """
    if chars is None:
        chars = o_ky_tu(1)
    box = layout.box()
    dong = o_dong(item, state, chars)
    # ĐỆM CHO ĐỦ CHIỀU CAO CHUNG. Dòng trống là `label(text='')` chứ không phải
    # `separator()`: separator cao chưa tới nửa dòng chữ, nên đệm bằng nó thì
    # các ô vẫn lệch nhau, chỉ lệch ít hơn — mà lệch ít thì lại càng khó nhìn
    # ra là đang lệch.
    dong = dong + [{'kieu': 'trong'}] * max(0, cao - len(dong))

    # GOM CÁC DÒNG CHỮ LIỀN NHAU VÀO MỘT CỘT `align=True`, còn nút thì vẽ rời.
    # Chữ trong cột align sát nhau hơn (ô đỡ cao), nhưng NÚT trong cột align
    # bị Blender dính thành một khối bo góc liền — hai cái nút rời nhau đọc ra
    # thành một cái nút hai tầng.
    cot = None
    for r in dong:
        if r['kieu'] == 'nut':
            cot = None
            op = box.operator(r['op'], text=r['chu'], icon=r['icon'],
                              depress=r['nhan'])
            for ten, gt in r['dat'].items():
                setattr(op, ten, gt)
            continue
        # `bool(...)`: dòng đệm không mang khoá `mo`, và `None != False` là
        # True — so thẳng thì mỗi dòng trống lại mở một cột mới, cột mới thì
        # mất `align` và ô phình cao thêm đúng chỗ vừa đệm cho nó bằng nhau.
        mo = bool(r.get('mo'))
        if cot is None or mo != cot[1]:
            cot = (box.column(align=True), mo)
            cot[0].enabled = not mo
        if r['kieu'] == 'trong':
            cot[0].label(text='')
        elif r.get('icon_value'):
            cot[0].label(text=r['chu'], icon_value=r['icon_value'])
        else:
            cot[0].label(text=r['chu'], icon=r['icon'])


def draw_payment(layout):
    """Mã QR chuyển khoản + dòng chữ dưới nó.

    Cả hai đều do tác giả khai trong danh mục; khai gì hiện nấy, không khai
    thì KHÔNG hiện gì cả. Ba trạng thái, và trạng thái thứ ba phải nói ra:
        - có ảnh          -> hiện mã QR
        - chỉ có chữ      -> hiện chữ (số tài khoản gõ tay cũng chuyển được)
        - có khai ảnh mà tải không về -> nói là chưa tải được, đừng để trống
    """
    pay = STATE.get('payment') or {}
    note, url = pay.get('note') or '', pay.get('qr') or ''
    if not (note or url):
        return
    layout.separator()
    layout.label(text='Payment', icon='FUND')
    icon = qr_icon()
    if icon:
        row = layout.row()
        row.alignment = 'CENTER'
        row.template_icon(icon_value=icon, scale=7.0)
    elif url and not os.path.isfile(catalog.qr_cache_path()):
        # CHỈ nói "chưa tải" khi trên đĩa thật sự không có ảnh. Ảnh có mà
        # icon_id bằng 0 là chuyện của chế độ nền — báo "chưa tải" ở đó là
        # nói sai, và người đọc log sẽ đi tìm một lỗi mạng không tồn tại.
        layout.label(text='QR code not downloaded yet', icon='ERROR')
    if note:
        col = layout.column(align=True)
        for line in lic_ui.wrap(note):
            col.label(text=line)


def draw_dashboard(layout, context):
    # BẢN MỚI CỦA CHÍNH BẢNG NÀY — đặt trên cùng, trước cả nút Refresh.
    #
    # Không phải để nó nổi bật cho vui: khách đang dùng bản cũ có thể đang kẹt
    # ở một việc mà bản mới đã sửa (bản 1.1.0 không đặt được đơn nữa). Nhét
    # dòng nhắc xuống cuối bảng là họ cuộn qua nó để đi tìm cái nút đang hỏng.
    hub_moi = hub_update_ready()
    if hub_moi:
        box = layout.box()
        box.label(text='DP_Hub %s available' % hub_moi['version'], icon='INFO')
        box.operator(DPHUB_OT_update_hub.bl_idname, icon='IMPORT')

    # BAN BLENDER KHONG CHAY NOI — dat NGAY DAY, tren ca danh sach san pham.
    #
    # Khach `hungkts.toancau@` (12/08/2026) tra tien roi moi biet may minh khong
    # chay duoc. Dong canh bao nay phai dap vao mat TRUOC khi ho cuon xuong tich
    # san pham va bam mua; nhet xuong duoi tung mon la ho da quyet dinh mua roi.
    if co_mon_nao_khong_hop():
        box = layout.box()
        box.alert = True
        box.label(text=cau_doi_ban(), icon='ERROR')
        col = box.column(align=True)
        for line in lic_ui.wrap('The paid plugins are compiled for Blender %s '
                                'and will not load here. Install Blender %s '
                                'before buying - your current Blender can stay, '
                                'both versions live side by side and open the '
                                'same .blend files.'
                                % (BLENDER_KHUYEN, BLENDER_KHUYEN)):
            col.label(text=line)

    layout.operator(DPHUB_OT_refresh.bl_idname, icon='FILE_REFRESH')
    if STATE['fetched']:
        layout.label(text='Catalog: %s'
                     % time.strftime('%d/%m %H:%M',
                                     time.localtime(STATE['fetched'])))
    else:
        layout.label(text='Catalog not downloaded yet')
    if STATE['skipped']:
        layout.label(text='%d bad %s skipped' % (
            STATE['skipped'], 'entry' if STATE['skipped'] == 1 else 'entries'),
            icon='ERROR')
    if STATE['msg']:
        col = layout.column(align=True)
        for line in lic_ui.wrap(STATE['msg']):
            col.label(text=line)

    # ĐƠN ĐANG CHỜ DUYỆT — đặt CAO, ngay dưới nút Refresh. Người đang chờ mở
    # bảng ra là để tìm đúng dòng này; nằm dưới đáy thì họ cuộn qua nó rồi bấm
    # gửi đơn lần nữa.
    don = STATE.get('order') or {}
    if don.get('order'):
        box = layout.box()
        box.label(text='Order %s - waiting for approval' % don['order'],
                  icon='TIME')
        col = box.column(align=True)
        cho = time.time() - float(don.get('at') or 0)
        col.label(text='Sent %s ago' % _khoang(cho))
        for line in lic_ui.wrap('Your plugins will activate by themselves '
                                'once the author approves. You can keep '
                                'working - or press the button below to check '
                                'right now.'):
            col.label(text=line)
        box.operator(DPHUB_OT_fetch_key.bl_idname, icon='IMPORT',
                     text='Check now')
        box.operator(DPHUB_OT_forget_order.bl_idname, icon='X')

    # LƯỚI SẢN PHẨM. Số cột đọc từ bề ngang N-panel ĐANG CÓ, nên kéo mép thanh
    # bên là lưới tự sắp lại — Blender vẽ lại bảng trong lúc kéo.
    #
    # `even_columns` để hai ô cạnh nhau bằng nhau; KHÔNG bật `even_rows`: một ô
    # đang chờ mở lại Blender cao hơn ô thường vài dòng, mà bắt cả hàng cao
    # bằng nó là chừa ra một mảng trống ngay giữa lưới.
    cols = grid_columns(context)
    # NGÂN SÁCH CHỮ LẤY THEO BỀ NGANG THẬT, không theo cảnh hẹp nhất của số
    # cột đó: kéo bảng rộng ra thì ô rộng ra thật, và câu mô tả phải hiện lại.
    chars = o_ky_tu(cols, rong_logic(context))
    # ĐỌC TRẠNG THÁI ĐÚNG MỘT LẦN MỖI SẢN PHẨM, rồi chuyền cái đó đi khắp nơi.
    # `product_state` mở đĩa (số hiệu bản đã cài, mã kích hoạt) và bảng thì
    # được vẽ lại mỗi lần con trỏ đi qua nó; xếp thứ tự một vòng, đo chiều cao
    # một vòng, vẽ một vòng — ba vòng cùng gọi lại là ba lần đọc đĩa cho mỗi
    # nhịp vẽ.
    cap = sap_cap([(it, product_state(it)) for it in STATE['products']])
    # CHIỀU CAO TỪNG HÀNG, đo TRƯỚC khi vẽ ô đầu tiên. Không có nó thì ô nào
    # cao theo ô nấy và cạnh mỗi ô ngắn là một mảng trống — xem `cao_tung_hang`.
    cao = cao_tung_hang(cap, chars, cols)
    grid = layout.grid_flow(row_major=True, columns=cols, even_columns=True,
                            even_rows=False, align=False)
    pending = 0
    for i, (item, state) in enumerate(cap):
        draw_product(grid, item, state, chars, cao[i])
        if state['released'] and item['zip'] \
                and (not state['installed'] or state['update']) \
                and (not item.get('gated') or key_for(item['code'])):
            pending += 1
    if pending > 1:
        # Chỉ hiện khi có TỪ HAI việc trở lên: một plugin thì nút riêng của nó
        # đã đủ, thêm nút nữa chỉ làm bảng rối.
        layout.operator(DPHUB_OT_install_owned.bl_idname, icon='IMPORT')
    if not STATE['products']:
        col = layout.column(align=True)
        for line in lic_ui.wrap('Press Refresh catalog to see the plugins.'):
            col.label(text=line)

    # NGAY DƯỚI DANH SÁCH PLUGIN. Khối này nói về chính những plugin vừa liệt kê
    # ở trên, nên đặt liền sau; nhét xuống dưới khối mua bán là chen một việc
    # thuộc lúc LÀM VIỆC vào giữa một luồng thuộc lúc MUA.
    draw_toolbox(layout, context)

    # KHỐI ĐƠN HÀNG. Chỉ hiện khi đã tick ít nhất một món — bảng của người đã
    # mua đủ thì không có gì để bày ra.
    n_cart, total = cart_total(context)
    if n_cart:
        layout.separator()
        box = layout.box()
        box.label(text='Your order: %d %s' % (n_cart,
                                              'item' if n_cart == 1 else 'items'),
                  icon='CHECKBOX_HLT')
        box.label(text='Total: %s' % order_mod.money(total))

        # Ba ô khai báo, NGAY TRÊN nút copy. Địa chỉ email đi trong đơn để tác
        # giả không phải gõ lại — gõ sai một chữ là mã bay vào hư không mà khách
        # thì đã trả tiền.
        p = prefs(context)
        if p is not None:
            box.prop(p, 'buyer_email')
            row = box.row(align=True)
            row.prop(p, 'buyer_name')
            row.prop(p, 'buyer_phone')
            col = box.column(align=True)
            if order_mod.email_ok((getattr(p, 'buyer_email', '') or '').strip()):
                for line in lic_ui.wrap('Your activation key will be sent to '
                                        'this email address.'):
                    col.label(text=line)
            else:
                # Biểu tượng CHỈ ở dòng đầu: đặt vào mọi dòng thì cột chữ bị
                # thụt vào và đọc ra như bốn lỗi khác nhau.
                for i, line in enumerate(
                        lic_ui.wrap('Enter your email - the activation key '
                                    'is sent there.')):
                    col.label(text=line, icon='ERROR' if i == 0 else 'BLANK1')

        draw_payment(box)

        # Ô CHỌN ẢNH BIÊN LAI + MỘT NÚT. Đây là toàn bộ việc khách phải làm:
        # chuyển khoản, chụp màn hình, chọn file, bấm gửi. Không copy, không
        # dán, không mở Telegram, không mở email.
        box.separator()
        if p is not None:
            box.prop(p, 'receipt_path')
        # CHỈ NHẮC TỚI MÃ QR KHI CÓ MÃ QR. Tác giả chưa khai khối thanh toán
        # thì `draw_payment` không vẽ gì, và một câu "dùng mã QR ở trên" lúc đó
        # bảo khách đi tìm một thứ không có trên màn hình.
        pay = STATE.get('payment') or {}
        cach = ('Transfer the money using the details above, then take a '
                if (pay.get('qr') or pay.get('note')) else 'Take a ')
        col = box.column(align=True)
        for i, line in enumerate(lic_ui.wrap(
                cach + 'screenshot of your bank transfer receipt, choose that '
                'image here, and press Send order.')):
            col.label(text=line, icon='INFO' if i == 0 else 'BLANK1')
        row = box.row()
        row.scale_y = 1.4
        row.operator(DPHUB_OT_send_order.bl_idname, icon='EXPORT')

        # ĐƯỜNG LÙI, VÀ CHỈ HIỆN KHI CẦN. Bày sẵn một đường copy tay cạnh nút
        # tự động là mời khách đi vào đường thủ công — họ làm việc họ NHÌN
        # THẤY. Chỉ khi cửa kiểm không với tới được thì nó mới có ích, và lúc
        # đó nó phải có mặt.
        if STATE.get('send_failed'):
            col = box.column(align=True)
            for i, line in enumerate(lic_ui.wrap(
                    'Could not reach the server. Copy the order below and send '
                    'it to the author together with your receipt.')):
                col.label(text=line, icon='ERROR' if i == 0 else 'BLANK1')
            box.operator(DPHUB_OT_copy_order.bl_idname, icon='COPYDOWN')

    layout.separator()
    # THỨ TỰ Ở ĐÂY LÀ CÓ CHỦ Ý — trên xuống dưới là dễ dần đến khó dần.
    #
    # Khách của addon Blender không phải dân làm máy tính. Việc gì bày ra trước
    # mắt họ thì họ làm việc đó, nên việc bày ra đầu tiên phải là việc DỄ NHẤT
    # và ít hỏng nhất: một nút, không copy, không dán, không mở email.
    col = layout.column(align=True)
    for line in lic_ui.wrap('Already paid? Get your key with one click:'):
        col.label(text=line)
    layout.operator(DPHUB_OT_fetch_key.bl_idname, icon='IMPORT')
    # Đường lùi khi hộp lấy mã chưa có gì (tác giả gửi tay, hoặc mạng chặn cửa
    # kiểm). Ô này nhận mã mở NHIỀU sản phẩm; ô riêng của từng plugin nằm trong
    # khối của plugin đó.
    layout.operator(DPHUB_OT_paste_key.bl_idname, icon='KEYINGSET',
                    text='Paste key from email').code = ''
    # KHÔNG in vân tay máy ra bảng nữa (03/08/2026) — xem `dp_license/ui.py`.
    # Dãy chữ hiện trên màn hình là thứ khách sẽ gõ tay hoặc đọc qua điện
    # thoại, và mã cấp từ nó không bao giờ chạy.
    layout.operator(DPHUB_OT_copy_machine.bl_idname, icon='COPYDOWN')

    # ĐỔI MÁY / CÀI LẠI WINDOWS. Không hiện khi đang chờ một yêu cầu — bày ra
    # là khách bấm thêm lần nữa, và tác giả nhận hai yêu cầu cho một việc.
    if not (STATE.get('order') or {}).get('order'):
        layout.separator()
        box = layout.box()
        # Câu này phải ngắn: cột N-panel của Blender cắt chữ quá 30 ký tự, và
        # `selftest_hub` có phép đo bắt đúng chuyện đó.
        box.label(text='Changed PC or reinstalled?', icon='FILE_REFRESH')
        p = prefs(context)
        if p is not None:
            box.prop(p, 'buyer_email')
            box.prop(p, 'bought_when')
        col = box.column(align=True)
        for line in lic_ui.wrap('Your old key only works on the old PC. Ask '
                                'for a new one - the author checks your '
                                'purchase and approves it.'):
            col.label(text=line)
        box.operator(DPHUB_OT_rekey.bl_idname, icon='EXPORT')


class VIEW3D_PT_dp_hub(bpy.types.Panel):
    bl_label = 'DP_Hub'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'DP'

    # KHÔNG có nút pop-out ở header bảng này. Hub không đi vào toolbox (xem
    # `toolbox.EXCLUDED_CATEGORIES`), và nút mở toolbox đã nằm ngay trong thân
    # bảng - thêm một nút nữa ở header là hai đường dẫn tới cùng một chỗ.

    def draw(self, context):
        draw_dashboard(self.layout, context)


class DPHubPreferences(bpy.types.AddonPreferences):
    bl_idname = ADDON_ID

    auto_check: bpy.props.BoolProperty(
        name='Check for new plugins automatically',
        description='Ask the server for the plugin list in the background, '
                    'at most once every few hours',
        default=True)

    catalog_url: bpy.props.StringProperty(
        name='Catalog URL',
        description='catalog.json file on the server',
        default=catalog.DEFAULT_URL)

    # BA Ô NÀY Ở PREFERENCES chứ không phải WindowManager như giỏ hàng: Blender
    # tự lưu Preferences qua `save_userpref`, nên khách khai một lần dùng mãi.
    # Để ở WindowManager thì mỗi lần mở Blender là gõ lại địa chỉ email.
    buyer_email: bpy.props.StringProperty(
        name='Email',
        description='Your activation key will be sent to this address')

    buyer_name: bpy.props.StringProperty(
        name='Name',
        description='Your name, for the invoice (optional)')

    buyer_phone: bpy.props.StringProperty(
        name='Phone',
        description='Phone number, in case the author needs to reach you '
                    '(optional)')

    # ẢNH BIÊN LAI. Để ở Preferences cùng chỗ với ba ô kia, nhưng nó là thứ
    # dùng MỘT LẦN: `send_order` xoá nó ngay sau khi gửi xong, để lần mua sau
    # khách không vô tình gửi lại đúng cái biên lai cũ.
    receipt_path: bpy.props.StringProperty(
        name='Receipt image',
        description='Screenshot of your bank transfer (PNG or JPG)',
        subtype='FILE_PATH')

    # KHI NAO MUA - de tac gia doi chieu voi so ban ra luc bam duyet yeu cau
    # cap lai. Khach go tu do ("thang 6", "12/8/2026"), khong ep khuon: ep
    # khuon o day la chan dung nguoi da tra tien vi ho nho khong chinh xac.
    bought_when: bpy.props.StringProperty(
        name='Bought around',
        description='Roughly when you bought, e.g. "June 2026" - helps the '
                    'author find your purchase')

    def draw(self, context):
        self.layout.prop(self, 'auto_check')
        self.layout.prop(self, 'catalog_url')
        draw_dashboard(self.layout, context)


CLASSES = (
    DPHubPreferences,
    DPHUB_OT_refresh, DPHUB_OT_install, DPHUB_OT_install_owned,
    DPHUB_OT_buy, DPHUB_OT_video, DPHUB_OT_companion,
    DPHUB_OT_cart_toggle, DPHUB_OT_copy_order, DPHUB_OT_send_order,
    DPHUB_OT_forget_order, DPHUB_OT_rekey, DPHUB_OT_trial,
    DPHUB_OT_paste_key, DPHUB_OT_fetch_key, DPHUB_OT_update_hub,
    DPHUB_OT_copy_machine, DPHUB_OT_clear_key,
    DPHUB_OT_toolbox_mode, DPHUB_OT_toolbox_block,
    DPHUB_OT_toolbox_open, DPHUB_OT_toolbox_close,
    VIEW3D_PT_dp_hub,
)

def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    register_keymaps()
    # Giỏ hàng của phiên làm việc. Đặt trên WindowManager chứ không phải Scene:
    # Scene được LƯU VÀO FILE .blend, và một giỏ hàng cũ sống lại trong file
    # người khác gửi tới là thứ không ai giải thích được.
    bpy.types.WindowManager.dphub_cart = bpy.props.StringProperty(default='')
    load_cached_into_state()
    # Timer thay vì gọi thẳng: lúc register() Blender chưa dựng xong cửa sổ,
    # và bản thân register() không được phép chậm.
    if not bpy.app.background:
        bpy.app.timers.register(_auto_timer, first_interval=3.0)


def unregister():
    try:
        if bpy.app.timers.is_registered(_auto_timer):
            bpy.app.timers.unregister(_auto_timer)
    except Exception as exc:
        print('[DP_Hub] go timer loi: %r' % (exc,))
    unregister_keymaps()
    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except Exception as exc:
            print('[DP_Hub] go lop %s loi: %r' % (cls.__name__, exc))
    try:
        del bpy.types.WindowManager.dphub_cart
    except AttributeError:
        pass
    qr_release()
    logo_release()
