# -*- coding: utf-8 -*-
# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
"""CUA SO DP — mot cua so HE DIEU HANH roi, keo ra ngoai khung Blender duoc.

Luat Ducphan chot 23/09/2026, sau khi nhin ban khay xep canh:

  · *"tao k can cai tray ben trai lam j, cai tao can la 1 cua so rieng biet
    co the di chuyen ngoai khung cua so blender"*
  · *"mo 1 cua so khong co bat cu noi dung j, la noi de chua cac cua so addon"*
  · *"tao muon bo het sach rom ra, chi co noi dung cua moi addon trong cua so"*

Nen: MOT cua so roi lam CHO CHUA, ben trong la cac o addon do ta tu ve. Keo
ca cua so sang man hinh khac duoc; o ben trong theo no ra ngoai khung Blender.

═══════════════════════════════════════════════════════════════════════════
DA DO TRUOC KHI VIET — nhung so nay quyet dinh cach lam o day
═══════════════════════════════════════════════════════════════════════════

⛔ `Window.x/y/width/height` la CHI DOC. Khong dat duoc vi tri hay be ngang
   cua so tu Python (do 23/09/2026: `AttributeError ... is read-only`). Vi
   the moi phai la MOT cua so chua chu khong phai mot cua so cho moi o: mo
   11 cua so, moi cai bung ra gan bang man hinh, khong cach nao thu lai.
   Khach keo nho MOT lan; Blender tu nho bo cuc cua so trong file/startup.

⛔ KIEU AREA QUYET DINH GIA. Do cung mot cua so rong:
       VIEW_3D 2,32 ms/khung · IMAGE_EDITOR 0,84 · PROPERTIES 0,75
       OUTLINER 0,26 · CONSOLE 0,23 · INFO 0,15 · TEXT_EDITOR 0,15
   VIEW_3D dat gap 15 lan vi Blender van dung CA CANH 3D phia sau roi ta phu
   o kin len — tra tien cho mot buc hinh khong ai nhin. Dung TEXT_EDITOR:
   re hon 94%, va no khong co canh nao de dung.

⛔ DUOC PHEP DUNG TEXT_EDITOR vi nut cua addon KHONG chay trong cua so nay.
   Ducphan chot: nut tac dong vao VIEWPORT CHINH. `o._chay_op` da doi ngu
   canh bang `temp_override` sang vung VIEW_3D that — xem `_vung_3d()`.
   Neu sau nay co nut nao doi chay tai cho thi phai xem lai ca doan nay.

⛔ MODAL AN THEO CUA SO. Da do: modal goi trong cua so roi nhan 3/3 su kien
   cua no va 0/3 su kien cua cua so chinh — khong cuop phim cua ai.

⛔ THAM CHIEU `Window` KHONG TU CHET. Doc `win.width` cua mot cua so DA DONG
   van ra so (con tro treo). Nen moi lan dung phai tim lai trong
   `wm.windows`, khong duoc tin cai da giu — xem `con_song()`.
"""
import bpy
from bpy.app.handlers import persistent

from . import nho

# Kieu area re nhat ma van ve duoc — xem bang do o dau file.
KIEU = 'TEXT_EDITOR'
LOP_VE = 'SpaceTextEditor'

# Ten dat cho `screen` cua cua so DP.
#
# ⛔ PHAI DOI TEN. Ducphan 23/09/2026: *"cai cua so chua cac khung addon co the
#    dat ten rieng cho no duoc khong, dung de trung ten hay anh huong toi cac
#    cua so goc"*. Blender dat mac dinh la `'temp'` — mot cai ten chung ma no
#    dung cho moi cua so phu, nen hai thu khac nhau de dam vao nhau.
#
# ⛔ CHI DOI TEN `screen`, TUYET DOI KHONG DOI `workspace`. Da do 23/09/2026:
#    cua so DP DUNG CHUNG workspace 'Layout' voi cua so chinh cua khach. Doi
#    ten workspace la doi thang cai tab tren cung cua khach.
#
# ⛔ TEN NAY KHONG PHAI TIEU DE TREN THANH HE DIEU HANH. `bpy.types.Window`
#    khong co thuoc tinh tieu de nao cho Python — Blender (C) dat theo ten file
#    .blend. Da do: `dir(Window)` khong co `title`/`name`/`label`.
TEN_SCREEN = 'DP_Hub'

_CUA = [None]          # Window dang lam cho chua, hoac None
_TAY = [None]          # tay cam lop ve


# ------------------------------------------------------------------ tra cuu
def con_song(w=None):
    """`w` co con la mot cua so THAT dang mo khong.

    ⛔ KHONG hoi `w.width`. Cua so da dong van tra ve so — con tro treo. Chi
    co mot cach dung: doi chieu voi danh sach cua so dang mo.
    """
    w = _CUA[0] if w is None else w
    if w is None:
        return None
    try:
        for x in bpy.context.window_manager.windows:
            if x == w:
                return w
    except Exception:                                        # noqa: BLE001
        pass
    return None


def dang_mo():
    return con_song() is not None


def vung():
    """(area, region) cua cua so chua, hoac (None, None).

    ⛔ NAN LAI KIEU VUNG MOI LAN HOI. Da do 23/09/2026: bam "Open DP Post
    Workspace" thi `dp_postprocess/workspace.py::_to_image_editor` duyet MOI
    screen thuoc workspace va doi vung lon nhat sang `IMAGE_EDITOR` — ke ca
    screen cua cua so DP. Lop ve dang ky theo `SpaceTextEditor`, vung khong
    con la TEXT_EDITOR nua thi `_ve()` KHONG BAO GIO chay: moi o bien mat.
    Te hon, modal van song va `kh.vung` con giu danh sach o bam lan ve cuoi,
    nen cua so DP thanh mot Image Editor trong VAN NUOT cu bam vao widget vo
    hinh. Tat/bat o khong cuu duoc vi `mo()` thay cua so con song la tra ve
    ngay. Khach phai bam ✕ roi mo lai.

    Addon khong duoc sua mot dong, nen phai chan tai day: thay lech kieu thi
    don lai. Phep thu la mot so sanh chuoi, chay moi nhip — khong dang ke.
    """
    w = con_song()
    if w is None:
        return None, None
    try:
        ar = w.screen.areas[0]
        if ar.type != KIEU:
            _don(w)
            ar = w.screen.areas[0]
        for r in ar.regions:
            if r.type == 'WINDOW':
                return ar, r
    except Exception:                                        # noqa: BLE001
        pass
    return None, None


def la_cua_dp(w):
    """`w` co phai chinh cua so chua khong — de cho khac tranh no ra.

    ⛔ PHAI HOI LAI `con_song()`. Da dam 23/09/2026: khach bam ✕ tren thanh
    tieu de he dieu hanh thi `_CUA[0]` VAN GIU con tro cua so da chet (doc
    `win.width` cua no van ra so). Neu Blender cap lai dung dia chi do cho mot
    cua so MOI thi Hub se coi CUA SO CUA KHACH la cua so DP: ve de len no,
    cuop modal cua no, va `_vung_3d()` lai bo qua dung cai cua so chinh.
    Da ep Blender dung lai dia chi 10 luot va khong lan nao trung, nen day la
    rui ro tiem an — nhung mot cau hoi them thi re hon mot cu vang.
    """
    if w is None or _CUA[0] is None:
        return False
    if con_song() is None:
        return False
    return w == _CUA[0]


# -------------------------------------------------------------------- don
def _don(w):
    """Bo het rom ra: chi con mot tam nen de ve noi dung addon len.

    Ducphan: *"bo het sach rom ra, chi co noi dung cua moi addon trong cua
    so do"*. Moi thanh Blender co the tat deu tat.
    """
    ar = w.screen.areas[0]
    try:
        if ar.type != KIEU:
            ar.type = KIEU
    except Exception as e:                                   # noqa: BLE001
        print('[DP_Hub] khong dat duoc kieu %s: %r' % (KIEU, e))
    # ⛔ DANH DAU DE ADDON TU GIAU NUT "MO KHAY CU". Ducphan 23/09/2026:
    # *"cai cua so chua cac khung addon tao k muon co bat cu cai panel nao
    # het, chi phuc vu hien dp addon thoi"*.
    # Ba agent cung bao mot chuyen: `draw_header_preset()` goc cua addon goi
    # `toolbox.draw_button()`, ve ra mot nut 🗔 ngay trong dau o — bam vao la
    # bung ra khay xep canh CU, tuc hai he giao dien chay song song.
    # `toolbox.py` da co san duong tu im: no giau nut khi thay dau nay tren
    # `screen` (`MARK = 'dp_toolbox'`, xem `dp_license/toolbox.py:94,749`).
    # Dat dau la xong — KHONG dong toi mot dong nao cua addon.
    try:
        from ..dp_license import toolbox as _tb
        w.screen[getattr(_tb, 'MARK', 'dp_toolbox')] = 1
    except Exception:                                        # noqa: BLE001
        try:
            w.screen['dp_toolbox'] = 1
        except Exception:                                    # noqa: BLE001
            pass

    sp = getattr(ar.spaces, 'active', None)
    if sp is None:
        return ar
    for ten in ('show_region_ui', 'show_region_header', 'show_region_footer',
                'show_region_toolbar', 'show_region_tool_header',
                'show_line_numbers', 'show_syntax_highlight',
                'show_word_wrap', 'show_margin'):
        try:
            setattr(sp, ten, False)
        except Exception:                                    # noqa: BLE001
            pass       # thanh nao khong co thi thoi
    return ar


# ------------------------------------------------------------------ mo/dong
def mo(ve_ham):
    """Mo cua so chua va cam `ve_ham` vao lop ve cua no.

    Tra ve Window, hoac None neu khong mo duoc. Da mo roi thi tra lai cai cu
    chu khong mo them cai nua.
    """
    cu = con_song()
    if cu is not None:
        return cu

    wm = bpy.context.window_manager
    truoc = set(w.as_pointer() for w in wm.windows)
    try:
        bpy.ops.wm.window_new()
    except Exception as e:                                   # noqa: BLE001
        print('[DP_Hub] khong mo duoc cua so: %r' % (e,))
        return None
    moi = [w for w in wm.windows if w.as_pointer() not in truoc]
    if not moi:
        print('[DP_Hub] wm.window_new() khong sinh cua so nao')
        return None

    w = moi[0]
    _CUA[0] = w
    _dat_ten(w)
    _don(w)
    _bat_lop_ve(ve_ham)
    return w


def _dat_ten(w):
    """Doi ten `screen` cua cua so DP cho khoi dam vao do cua khach.

    Blender tu them hau to `.001` neu ten da co, nen mo hai cua so cung khong
    trung. Doi khong duoc thi thoi — cai ten chi de nhin, khong dang de hong
    ca viec mo cua so.
    """
    try:
        if w.screen.name != TEN_SCREEN:
            w.screen.name = TEN_SCREEN
    except Exception as e:                                   # noqa: BLE001
        print('[DP_Hub] khong doi duoc ten screen: %r' % (e,))


def la_screen_dp(sc):
    """Screen nay co phai cua cua so DP khong (ke ca ban co hau to .001)."""
    try:
        return bool(sc) and sc.name.startswith(TEN_SCREEN)
    except Exception:                                        # noqa: BLE001
        return False


def dong():
    """Dong cua so chua. Khong con thi cung khong sao."""
    _tat_lop_ve()
    w = con_song()
    _CUA[0] = None
    _bao_da_dong()
    if w is None:
        return False
    try:
        with bpy.context.temp_override(window=w):
            bpy.ops.wm.window_close()
    except Exception as e:                                   # noqa: BLE001
        print('[DP_Hub] dong cua so hong: %r' % (e,))
        return False
    return True


# Ham `khay_ui` cam vao de duoc bao khi cua so DP khong con — nho no ma
# `_CHAY` khong bi ket o True sau khi khach bam ✕. Xem `DPHUB_OT_khay.cancel`.
_KHI_DONG = [None]


def khi_dong(ham):
    _KHI_DONG[0] = ham


def _bao_da_dong():
    f = _KHI_DONG[0]
    if f is None:
        return
    try:
        f()
    except Exception as e:                                   # noqa: BLE001
        print('[DP_Hub] don sau khi dong cua so hong: %r' % (e,))


def quen():
    """Bo lop ve va quen cua so — dung khi KHACH tu bam ✕ dong no.

    Khac `dong()` o cho khong goi `window_close` (cua so da khong con).
    """
    _tat_lop_ve()
    _CUA[0] = None
    _bao_da_dong()


# ------------------------------------------------------------------ lop ve
def _bat_lop_ve(ve_ham):
    if _TAY[0] is not None:
        return
    lop = getattr(bpy.types, LOP_VE, None)
    if lop is None:
        print('[DP_Hub] khong co %s de dang ky lop ve' % LOP_VE)
        return
    _TAY[0] = lop.draw_handler_add(ve_ham, (), 'WINDOW', 'POST_PIXEL')


def _tat_lop_ve():
    if _TAY[0] is None:
        return
    lop = getattr(bpy.types, LOP_VE, None)
    if lop is not None:
        try:
            lop.draw_handler_remove(_TAY[0], 'WINDOW')
        except Exception:                                    # noqa: BLE001
            pass
    _TAY[0] = None


def ve_lai():
    """Bao cho CUA SO DP phai ve lai."""
    ar, _r = vung()
    if ar is not None:
        ar.tag_redraw()


def ve_lai_ngoai():
    """Bao cho MOI VUNG CUA KHACH phai ve lai — tru cua so DP.

    ⛔ DOI MOT GIA TRI TRONG CUA SO DP THI VIEWPORT PHAI THAY NGAY.
    Ducphan 23/09/2026, thu tay: *"thong tin qua lai giua cac cua so addon va
    viewport khong lien mach ma cu phai quet chuot qua lai 2 vi tri moi thay
    co tac dung"*.

    Goc benh: `khay_ui.modal` chi goi `ar.tag_redraw()` cho vung CUA CHINH NO.
    Blender chi ve lai vung nao bi danh dau, nen viewport 3D giu nguyen hinh
    cu cho toi khi co gi khac cham vao no — ma "cai gi khac" thuong la chinh
    con chuot cua khach di ngang qua. Keo mot thanh truot trong cua so DP roi
    nhin sang viewport: khong doi. Phai quet chuot sang do no moi ve lai.

    Dung tag CA MAN HINH moi nhip: chi goi khi CO GI DOI THAT (bam, keo, go,
    lan an vao gia tri) — luat "o phai nhe". `tag_redraw()` chi bat mot co,
    khong ve gi ngay tai cho.
    """
    try:
        for w in bpy.context.window_manager.windows:
            if la_cua_dp(w):
                continue
            for a in w.screen.areas:
                a.tag_redraw()
    except Exception:                                        # noqa: BLE001
        pass


def ve_lai_ca_hai():
    """Ca cua so DP lan moi vung cua khach."""
    ve_lai()
    ve_lai_ngoai()


# ═══════════════════════════════════════════════════════════════════════════
# CHIEU NGUOC LAI: canh doi thi CUA SO DP phai thay ngay
# ═══════════════════════════════════════════════════════════════════════════
#
# ⛔ Cung mot con benh, huong nguoc. Khach chon mot vat the trong viewport,
#    hay chay mot lenh lam doi canh — ruot o van la so cu, vi khong ai danh
#    dau cua so DP phai ve lai. Khach phai quet chuot VAO cua so DP thi
#    `Khay.ro()` moi doi va moi ve lai.
#
# ⛔ NHE: handler nay CHI goi `tag_redraw()`, khong tinh gi, khong quet gi.
#    Blender goi `depsgraph_update_post` khi du lieu canh doi that — dung yen
#    thi no khong chay, nen "dung yen ton 0" van giu.
#
# ⛔ PHAI `@persistent`. Ducphan 23/09/2026: *"chon 1 vat the thi addon ben
#    dp window khong tu nhan luon ma phai di chuot qua moi cap nhat"*.
#    Do tren Blender 5.2.2: chon vat the CO kich `depsgraph_update_post`
#    (select_set, doi active, select_all deu 1 lan). Nhung mo mot file .blend
#    la Blender GO SACH moi moc thieu `@persistent` — sau `open_mainfile` moc
#    thuong dem 0, moc persistent dem 1. Bai do dung canh bang script khong
#    mo file nen khong bao gio thay. Hai moc luu file ben duoi cung vay.

@persistent
def _canh_doi(*_a):
    if _CUA[0] is None:
        return
    # ⛔ CANH DOI THI RUOT PHAI DUNG LAI. Chi `tag_redraw` thoi thi o ve lai
    # bang RUOT CU da nho — so cu, danh sach cu. Xem `o.THE_HE`.
    try:
        from . import o as _o
        _o.doi_roi()
    except Exception:                                        # noqa: BLE001
        pass
    # Vat lieu / map vua sua -> xin Blender ve lai preview (panel N tu lam
    # viec nay khi no ve icon; cua so DP thi khong). Xem `ve.id_doi`.
    try:
        _preview_doi(_a)
    except Exception:                                        # noqa: BLE001
        pass
    ve_lai()


_LOAI_ID = {'Material': 'materials', 'Image': 'images', 'World': 'worlds',
            'Texture': 'textures', 'Brush': 'brushes'}


def _preview_doi(a):
    dg = a[1] if len(a) > 1 else None
    if dg is None or not hasattr(dg, 'updates'):
        return
    ids = set()
    cay = False
    for u in dg.updates:
        x = getattr(u.id, 'original', None) or u.id
        loai = type(x).__name__
        kho = _LOAI_ID.get(loai)
        if kho is None:
            for k, v in _LOAI_ID.items():
                if isinstance(x, getattr(bpy.types, k)):
                    kho = v
                    break
        if kho is not None:
            ids.add((kho, x.name))
        elif isinstance(x, bpy.types.ShaderNodeTree):
            cay = True
    if cay:
        # ⛔ Sua mot node thi depsgraph bao CAY NODE (nhung trong vat lieu),
        # khong bao vat lieu. Tim chu cua cay — duyet `bpy.data`, re.
        for m in bpy.data.materials:
            nt = m.node_tree
            if nt is not None and any(
                    (getattr(u.id, 'original', None) or u.id) == nt
                    for u in dg.updates):
                ids.add(('materials', m.name))
    if ids:
        from . import ve as _ve
        _ve.id_doi(ids)


def bat_theo_canh():
    for so in (bpy.app.handlers.depsgraph_update_post,
               bpy.app.handlers.undo_post,
               bpy.app.handlers.redo_post,
               bpy.app.handlers.frame_change_post):
        if _canh_doi not in so:
            so.append(_canh_doi)


def tat_theo_canh():
    for so in (bpy.app.handlers.depsgraph_update_post,
               bpy.app.handlers.undo_post,
               bpy.app.handlers.redo_post,
               bpy.app.handlers.frame_change_post):
        if _canh_doi in so:
            try:
                so.remove(_canh_doi)
            except Exception:                                # noqa: BLE001
                pass


# --------------------------------------------------------------- nho cho mo
# ══════════════════════════════════════════════════════════════════════════
# KHONG DE CUA SO DP DINH VAO FILE .blend CUA KHACH
# ══════════════════════════════════════════════════════════════════════════
#
# ⛔ DA DO 23/09/2026: `wm.window_new()` de ra mot screen ma `is_temporary` la
#    False, nen no BI GHI VAO FILE. Luu file luc cua so DP dang mo roi mo lai
#    -> Blender bung ra HAI cua so va de lai mot screen thua. File gui cho tho
#    khac, may khong co DP_Hub, cung bung ra cai cua so trong do.
#
# ⛔ `Screen.is_temporary` LA CHI DOC — khong danh dau "tam" tu Python duoc.
#    Duong con lai: dong cua so TRUOC khi Blender ghi dia, mo lai ngay sau.
#    Da do: file sach hoan toan, mo lai dung 1 cua so, 0 screen thua.
#
# Ducphan chot 23/09/2026: dong truoc khi luu, mo lai ngay sau.
# Gia phai tra: moi lan Ctrl+S cua so nhap nhay mot cai va bat lai o kich
# thuoc mac dinh — vi `Window.x/y/width/height` cung chi doc.

_VE_HAM = [None]        # giu lai de con mo lai sau khi luu
_MO_LAI = [False]


@persistent
def _truoc_khi_luu(*_a):
    """Dong cua so DP de no khong bi ghi vao file."""
    _MO_LAI[0] = dang_mo()
    if _MO_LAI[0]:
        dong()


@persistent
def _sau_khi_luu(*_a):
    """Mo lai cua so DP neu vua dong no di de luu."""
    if not _MO_LAI[0]:
        return
    _MO_LAI[0] = False
    if _VE_HAM[0] is None:
        return
    try:
        mo(_VE_HAM[0])
    except Exception as e:                                   # noqa: BLE001
        print('[DP_Hub] mo lai cua so sau khi luu hong: %r' % (e,))


def bat_giu_file(ve_ham):
    """Cam hai handler luu file. Goi mot lan luc `register()`."""
    _VE_HAM[0] = ve_ham
    for so, ham in ((bpy.app.handlers.save_pre, _truoc_khi_luu),
                    (bpy.app.handlers.save_post, _sau_khi_luu)):
        if ham not in so:
            so.append(ham)


def go_giu_file():
    for so, ham in ((bpy.app.handlers.save_pre, _truoc_khi_luu),
                    (bpy.app.handlers.save_post, _sau_khi_luu)):
        if ham in so:
            try:
                so.remove(ham)
            except Exception:                                # noqa: BLE001
                pass
    _VE_HAM[0] = None
    _MO_LAI[0] = False


def nho_dang_mo(mo_khong):
    """Ghi lai lan sau co tu mo cua so khong."""
    dl = nho.doc()
    dl['cua_so_mo'] = bool(mo_khong)
    nho.ghi(dl)


def da_tung_mo():
    return bool(nho.doc().get('cua_so_mo'))
