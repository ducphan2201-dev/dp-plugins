# -*- coding: utf-8 -*-
# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
"""BANG MAU CUA NHA DP — MOT CHO DUY NHAT.

⛔ KHONG DOC THEME CUA BLENDER. Ducphan chot 23/09/2026, sau khi thu ca hai
duong: *"ko can theo theme blender, giong cach bai tri va cach su dung thoi"*.
Mau la cua nha DP, giu nguyen o moi theme, moi may. Cai phai giong UI goc la
CACH BAI TRI (nhan trai / o phai, dau bang gap duoc, hop long nhau) va CACH
DUNG (bam vao dau thi ra cai gi) — khong phai mau.

Mot cho duy nhat, de sau nay doi mot mau la ca khay doi theo, va de ban DP_Hub
that dung chung dung mot bang voi ban thu nay.
"""


class Bang:
    """Mot vat duy nhat; moi noi giu tham chieu toi no."""

    def __init__(self):
        # --- than va khung
        # ⛔ NEN LA XAM TRUNG TINH. Ducphan 23/09/2026: *"doi mau nen cua so
        #   addon la mau xam"*. Truoc do la xam ANH LAM (0.118,0.129,0.153)
        #   — ngam vao thi ca o co mot sac xanh. Nay ba kenh bang nhau.
        self.nen_panel = (0.180, 0.180, 0.180, 0.97)   # than mot o
        self.nen_dau   = (0.251, 0.251, 0.251, 1)      # thanh tieu de
        self.hop       = (0.220, 0.220, 0.220, 1)      # `box()` — SANG hon than
        self.hop_vien  = (0.145, 0.145, 0.145, 1)
        # --- dau bang (Ducphan 23/09/2026: *"boi dam cac hang chuc nang hien
        #     tai dang mau trang cuc ky kho nhin"*)
        self.dau_con   = (0.235, 0.235, 0.235, 1)   # dau bang CON, sang hon than
        self.dau_vach  = (0.204, 0.204, 0.204, 1)   # vach sang mep tren dau bang
        self.chu_dau   = (1.000, 1.000, 1.000, 1)   # chu tieu de: trang, IN DAM
        # ⛔ KHONG DUNG CAM O DAY. Ducphan 23/09/2026: *"the deo nao lai co
        #   cai vien cam rat kho chiu"*. Vien nay chay quanh CA mot o, dai
        #   hang nghin pixel — mau noi bat o dien tich lon thi thanh choi.
        #   Cam chi de danh cho vet NHO: con tro go chu, o tich da bat.
        #   O dang o tren cung chi can SANG hon vien thuong mot bac.
        self.vien_chon = (0.286, 0.286, 0.286, 1)      # o dang o tren cung

        # --- nut: phai NHIN RA LA NUT (Ducphan 23/09: "sao toan thay chu la
        #     chu, nut phai nhin ro chu")
        self.nut      = (0.290, 0.290, 0.290, 1)
        # ⛔ "DANG CHON" PHAI KHAC HAN "CHUOT RE QUA". Ban dau nut_nhan
        # (0.365,0.400,0.467) gan trung nut_tro (0.372,0.404,0.471) — nhin ra
        # y het nhau, khong doc duoc trang thai. Do 23/09/2026.
        self.nut_nhan = (0.259, 0.435, 0.678, 1)
        # ⛔ KHONG CON DUNG. Vet sang mep tren la thu lam nut trong 'dap
        #   noi'; da bo het 23/09/2026 khi chuyen sang phang. Giu bien de
        #   ma cu goi vao khong no.
        self.nut_sang = (0.290, 0.290, 0.290, 1)
        self.nut_vien = (0.180, 0.180, 0.180, 1)

        # --- o nhap: LUN xuong, toi hon han
        self.o_chu   = (0.129, 0.129, 0.129, 1)
        self.o_so    = (0.129, 0.129, 0.129, 1)
        self.truot   = (0.129, 0.129, 0.129, 1)
        self.con_tro = (0.949, 0.678, 0.333, 1)
        # ⛔ NEN CHUOI DANG BOI DEN. Ducphan 23/09/2026: *"khi boi den so thi
        #   k thay co dau hieu boi marking"*. Hanh vi boi den co tu dau (go
        #   mot phim la thay ca chuoi) nhung khong mot net nao ve no ra.
        self.boi_den = (0.259, 0.435, 0.678, 1)

        # --- mau noi bat
        self.truot_ruot = (0.278, 0.435, 0.647, 1)     # ruot thanh truot
        self.tich       = (0.129, 0.129, 0.129, 1)
        self.tich_bat   = (0.949, 0.678, 0.333, 1)
        self.ds_chon    = (0.278, 0.435, 0.647, 1)     # dong dang chon

        # --- bang xo ra
        self.xo_nen  = (0.180, 0.180, 0.180, 0.99)
        self.xo_vien = (0.243, 0.243, 0.243, 1)

        # --- chu
        # --- khi chuot re qua (Blender luon sang len o duoi con tro; khong
        #     co cai nay thi bang nhin "chet", du bam van an)
        self.nut_tro  = (0.345, 0.345, 0.345, 1)
        self.o_tro    = (0.157, 0.157, 0.157, 1)
        self.menu_tro = (0.259, 0.259, 0.259, 1)
        # ⛔ KHONG DUNG TRANG TINH DUA VAO ALPHA. Truoc day cho nay la
        #   (1,1,1, 0.07): dep khi hoa tron bat, nhung he mot lenh ve
        #   nao tat hoa tron la no thanh MOT KHOI TRANG DAC che het chu
        #   ben duoi. Ducphan 23/09/2026: *"highlight trang xoa dech
        #   nhin thay chu dau"*. Nay la mot mau XAM DUC — khong the
        #   trang xoa duoc nua, du trang thai GL the nao.
        self.hang_tro = (0.329, 0.329, 0.329, 1)
        self.vien_tro = (0.322, 0.322, 0.322, 1)

        self.chu     = (0.925, 0.925, 0.925, 1)
        self.chu_nut = (1.000, 1.000, 1.000, 1)
        self.chu_mo  = (0.510, 0.510, 0.510, 1)
        self.do      = (0.882, 0.373, 0.337, 1)
        self.cam     = (0.949, 0.678, 0.333, 1)


def _len_srgb(x):
    """linear -> sRGB, cho MOT kenh 0..1."""
    if x <= 0.0031308:
        return max(0.0, 12.92 * x)
    return min(1.0, 1.055 * (x ** (1.0 / 2.4)) - 0.055)


def _bu_gamma(bang):
    """Bu lai cai gamma ma Blender tu ap len moi mau ta dua vao `gpu`.

    ⛔ DAY LA GOC CUA "MAU DAT BAO NHIEU CUNG RA DEN". Do 23/09/2026 bang cach
    chup man hinh cua so DP that roi dem pixel:

        ta dat nut      = 0.451   ->  man hinh hien  44/255 = 0.173
        ta dat nen_panel= 0.290   ->  man hinh hien  18/255 = 0.071
        ta dat nut_vien = 0.576   ->  man hinh hien  74/255 = 0.290
        ta dat hop      = 0.345   ->  man hinh hien  25/255 = 0.098

    Ca bon khop chinh xac cong thuc `sRGB -> linear`:
        ((x + 0.055) / 1.055) ** 2.4
    Tuc Blender COI SO TA DUA LA sRGB roi ha xuong linear truoc khi ve. Ca bang
    mau vi the bi toi di am tham NGAY TU DAU — do la ly do Ducphan dat mau xam
    ma nhin ra gan den, va vi sao moi lan chinh mau deu "khong an".

    Nen: viet mau trong `Bang` theo DUNG cai mat nhin thay (sRGB, y nhu ma mau
    trong Figma/anh chup), roi o day day nguoc len mot nhip — `linear -> sRGB`
    — de sau khi Blender ha xuong thi ra dung so ta muon.

    ⛔ CHI BU BA KENH MAU. Alpha khong di qua duong gamma nao.
    ⛔ MOT CHO DUY NHAT. Dung bu lai o cho khac, bu hai lan la sang trang.
    """
    for ten in dir(bang):
        if ten.startswith('_'):
            continue
        gt = getattr(bang, ten)
        if not isinstance(gt, tuple) or len(gt) != 4:
            continue
        r, g, b, a = gt
        setattr(bang, ten, (_len_srgb(r), _len_srgb(g), _len_srgb(b), a))
    return bang


M = _bu_gamma(Bang())


def lam_moi(ep=False):
    """Giu lai cho nguoi goi — bang mau co dinh nen khong phai lam gi."""
    return M
