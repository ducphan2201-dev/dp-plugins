# -*- coding: utf-8 -*-
# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
"""KHUNG — mot `UILayout` GIA, tu ve bang `gpu` + `blf`.

Y TUONG GOC
-----------
Ham `draw()` cua mot Panel chi la Python goi `self.layout.row()`,
`self.layout.prop(...)`, `self.layout.operator(...)`. Python khong kiem kieu
cua `self`. Nen neu ta dua cho no MOT `layout` khac — cai lop nay — thi

    <lop panel that>.draw(<self gia>, context)

chay NGUYEN BAN GOC va ve ra bang cua ta.

Tuc la DP_Hub ve ho bang cua addon khac ma KHONG sua mot dong nao cua addon
do. Do la dieu kien Ducphan dat ra 23/09/2026: *"toolbox nam trong dphub,
giao dien goi ra tu dphub, khong lam anh huong toi cac addon goc"*.

HAI LUOT, KHONG VE NGAY
-----------------------
`draw()` chi DUNG CAY. Xong moi `do()` (tinh cao tu duoi len) roi `ve()` (ve
tu tren xuong). Ve ngay khong duoc: mot cai `box()` chua biet no cao bao nhieu
cho toi khi con cuoi cung da khai xong.

CHO NAO CHUA LAM DUOC THI NOI RA
--------------------------------
`template_list`, `template_icon_view`, `menu`... chua ve duoc thi ve mot vet
xam ghi ro ten no, KHONG nem loi. Mot bang tat ngang vi mot widget chua co la
nguoi dung mat ca bang; mot vet xam thi ho van dung duoc phan con lai va ta
van biet con no.
"""
import time
import types

import bpy

from . import mau
from . import ve as V

# ------------------------------------------------------------------ mau
# ⛔ KHONG TU CHE BANG MAU. Moi mau doc tu theme dang dung cua Blender —
# `mau.M`. Ducphan 23/09/2026: *"can lam giong UI goc"*. Cai loi kem theo:
# khach doi theme thi o tu ve doi theo, khong sua mot dong nao.
M = mau.M

CHUA_LAM = (0.30, 0.26, 0.20, 1)          # vet "chua lam" — khong co trong theme
NOI_CHIM = (0.0, 0.0, 0.0, 0.15)          # widget_emboss: vach toi duoi widget

# ------------------------------------------------- co, tinh theo ui_scale
HANG   = 20.0
DON_VI = 20.0          # UI_UNIT_X — do cho `ui_units_x`
CHIA   = 0.4           # `use_property_split`: cot nhan chiem 40%, y Blender
KHE    = 2.0
LE_HOP = 6.0
CO_CHU = 11.0
BO_GOC = 2.0        # phang: bo goc nhe, khong tron ung


# ⛔ CHUOT O DAU — de widget duoi con tro SANG LEN.
#
# Blender luon to sang cai widget dang nam duoi con tro. Khong co phan hoi do
# thi bang nhin nhu mot tam anh: bam van an nhung tay khong biet minh dang o
# dau. Ducphan 23/09/2026: *"giao dien vẫn rất dại chứ chưa có sự linh hoạt
# như bảng N-Panel"*.
#
# Dat mot cho duy nhat vi ham ve la ham THUAN — chuyen toa do chuot qua bay
# tang ham la khong xong. `Khay.ve` dat no truoc moi the, va dat ra ngoai troi
# cho nhung the KHONG nam tren cung (the bi che thi khong duoc sang).
TRO = [-1e9, -1e9]


def tro_trong(x, y, w, h):
    return x <= TRO[0] <= x + w and y <= TRO[1] <= y + h


def _ui():
    try:
        s = bpy.context.preferences.system.ui_scale
        return s if s > 0.1 else 1.0
    except Exception:                                        # noqa: BLE001
        return 1.0


# ⛔ O BAM NAM NGOAI VUNG CAT VAN BAM DUOC — neu khong ghi lai vung cat.
# Ruot mot o cuon duoc thi phan tran ra ngoai bi `V.cat_bat` che di, nhung
# `Khay._tim` van thay o bam cua no va van chay. Nen moi o bam deu mang theo
# hinh chu nhat dang cat luc no duoc nap; `_tim` phai hoi lai cai do.
_NGAN_CAT = []


def cat_vao(x, y, w, h):
    """Vao mot vung cat. Long nhau thi lay phan GIAO."""
    if _NGAN_CAT:
        ox, oy, ow, oh = _NGAN_CAT[-1]
        x1, y1 = max(x, ox), max(y, oy)
        x2, y2 = min(x + w, ox + ow), min(y + h, oy + oh)
        x, y, w, h = x1, y1, max(0.0, x2 - x1), max(0.0, y2 - y1)
    _NGAN_CAT.append((x, y, w, h))
    V.cat_bat(x, y, w, h)


def cat_ra():
    if _NGAN_CAT:
        _NGAN_CAT.pop()
    if _NGAN_CAT:
        V.cat_bat(*_NGAN_CAT[-1])
    else:
        V.cat_thoi()


def nap(vung, v):
    """Nap mot o bam, kem vung cat dang hieu luc."""
    if _NGAN_CAT:
        v['cat'] = _NGAN_CAT[-1]
    vung.append(v)


# Bang nao dang gap. Khoa la `bl_idname` cua panel — ben ngoai khong doi
# giua chung, nen nho duoc qua ca lan mo lai Blender neu ghi ra file.
GAP = {}


def dang_gap(khoa, mac_dinh=False):
    if khoa not in GAP:
        GAP[khoa] = bool(mac_dinh)
    return GAP[khoa]


def bat_tat_gap(khoa):
    GAP[khoa] = not GAP.get(khoa, False)
    return GAP[khoa]


class _OpProps:
    """Cai ma `layout.operator()` tra ve. Gan gi vao thi nho de luc bam
    truyen lai cho operator."""

    def __init__(self):
        object.__setattr__(self, '_o', {})

    def __setattr__(self, ten, gt):
        self._o[ten] = gt

    def __getattr__(self, ten):
        if ten == '_o':
            raise AttributeError(ten)
        return self._o.get(ten)


class _Muc:
    """Mot o la: nhan, o nhap, nut, khoang cach."""

    __slots__ = ('kieu', 'dl', 'cao', 'rong', 'x', 'y')

    def __init__(self, kieu, dl):
        self.kieu = kieu
        self.dl = dl
        self.cao = 0.0
        self.rong = 0.0
        self.x = 0.0
        self.y = 0.0


class Khung:
    """Nhai `UILayout`. Moi ten ham deu la ten that cua Blender."""

    def __init__(self, doc=True, align=False, hop=False, cha=None,
                 he_so=0.0):
        self._con = []
        self._doc = doc
        self._align = align
        self._hop = hop
        self._cha = cha
        self._he_so = he_so         # `split(factor=...)`
        self._rongs = []            # be ngang da chia cho tung con
        self._ngu_canh = {}         # `context_pointer_set` da dat o day
        self._dau_bang = None       # khoa, neu khung nay la mot DAU BANG
        self._dau_dam = False       # dau bang cua CA MOT panel addon
        self._so_cot = 0            # >1: khung nay la mot LUOI
        self._doc_luoi = False
        self._active = True if cha is None else cha._active
        self._enabled = True if cha is None else cha._enabled
        self._alert = False if cha is None else cha._alert
        # Khung la ruot cua mot MENU (khong phai popover): nut ve PHANG, chu
        # canh TRAI, y menu Blender (agent MaxImporter vong 2).
        self._la_menu = False if cha is None else cha._la_menu
        self.scale_y = 1.0
        self.scale_x = 1.0
        self.ui_units_x = 0.0
        self.ui_units_y = 0.0
        # ⛔ `use_property_split` PHAI THUA TU KHUNG CHA. Panel nao cung dat
        # no MOT lan tren `layout` roi moi de ra hang, cot; khong thua thi moi
        # o ben trong lai ve kieu cu va ca bang lech nhau.
        self.use_property_split = False if cha is None else \
            cha.use_property_split
        self.use_property_decorate = False if cha is None else \
            cha.use_property_decorate
        self.operator_context = 'INVOKE_DEFAULT'
        self.emboss = 'NORMAL'
        # `alignment`: 'EXPAND' (mac dinh) · 'LEFT' · 'CENTER' · 'RIGHT'.
        # Khac 'EXPAND' thi cac con KHONG gian ra chiem het hang, ma dung
        # be ngang tu nhien roi don ve mot phia — y Blender.
        self.alignment = 'EXPAND'
        self.rong = 0.0
        self.cao = 0.0
        self.x = 0.0
        self.y = 0.0

    # ---------------------------------------------------------- co tinh
    @property
    def active(self):
        return self._active

    @active.setter
    def active(self, v):
        self._active = bool(v)

    @property
    def enabled(self):
        return self._enabled

    @enabled.setter
    def enabled(self, v):
        self._enabled = bool(v)

    @property
    def alert(self):
        return self._alert

    @alert.setter
    def alert(self, v):
        self._alert = bool(v)

    def lan_co(self, mo=True, bam=True):
        """Truyen `enabled`/`active` cua khung cha xuong MOI con, sau khi
        `draw()` chay xong.

        ⛔ Blender AND co cua moi tang cha, va co dat SAU khi da tao con van
        an vao con. Ta chep co luc tao con nen: con dat `enabled=True` de
        luon cha dang khoa (keo duoc `vein_variation` khi Veining dang mo),
        va nhan tao truoc dong `k.enabled = False` van sang. Do 25/09/2026,
        agent DP_Tiles."""
        mo = mo and self._active and self._enabled
        bam = bam and self._enabled
        for c in self._con:
            if isinstance(c, Khung):
                c.lan_co(mo, bam)
            elif isinstance(getattr(c, 'dl', None), dict):
                if not mo:
                    c.dl['mo'] = False
                if not bam:
                    c.dl['bam'] = False

    def _mo(self):
        """CO BAM DUOC khong. ⛔ CHI `enabled` MOI CHAN.

        Blender phan biet hai thu: `active=False` chi LAM MO (van keo, van go
        duoc), `enabled=False` moi thuc su khoa. Gop chung lam mot thi 26 cho
        `active` cua MatPro va 9 cho cua RAMchill chet han — nhung cho tac gia
        co y de "mo nhung van dung duoc". Do 23/09/2026."""
        return self._enabled

    def _dam(self):
        """Chu co duoc to DAY khong (mau, khong phai quyen bam)."""
        return self._active and self._enabled

    # ------------------------------------------------------ dung bo cuc
    def _them_khung(self, doc, align, hop=False, he_so=0.0):
        k = Khung(doc=doc, align=align, hop=hop, cha=self, he_so=he_so)
        self._con.append(k)
        return k

    def row(self, align=False, heading="", heading_ctxt="", translate=True):
        return self._them_khung(False, align)

    def column(self, align=False, heading="", heading_ctxt="", translate=True):
        return self._them_khung(True, align)

    def box(self):
        return self._them_khung(True, False, hop=True)

    def split(self, factor=0.0, align=False):
        """Con DAU TIEN chiem `factor` be ngang, con lai chia deu phan con
        thua — y nhu Blender. Chia deu het la ly do bang nhin khong thang
        hang voi panel N that."""
        return self._them_khung(False, align, he_so=float(factor or 0.0))

    def column_flow(self, columns=0, align=False):
        return self._luoi(columns, align, row_major=False)

    def grid_flow(self, row_major=False, columns=0, even_columns=False,
                  even_rows=False, align=False):
        return self._luoi(columns, align, row_major)

    def _luoi(self, columns, align, row_major):
        """`grid_flow(columns=n)` la MOT LUOI n cot, khong phai mot cot.

        ⛔ Ha no thanh `column()` thi 26 nut cua DP_Sketch xep 26 hang thay vi
        2 cot (ruot 862 px thay vi ~450), va 9 nut "Load into one slot" cua
        MatPro xep 9 hang. Do 23/09/2026."""
        n = int(columns or 0)
        if n <= 1:
            return self._them_khung(True, align)
        k = self._them_khung(True, align)
        k._so_cot = n
        k._doc_luoi = not row_major
        return k

    def panel(self, idname, default_closed=False):
        """Blender 4.1+ tra ve `(dau, than)`, va `than` la **None** khi bang
        dang gap. Addon nao cung phai hoi `if than:` truoc khi dung, nen tra
        None la dung hop dong — va la cach duy nhat de bang gap that su
        khong ton mot dong nao."""
        khoa = 'panel:%s' % idname
        gap = dang_gap(khoa, default_closed)
        dau = self._them_khung(False, False)
        dau._dau_bang = khoa
        if gap:
            return dau, None
        than = self._them_khung(True, False, hop=True)
        return dau, than


    def panel_prop(self, data, prop):
        return self.panel(prop)

    def menu_pie(self):
        return self._them_khung(True, False)

    def separator(self, factor=1.0, type='AUTO'):
        self._con.append(_Muc('cach', {'he_so': factor}))

    def separator_spacer(self):
        self._con.append(_Muc('cach', {'he_so': 1.0}))

    # ----------------------------------------------------------- noi dung
    def label(self, text="", text_ctxt="", translate=True, icon='NONE',
              icon_value=0):
        self._con.append(_Muc('nhan', {'chu': text, 'icon': icon,
                                       'anh': icon_value,
                                       'mo': self._dam(), 'bam': self._mo(),
                                       'do': self._alert}))

    def prop(self, data, property, text=None, text_ctxt="", translate=True,
             icon='NONE', expand=False, slider=False, toggle=-1,
             icon_only=False, event=False, full_event=False, emboss=True,
             index=-1, icon_value=0, invert_checkbox=False):
        # `expand=True` tren mot enum: Blender bay ra MOT HANG NUT, moi muc
        # mot nut, khong phai mot o xo-xuong.
        if expand:
            pr = _rna(data, property)
            if pr is not None and pr.type == 'ENUM':
                ds = muc_enum(data, property, pr)
                if ds:
                    # `use_property_split`: NHAN cot trai ("Colour"), hang nut
                    # cot phai — y panel N (agent DP Post vong 2: mat nhan,
                    # hai nut trai het be ngang).
                    nhan = pr.name if text is None else text
                    if self.use_property_split and nhan:
                        sp = self._them_khung(False, False, he_so=CHIA)
                        cot = sp._them_khung(True, True)
                        cot.alignment = 'RIGHT'
                        cot.label(text=nhan)
                        hang = sp._them_khung(False, True)
                    else:
                        hang = self._them_khung(False, True)
                    for ma, ten_m, _ic in ds:
                        hang.prop_enum(data, property, ma, text=ten_m)
                    return
        # ⛔ MANG SO (Vector/Euler/XYZ) KHONG CO index -> TACH TUNG THANH
        # PHAN, y Blender xep mot cot X/Y/Z. Truoc day ca vector di vao o so:
        # `abs(Vector)` nem TypeError giua `cat_vao`/`cat_ra` va o DP_Lighting
        # chet han toi khi mo lai Blender (`sun_direction`, agent 25/09/2026).
        if index == -1 and not icon_only:
            pr = _rna(data, property)
            n = getattr(pr, 'array_length', 0) if pr is not None else 0
            if (n and pr.type in ('FLOAT', 'INT')
                    and pr.subtype not in ('COLOR', 'COLOR_GAMMA')):
                cot = self._them_khung(True, True)
                nhan = pr.name if text is None else text
                if nhan:
                    cot.label(text=nhan + ":")
                truc = 'XYZW' if n <= 4 else ''
                for i in range(n):
                    cot.prop(data, property, index=i, slider=slider,
                             text=(truc[i] if truc else str(i)))
                return
        self._con.append(_Muc('o', {
            'dl': data, 'ten': property, 'chu': text, 'keo': slider,
            'mo_rong': expand, 'chi_icon': icon_only, 'chi_so': index,
            'anh': icon_value, 'chim': (emboss is False),
            'icon': icon, 'bat_tat': (toggle == 1),
            'la_bool': _la_bool(data, property),
            'chia': self.use_property_split and not icon_only,
            'mo': self._dam(), 'bam': self._mo(), 'do': self._alert}))

    def props_enum(self, data, property):
        self.prop(data, property, expand=True)

    def prop_enum(self, data, property, value, text=None, icon='NONE'):
        """MOT nut bat/tat cho MOT gia tri cua enum — khong phai mot o xo.

        ⛔ HA NO THANH `prop()` LA SAI HAI LAN. Mot: hai nut canh nhau bien
        thanh hai o xo-xuong giong het nhau, cung hien mot gia tri. Hai: mat
        luon chu addon truyen qua `text=` — DP_Lighting dua chu tieng Viet
        ("Tiếng Việt | English") vao dung cho nay. Do 23/09/2026."""
        nhan = text
        if nhan is None:
            for ma, ten_m, _ic in muc_enum(data, property, _rna(data, property)):
                if ma == value:
                    nhan = ten_m
                    break
            if nhan is None:
                nhan = value
        self._con.append(_Muc('nut_enum', {
            'dl': data, 'ten': property, 'gt': value, 'chu': nhan,
            'icon': icon, 'mo': self._dam(), 'bam': self._mo()}))

    def prop_search(self, data, property, search_data, search_property,
                    text=None, text_ctxt="", translate=True, icon='NONE',
                    results_are_suggestions=False):
        """O gõ kem DANH SACH de chon.

        ⛔ Ha no thanh o chu tron thi khach phai danh dung tung ky tu ten mot
        vat the / mot lop UV / mot anh — sai mot chu la ve vao hu khong.
        DP_Sketch "Draw Into", DP_MaxImporter 4 o "UV Channel", DP_Tiles
        "map_base" deu dung cai nay."""
        self._con.append(_Muc('tim', {
            'dl': data, 'ten': property, 'chu': text,
            'kho': search_data, 'kho_ten': search_property, 'icon': icon,
            'mo': self._dam(), 'bam': self._mo(), 'do': self._alert}))

    def operator(self, operator, text=None, text_ctxt="", translate=True,
                 icon='NONE', emboss=True, depress=False, icon_value=0):
        p = _OpProps()
        # ⛔ `text=""` KHAC `text=None`. None = "lay nhan cua operator";
        # chuoi rong = "khong chu, chi icon". Lan dau ta go chung lam mot, va
        # cap nut `+ / -` ben canh `template_list` cua MatPro bay ra thanh hai
        # nut dai "Add Material Slot" / "Remove Material Slot" — sai han bo cuc
        # panel N. Ducphan nhin ra ngay 23/09/2026.
        # `emboss=False` -> nut PHANG (mat/nhan ban/thung rac trong dong danh
        # sach); `alert` -> nen do (Apply scale cua MatPro, camera dang xem
        # cua DP_Optimize). Hai co nay truoc day bi bo (agent 25/09/2026).
        duoc, _ly = op_poll(operator)
        self._con.append(_Muc('nut', {'ma': operator, 'chu': text,
                                      'icon': icon, 'anh': icon_value,
                                      'nhan': depress,
                                      'chim': (emboss is False
                                               or self._la_menu),
                                      'trai': self._la_menu,
                                      'do': self._alert,
                                      'props': p,
                                      # poll False: MO nhung VAN BAM duoc
                                      # (bam thi `_chay_op` noi ly do).
                                      'mo': self._dam() and duoc,
                                      'bam': self._mo()}))
        return p

    def operator_menu_enum(self, operator, property, text=None, icon='NONE'):
        return self.operator(operator, text=text, icon=icon)

    def menu(self, menu, text=None, text_ctxt="", translate=True,
             icon='NONE', icon_value=0):
        """Nut xo ra mot bang. Bam thi chay `draw()` cua chinh lop Menu do
        vao mot `Khung` khac roi bay len — lai dung cai meo cu."""
        lop = getattr(bpy.types, menu, None)
        nhan = text
        if nhan is None:
            nhan = getattr(lop, 'bl_label', menu) if lop else menu
        self._con.append(_Muc('menu', {'lop': lop, 'ma': menu, 'chu': nhan,
                                       'nc': self.ngu_canh(),
                                       'mo': self._dam(), 'bam': self._mo()}))

    def popover(self, panel, text=None, icon='NONE', icon_value=0):
        """Giong `menu` nhung ruot la mot Panel."""
        lop = getattr(bpy.types, panel, None)
        nhan = text
        if nhan is None:
            nhan = getattr(lop, 'bl_label', panel) if lop else panel
        self._con.append(_Muc('menu', {'lop': lop, 'ma': panel, 'chu': nhan,
                                       'panel': True, 'nc': self.ngu_canh(),
                                       'mo': self._dam(), 'bam': self._mo()}))

    def template_list(self, listtype_name, list_id, dataptr, propname,
                      active_dataptr, active_propname, item_dyntip_propname="",
                      rows=5, maxrows=0, type='DEFAULT', columns=9,
                      sort_reverse=False, sort_lock=False):
        """Danh sach cuon duoc. Tung dong do chinh `UIList.draw_item()` cua
        addon ve — cung cai meo dua `layout` gia nhu voi `Panel.draw()`.

        ⛔ `filter_items` DA LAM — xem `_loc_danh_sach`. (Chu thich cu o day
        ghi "CHUA LAM" suot mot thoi gian sau khi da lam xong; nguoi doc sau de
        tuong chua co ma di lam lai.)

        ⛔ TON TRONG `maxrows`. Blender lay `rows` lam SAN va tu cao len toi
        `maxrows` khi danh sach dai ra. Truoc day o day chot cung `rows`, nen
        "Cameras in Scene" cua DP_Camera (rows=3) mai mai cao 3 hang du canh co
        20 camera. Ducphan 23/09/2026: *"o camera in scene va cac o chua nhieu
        hang theo noi dung cua scene co the dai hon can con lan"*.
        """
        # ⛔ DEM SAU KHI LOC. `CAMERA_UL_list` tro vao `scene.objects` roi
        # tu loc ra camera bang `filter_items`. Dem ca cho thi mot ban ve noi
        # that vai tram object nao cung cham tran: hop danh sach cao 12 hang
        # (366 px) trong khi chi co 3 camera — 270 px TRONG roi moi toi nut
        # ke tiep. Do 23/09/2026.
        # ⛔ DEM SAU KHI LOC. `CAMERA_UL_list` tro vao `scene.objects` roi
        # tu loc ra camera bang `filter_items`. Dem ca cho thi mot ban ve noi
        # that vai tram object nao cung cham tran: hop danh sach cao 12 hang
        # (366 px) trong khi chi co 3 camera — 270 px TRONG roi moi toi nut
        # ke tiep. Do 23/09/2026.
        try:
            tho = list(getattr(dataptr, propname))
        except Exception:                                    # noqa: BLE001
            tho = []
        try:
            _lop = getattr(bpy.types, listtype_name, None)
            tho, _bo = _loc_danh_sach(_lop, dataptr, propname, tho)
        except Exception:                                    # noqa: BLE001
            pass
        so_muc = len(tho)
        san = max(1, int(rows))
        tran = max(san, int(maxrows) if maxrows else san + 7)
        self._con.append(_Muc('danh_sach', {
            'lop': listtype_name, 'dl': dataptr, 'ten': propname,
            'dl_hd': active_dataptr, 'ten_hd': active_propname,
            'hang': max(san, min(tran, so_muc)), 'mo': self._dam(),
            'bam': self._mo(),
            'khoa': '%s|%s|%s' % (listtype_name, propname, active_propname)}))

    def template_icon_view(self, data, property, show_labels=False,
                           scale=6.0, scale_popup=5.0):
        """O xem to cua muc enum dang chon; bam thi xo ra luoi anh."""
        self._con.append(_Muc('anh_chon', {
            'dl': data, 'ten': property, 'nhan': show_labels,
            'ti_le': max(1.0, scale), 'ti_le_xo': max(1.0, scale_popup),
            'mo': self._dam(), 'bam': self._mo()}))

    def template_icon(self, icon_value, scale=1.0):
        self._con.append(_Muc('icon', {'gt': icon_value,
                                       'ti_le': max(1.0, scale)}))

    def template_ID(self, data, property, new="", open="", unlink="",
                    filter='ALL', live_icon=False, text=None):
        """O chon mot khoi du lieu (vat lieu, anh, the gioi...).

        Blender ve: [nut xo danh sach] [o ten sua duoc] [nut go lien ket].
        Ta ve dung ba phan do — day la o quan trong nhat cua bang MatPro, bo
        no thanh vet cam la khach khong doi duoc vat lieu."""
        self._con.append(_Muc('id', {'dl': data, 'ten': property,
                                     'go': unlink, 'moi': new,
                                     'mo': self._dam(), 'bam': self._mo()}))

    def template_curve_mapping(self, data, property, type='NONE',
                               levels=False, brush=False, use_negative_slope=False,
                               show_tone=False):
        """Do thi duong cong (Tone Curve, Falloff...).

        ⛔ DAY LA CONG CU CHU KY CUA HAI ADDON. DP-PostProcessing dung no lam
        Tone Curve 4 kenh C/R/G/B; DP_MaxImporter dung cho Falloff vai/nhung
        (Ducphan chot 30/07: "rat quan trong cho vat lieu vai"). De no thanh
        mot vet cam la bo mat chuc nang chinh."""
        self._con.append(_Muc('cong', {
            'dl': data, 'ten': property, 'kieu': type,
            'mo': self._dam(), 'bam': self._mo()}))
        # O X / Y cua DIEM DANG CHON, y panel N (agent DP Post 25/09/2026:
        # khong co cach go chinh xac toa do diem).
        try:
            cm = getattr(data, property)
            cong = list(cm.curves)
            k = min(KENH_CONG.get(_khoa_cong(data, property), 0),
                    len(cong) - 1)
            tt = _thu_tu_kenh(len(cong))
            cv = cong[tt[k] if k < len(tt) and tt[k] < len(cong) else k]
            chon = [p for p in cv.points if p.select]
            if len(chon) == 1:
                hang = self.row(align=True)
                hang.prop(chon[0], 'location', index=0, text="X")
                hang.prop(chon[0], 'location', index=1, text="Y")
        except Exception:                                    # noqa: BLE001
            pass

    def template_color_ramp(self, data, property, expand=False):
        """Dai mau: thanh mau + cac moc keo duoc."""
        self._con.append(_Muc('dai_mau', {
            'dl': data, 'ten': property, 'xoe': bool(expand),
            'mo': self._dam(), 'bam': self._mo()}))

    def template_preview(self, *a, **kw):
        self._chua_lam('template_preview', cao=6)

    def template_node_view(self, *a, **kw):
        self._chua_lam('template_node_view', cao=4)

    # Nhung ham KHONG ve gi ca. Phai khai ro, neu khong `__getattr__` nuot
    # roi ve mot vet cam "chua lam" ngay giua dong — `MATERIAL_UL_matslots`
    # goi `context_pointer_set` HAI lan cho moi dong danh sach.
    def context_pointer_set(self, name, data):
        """⛔ KHONG DUOC LA HAM RONG. Addon dat mot vat vao `context` roi bay
        ra mot menu doc lai no:

            split.context_pointer_set("dp_sky_node", sky)
            split.menu("LIGHTING_MT_kieu_troi")

        Ham rong thi `draw()` cua menu do hoi `context.dp_sky_node` -> khong
        co -> `return` ngay -> menu XO RA RONG, khach khong doi duoc kieu troi.
        Do 23/09/2026 tren DP_Lighting."""
        self._ngu_canh[name] = data
        return None

    def context_string_set(self, name, value):
        self._ngu_canh[name] = value
        return None

    def ngu_canh(self):
        """Gom moi thu da `context_pointer_set` tu goc cay xuong toi day."""
        ra = {}
        k = self
        chuoi = []
        while k is not None:
            chuoi.append(k)
            k = k._cha
        for k in reversed(chuoi):
            ra.update(k._ngu_canh)
        return ra

    def prop_decorator(self, *a, **kw):
        return None

    def template_header(self, *a, **kw):
        return None

    def template_running_jobs(self, *a, **kw):
        return None

    def template_reports_banner(self, *a, **kw):
        return None

    def _chua_lam(self, ten, cao=1.0):
        self._con.append(_Muc('chua_lam', {'chu': ten, 'so_hang': cao}))

    def __getattr__(self, ten):
        """Ham nao cua UILayout chua co o day thi KHONG nem loi — tra ve mot
        ham nuot moi doi so. Thieu mot widget khong duoc lam sap ca bang."""
        if ten.startswith('_'):
            raise AttributeError(ten)

        def _nuot(*a, **kw):
            self._chua_lam(ten)
            return None
        return _nuot

    # --------------------------------------------------------------- do
    def rong_tu_nhien(self, s):
        """0 = co gian lay het cho; >0 = chi doi dung bay nhieu.

        ⛔ BLENDER KHONG CHIA DEU MOI HANG. Mot cot chi chua nut ICON thi no
        chi rong bang mot o vuong, phan con lai de cho `template_list`. Chia
        deu thi cap nut `+ / -` cua MatPro an nua hang — sai han panel N.
        """
        if self.ui_units_x:
            return self.ui_units_x * DON_VI * s
        if not self._con:
            return 0.0
        rong = 0.0
        for c in self._con:
            if isinstance(c, Khung):
                w = c.rong_tu_nhien(s)
                if not w:
                    return 0.0
            elif c.kieu == 'cach':
                continue
            else:
                w = _rong_rieng(c, s)
                if not w:
                    return 0.0
            rong = max(rong, w) if self._doc else rong + w
        return rong

    def _chia_ngang(self, trong, s):
        """Be ngang cho tung con, theo dung thu tu uu tien cua Blender:
        1) con nao dat `ui_units_x` thi lay dung bay nhieu, khong co ban;
        2) `split(factor)` cat `factor` phan con lai cho con DAU;
        3) so con lai chia deu."""
        n = len(self._con)
        if not n:
            return []
        khe = 0.0 if self._align else KHE * s
        du = trong - khe * (n - 1)
        ra = [None] * n
        tu_do = []
        for i, c in enumerate(self._con):
            u = _rong_rieng(c, s)
            if u > 0.0 and u < du:
                ra[i] = u
                du -= u
            else:
                tu_do.append(i)
        if self._he_so > 0.0 and tu_do:
            i0 = tu_do.pop(0)
            ra[i0] = max(0.0, du * self._he_so)
            du -= ra[i0]
        if tu_do:
            moi = du / len(tu_do)
            for i in tu_do:
                ra[i] = max(0.0, moi)
        return [x if x is not None else 0.0 for x in ra]

    def _lui_can(self, rongs, trong, s):
        """`alignment` khac 'EXPAND' thi don cac con ve mot phia.

        Tra ve (do lui, danh sach be ngang moi). Blender khong gian con ra khi
        can le — vi the mot dong "No destination yet" dat `alignment='RIGHT'`
        moi that su nam ben phai."""
        can = getattr(self, 'alignment', 'EXPAND')
        if can == 'EXPAND' or not rongs:
            return 0.0, rongs
        tn = []
        for c, w in zip(self._con, rongs):
            u = _rong_rieng(c, s)
            # Be ngang TU NHIEN, khong bop theo phan chia deu — con cho thi
            # nhan dai van hien du (Blender can le theo be ngang that).
            tn.append(u if u > 0 else _rong_chu(c, s))
        tong = sum(tn) + (0.0 if self._align else KHE * s * (len(tn) - 1))
        if tong > trong:
            tn = [min(a, b) for a, b in zip(tn, rongs)]
            tong = sum(tn) + (0.0 if self._align else
                              KHE * s * (len(tn) - 1))
        thua = max(0.0, trong - tong)
        if thua <= 0.5:
            return 0.0, rongs
        if can == 'RIGHT':
            return thua, tn
        if can == 'CENTER':
            return thua / 2.0, tn
        return 0.0, tn

    def _xep_luoi(self):
        """Gom con thanh tung hang truoc khi do — goi mot lan, truoc `do()`."""
        if self._so_cot <= 1 or getattr(self, '_da_xep', False):
            return
        self._da_xep = True
        con = self._con
        self._con = []
        n = self._so_cot
        for i in range(0, len(con), n):
            hang = Khung(doc=False, align=self._align, cha=self)
            hang._con = con[i:i + n]
            for c in hang._con:
                if isinstance(c, Khung):
                    c._cha = hang
            # Hang cuoi thieu o: chen o RONG cho du `n` — nut le giu be ngang
            # MOT o, y Blender (agent DP_Tiles "ARM / ORM", DP_Sketch "Check
            # Solid" bi keo kin hang, 25/09/2026).
            # Chi MOT hang (it o hon so cot) thi khong chen: Blender tu giam
            # so cot, nut duy nhat rong het hang (agent DP_Sketch vong 3:
            # "Select").
            while len(con) > n and len(hang._con) < n:
                hang._con.append(Khung(doc=True, align=True, cha=hang))
            self._con.append(hang)

    def do(self, rong, s):
        """Tinh chieu cao. `rong` la be ngang duoc cap, `s` la ui_scale."""
        self._xep_luoi()
        self.rong = rong
        khe = KHE * s
        if self._hop:
            trong = rong - 2 * LE_HOP * s
        else:
            trong = rong

        if self._doc:
            self._rongs = [trong] * len(self._con)
            tong = 0.0
            for c in self._con:
                h = _do_mot(c, trong, s, self.scale_y)
                tong += h + (0.0 if self._align else khe)
            if self._con and not self._align:
                tong -= khe
            self.cao = max(0.0, tong)
        else:
            self._rongs = self._chia_ngang(trong, s)
            cao = 0.0
            for c, w in zip(self._con, self._rongs):
                cao = max(cao, _do_mot(c, w, s, self.scale_y))
            self.cao = cao
        if self._hop:
            self.cao += 2 * LE_HOP * s
        return self.cao

    # -------------------------------------------------------------- ve
    def ve(self, x, y_tren, s, vung):
        """Ve tu goc TREN-TRAI. `vung` la danh sach o bam se duoc nap them."""
        self.x, self.y = x, y_tren
        khe = KHE * s
        if self._hop:
            V.hop(x, y_tren - self.cao, self.rong, self.cao, M.hop,
                  BO_GOC * s)
            V.vien(x, y_tren - self.cao, self.rong, self.cao, M.hop_vien, 1.0)
            x += LE_HOP * s
            y_tren -= LE_HOP * s
            trong = self.rong - 2 * LE_HOP * s
        else:
            trong = self.rong

        if self._doc:
            y = y_tren
            # ⛔ BO QUA CON NAM HAN NGOAI VUNG CAT. Scissor chi cat pixel,
            # `blf.draw` van chay: ruot DP_Sketch cao 3.397 px trong o 1.271
            # px ve 220 chuoi moi luot, chi ~80 nhin thay (agent vong 2). O
            # bam cua chung vo dung (`_tim` loai o ngoai vung cat).
            cat = _NGAN_CAT[-1] if _NGAN_CAT else None
            for c in self._con:
                hc = _cao_cua(c)
                if cat is None or not (y - hc > cat[1] + cat[3]
                                       or y < cat[1]):
                    _ve_mot(c, x, y, trong, s, vung)
                y -= hc + (0.0 if self._align else khe)
        else:
            rongs = self._rongs or self._chia_ngang(trong, s)
            lui, rongs = self._lui_can(rongs, trong, s)
            cx = x + lui
            for c, w in zip(self._con, rongs):
                _ve_mot(c, cx, y_tren, w, s, vung)
                cx += w + (0.0 if self._align else khe)


# ===================================================================== la
def _rong_chu(c, s):
    """Be ngang tu nhien cua mot o la — do theo chu no mang."""
    if isinstance(c, Khung):
        return 0.0
    co = CO_CHU * s
    t = ''
    if c.kieu in ('nhan', 'nut', 'nut_enum', 'menu'):
        t = c.dl.get('chu') or ''
        # Icon cung chiem cho — quen no la "No destination yet" bi cat
        # (agent DP Post vong 2).
        b = icon_chu(c.dl.get('icon')) or icon_la(c.dl.get('icon'))
        if b:
            t = (b + " " + t) if t else b
    if not t:
        return c.rong or 0.0
    return V.do_chu(t, co)[0] + 16 * s


def _rong_rieng(c, s):
    """Be ngang RIENG cua mot o la. 0 = co gian lay het cho con lai.

    ⛔ `template_icon(scale=n)` LA MOT O VUONG CANH n DON VI ICON, khong phai
    mot nut chi-icon rong 27 px. Bieu do Histogram cua DP-PostProcessing tu
    tinh `scale` theo `context.region.width` roi giao ca buc anh cho o nay.
    Xep no vao loai "nut chi-icon" thi no bi chot cung 40,5 px: do 23/09/2026
    tren cua so that — anh 40,5 px nam mot goc, ben canh la 283 px TRONG, con
    panel Histogram van chiem tron 283 px chieu cao. Bieu do la thu duy nhat
    cho biet anh chay sang hay bet den; bop the la bo han no.
    Blender dung `ICON_DEFAULT_HEIGHT_SCALE = 16 * ui_scale`.
    """
    if isinstance(c, Khung):
        return c.rong_tu_nhien(s)
    if c.kieu == 'icon':
        # `uiTemplateIcon`: UI_UNIT_X (20) * scale — KHONG phai 16. Histogram
        # cua DP Post hep 235/325 px vi cho nay (agent vong 2).
        return 20.0 * s * float(c.dl.get('ti_le') or 1.0)
    return DON_VI * s * 1.35 if _chi_icon(c) else 0.0


def _chi_icon(c):
    """O la nay co phai "chi mot cai icon" khong."""
    if isinstance(c, Khung):
        return False
    if c.kieu == 'nut':
        return c.dl.get('chu') == ""
    if c.kieu == 'nhan':
        # `label(text="", icon=...)` — dau ✓ cua dong Gallery DP Post phai
        # nho gon o mep phai, khong chia deu nua dong (agent vong 2).
        return (c.dl.get('chu') or '') == '' and \
            (c.dl.get('icon') or 'NONE') not in ('NONE', 'BLANK1')
    if c.kieu == 'o':
        # ⛔ CHI O TICH MOI LA "CHI-ICON". `icon_only=True` tren mot o tro toi
        # khoi du lieu hay mot o chon KHONG co nghia la no chi rong 27 px —
        # Blender van cho no gan tron hang. Go chung lam mot thi o "Concrete -
        # Exposed" cua MatPro bop con 3 px va o ten khe con 17 px. Do
        # 23/09/2026 (agent doc MatPro bat duoc ngay trong dot va).
        if not c.dl.get('la_bool'):
            return False
        if c.dl.get('chi_icon'):
            return True
        if c.dl.get('chu') != "":
            return False
        # ⛔ `text=""` TREN MOT O CHU KHONG PHAI LA CHI-ICON. `text=""` nghia la
        # "khong ve nhan"; voi o tich thi con lai dung mot o vuong nho, nhung
        # voi O NHAP TEN (`prop(ma, "name", text="")` — moi dong cua
        # `MATERIAL_UL_matslots` va `CAMERA_UL_list`) thi o van phai rong het
        # dong. Go chung lam mot: cot ten bop con 27 px, va do phu bai do tut
        # 30 -> 9. Do 23/09/2026.
        return c.dl.get('la_bool') or (c.dl.get('icon') or 'NONE') != 'NONE'
    if c.kieu == 'icon':
        return True
    return False


def _cao_cua(c):
    return c.cao


def _do_mot(c, rong, s, sy=1.0):
    """`sy` la `scale_y` cua KHUNG CHA — Blender keo cao tung o la, con khung
    con tu mang `scale_y` cua rieng no."""
    if isinstance(c, Khung):
        return c.do(rong, s)
    c.rong = rong
    if c.kieu == 'cach':
        c.cao = HANG * s * 0.35 * c.dl.get('he_so', 1.0)
    elif c.kieu == 'chua_lam':
        c.cao = HANG * s * c.dl.get('so_hang', 1.0)
    elif c.kieu == 'danh_sach':
        # Blender do `rows` bang SO HANG, cong hai vien hop.
        c.cao = HANG * s * c.dl['hang'] + 4 * s
    elif c.kieu in ('id', 'nut_enum', 'tim'):
        c.cao = HANG * s
    elif c.kieu == 'cong':
        # 8 hang: 1 hang the kenh + 7 hang do thi (Blender cho ~8 don vi)
        c.cao = HANG * s * 8.0
    elif c.kieu == 'dai_mau':
        # 1 hang nut + 1 thanh mau + 1 hang chinh moc
        c.cao = HANG * s * (4.0 if c.dl.get('xoe') else 3.2)
    elif c.kieu == 'anh_chon':
        # `scale` cua Blender cung tinh bang so hang — `ban_ve_gia.py` cua
        # MatPro da chot: `template_icon_view(scale=5)` cao NAM hang.
        c.cao = HANG * s * c.dl['ti_le']
    elif c.kieu == 'icon':
        # ⛔ `template_icon` dung don vi ICON (16 * ui_scale), khong phai don
        # vi HANG (20). Xem `_rong_rieng()`.
        c.cao = 20.0 * s * c.dl['ti_le']
    else:
        c.cao = HANG * s
    if sy and sy != 1.0:
        c.cao *= sy
    return c.cao


def _ve_mot(c, x, y_tren, rong, s, vung):
    if isinstance(c, Khung):
        if c._dau_bang:
            _ve_nen_dau_bang(c, x, y_tren, rong, s, vung)
            # ⛔ THUT LE THI PHAI CHIA LAI BE NGANG. `do()` da chia cho cac con
            # theo be ngang DAY DU; thut vao 16 px roi ve ma khong chia lai thi
            # con CUOI CUNG tran ra ngoai vung cat dung 16 px — do 23/09/2026:
            # nut `dplic.toolbox_*` o dau bang cua 5 addon nam ngoai vung cat,
            # nhin thay ma bam khong trung.
            lui = 16 * s
            c.rong = rong - lui
            c._rongs = c._chia_ngang(c.rong, s)
            TRONG_DAU[0] = True
            try:
                c.ve(x + lui, y_tren, s, vung)
            finally:
                TRONG_DAU[0] = False      # phai tra lai du co nem loi
            return
        c.rong = rong
        c.ve(x, y_tren, s, vung)
        return
    c.x, c.y, c.rong = x, y_tren - c.cao, rong
    if c.kieu == 'nhan':
        _ve_nhan(c, s)
    elif c.kieu == 'nut':
        _ve_nut(c, s, vung)
    elif c.kieu == 'nut_enum':
        _ve_nut_enum(c, s, vung)
    elif c.kieu == 'o':
        _ve_o(c, s, vung)
    elif c.kieu == 'chua_lam':
        _ve_chua_lam(c, s, vung)
    elif c.kieu == 'danh_sach':
        _ve_danh_sach(c, s, vung)
    elif c.kieu == 'anh_chon':
        _ve_anh_chon(c, s, vung)
    elif c.kieu == 'icon':
        _ve_icon(c, s)
    elif c.kieu == 'menu':
        _ve_menu_nut(c, s, vung)
    elif c.kieu == 'id':
        _ve_id(c, s, vung)
    elif c.kieu == 'cong':
        _ve_cong(c, s, vung)
    elif c.kieu == 'dai_mau':
        _ve_dai_mau(c, s, vung)
    elif c.kieu == 'tim':
        _ve_tim(c, s, vung)


def _tron_nhin(a, b, t):
    """Tron hai mau cua bang TRONG KHONG GIAN NHIN THAY (sRGB). Bang da
    nang bu gamma, nhan thang `x * 0.62` la toi gap doi: nut bi khoa ra nen
    27, toi hon ca than the 56 — nhu mot cai lo (agent MatPro vong 3, panel N
    73 = giua nen 61 va nut 84)."""
    kq = []
    for i in range(3):
        va, vb = V.xuong_linear(a[i]), V.xuong_linear(b[i])
        kq.append(V.len_srgb(va * (1.0 - t) + vb * t))
    return tuple(kq) + (1.0,)


def _mau_chu(c):
    if c.dl.get('do'):
        return M.do
    return M.chu if c.dl.get('mo', True) else M.chu_mo


def _ve_nhan(c, s):
    co = CO_CHU * s
    lui = 2 * s
    tex = V.texture(c.dl.get('anh') or 0)
    if tex is not None:
        canh = c.cao - 3 * s
        V.anh(c.x + 1 * s, c.y + 1.5 * s, canh, canh, tex)
        lui = canh + 4 * s
    chu = c.dl['chu'] or ''
    bieu = icon_chu(c.dl.get('icon')) or icon_la(c.dl.get('icon'))
    if bieu:
        chu = (bieu + " " + chu) if chu else bieu
    elif c.dl.get('icon') == 'BLANK1':
        # BLANK1 = CHUA CHO bang mot icon, khong ve gi — dong thut vao y
        # panel N (agent DP_Sketch "L · QS · Ctrl Shift S" 25/09/2026).
        lui += CO_CHU * s * 1.25
    # ⛔ TRONG DAU BANG THI BOI DAM + doi mau sang. Xem `TRONG_DAU`.
    trong_dau = TRONG_DAU[0]
    V.chu_cat(chu, c.x + lui, c.y + (c.cao - co) / 2 + 1 * s,
              c.rong - lui - 2 * s, co,
              M.chu_dau if trong_dau else _mau_chu(c),
              dam=trong_dau)


def _ve_chua_lam(c, s, vung=None):
    V.hop(c.x, c.y, c.rong, c.cao, CHUA_LAM, BO_GOC * s)
    co = CO_CHU * s * 0.9
    V.chu_cat("⌁ " + c.dl['chu'], c.x + 4 * s,
              c.y + c.cao - co - 3 * s, c.rong - 8 * s, co, M.cam)
    # Nap ca mot o bam "khong lam gi" — de bai do dem duoc con bao nhieu cho
    # chua lam, va ke ten chung ra. Vet cam tren man hinh chi noi voi NGUOI;
    # cai nay noi voi MAY.
    if vung is not None:
        nap(vung, {'x': c.x, 'y': c.y, 'w': c.rong, 'h': c.cao,
                   'kieu': 'chua_lam', 'chu': c.dl['chu']})


def _ve_nut(c, s, vung):
    mo = c.dl.get('mo', True)
    tro = mo and tro_trong(c.x, c.y, c.rong, c.cao)
    nen = M.nut_nhan if c.dl.get('nhan') else (M.nut_tro if tro else M.nut)
    if c.dl.get('do'):
        nen = tuple(x * 0.75 for x in M.do[:3]) + (1.0,)
    if not mo:
        nen = _tron_nhin(nen, M.nen_panel, 0.5)
    # ⛔ PHANG: nut KHONG co vien va KHONG co vet sang mep tren.
    #   Ducphan 23/09/2026: *"giao dien dang flat nhe nhang toi gian, vien nhe
    #   thoi, khong co noi khoi nhu the nay trong que vai"*.
    #   Nut doc ra la nut nho SAC NEN khac voi than bang, khong nho vien va
    #   khong nho beveled edge — dung loi cac bo giao dien phang.
    # `emboss=False`: khong nen, chi hien nen khi re chuot (y panel N).
    if not c.dl.get('chim') or tro or c.dl.get('nhan'):
        V.hop(c.x, c.y, c.rong, c.cao, nen, BO_GOC * s)
    # ⛔ NUT MANG `icon_value` PHAI VE RA TAM ANH. O map cua DP_MaxMat la mot
    # nut operator mang `icon_value=img.preview.icon_id`; khong ve thi kenh DA
    # CO map trong rong hon kenh chua co (kenh trong con co ky tu ▦). Khach
    # nhin bang 10 kenh khong biet kenh nao da gan gi. Do 23/09/2026.
    _tex = V.texture(c.dl.get('anh') or 0)
    if _tex is not None:
        _canh = max(4.0, c.cao - 4 * s)
        V.anh(c.x + 2 * s, c.y + 2 * s, _canh, _canh, _tex)
        if not (c.dl.get('chu') or ''):
            if c.dl.get('bam', True):
                nap(vung, {'x': c.x, 'y': c.y, 'w': c.rong, 'h': c.cao,
                           'kieu': 'nut', 'ma': c.dl['ma'],
                           'props': c.dl['props']._o})
            return
    chu = c.dl.get('chu')
    if chu is None:
        chu = _nhan_operator(c.dl['ma'])
    bieu = icon_chu(c.dl.get('icon'))
    co = CO_CHU * s
    if not chu:
        chu = bieu or icon_la(c.dl.get('icon'))   # chi icon, KHONG lay ten op
    elif bieu and not c.dl.get('trai') and c.rong > 60 * s:
        # ⛔ NUT CO CHU + ICON: icon SAT MEP TRAI, chu giua phan con lai — y
        # panel N (agent DP_Tiles vong 2 so anh "Pick Surface"). Truoc day
        # icon dinh sat chu o giua.
        mau = M.chu_nut if mo else M.chu_mo
        y = c.y + (c.cao - co) / 2 + 1 * s
        V.chu(bieu, c.x + 6 * s, y, co, mau)
        w_ic = 20 * s
        V.chu_giua(chu, c.x + w_ic, y, c.rong - w_ic - 4 * s, co, mau,
                   dam=True)
        if c.dl.get('bam', True):
            nap(vung, {'x': c.x, 'y': c.y, 'w': c.rong, 'h': c.cao,
                       'kieu': 'nut', 'ma': c.dl['ma'],
                       'props': c.dl['props']._o})
        return
    elif bieu:
        chu = bieu + " " + chu
    if c.dl.get('trai'):
        V.chu_cat(chu, c.x + 8 * s, c.y + (c.cao - co) / 2 + 1 * s,
                  c.rong - 12 * s, co, M.chu if mo else M.chu_mo)
    else:
        V.chu_giua(chu, c.x, c.y + (c.cao - co) / 2 + 1 * s, c.rong, co,
                   M.chu_nut if mo else M.chu_mo, dam=True)
    if c.dl.get('bam', True):
        nap(vung, {'x': c.x, 'y': c.y, 'w': c.rong, 'h': c.cao,
                     'kieu': 'nut', 'ma': c.dl['ma'],
                     'props': c.dl['props']._o})


# ⛔ KHONG LAY DUOC ICON GOC CUA BLENDER. Bo icon cua Blender nam trong mot
# tam atlas cua phan C, Python khong hoi ra pixel duoc (chi `icon_value` cua
# `bpy.utils.previews` la lay duoc — xem `ve.texture`). Nen nhung icon hay gap
# nhat thi ve bang MOT KY TU; cai nao khong co trong bang thi thoi, de trong,
# con hon bay ra mot o vuong rac.
#
# Bang nay dung tu dem THAT: 41 ERROR · 29 INFO · 17 COPYDOWN · 17 CHECKMARK
# · 12 TRASH · 11 ADD ... tren 6 addon (23/09/2026).
ICON_CHU = {
    'NONE': '', 'BLANK1': '',
    'ERROR': '⚠', 'CANCEL': '⨂', 'INFO': 'ⓘ', 'QUESTION': '?',
    'CHECKMARK': '✓', 'X': '✕', 'PANEL_CLOSE': '✕',
    'ADD': '+', 'REMOVE': '–', 'PLUS': '+',
    'TRASH': '🗑', 'DUPLICATE': '⧉', 'COPYDOWN': '⎘', 'PASTEDOWN': '⎗',
    'FILE_REFRESH': '⟳', 'LOOP_BACK': '↺', 'LOOP_FORWARDS': '↻',
    'LOCKED': '🔒', 'UNLOCKED': '🔓',
    'LINKED': '🔗', 'UNLINKED': '⛓',
    'FAKE_USER_ON': '🛡', 'FAKE_USER_OFF': '⛉',
    'TRIA_RIGHT': '▸', 'TRIA_DOWN': '▾', 'TRIA_LEFT': '◂', 'TRIA_UP': '▴',
    'DISCLOSURE_TRI_DOWN': '▾', 'DISCLOSURE_TRI_RIGHT': '▸',
    'VIEWZOOM': '🔍', 'ZOOM_IN': '⊕', 'ZOOM_OUT': '⊖',
    'FILEBROWSER': '🗀', 'FILE_FOLDER': '🗀', 'FILE_IMAGE': '🖾',
    'IMAGE_DATA': '🖼', 'IMAGE': '🖽', 'TEXTURE': '▦', 'MATERIAL': '◍',
    'CAMERA_DATA': '🎥', 'OUTLINER_OB_CAMERA': '🎥',
    'LIGHT_SUN': '☀', 'LIGHT_AREA': '▭', 'LIGHT_POINT': '◌', 'LIGHT': '☀',
    'OUTLINER_OB_MESH': '△', 'MESH_DATA': '△', 'MESH_CUBE': '▣',
    'OUTLINER_COLLECTION': '▤', 'COLLECTION_NEW': '🗃',
    'WORLD': '🌐', 'WORLD_DATA': '🌐', 'SCENE_DATA': '🎬',
    'TIME': '🕑', 'PREFERENCES': '⚙', 'SETTINGS': '⚙', 'TOOL_SETTINGS': '🛠',
    'RENDER_STILL': '📷', 'RENDER_ANIMATION': '🎞', 'OUTPUT': '📤',
    'SHADING_RENDERED': '◍', 'SHADING_SOLID': '◉', 'SHADING_TEXTURE': '◎',
    'GROUP_UVS': '▩', 'GROUP_VERTEX': '⁘', 'NODETREE': '⦿', 'NODE': '⬡', 'KEYINGSET': '⌨', 'WINDOW': '🗔',
    'RESTRICT_SELECT_OFF': '➤', 'RESTRICT_SELECT_ON': '⊘',
    'HIDE_OFF': '👁', 'HIDE_ON': '🚫', 'EXPORT': '⤴', 'IMPORT': '📥',
    'MOD_ARRAY': '▥', 'MOD_UVPROJECT': '▩', 'UV': '▩',
    'PIVOT_CURSOR': '✛', 'COLOR': '◼', 'BRUSH_DATA': '✎',
    # ⛔ NAM NUT CUA DP_Sketch TRUOC DAY TRO CHU. Do 23/09/2026: trong luoi
    # Draw/Modify, "Rectangle ▬" va "Circle ◯" co ky hieu con "Line",
    # "Arc", "Move", "Offset", "Check Solid" thi khong — nhin ra hai loai nut
    # khac nhau trong khi chung cung mot loai.
    'IPO_LINEAR': '╱', 'SPHERECURVE': '◜', 'ORIENTATION_VIEW': '⤧',
    'MOD_OFFSET': '⇥', 'ZOOM_ALL': '⌕',
    'FULLSCREEN_EXIT': '⤡', 'FULLSCREEN_ENTER': '⤢',
    'PLAY': '▶', 'PAUSE': '⏸', 'REC': '⏺', 'SORTALPHA': '⇅',
    'GRAPH': '📈', 'CON_SIZELIKE': '⇲', 'CON_LOCLIKE': '⌖',
    'FORWARD': '▶', 'BACK': '◀', 'DOT': '·',
    # bo sung tu dot ra soat 23/09/2026 (agent doc DP_SU Sync)
    'MOD_DECIM': '⊿', 'FILE_TICK': '💾', 'FILE_3D': '🧊',
    'DRIVER_DISTANCE': '↔', 'MOD_SMOOTH': '◡', 'MOD_SUBSURF': '◍',
    'FILE_NEW': '🗋', 'FILE_TEXT': '🗒', 'FILE_BLEND': '🅑',
    'SNAP_ON': '🧲', 'SNAP_OFF': '⊗', 'CONSOLE': '⌨',
    # bo sung dot hai (agent doc DP_Camera, DP_Sketch, DP_MaxImporter)
    'RESTRICT_VIEW_ON': '◡', 'RESTRICT_VIEW_OFF': '👁',
    'RESTRICT_RENDER_ON': '⊙', 'RESTRICT_RENDER_OFF': '📷',
    'WORKSPACE': '🗂', 'MESH_CIRCLE': '◯', 'MESH_PLANE': '▬',
    'MOD_BEVEL': '◣', 'MOD_LENGTH': '⟷', 'MOD_MESHDEFORM': '◈',
    'MOD_SCREW': '➰', 'MOD_MIRROR': '⇄', 'MOD_HUE_SATURATION': '◐',
    'MOD_NORMALEDIT': '⊥', 'PARTICLES': '⁂', 'SMALL_CAPS': 'T',
    'DRIVER_ROTATIONAL_DIFFERENCE': '∡', 'EVENT_ESC': '⎋',
    'FILE_ARCHIVE': '🗜', 'TRIA_DOWN_BAR': '⤓', 'TRIA_UP_BAR': '⤒',
    'SEQ_HISTOGRAM': '📊', 'CURVE_DATA': '∿', 'COLORSET_01_VEC': '◼',
    # dot ba — quet HET ten icon 11 addon dung (125 ten), moi ten MOT ky hieu
    # RIENG. Ducphan 23/09/2026: *"khong nen de cac nut va icon trung lap nhau
    # khi khac noi dung, cac icon nen dac thu nhu ban goc"*.
    'ARROW_LEFTRIGHT': '↔', 'CHECKBOX_HLT': '☑', 'CHECKBOX_DEHLT': '☐',
    'CON_CAMERASOLVER': '⌖', 'CURRENT_FILE': '🗎', 'EVENT_A': 'A',
    'EYEDROPPER': '⌇', 'FACESEL': '◲', 'FIXED_SIZE': '⛶',
    'IMAGE_ZDEPTH': '◧', 'LIGHT_DATA': '✦', 'LIGHT_SPOT': '🔦',
    'MATSPHERE': '◍', 'MEMORY': '🧠', 'MESH_CYLINDER': '⬭',
    'MESH_UVSPHERE': '⬮', 'MODIFIER': '🔧', 'MODIFIER_ON': '🔩',
    'MOD_LINEART': '╱', 'MOD_SOLIDIFY': '▧', 'OBJECT_DATA': '◆',
    'OUTLINER': '☰', 'OUTLINER_DATA_FONT': 'Ⓐ', 'OUTLINER_DATA_LIGHT': '✩',
    'OUTLINER_OB_EMPTY': '⊹', 'OUTLINER_OB_IMAGE': '🖻',
    'OUTLINER_OB_LIGHT': '✧', 'OUTLINER_OB_POINTCLOUD': '⋮',
    'PACKAGE': '📦', 'PINNED': '📌', 'UNPINNED': '📍',
    'RADIOBUT_ON': '◉', 'RADIOBUT_OFF': '○', 'RENDER_RESULT': '🏞',
    'RNDCURVE': '∫', 'SELECT_EXTEND': '⊞', 'SELECT_SET': '⊡',
    'SEQ_CHROMA_SCOPE': '◔', 'SHADERFX': '✨', 'SORTTIME': '⏱',
    'VIEW_CAMERA': '📹', 'VIEW_ORTHO': '▱', 'VIEW_PAN': '✥',
    'CON_TRACKTO': '➤', 'DRIVER': '⚡', 'ANIM': '⏱',
    'MOD_BUILD': '🧱', 'SNAP_FACE': '◳', 'SNAP_EDGE': '◱',
    'PRESET': '☰', 'IMGDISPLAY': '🖻', 'MOD_NOISE': '፨',
    'MOD_EDGESPLIT': '⋔', 'MOD_DISPLACE': '⩘', 'MOD_BOOLEAN': '⊍',
    'PIVOT_BOUNDBOX': '⬚', 'DRIVER_TRANSFORM': '⤡',
    'CON_DISTLIMIT': '⌀', 'SOLO_ON': '★', 'SOLO_OFF': '☆',
}

# ⛔ KHONG DUOC DUNG MOT KY HIEU CHUNG CHO MOI ICON LA. Mot nut trang tron
# te, nhung TAM NUT GIONG HET NHAU con te hon: khach khong phan biet noi cai
# nao lam gi. Ducphan 23/09/2026: *"khong nen de cac nut va icon trung lap
# nhau khi khac noi dung"*. Nen icon la thi lay chu cai dac trung cua chinh
# TEN no — hai icon khac ten thi gan nhu luon ra hai ky hieu khac nhau.
_BO_DAU = ('OUTLINER_OB_', 'OUTLINER_DATA_', 'OUTLINER_', 'RESTRICT_',
           'SEQUENCE_', 'MOD_', 'MESH_', 'LIGHT_', 'FILE_', 'EVENT_',
           'SNAP_', 'VIEW_', 'CON_', 'SEQ_', 'IMAGE_', 'OBJECT_')


def icon_la(ten):
    """Ky hieu tam cho mot icon chua co trong bang: hai chu cai dac trung.

    ⛔ `BLANK1` KHONG PHAI MOT ICON. Trong Blender no nghia la "chua dung cho
    trong bang be rong mot icon, khong ve gi". Truoc day no rot xuong duong
    sinh ky hieu tu ten va ra chu "Bl" — khach doc thay "Bl L · QS · Ctrl
    Shift S" va "Bl Size 96 x 40 mm" trong DP_Sketch. Do 23/09/2026.
    """
    if ten in ('BLANK1', 'BLANK', 'NONE', ''):
        return ''
    if not ten or ten == 'NONE':
        return ''
    t = ten
    for d in _BO_DAU:
        if t.startswith(d) and len(t) > len(d):
            t = t[len(d):]
            break
    t = t.replace('_', '')
    return t[:1].upper() + (t[1:2].lower() if len(t) > 1 else '')


def icon_chu(ten):
    """Mot ky tu thay cho icon goc. Khong biet thi tra ve chuoi rong."""
    if not ten or ten == 'NONE':
        return ''
    return ICON_CHU.get(ten, '')


def _nhan_operator(ma):
    try:
        mod, ham = ma.split('.', 1)
        op = getattr(getattr(bpy.ops, mod), ham)
        return op.get_rna_type().name
    except Exception:                                        # noqa: BLE001
        return ma


# ---------------------------------------------------------------- o nhap
def _la_bool(dl, ten):
    """Thuoc tinh nay co phai mot o tich don khong."""
    try:
        pr = dl.bl_rna.properties[ten]
        return pr.type == 'BOOLEAN' and getattr(pr, 'array_length', 0) == 0
    except Exception:                                        # noqa: BLE001
        return False


def _rna(dl, ten):
    try:
        return dl.bl_rna.properties[ten]
    except Exception:                                        # noqa: BLE001
        return None


def _ve_o(c, s, vung):
    dl, ten = c.dl['dl'], c.dl['ten']
    pr = _rna(dl, ten)
    if pr is None:
        V.chu_cat("? %s" % ten, c.x, c.y + 4 * s, c.rong, CO_CHU * s, M.do)
        return
    nhan = c.dl['chu']
    if nhan is None:
        nhan = pr.name
    mo = c.dl.get('mo', True)

    # ⛔ `use_property_split`: NHAN SANG COT TRAI, O SANG COT PHAI. Khong lam
    # cai nay thi bang tu ve khong bao gio thang hang duoc nhu panel N goc —
    # do la cai Ducphan nhin ra ngay 23/09/2026 ("cach bai tri").
    if c.dl.get('chia') and nhan and pr.type != 'BOOLEAN':
        co = CO_CHU * s
        w_nhan = c.rong * CHIA - 8 * s
        if w_nhan > 20 * s:
            # nhan CAN PHAI trong cot trai, y Blender
            t = nhan
            while t and V.do_chu(t, co)[0] > w_nhan:
                t = t[:-1]
            V.chu(t, c.x + w_nhan - V.do_chu(t, co)[0],
                  c.y + (c.cao - co) / 2 + 1 * s, co, _mau_chu(c))
            c.x += c.rong * CHIA
            c.rong -= c.rong * CHIA
            nhan = ""

    if pr.type == 'BOOLEAN' and getattr(pr, 'array_length', 0) == 0:
        if c.dl.get('bat_tat'):
            # `toggle=True`: Blender ve mot NUT lun xuong khi bat, khong phai
            # o tich. Ve o tich thi nut "Shift" cua DP_Camera nhin nhu mot
            # tuy chon phu chu khong phai mot cai nut.
            _ve_tich_nut(c, dl, ten, nhan, s, vung, mo)
            return
        if c.dl.get('chia') and nhan:
            # ⛔ O TICH trong `use_property_split`: cot trai BO TRONG, o tich
            # + chu nam o COT PHAI (o tich TRUOC chu) — y panel N (Render >
            # Film > Transparent). Truoc day chu cot trai, o tich cot phai
            # (agent DP Post 25/09/2026).
            c.x += c.rong * CHIA
            c.rong -= c.rong * CHIA
        _ve_tich(c, dl, ten, nhan, s, vung, mo)
    elif pr.type == 'ENUM':
        _ve_enum(c, dl, ten, pr, nhan, s, vung, mo)
    elif pr.type in ('FLOAT', 'INT'):
        # ⛔ HOI `index` TRUOC. `prop(dl, "mau", index=1)` la MOT KENH cua mot
        # o mau — phai ve thanh truot, khong phai ve lai ca vet mau. Khong hoi
        # thi chinh bang chinh mau cua ta bay ra 3 vet mau khong keo duoc.
        if (c.dl.get('chi_so', -1) < 0 and
                getattr(pr, 'array_length', 0) > 1 and
                pr.subtype in ('COLOR', 'COLOR_GAMMA')):
            # O mau CO NHAN ("Base:") -> nhan trai, vet mau phai, y panel N
            # (agent MatPro vong 2: o mau keo het be ngang, mat nhan).
            if nhan:
                _cot_nhan(c, _hai_cham(c, nhan), s)   # "Base:" y panel N
            _ve_mau(c, dl, ten, s, vung, mo)
        else:
            _ve_so(c, dl, ten, pr, nhan, s, vung, mo)
    elif pr.type == 'STRING':
        if pr.subtype in ('FILE_PATH', 'DIR_PATH'):
            _ve_duong(c, dl, ten, pr, nhan, s, vung, mo)
        else:
            _ve_chuoi(c, dl, ten, nhan, s, vung, mo)
    elif pr.type == 'POINTER':
        # Truoc day cho nay bay ra mot dong chu xam " (POINTER)" — nhin la
        # biet sai. Blender ve mot o ID nho; ta ve dung o ID cua minh.
        _cot_nhan(c, _hai_cham(c, nhan), s)
        c.dl.setdefault('go', '')
        c.dl['con_tro'] = True      # prop() tro ID: bam ten = CHON, khong doi ten
        _ve_id(c, s, vung)
    else:
        V.chu_cat("%s (%s)" % (nhan, pr.type), c.x, c.y + 4 * s, c.rong,
                  CO_CHU * s, M.chu_mo)


def _ve_tich(c, dl, ten, nhan, s, vung, mo):
    """⛔ `emboss=False` LA VE PHANG. Ba dau bang gap cua DP_Lighting
    (`show_light_mix_collections`...) ve them mot O TICH VUONG CAM ben trai
    trong khi panel N chi co `▼ Nhom Den Theo Collection`. Do 23/09/2026."""
    o = c.cao - 3 * s
    bat = bool(getattr(dl, ten))
    tro = mo and tro_trong(c.x, c.y, c.rong, c.cao)

    # ⛔ CHI-ICON THI VE DUNG CAI ICON, KHONG VE O VUONG.
    #
    # Ducphan 23/09/2026, gui anh: *"nut bi dinh chum vao nhau"* — hang camera
    # cua DP_Camera ra mot chum "o vuong cam + .. + icon + icon" dinh lien.
    #
    # Goc benh: `prop(..., text="", icon='RESTRICT_RENDER_OFF')` duoc Blender
    # ve bang DUNG CAI ICON thay cho o vuong. O day truoc do van ve o vuong
    # chiem `cao - 3s` (~18 px) roi moi ve icon vao phan con lai — ma o
    # chi-icon chi rong ~27 px, nen icon con 27 - 18 - 7 = 2 px va `chu_cat`
    # cat no thanh mot dau "..". Khach thay mot day dau cham, khong biet nut
    # nao la nut nao.
    bieu_som = icon_chu(c.dl.get('icon')) or icon_la(c.dl.get('icon'))
    # ⛔ BOOL CO ICON + CHU: Blender ve NUT BAT/TAT (ICON_TOGGLE), khong ve o
    # vuong. `emboss=False` thi PHANG: icon + chu, y dau muc gap
    # (`prop(..., emboss=False, icon='TRIA_DOWN')` cua DP_Lighting). Truoc
    # day ra o tich cam + "▾" nho — khi gap trong nhu mot tuy chon chua bat.
    # Do 25/09/2026, agent DP_Lighting + DP_Tiles ("Cut where areas overlap").
    if bieu_som and (nhan or ''):
        if not c.dl.get('chim'):
            return _ve_tich_nut(c, dl, ten, nhan, s, vung, mo)
        if tro:
            V.hop(c.x, c.y, c.rong, c.cao, M.hang_tro, BO_GOC * s)
        co = CO_CHU * s
        V.chu_cat(bieu_som + " " + nhan, c.x + 2 * s,
                  c.y + (c.cao - co) / 2 + 1 * s, c.rong - 4 * s, co,
                  _mau_chu(c))
        if c.dl.get('bam', mo):
            nap(vung, {'x': c.x, 'y': c.y, 'w': c.rong, 'h': c.cao,
                       'kieu': 'tich', 'dl': dl, 'ten': ten})
        return
    if bieu_som and not (nhan or ''):
        if bat and not c.dl.get('chim'):
            # Nut chi-icon DANG BAT co nen xanh, y panel N (khoa ti le cua
            # DP_Camera — agent vong 2).
            V.hop(c.x, c.y, c.rong, c.cao, M.nut_nhan, BO_GOC * s)
        elif tro:
            V.hop(c.x, c.y, c.rong, c.cao, M.hang_tro, BO_GOC * s)
        co_i = CO_CHU * s * 1.1
        w_i = V.do_chu(bieu_som, co_i)[0]
        V.chu(bieu_som, c.x + max(0.0, (c.rong - w_i) / 2),
              c.y + (c.cao - co_i) / 2 + 1 * s, co_i,
              M.tich_bat if bat else (M.chu if tro else M.chu_mo),
              dam=bat)
        if c.dl.get('bam', mo):
            nap(vung, {'x': c.x, 'y': c.y, 'w': c.rong, 'h': c.cao,
                       'kieu': 'tich', 'dl': dl, 'ten': ten})
        return

    if tro:
        V.hop(c.x, c.y, c.rong, c.cao, M.hang_tro, BO_GOC * s)
    # ⛔ VIEN PHAI BO TRON THEO NEN. `V.vien` la bon thanh thang -> goc
    # vuong nhon de len nen bo tron (khung.py da gap o nut). O dang bat: chi
    # mot mang mau, khong vien — y Blender.
    if bat:
        # O tich BI KHOA van bat: mo cam di, y Blender (agent Max vong 4:
        # Light Proxies khoa van cam dac).
        V.hop(c.x, c.y + 1.5 * s, o, o,
              M.tich_bat if mo else _tron_nhin(M.tich_bat, M.nen_panel, 0.5),
              3 * s)
    else:
        # Nen XAM (M.nut), khong phai nen o chu: tren dong danh sach toi, o
        # 0.129 gan nhu tan vao nen 40/255 (agent DP_Camera vong 2).
        V.vien_tron(c.x, c.y + 1.5 * s, o, o,
                    M.vien_tro if tro else M.nut_vien,
                    M.o_tro if tro else M.nut,
                    max(1.0, 1.0 * s), 3 * s)
    if bat:
        # ⛔ DAU TICH PHAI LA CHU V THAT. Ban dau ve bang hai thanh chu nhat
        # cheo nhau, nhin ra mot dau cong nghieng chu khong ra dau tich —
        # Ducphan 23/09/2026: *"o tick chon nen co tick chu v dang hoang"*.
        V.dau_tich(c.x, c.y + 1.5 * s, o, (0.09, 0.10, 0.12, 1), s)
    co = CO_CHU * s
    # `prop(..., text="", icon='RESTRICT_RENDER_OFF')` — Blender ve CAI ICON
    # thay cho o vuong. Bo qua `icon=` thi nut bat/tat render tung camera cua
    # DP_Camera ra mot o vuong cam khong ai doan duoc la gi.
    bieu = icon_chu(c.dl.get('icon')) or icon_la(c.dl.get('icon'))
    chu = nhan or ''
    if bieu:
        chu = (bieu + " " + chu) if chu else bieu
    V.chu_cat(chu, c.x + o + 5 * s, c.y + (c.cao - co) / 2 + 1 * s,
              c.rong - o - 7 * s, co, _mau_chu(c))
    if c.dl.get('bam', mo):
        nap(vung, {'x': c.x, 'y': c.y, 'w': c.rong, 'h': c.cao,
                     'kieu': 'tich', 'dl': dl, 'ten': ten})


def _ve_so(c, dl, ten, pr, nhan, s, vung, mo):
    gt = getattr(dl, ten)
    if c.dl.get('chi_so', -1) >= 0:
        try:
            gt = gt[c.dl['chi_so']]
        except Exception:                                    # noqa: BLE001
            pass
    if _dang_soan(dl, ten, c.dl.get('chi_so', -1)):
        _ve_so_dang_go(c, nhan, s)
        return
    # ⛔ `emboss=False` LA VE PHANG, khong nen khong vien. Blender lam the;
    # Hub truoc day cat co `chim` vao o bam roi KHONG AI DOC. Hau qua: moi
    # dong cua `MATERIAL_UL_matslots` (`prop(ma,"name",text="",emboss=False)`)
    # ra mot cai hop co vien, nhin thanh "hai o nhap" chong len dong dang
    # chon. Do 23/09/2026.
    chim = bool(c.dl.get('chim'))
    lo, hi = pr.soft_min, pr.soft_max
    # ⛔ `FACTOR` VA `PERCENTAGE` LA THANH TRUOT du addon khong truyen
    # `slider=True` — Blender tu lam the. `Fac` cua node tron (chinh la o
    # cuong do cua moi kenh co map trong DP_MaxMat) la FACTOR; ve no thanh o
    # so tron thi khach mat cam giac "minh dang o dau trong dai 0..1".
    # Do 23/09/2026.
    _ep_thanh = getattr(pr, 'subtype', '') in ('FACTOR', 'PERCENTAGE')
    co_thanh = ((c.dl.get('keo') or _ep_thanh) and
                lo > -1e30 and hi < 1e30 and hi > lo)
    tro = mo and tro_trong(c.x, c.y, c.rong, c.cao)
    if not chim or tro:
        # O `active=False` / khoa: nen cung mo di mot nua, y panel N (agent
        # MatPro vong 5: "Map size" nen y het o thuong).
        nen_o = M.o_tro if tro else M.o_chu
        if not c.dl.get('mo', True):
            nen_o = _tron_nhin(nen_o, M.hop, 0.5)
        V.hop(c.x, c.y, c.rong, c.cao, nen_o, BO_GOC * s)
    if co_thanh and not chim:
        p = max(0.0, min(1.0, (gt - lo) / (hi - lo)))
        if p > 0.001:
            # ⛔ O DANG KHOA THI RUOT PHAI NHAT. Panel N ve mo han; o tu ve
            # truoc day ve xanh ruc nhu dang dung duoc, khach keo mai khong
            # nhuc nhich ma khong hieu vi sao. Do 23/09/2026 tren hai o EV/K
            # cua DP_Camera luc `my_cam_use_ev = False`.
            _ruot = M.truot_ruot if mo else tuple(
                a * 0.45 + b * 0.55 for a, b in
                zip(M.truot_ruot[:3], M.o_chu[:3])) + (1.0,)
            V.hop(c.x, c.y, c.rong * p, c.cao, _ruot, BO_GOC * s)
    if not chim:
        V.vien(c.x, c.y, c.rong, c.cao,
               (M.vien_tro if tro else M.nut_vien) if mo else M.hop_vien,
               max(1.0, 1.0 * s))
    co = CO_CHU * s
    y = c.y + (c.cao - co) / 2 + 1 * s
    # Re chuot: hai mui ten o hai mep -> chu lui vao, KHONG de len mui ten
    # (agent CAD Sync: ‹ › de len chu "A" va so cuoi).
    # Thanh truot (co_thanh) KHONG co mui ten, y Blender (agent DP Post
    # vong 3: "‹ Exposure 0.00 ›").
    tro_mt = tro and not co_thanh
    le = 14 * s if tro_mt else 5 * s
    if tro_mt:
        # hai mui ten buoc mot nac — y Blender, va de tay biet o nay KEO duoc
        V.chu("‹", c.x + 4 * s, y, co, M.chu)
        V.chu("›", c.x + c.rong - 10 * s, y, co, M.chu)
    chuoi = _so_ra_chu(gt, pr)
    if nhan:
        w = V.do_chu(chuoi, co)[0]
        # Nhan CHUA CHO cho so + mot khoang: "Cường độ10.00" dinh lien la
        # vi nhan duoc 60% be ngang bat ke so dai bao nhieu (agent DP_Lighting).
        V.chu_cat(nhan, c.x + le, y,
                  max(0.0, c.rong - w - 2 * le - 8 * s), co, _mau_chu(c))
        V.chu(chuoi, c.x + c.rong - w - le, y, co, _mau_chu(c))
    else:
        # da co cot nhan ben trai: con so CAN GIUA o, y nhu Blender
        V.chu_giua(chuoi, c.x, y, c.rong, co, _mau_chu(c))
    if c.dl.get('bam', mo):
        nap(vung, {'x': c.x, 'y': c.y, 'w': c.rong, 'h': c.cao,
                   'kieu': 'keo', 'dl': dl, 'ten': ten, 'pr': pr,
                   'nhan_tip': c.dl.get('chu') or nhan,
                   # ⛔ PHAI NAP `truot`. Thieu no thi nhanh "do nhay theo be
                   # ngang o" trong `o._dat_so` la MA CHET, va moi o roi ve
                   # `step/100` — keo het mot o 0..100000 can 3,3 TRIEU pixel.
                   'truot': bool(co_thanh),
                   'chi_so': c.dl.get('chi_so', -1)})


def la_goc(pr):
    """O nay co phai mot GOC khong (luu radian, hien do)?

    ⛔ HOI `unit`, DUNG HOI `subtype`. Da dam 23/09/2026: truoc day chi thu
    `subtype in ('ANGLE','ROTATION')`, nen bo sot `EULER` — dung kieu ma socket
    `Rotation` cua node Mapping dung, tuc CA 5 o "Rotate" cua bang 3 (UVW) cua
    DP_MaxImporter. Chung hien "0.000" thay vi "0.0°". Mot phep thu theo `unit`
    bat tron ANGLE · ROTATION · EULER · AXISANGLE.
    """
    try:
        if getattr(pr, 'unit', '') == 'ROTATION':
            return True
    except Exception:                                        # noqa: BLE001
        pass
    return getattr(pr, 'subtype', '') in ('ANGLE', 'ROTATION', 'EULER',
                                          'AXISANGLE')


def la_do_dai(pr):
    """O nay co phai mot DO DAI khong (de hien kem don vi cua canh)?

    ⛔ Cung mot bai hoc: `TRANSLATION` (socket `Location` cua node Mapping —
    o "Offset U/V" cua DP_MaxImporter) co `unit='LENGTH'` ma `subtype` khong
    nam trong bo cu, nen hien "0.000" thay vi "0 m".
    """
    st = getattr(pr, 'subtype', '')
    if st == 'DISTANCE_CAMERA':
        return True                 # tieu cu: co he don vi RIENG, xu ly duoi
    try:
        if getattr(pr, 'unit', '') == 'LENGTH':
            return True
    except Exception:                                        # noqa: BLE001
        pass
    return st in ('DISTANCE', 'TRANSLATION', 'XYZ_LENGTH')


# ⛔ `bpy.utils.units.to_string()` KHONG CO THAM SO `unit=`.
# Chu ky that (do lai 23/09/2026 tren Blender 5.2.2):
#     to_string(unit_system, unit_category, value, *, precision=3,
#               split_unit=False, compatible_unit=False)
# Truyen `unit=` la `TypeError`, roi thang xuong nhanh du phong — va nhanh do
# BO HAN `length_unit` cua canh. Hau qua do duoc, canh dat MILLIMETERS:
#     panel N "100 mm"   -> o tu ve "10 cm"
#     panel N "1000000 mm" -> o tu ve "1 km"
# Te hon la luc GO: khach nhin "100 mm", go "150" mong 150 mm, ma o nhan 150
# don vi Blender = 150 m — sai MOT NGHIN LAN. Nen tu doi bac don vi.
_BAC_DAI = {'KILOMETERS': (1000.0, 'km'), 'METERS': (1.0, 'm'),
            'CENTIMETERS': (0.01, 'cm'), 'MILLIMETERS': (0.001, 'mm'),
            'MICROMETERS': (1e-6, 'µm'),
            'MILES': (1609.344, 'mi'), 'FEET': (0.3048, "'"),
            'INCHES': (0.0254, '"'), 'THOU': (2.54e-5, 'thou')}


def he_so_dai(dv=None):
    """(he so, duoi) de doi don vi Blender -> don vi dang HIEN.

    None = canh de Blender tu co bac (ADAPTIVE) — luc do cu nho `to_string`.
    """
    if dv is None:
        try:
            dv = bpy.context.scene.unit_settings
        except Exception:                                    # noqa: BLE001
            return None
    bac = _BAC_DAI.get(getattr(dv, 'length_unit', 'ADAPTIVE'))
    if bac is None:
        return None
    tl = getattr(dv, 'scale_length', 1.0) or 1.0
    return (tl / bac[0], bac[1])


def _so_ra_chu(gt, pr):
    """⛔ PHAI THEO `precision` CUA CHINH O DO. Dan cung `%.3f` thi mot o khai
    `precision=1` hien `30.000` trong khi panel N hien `30.0` — nhin la biet
    ngay day khong phai bang cua Blender."""
    if pr.type == 'INT':
        if pr.subtype == 'PERCENTAGE':
            return "%d%%" % gt
        return "%d" % gt
    cx = getattr(pr, 'precision', 3)
    if cx is None or cx < 0:
        cx = 3
    if pr.subtype == 'PERCENTAGE':
        # Theo `precision` cua prop: panel N "50.00%" (agent DP Post vong 2).
        return "%.*f%%" % (cx, gt)
    if la_goc(pr):
        # ⛔ GOC TRONG BLENDER LUU BANG RADIAN, HIEN BANG DO. Khong doi thi o
        # hien `0.262` thay vi `15.0°`, va khach go "15" vao la dat 15 RADIAN
        # — sai chuc nang chu khong chi xau. Do 23/09/2026 (DP_Lighting:
        # sun_elevation, sun_size, sun_rotation).
        # Viet dung nhu Blender ("0°", "30°", "15.5°") — nho chinh bo viet
        # don vi cua no. "0.0°" la sai (agent DP_Tiles/Optimize 25/09/2026).
        try:
            return bpy.utils.units.to_string('METRIC', 'ROTATION', gt,
                                             precision=max(1, min(cx, 6)))
        except Exception:                                    # noqa: BLE001
            import math as _m
            return "%.1f°" % _m.degrees(gt)
    # Nhiet do mau ("6500 K") va pixel ("4.50 px") — panel N co duoi don vi.
    if pr.subtype == 'COLOR_TEMPERATURE':
        try:
            return bpy.utils.units.to_string('METRIC', 'COLOR_TEMPERATURE',
                                             gt, precision=min(cx, 3))
        except Exception:                                    # noqa: BLE001
            pass
    if pr.subtype == 'PIXEL':
        return "%.*f px" % (cx, gt)
    if la_do_dai(pr):
        # `DISTANCE_CAMERA` (Focal Length) cung la do dai — bo sot thi panel N
        # hien "50 mm" con o tu ve hien "50.0000".
        try:
            dv = bpy.context.scene.unit_settings
            # ⛔ THEO `length_unit` CUA CANH. Khong truyen thi Blender tu co
            # bac don vi: panel N hien "0.1 m" con o tu ve hien "10 cm".
            # ⛔ TIEU CU KHONG THEO `length_unit` CUA CANH. Canh dat don vi
            # METERS thi Focal Length ra "50 m" thay vi "50 mm" — sai han.
            # Blender co he don vi RIENG ('CAMERA') cho tieu cu.
            if pr.subtype == 'DISTANCE_CAMERA':
                return bpy.utils.units.to_string(
                    dv.system, 'CAMERA', gt, precision=max(1, min(cx, 4)))
            hs = he_so_dai(dv)
            if hs is not None:
                t = "%.*f" % (max(1, min(cx, 6)), gt * hs[0])
                if '.' in t:
                    t = t.rstrip('0').rstrip('.')
                return "%s %s" % (t, hs[1])
            return bpy.utils.units.to_string(
                dv.system, 'LENGTH', gt, precision=max(1, min(cx, 4)))
        except Exception:                                    # noqa: BLE001
            try:
                return bpy.utils.units.to_string(
                    bpy.context.scene.unit_settings.system, 'LENGTH', gt,
                    precision=max(1, min(cx, 4)))
            except Exception:                                # noqa: BLE001
                return "%.*f" % (cx, gt)
    # ⛔ KHONG cat so le khi >= 1000: panel N hien "1000.00" (agent CAD Sync,
    # MatPro, Tiles 25/09/2026).
    return "%.*f" % (cx, gt)


def _ve_enum(c, dl, ten, pr, nhan, s, vung, mo):
    _cot_nhan(c, _hai_cham(c, nhan), s)
    gt = getattr(dl, ten)
    ten_hien = gt
    ic_hien = None
    for ma, ten_m, _ic in muc_enum(dl, ten, pr):
        if ma == gt:
            ten_hien = ten_m
            ic_hien = _ic
            break
    # Icon cua muc dang chon (hoac `icon=` cua prop) dung truoc chu, y panel
    # N (agent DP_Tiles vong 2: `pattern` thieu hoa van, preset thieu
    # MATSPHERE).
    ic = c.dl.get('icon')
    if not ic or ic == 'NONE':
        try:
            ic = pr.enum_items[gt].icon
        except Exception:                                    # noqa: BLE001
            ic = None
    bieu = icon_chu(ic)
    if bieu:
        ten_hien = bieu + " " + str(ten_hien)
    anh_x = 0.0
    if not bieu and isinstance(ic_hien, int) and ic_hien > 0:
        # Enum dong co anh rieng (hoa van Tiles): anh nho dau o.
        try:
            tx = V.texture(ic_hien, xin=False)
        except Exception:                                    # noqa: BLE001
            tx = None
        if tx is not None:
            anh_x = c.cao - 2 * s
    tro = mo and tro_trong(c.x, c.y, c.rong, c.cao)
    V.hop(c.x, c.y, c.rong, c.cao, M.nut_tro if tro else M.nut, BO_GOC * s)
    V.vien(c.x, c.y, c.rong, c.cao,
           (M.vien_tro if tro else M.nut_vien) if mo else M.hop_vien,
           max(1.0, 1.0 * s))
    co = CO_CHU * s
    y = c.y + (c.cao - co) / 2 + 1 * s
    if anh_x:
        V.anh(c.x + 3 * s, c.y + 1 * s, anh_x - 2 * s, anh_x - 2 * s, tx)
    V.chu_cat(ten_hien, c.x + 7 * s + anh_x, y, c.rong - 24 * s - anh_x, co,
              M.chu_nut if mo else M.chu_mo)
    V.hop(c.x + c.rong - 20 * s, c.y + 2 * s, 1.0 * s, c.cao - 4 * s,
          M.hop_vien, 0)
    V.chu("▾", c.x + c.rong - 14 * s, y, co, M.chu if mo else M.chu_mo)
    if c.dl.get('bam', mo):
        nap(vung, {'x': c.x, 'y': c.y, 'w': c.rong, 'h': c.cao,
                   'kieu': 'enum', 'dl': dl, 'ten': ten, 'pr': pr})


# O DANG DUOC GO. `Khay` dat cai nay; o nhap doc no de biet minh co dang
# duoc soan khong. Mot bien module la du: mot luc chi go duoc MOT o.
DANG_SOAN = [None]


def _dang_soan(dl, ten, chi_so=-1):
    d = DANG_SOAN[0]
    if d is None or d['ten'] != ten:
        return False
    try:
        if d['dl'] != dl:
            return False
    except Exception:                                        # noqa: BLE001
        if d['dl'] is not dl:
            return False
    return d.get('chi_so', -1) == chi_so


def _ve_so_dang_go(c, nhan, s):
    """O so dang duoc GO TAY. Blender cho bam mot cai la go so chinh xac;
    thieu duong nay thi mot addon dung hinh khong dat noi "phao rong 96 mm",
    va mot addon chinh anh khong dat noi "Temp 6500"."""
    d = DANG_SOAN[0]
    V.hop(c.x, c.y, c.rong, c.cao, M.o_chu, BO_GOC * s)
    V.vien(c.x, c.y, c.rong, c.cao, M.cam, max(1.0, 1.0 * s))
    co = CO_CHU * s
    y = c.y + (c.cao - co) / 2 + 1 * s
    if nhan:
        V.chu_cat(nhan, c.x + 5 * s, y, c.rong * 0.45, co, M.chu_mo)
    x0 = c.x + max(5 * s, c.rong * 0.45 + 6 * s) if nhan else c.x + 5 * s
    ve_boi_den(d, x0, c, s, co)
    V.chu_cat(d['chu'], x0, y, c.rong - (x0 - c.x) - 6 * s, co, M.chu)
    V.hop(x0 + V.do_chu(d['chu'][:d['vi_tri']], co)[0], c.y + 3 * s,
          max(1.0, 1.5 * s), c.cao - 6 * s, M.con_tro, 0)


class _OTho:
    """Mot `O` bo cuc gia, dung toa do tho. Cac ham ve o duoi doc
    `c.x/.y/.rong/.cao`; cho nao khong co bo cuc that thi dung cai nay."""

    __slots__ = ('x', 'y', 'rong', 'cao')

    def __init__(self, x, y, rong, cao):
        self.x, self.y, self.rong, self.cao = x, y, rong, cao


def ve_o_soan(d, x, y, w, h, s):
    """Mot o dang GO TAY, ve theo toa do tho.

    ⛔ DUNG CHO O HEX TRONG BANG CHON MAU. Bang do khong di qua bo cuc
    `Khung` nen khong co `O` nao de muon; ma thieu net boi den va con tro
    nhay thi khach go vao khong biet minh dang go cai gi.
    """
    c = _OTho(x, y, w, h)
    co = CO_CHU * s
    x0 = x + 5 * s
    ve_boi_den(d, x0, c, s, co)
    V.chu_cat(d['chu'], x0, y + (h - co) / 2 + 1 * s, w - 10 * s, co, M.chu)
    V.hop(x0 + V.do_chu(d['chu'][:d['vi_tri']], co)[0], y + 3 * s,
          max(1.0, 1.5 * s), h - 6 * s, M.con_tro, 0)


def ve_boi_den(d, x0, c, s, co, hop=None):
    """Nen xanh sau chuoi dang BOI DEN — ve TRUOC chu.

    ⛔ Ducphan 23/09/2026, thu tay: *"khi boi den so thi k thay co dau hieu boi
    marking o tat ca cac cua so addon"*.
    Goc benh: co `boi_den` co tu dau va HANH VI dung (go mot phim la thay ca
    chuoi, y Blender) — nhung khong mot net nao ve no ra. Khach nhin thay mot
    o so binh thuong, go mot phim, ca so bay mat: khong hieu vi sao.

    ⛔ VE TRUOC CHU, khong thi nen phu kin chu.

    ⛔ BOI DEN LA MOT KHOANG, KHONG PHAI "CHON HET". Ducphan 23/09/2026, thu
    tay: *"boi den chu hoac so de sua van khong duoc"*. Truoc day chi co co
    `boi_den` (ca chuoi) — khong keo chuot boi mot doan, khong Shift+mui ten.
    Nay khoang chon la `neo`..`vi_tri` (xem `vung_chon`).

    ⛔ GHI HINH HOC CUA O DANG GO vao `d` (`hop`, `x0`, `co`). O dang go KHONG
    nap o bam nao, nen truoc day bam vao chinh no la chot luon gia tri — khong
    cach nao dat con tro giua chuoi. `Khay.bam` doc `hop` de biet cu bam roi
    vao trong o dang go.
    """
    d['hop'] = hop or (c.x, c.y, c.rong, c.cao)
    d['x0'] = x0
    d['co'] = co
    r = vung_chon(d)
    if not r:
        return
    chu = d.get('chu') or ''
    tran = c.rong - (x0 - c.x) - 6 * s      # khong tran ra ngoai o
    xa = min(V.do_chu(chu[:r[0]], co)[0], tran)
    xb = min(V.do_chu(chu[:r[1]], co)[0], tran)
    if xb <= xa:
        return
    V.hop(x0 + xa - 1 * s, c.y + 3 * s, xb - xa + 2 * s, c.cao - 6 * s,
          M.boi_den, 2 * s)


def vung_chon(d):
    """(dau, cuoi) cua doan dang boi den trong o dang go, hoac None."""
    chu = d.get('chu') or ''
    if d.get('boi_den'):
        return (0, len(chu)) if chu else None
    neo = d.get('neo')
    vt = d.get('vi_tri', 0)
    if neo is None or neo == vt:
        return None
    return (min(neo, vt), max(neo, vt))


def chi_so_ky_tu(d, mx):
    """Vi tri ky tu gan diem `mx` nhat trong o dang go (de dat con tro)."""
    chu = d.get('chu') or ''
    x0 = d.get('x0', 0.0)
    co = d.get('co', CO_CHU)
    tot, kc = 0, None
    for i in range(len(chu) + 1):
        k = abs(x0 + V.do_chu(chu[:i], co)[0] - mx)
        if kc is None or k < kc:
            tot, kc = i, k
    return tot


def trong_o_soan(d, mx, my):
    hp = d.get('hop') if d else None
    return bool(hp) and hp[0] <= mx <= hp[0] + hp[2] and \
        hp[1] <= my <= hp[1] + hp[3]


def _hai_cham(c, nhan):
    """Blender `ui_item_name_add_colon`: enum xo, chuoi, duong dan, con tro
    ve nhan TRAI co dau ":" ("Format:") khi KHONG `use_property_split`
    (agent RAMchill vong 1+2 so anh panel N, 25/09/2026)."""
    if nhan and not c.dl.get('chia') and not nhan.endswith(':'):
        return nhan + ':'
    return nhan


def _cot_nhan(c, nhan, s):
    """Ve nhan ben TRAI o, tra ve phan be ngang con lai cho chinh o.

    ⛔ KHONG DUOC DE GIA TRI DE LEN NHAN. Ban dau `_ve_chuoi` ve
    `gt if gt else nhan` — co gia tri thi nhan bien mat. Bang "Pie Shortcuts"
    cua DP_Sketch thanh 24 cai hop chi chua mot chu cai (`L`, `R`, `C`...),
    khong biet o nao la lenh nao. Panel N goc ve `Line  [L]`. Do 23/09/2026."""
    if not nhan:
        return
    co = CO_CHU * s
    # ⛔ NHAN CHIEM 1/3 BE NGANG (Blender `ui_item_with_label`: w_label =
    # w/3), khong theo be ngang chu — theo chu thi moi dong mot kieu, cot o
    # nhap khong thang (Pie Shortcuts DP_Sketch, agent vong 2). Nhan dai qua
    # 1/3 thi duoc toi 45% roi cat.
    # Co dinh 1/3, nhan dai thi CAT — y panel N ("Select P…"); cho gian toi
    # 45% la cot o nhap lech hang (agent Sketch vong 5, Pie Shortcuts).
    w = c.rong / 3.0
    if w < 18 * s:
        return
    V.chu_cat(nhan, c.x + 2 * s, c.y + (c.cao - co) / 2 + 1 * s,
              w - 4 * s, co, _mau_chu(c))
    c.x += w
    c.rong -= w


def _ve_tich_nut(c, dl, ten, nhan, s, vung, mo):
    """BOOLEAN ve bang mot nut bat/tat (`toggle=True`)."""
    bat = bool(getattr(dl, ten))
    tro = mo and tro_trong(c.x, c.y, c.rong, c.cao)
    nen = M.nut_nhan if bat else (M.nut_tro if tro else M.nut)
    if not mo:
        nen = _tron_nhin(nen, M.nen_panel, 0.5)
    # ⛔ PHANG: khong vien, khong vet sang mep tren. Nut doc ra la
    #   nut nho SAC NEN, khong nho vien. Xem `_ve_nut`.
    V.hop(c.x, c.y, c.rong, c.cao, nen, BO_GOC * s)
    chu = nhan or ''
    bieu = icon_chu(c.dl.get('icon'))
    co = CO_CHU * s
    y = c.y + (c.cao - co) / 2 + 1 * s
    mau = M.chu_nut if mo else M.chu_mo
    if bieu and chu and c.rong > 60 * s:
        # Icon SAT MEP TRAI, chu giua phan con lai — y `_ve_nut` va panel N
        # (agent DP_Tiles vong 4, "Cut where areas overlap").
        V.chu(bieu, c.x + 6 * s, y, co, mau)
        V.chu_giua(chu, c.x + 20 * s, y, c.rong - 24 * s, co, mau, dam=bat)
    else:
        if bieu:
            chu = (bieu + " " + chu) if chu else bieu
        V.chu_giua(chu, c.x, y, c.rong, co, mau, dam=bat)
    if c.dl.get('bam', mo):
        nap(vung, {'x': c.x, 'y': c.y, 'w': c.rong, 'h': c.cao,
                   'kieu': 'tich', 'dl': dl, 'ten': ten})


def _ve_chuoi(c, dl, ten, nhan, s, vung, mo):
    _cot_nhan(c, _hai_cham(c, nhan), s)
    soan = _dang_soan(dl, ten)
    # ⛔ `emboss=False` LA VE PHANG. Moi dong cua `MATERIAL_UL_matslots` va
    # `CAMERA_UL_list` la `prop(x, "name", text="", emboss=False)`; ve nen va
    # vien vao do thi dong dang chon nhin ra "hai o nhap chong len nhau".
    # Blender ve chu tron. Do 23/09/2026.
    chim = bool(c.dl.get('chim')) and not soan
    if not chim:
        # `alert` (duong khong ton tai...) -> nen do nhat, y panel N.
        V.hop(c.x, c.y, c.rong, c.cao,
              tuple(x * 0.45 for x in M.do[:3]) + (1.0,)
              if (c.dl.get('do') and not soan) else M.o_chu, BO_GOC * s)
        V.vien(c.x, c.y, c.rong, c.cao,
               M.cam if soan else (M.nut_vien if mo else M.hop_vien),
               max(1.0, 1.0 * s))
    co = CO_CHU * s
    y = c.y + (c.cao - co) / 2 + 1 * s
    if soan:
        d = DANG_SOAN[0]
        gt = d['chu']
        ve_boi_den(d, c.x + 5 * s, c, s, co)
        V.chu_cat(gt, c.x + 5 * s, y, c.rong - 10 * s, co, M.chu)
        # con tro nhay theo vi tri ky tu, khong dinh o cuoi
        w = V.do_chu(gt[:d['vi_tri']], co)[0]
        V.hop(c.x + 5 * s + w, c.y + 3 * s, max(1.0, 1.5 * s),
              c.cao - 6 * s, M.cam, 0)
        return
    gt = str(getattr(dl, ten) or "")
    bieu = icon_chu(c.dl.get('icon'))
    if bieu:
        gt = bieu + " " + gt
    # ⛔ DONG DANH SACH MANG `icon_value` PHAI VE RA TAM ANH — do la qua cau
    # vat lieu / tam anh thu nho ma `UIList.draw_item` giao cho. Thieu no thi
    # danh sach vat lieu chi con chu. Do 23/09/2026.
    le_t = 5 * s
    tex = V.texture(c.dl.get('anh') or 0)
    if tex is not None:
        canh = max(4.0, c.cao - 4 * s)
        V.anh(c.x + 2 * s, c.y + 2 * s, canh, canh, tex)
        le_t = canh + 5 * s
    elif c.dl.get('anh'):
        # Preview CHUA VE XONG: van chua cho icon — chu khong nhay sang phai
        # khi anh toi (agent MatPro vong 2: Glass Milky0/PVC lech 30 px).
        le_t = max(4.0, c.cao - 4 * s) + 5 * s
    (V.chu_cat_giua if c.dl.get('cat_giua') else V.chu_cat)(
        gt, c.x + le_t, y, c.rong - le_t - 5 * s, co, _mau_chu(c))
    if c.dl.get('bam', mo):
        nap(vung, {'x': c.x, 'y': c.y, 'w': c.rong, 'h': c.cao,
                   'kieu': 'chuoi', 'dl': dl, 'ten': ten})


def la_mau_linear(pr):
    """O mau nay giu gia tri LINEAR (`subtype='COLOR'`) hay da la mau hien
    (`COLOR_GAMMA`)."""
    return getattr(pr, 'subtype', '') == 'COLOR'


def mau_ve(m, pr):
    """Mau de VE tu gia tri that cua mot o mau."""
    m4 = tuple(m[:3]) + (1.0,)
    return V.nang(V.mau_hien(m4) if la_mau_linear(pr) else m4)


def _ve_mau(c, dl, ten, s, vung, mo):
    """Vet mau. ⛔ PHAI NAP O BAM. Truoc day chi ve roi thoi — 4 o mau cua
    MatPro (Base/Dark/Mid/Light), 4 o cua Tiles va 6 o cua DP_MaxImporter deu
    CHET: khach khong doi duoc mau trong mot addon vat lieu. Do 23/09/2026."""
    m = list(getattr(dl, ten))
    while len(m) < 4:
        m.append(1.0)
    tro = tro_trong(c.x, c.y, c.rong, c.cao)
    pr = _rna(dl, ten)
    # ⛔ GIA TRI CUA CANH LA LINEAR — phai nang len sRGB moi ve. Xem
    # `ve.mau_hien()`. Truoc day ve thang: o mau toi di hon ba lan so voi
    # panel N, tuc mot addon vat lieu hien sai chinh cai mau no ban.
    mv = mau_ve(m, pr)
    if not mo:
        # O mau BI KHOA thi MO di, y panel N (agent DP_Lighting vong 2: mau
        # nhom den khoa van tuoi 255,231,208; panel N 144,131,120).
        # Blender ve o khoa voi alpha 0,5 de len nen, TINH TRONG sRGB NHIN
        # THAY. Truoc day tron 0,55/0,45 voi `o_chu` trong khong gian da
        # nang -> toi hon panel N ~17% (agent DP_Tiles vong 2: 191 -> Hub
        # 101, N 122). Nen ~0,16: Tiles 191->115, Lighting 255->147 (N 144).
        m4 = tuple(m[:3]) + (1.0,)
        nhin = V.mau_hien(m4) if la_mau_linear(pr) else m4
        mv = V.nang(tuple(x * 0.5 + 0.16 * 0.5 for x in nhin[:3]) + (1.0,))
    V.hop(c.x, c.y, c.rong, c.cao, mv, BO_GOC * s)
    V.vien(c.x, c.y, c.rong, c.cao,
           M.vien_tro if tro else M.hop_vien, max(1.0, 1.0 * s))
    if c.dl.get('bam', mo):
        nap(vung, {'x': c.x, 'y': c.y, 'w': c.rong, 'h': c.cao,
                   'kieu': 'mau', 'dl': dl, 'ten': ten, 'pr': pr,
                   # Socket node: tieu de la TEN SOCKET ("Color"), khong
                   # phai "default_value" (agent DP_Lighting vong 2).
                   'chu': c.dl.get('chu') or (
                       getattr(dl, 'name', None) if ten == 'default_value'
                       else None) or (pr.name if pr else ten),
                   'so_kenh': min(4, getattr(pr, 'array_length', 3) or 3)})


# ================================================== goi draw() cua panel
# ⛔ BLENDER DAT MOT SO THUOC TINH LEN CHINH THE INSTANCE, KHONG LEN LOP.
# `UIList.draw_item` hay hoi `self.layout_type` de biet dang ve kieu danh sach
# nao; lop KHONG co thuoc tinh do, Blender gan no luc chay. Lay tu lop ra thi
# nem `AttributeError` va ca danh sach im lang khong ve gi.
# Do 23/09/2026: `DPP_UL_images` cua DP-PostProcessing, 10 dong deu trong.
_SAN_CO = {
    'layout_type': 'DEFAULT',
    'list_id': '',
    'use_filter_show': False,
    'filter_name': '',
    'use_filter_invert': False,
    'use_filter_sort_alpha': False,
    'use_filter_sort_reverse': False,
    'use_filter_sort_lock': False,
    'bitflag_filter_item': 1 << 30,
    'is_popover': False,
}


class _GiaSelf:
    """`self` gia cho `Panel.draw`. Thuoc tinh nao khong co thi lay cua lop,
    khong co nua thi lay trong bo san co."""

    def __init__(self, lop, khung):
        object.__setattr__(self, '_lop', lop)
        object.__setattr__(self, 'layout', khung)

    def __setattr__(self, ten, gt):
        object.__setattr__(self, ten, gt)

    def __getattr__(self, ten):
        lop = object.__getattribute__(self, '_lop')
        # ⛔ PHUONG THUC THUONG PHAI DUOC BUOC VAO `self` GIA NAY.
        # `getattr(<lop>, 'ten_ham')` tra ve mot ham CHUA BUOC, nen khi panel
        # goi `self._draw_card(lo, "diffuse")` thi `lo` bi nuot lam `self` va
        # Python nem:
        #     TypeError: _draw_card() missing 1 required positional argument
        # Ca bang "2 · Max_Material" cua DP_MaxImporter (10 the kenh, Round
        # Edges, Advanced, cay map — 1296 px) TRANG TRON vi dung mot dong nay.
        # Do 23/09/2026. `staticmethod`/`classmethod` thi lay qua `getattr`
        # da dung san, nen chi buoc dung loai ham thuan.
        for c in getattr(lop, '__mro__', (lop,)):
            if ten in getattr(c, '__dict__', {}):
                tho = c.__dict__[ten]
                if isinstance(tho, types.FunctionType):
                    return types.MethodType(tho, self)
                break
        try:
            return getattr(lop, ten)
        except AttributeError:
            if ten in _SAN_CO:
                return _SAN_CO[ten]
            raise


def chay_draw(lop, context, khung):
    """Goi `lop.draw(self_gia, context)`. Tra ve None neu chay duoc, chuoi
    loi neu khong — KHONG nem ra ngoai, vi mot panel hong khong duoc lam
    sap ca khay."""
    try:
        if hasattr(lop, 'poll') and not lop.poll(context):
            # ⛔ KHONG DUOC VE GI CA. Truoc day cho nay ghi mot dong tieng Viet
            # khong dau vao ruot — khach nuoc ngoai mua DP_Sketch nhin thay
            # "(panel nay dang an: poll() = False)" ngay trong san pham ban ra.
            # Blender an HAN ca panel; ta cung phai the.
            return 'AN'
    except Exception as e:                                   # noqa: BLE001
        return "poll: %s" % e
    NGU_CANH_VE[0] = context
    try:
        lop.draw(_GiaSelf(lop, khung), context)
    except Exception as e:                                   # noqa: BLE001
        import traceback
        traceback.print_exc()
        return "%s: %s" % (type(e).__name__, e)
    finally:
        NGU_CANH_VE[0] = None
    return None


# Ngu canh cua panel DANG chay draw() — `operator()` hoi `poll` bang no.
NGU_CANH_VE = [None]


def op_poll(ma):
    """(duoc, ly do) cua operator Python `ma` trong ngu canh dang ve.

    ⛔ Panel N ve XAM nut co poll() = False; Hub ve sang nhu thuong va bam
    vao im lang (agent DP_Sketch "Delete Selected" 25/09/2026). Chi hoi
    operator Python (lop tim duoc trong `bpy.types`); operator C thi coi nhu
    duoc. Loi khi hoi (ngu canh gia thieu gi do) -> coi nhu DUOC: lam mo
    nham mot nut dung duoc con te hon de sang mot nut dang khoa."""
    ctx = NGU_CANH_VE[0]
    if ctx is None or '.' not in ma:
        return True, ''
    a, b = ma.split('.', 1)
    lop = getattr(bpy.types, '%s_OT_%s' % (a.upper(), b), None)
    if lop is None or not hasattr(lop, 'poll'):
        return True, ''
    try:
        if lop.poll(ctx):
            return True, ''
    except Exception:                                        # noqa: BLE001
        return True, ''
    return False, ''


# ================================================== danh sach muc cua enum
# ⛔ `pr.enum_items` TRONG RONG VOI ENUM DONG. Enum khai bang `items=<ham>`
# (MatPro 15 ho, Tiles 8 hoa van, Sketch 168 mau phao) thi RNA khong goi ham
# do khi ta hoi qua `bl_rna.properties[...]` — no tra ve 0 muc va khong keu
# gi. Da do 23/09/2026: `len(pr.enum_items) == 0` trong khi o chon that hien
# du 15 dong.
#
# Duong vong: ham `items=` van nam trong `__annotations__` cua chinh lop
# PropertyGroup (Blender giu nguyen `_PropertyDeferred`), goi thang no ra.
def _ham_items(dl, ten):
    """Tim ham `items=` cua mot enum dong.

    Hai kieu khai, PHAI DO CA HAI:
      1. trong `__annotations__` cua mot PropertyGroup (MatPro, Tiles, Sketch);
      2. gan THANG len lop RNA — `bpy.types.Scene.my_cam_preset = EnumProperty(
         items=preset_items)`. Kieu nay KHONG di qua `__annotations__`, va do
         bo sot no ma o chon Preset cua DP_Camera chet han (do 23/09/2026).
    """
    for c in getattr(type(dl), '__mro__', ()):
        a = getattr(c, '__annotations__', None)
        if not a or ten not in a:
            continue
        kw = getattr(a[ten], 'keywords', None)
        if kw and callable(kw.get('items')):
            return kw['items']
    for c in getattr(type(dl), '__mro__', ()):
        tho = c.__dict__.get(ten)
        kw = getattr(tho, 'keywords', None)
        if kw and callable(kw.get('items')):
            return kw['items']
    return None


def muc_enum(dl, ten, pr=None):
    """[(ma, ten hien, icon_value)] — chay duoc voi ca enum tinh va dong."""
    if pr is not None:
        try:
            ds = [(m.identifier, m.name, 0) for m in pr.enum_items]
            if ds:
                return ds
        except Exception:                                    # noqa: BLE001
            pass
    ham = _ham_items(dl, ten)
    if ham is None:
        return []
    try:
        tho = ham(dl, bpy.context)
    except Exception as e:                                   # noqa: BLE001
        print("[dp_bang] goi items cua %s hong: %s" % (ten, e))
        return []
    ds = []
    for m in tho or ():
        if not isinstance(m, (tuple, list)) or len(m) < 3:
            continue
        # (ma, ten, mo_ta) | (ma, ten, mo_ta, icon, so) — `icon` la SO thi no
        # la icon_value cua kho anh rieng; la CHUOI thi la icon san cua Blender
        ic = m[3] if len(m) >= 4 and isinstance(m[3], int) else 0
        ds.append((m[0], m[1], ic))
    return ds


# ===================================================== template_list
# Cuon cua tung danh sach. Khoa la lop UIList + ten o, khong phai id() —
# `id()` cua mot bpy_struct doi moi lan lay ra.
CUON_DS = {}
HD_DS = {}           # dong dang chon lan ve truoc, theo khoa danh sach


def _ve_danh_sach(c, s, vung):
    dl, ten = c.dl['dl'], c.dl['ten']
    try:
        muc = list(getattr(dl, ten))
    except Exception:                                        # noqa: BLE001
        muc = []
    lop = getattr(bpy.types, c.dl['lop'], None)
    try:
        hd = int(getattr(c.dl['dl_hd'], c.dl['ten_hd']))
    except Exception:                                        # noqa: BLE001
        hd = -1

    V.hop(c.x, c.y, c.rong, c.cao, M.o_chu, BO_GOC * s)
    V.vien(c.x, c.y, c.rong, c.cao, M.nut_vien if c.dl.get('mo', True) else M.hop_vien,
           max(1.0, 1.0 * s))

    muc, chi_so = _loc_danh_sach(lop, dl, ten, muc)
    le = 2 * s
    tx, t_rong = c.x + le, c.rong - 2 * le
    t_duoi, t_cao = c.y + le, c.cao - 2 * le
    h_hang = HANG * s
    khoa = c.dl['khoa']
    toi_da = max(0.0, h_hang * len(muc) - t_cao)
    cuon = max(0.0, min(CUON_DS.get(khoa, 0.0), toi_da))
    # Dong DANG CHON vua doi (camera vua tao...) -> cuon toi no, y panel N
    # (agent DP_Camera vong 4-5: Camera.018 nam ngoai tam nhin). Chi khi
    # chon doi, de khong gianh con lan cua khach.
    if HD_DS.get(khoa) != hd:
        HD_DS[khoa] = hd
        if hd in chi_so:
            vt = chi_so.index(hd) * h_hang
            if vt < cuon:
                cuon = vt
            elif vt + h_hang > cuon + t_cao:
                cuon = min(toi_da, vt + h_hang - t_cao)
    CUON_DS[khoa] = cuon

    # ⛔ O BAM NEN CUA CA DANH SACH PHAI NAP TRUOC TUNG DONG. `Khay._tim` quet
    # NGUOC, nen nap no sau cung la no che het moi dong va moi o nhap ten ben
    # trong — bai do 23/09 ra 7/9 dung vi cai nay, CUNG MOT BAY da ghi o dau
    # `o.py` cho vung 'than'. Bay nay lap lai moi lan them mot lop nen moi.
    nap(vung, {'x': c.x, 'y': c.y, 'w': c.rong, 'h': c.cao,
               'kieu': 'ds_lan', 'khoa': khoa, 'toi_da': toi_da})

    # ⛔ DAI HON CHO THI PHAI CO THANH LAN NHIN THAY DUOC. Truoc day danh
    # sach cuon duoc bang con lan chuot nhung KHONG VE GI, nen khach khong co
    # cach nao biet ben duoi con dong. Ducphan 23/09/2026: *"cac o chua nhieu
    # hang theo noi dung cua scene co the dai hon can con lan"*.
    if toi_da > 0.5:
        w_thanh = 4 * s
        x_thanh = c.x + c.rong - w_thanh - le
        V.hop(x_thanh, t_duoi, w_thanh, t_cao, M.truot, w_thanh / 2)
        phan = t_cao / max(1.0, h_hang * len(muc))
        h_con = max(12 * s, t_cao * phan)
        # cuon=0 la o DINH danh sach -> con chay nam tren cung
        p = 0.0 if toi_da <= 0.0 else (cuon / toi_da)
        y_con = t_duoi + (t_cao - h_con) * (1.0 - p)
        V.hop(x_thanh, y_con, w_thanh, h_con, M.truot_ruot, w_thanh / 2)
        t_rong -= w_thanh + le      # nhuong cho, dong chu khong chui xuong duoi

    cat_vao(tx, t_duoi, t_rong, t_cao)
    for j, m in enumerate(muc):
        i = chi_so[j]
        y = t_duoi + t_cao - (j + 1) * h_hang + cuon
        if y + h_hang < t_duoi or y > t_duoi + t_cao:
            continue                       # ngoai tam nhin: khong ve, khong nap
        if i == hd:
            V.hop(tx, y, t_rong, h_hang, M.ds_chon, 2 * s)
        elif tro_trong(tx, y, t_rong, h_hang):
            V.hop(tx, y, t_rong, h_hang, M.hang_tro, 2 * s)
        # ⛔ NAP O BAM CUA DONG TRUOC RUOT DONG. `Khay._tim` quet nguoc, nap
        # sau la dong che het nut ben trong no — dung bay da tra gia o `o.py`.
        nap(vung, {'x': tx, 'y': y, 'w': t_rong, 'h': h_hang,
                   'kieu': 'ds_muc', 'dl_hd': c.dl['dl_hd'],
                   'ten_hd': c.dl['ten_hd'], 'chi_so': i,
                   'khoa': khoa})
        kh = Khung(doc=False)
        xong = False
        if lop is not None and hasattr(lop, 'draw_item'):
            try:
                _goi_draw_item(lop, kh, dl, m, i, c.dl['dl_hd'],
                               c.dl['ten_hd'])
                xong = True
            except Exception as e:                           # noqa: BLE001
                print("[dp_bang] draw_item %s hong: %s" % (c.dl['lop'], e))
        if not xong:
            kh = Khung(doc=False)
            kh.label(text=str(getattr(m, 'name', m)))
        kh.do(t_rong - 4 * s, s)
        kh.cao = h_hang                    # moi dong dung MOT hang, nhu Blender
        kh.ve(tx + 2 * s, y + h_hang, s, vung)
    cat_ra()

    if toi_da > 0.5:
        h = max(16 * s, t_cao * (t_cao / max(1.0, h_hang * len(muc))))
        V.hop(c.x + c.rong - 4 * s,
              t_duoi + (t_cao - h) * (1.0 - cuon / toi_da), 3 * s, h,
              M.nut, 1.5 * s)




# ================================================ template_icon_view
def _tex_cua_muc(ma, icon_value, song=False):
    t = V.texture(icon_value or 0, song=song)
    if t is None:
        # ⛔ CHAY NEN THI `icon_id` = 0 — tra theo TEN key trong kho anh.
        t = V.texture_theo_ten(ma)
    return t


def _vua_khit(tex, w, h):
    """(rong, cao) cua anh `tex` vua khit khung w x h, giu ti le."""
    try:
        tw, th = float(tex.width), float(tex.height)
    except Exception:                                        # noqa: BLE001
        return w, h
    if tw <= 0 or th <= 0 or w <= 0 or h <= 0:
        return w, h
    if w / h > tw / th:
        return h * tw / th, h
    return w, w * th / tw


def _ve_anh_chon(c, s, vung):
    dl, ten = c.dl['dl'], c.dl['ten']
    pr = _rna(dl, ten)
    ds = muc_enum(dl, ten, pr)
    gt = getattr(dl, ten, None)
    canh = min(c.rong, c.cao)
    x = c.x + (c.rong - canh) / 2.0

    V.hop(x, c.y, canh, canh, M.o_chu, BO_GOC * s)
    tex, nhan_muc = None, ""
    for ma, ten_m, ic in ds:
        if ma == gt:
            tex, nhan_muc = _tex_cua_muc(ma, ic, song=True), ten_m
            break
    if tex is not None:
        # ⛔ GIU TI LE ANH (anh Gallery 16:10 cua DP Post bi ep vuong — agent
        # 25/09/2026): vua khit trong o, phan thua de trong.
        aw, ah = _vua_khit(tex, canh - 4 * s, canh - 4 * s)
        V.anh(x + 2 * s + (canh - 4 * s - aw) / 2,
              c.y + 2 * s + (canh - 4 * s - ah) / 2, aw, ah, tex)
    else:
        V.chu_giua("?", x, c.y + canh / 2 - CO_CHU * s / 2, canh,
                   CO_CHU * s * 1.6, M.chu_mo, dam=True)
    V.vien(x, c.y, canh, canh, M.nut_vien, max(1.0, 1.0 * s))
    # `show_labels` chi hien ten o LUOI XO, khong de len anh lon — panel N
    # khong co chu "Stack bond (..." tren anh (agent DP_Tiles 25/09/2026).
    del nhan_muc
    if c.dl.get('bam', True):
        nap(vung, {'x': x, 'y': c.y, 'w': canh, 'h': canh,
                   'kieu': 'luoi_anh', 'dl': dl, 'ten': ten, 'pr': pr,
                   'ti_le': c.dl['ti_le_xo'], 'nhan': c.dl.get('nhan')})


def _ve_icon(c, s):
    """Mot buc anh tu `template_icon`.

    ⛔ GIU DUNG TI LE CUA ANH. Bieu do Histogram la 2:1; ep vao mot o vuong
    thi no bi keo cao gap doi va doc sai. Ve kieu KHUNG THU: vua khit be
    ngang hoac be cao, phan con lai de trong.
    """
    tex = V.texture(c.dl.get('gt') or 0, song=True)
    if tex is None:
        canh = min(c.rong, c.cao)
        V.hop(c.x, c.y, canh, canh, M.o_chu, BO_GOC * s)
        return
    try:
        tw, th = float(tex.width), float(tex.height)
    except Exception:                                        # noqa: BLE001
        tw = th = 0.0
    if tw <= 0 or th <= 0:
        tw = th = 1.0
    w, h = c.rong, c.cao
    if w / h > tw / th:
        w = h * tw / th
    else:
        h = w * th / tw
    V.anh(c.x + (c.rong - w) / 2, c.y + (c.cao - h) / 2, w, h, tex)


# ============================================================ menu / popover
def _ve_menu_nut(c, s, vung):
    mo = c.dl.get('mo', True)
    V.hop(c.x, c.y, c.rong, c.cao, M.nut, BO_GOC * s)
    V.vien(c.x, c.y, c.rong, c.cao, M.nut_vien if mo else M.hop_vien,
           max(1.0, 1.0 * s))
    co = CO_CHU * s
    y = c.y + (c.cao - co) / 2 + 1 * s
    V.chu_cat(c.dl['chu'], c.x + 7 * s, y, c.rong - 24 * s, co,
              M.chu_nut if mo else M.chu_mo, dam=True)
    V.chu("▾", c.x + c.rong - 14 * s, y, co, M.chu if mo else M.chu_mo)
    if mo and c.dl.get('lop') is not None:
        nap(vung, {'x': c.x, 'y': c.y, 'w': c.rong, 'h': c.cao,
                   'kieu': 'menu_lop', 'lop': c.dl['lop'],
                   'nc': c.dl.get('nc') or {},
                   'panel': c.dl.get('panel', False)})


# ================================================== dau bang gap duoc
# Co bat trong luc ve RUOT cua mot dau bang. `_ve_nhan` doc no de boi dam.
# ⛔ Ducphan 23/09/2026, thu tay: *"boi dam cac hang chuc nang hien tai dang
#    mau trang cuc ky kho nhin"* — hang tieu de bang. Chu tieu de truoc do ve
#    y het chu thuong trong than bang, nen ca o nhin ra mot khoi chu deu tap,
#    khong doc duoc dau la dau mot bang.
TRONG_DAU = [False]


def _ve_nen_dau_bang(k, x, y_tren, rong, s, vung):
    """Nen + mui ten cua mot dau bang. Ruot cua dau bang la do CHINH ADDON
    ve — `bl_label`, hoac `draw_header()` cua no — nen ta chi lo cai vo."""
    cao = k.cao if k.cao else HANG * s
    y = y_tren - cao
    gap = GAP.get(k._dau_bang, False)
    # ⛔ NEN DAU BANG PHAI TACH HAN KHOI THAN. Dau bang cua CA MOT panel
    # dung `nen_dau`; dau bang con (`layout.panel`) dung `dau_con` — sang hon
    # than mot bac de doc ra tang, nhung van dam hon `hop`.
    V.hop(x, y, rong, cao, M.nen_dau if k._dau_dam else M.dau_con, BO_GOC * s)
    # Vach sang mep tren: y Blender, giup mat bat duoc ranh gioi bang.
    V.hop(x, y + cao - max(1.0, 1.0 * s), rong, max(1.0, 1.0 * s),
          M.dau_vach, 0)
    if tro_trong(x, y, rong, cao):
        V.hop(x, y, rong, cao, M.hang_tro, BO_GOC * s)
    co = CO_CHU * s
    V.chu("▸" if gap else "▾", x + 5 * s, y + (cao - co) / 2 + 1 * s, co,
          M.chu_dau, dam=True)
    # ⛔ NAP O BAM TRUOC RUOT — cung cai bay nen-che-noi-dung o `o.py`.
    nap(vung, {'x': x, 'y': y, 'w': rong, 'h': cao,
               'kieu': 'gap_bang', 'khoa': k._dau_bang})




def chay_draw_header_preset(lop, context, khung):
    """`draw_header_preset()` — Blender goi no o BEN PHAI dau bang. Nhieu addon
    nha DP de nut "be tab ra cua so rieng" cua `dp_license/toolbox.py` o day;
    khong goi thi nut do bien mat khoi o tu ve."""
    if not hasattr(lop, 'draw_header_preset'):
        return False
    try:
        lop.draw_header_preset(_GiaSelf(lop, khung), context)
        return True
    except Exception as e:                                   # noqa: BLE001
        print("[dp_bang] draw_header_preset %s hong: %s" % (lop.__name__, e))
        return False


def chay_draw_header(lop, context, khung):
    """Goi `draw_header()` GOC cua panel. Nhieu panel nha DP de `bl_label = ""`
    roi tu ve dau muc trong `draw_header` (MatPro lam the o 8/8 panel), nen
    khong goi cai nay thi dau bang trong khong, hoac phai bay ra `bl_idname`."""
    if not hasattr(lop, 'draw_header'):
        return False
    try:
        lop.draw_header(_GiaSelf(lop, khung), context)
        return True
    except Exception as e:                                   # noqa: BLE001
        print("[dp_bang] draw_header %s hong: %s" % (lop.__name__, e))
        return False


# ============================================================ template_ID
def _kho_id(pr):
    """`bpy.data.<gi>` ung voi kieu cua mot o tro toi khoi du lieu.

    Khong go cung ten kho: hoi thang RNA cua `bpy.data` xem kho nao chua dung
    kieu do. The la o nay chay duoc voi moi kieu, khong rieng vat lieu."""
    try:
        kieu = pr.fixed_type.identifier
    except Exception:                                        # noqa: BLE001
        return None, None
    for q in bpy.data.bl_rna.properties:
        if q.type != 'COLLECTION':
            continue
        try:
            if q.fixed_type.identifier == kieu:
                return getattr(bpy.data, q.identifier, None), kieu
        except Exception:                                    # noqa: BLE001
            continue
    return None, kieu


def _ve_id(c, s, vung):
    dl, ten = c.dl['dl'], c.dl['ten']
    pr = _rna(dl, ten)
    gt = getattr(dl, ten, None)
    mo = c.dl.get('mo', True)
    co = CO_CHU * s
    y = c.y + (c.cao - co) / 2 + 1 * s

    w_xo = 26 * s
    # ⛔ NUT ✕ HIEN KHI CO GIA TRI va prop cho phep rong — y Blender, du
    # addon co truyen `unlink=` hay khong. Truoc day chi hien khi `go` khac
    # rong: Focus Object cua DP_Camera, template_ID cua MatPro/MaxMat khong
    # co cach nao bo chon (agent 25/09/2026).
    rong_duoc = not getattr(pr, 'is_never_none', False)
    w_go = 18 * s if (gt is not None and rong_duoc
                      and c.dl.get('go') is not False) else 0.0
    # ⛔ PHAI CO NUT "New". `template_ID(..., new=...)` la duong DUY NHAT tao
    # mot khoi du lieu moi tu panel; DP_MaxMat tro no vao
    # `dpmax.material_new` de vat lieu moi luon co san node Max_Material.
    # Truoc day `'moi'` duoc cat vao o bam roi KHONG AI DOC — khach khong tao
    # noi mot vat lieu tu o Hub, phai quay ve panel N. Do 23/09/2026.
    # `template_ID` co vat: nut "New" thanh icon NHAN BAN (y Blender), them
    # so NGUOI DUNG (>1, bam = tach ban rieng) va khien FAKE USER. O con tro
    # (`prop`) thi khong co ba thu nay. (agent MatPro/MaxMat 25/09/2026)
    la_tid = not c.dl.get('con_tro') and gt is not None
    w_moi = (22 * s if gt is not None else 34 * s) if c.dl.get('moi') else 0.0
    # Blender hien so nguoi dung THAT, khong tinh fake user (agent MatPro
    # vong 3: N "2", Hub "3").
    so_dung = (getattr(gt, 'users', 0) -
               (1 if getattr(gt, 'use_fake_user', False) else 0)) \
        if la_tid else 0
    w_so = 22 * s if so_dung > 1 else 0.0
    w_gia = 20 * s if (la_tid and hasattr(gt, 'use_fake_user')) else 0.0
    w_ten = max(20 * s, c.rong - w_xo - w_go - w_moi - w_so - w_gia - 4 * s)

    # --- nut xo danh sach: QUA CAU preview cua vat dang chon (y Blender)
    V.hop(c.x, c.y, w_xo, c.cao, M.nut, BO_GOC * s)
    V.vien(c.x, c.y, w_xo, c.cao, M.nut_vien, max(1.0, 1.0 * s))
    _tex_xo = None
    if gt is not None and isinstance(gt, bpy.types.ID):
        try:
            _pv = gt.preview
            if _pv is not None and _pv.icon_id:
                _tex_xo = V.texture(_pv.icon_id)
            elif _pv is None:
                V.can_preview(gt)
        except Exception:                                    # noqa: BLE001
            _tex_xo = None
    if _tex_xo is not None:
        _k = c.cao - 4 * s
        V.anh(c.x + 2 * s, c.y + 2 * s, _k, _k, _tex_xo)
        V.chu("▾", c.x + w_xo - 8 * s, c.y + 1 * s, co * 0.7, M.chu_nut)
    else:
        V.chu("▾", c.x + w_xo - 12 * s, y, co, M.chu_nut)
    if c.dl.get('bam', mo):
        nap(vung, {'x': c.x, 'y': c.y, 'w': w_xo, 'h': c.cao,
                   'kieu': 'id_xo', 'dl': dl, 'ten': ten, 'pr': pr})

    # --- o ten: sua duoc y nhu Blender
    x2 = c.x + w_xo + 2 * s
    if gt is None:
        V.hop(x2, c.y, w_ten, c.cao, M.o_chu, BO_GOC * s)
        V.vien(x2, c.y, w_ten, c.cao, M.hop_vien, 1.0)
        # ⛔ CHU CUA KHAY LA TIENG ANH. Ducphan chot 23/09/2026:
        #   *"ngon ngu khay la tieng anh"*. Chu tieng Viet cua CHINH
        #   ADDON (73 nut cua DP_Lighting) thi giu nguyen — do la ruot
        #   addon, khong phai vo cua khay.
        V.chu_cat("(none)", x2 + 5 * s, y, w_ten - 10 * s, co, M.chu_mo)
    else:
        soan = _dang_soan(gt, 'name')
        V.hop(x2, c.y, w_ten, c.cao, M.o_chu, BO_GOC * s)
        V.vien(x2, c.y, w_ten, c.cao,
               M.cam if soan else M.nut_vien, max(1.0, 1.0 * s))
        if soan:
            d = DANG_SOAN[0]
            ve_boi_den(d, x2 + 5 * s, c, s, co, (x2, c.y, w_ten, c.cao))
            V.chu_cat(d['chu'], x2 + 5 * s, y, w_ten - 10 * s, co, M.chu)
            V.hop(x2 + 5 * s + V.do_chu(d['chu'][:d['vi_tri']], co)[0],
                  c.y + 3 * s, max(1.0, 1.5 * s), c.cao - 6 * s, M.con_tro, 0)
        else:
            V.chu_cat(gt.name, x2 + 5 * s, y, w_ten - 10 * s, co, M.chu)
            if c.dl.get('bam', mo):
                # ⛔ O CON TRO (`prop` Focus Object...) bam ten la MO DANH
                # SACH CHON; chi `template_ID` moi doi ten ID. Truoc day bam
                # vao "Balloons" la vao che do DOI TEN chinh vat the do trong
                # canh khach (agent DP_Camera 25/09/2026).
                if c.dl.get('con_tro'):
                    nap(vung, {'x': x2, 'y': c.y, 'w': w_ten, 'h': c.cao,
                               'kieu': 'id_xo', 'dl': dl, 'ten': ten,
                               'pr': pr})
                else:
                    nap(vung, {'x': x2, 'y': c.y, 'w': w_ten, 'h': c.cao,
                               'kieu': 'chuoi', 'dl': gt, 'ten': 'name'})
    xp = x2 + w_ten + 2 * s
    if w_so:
        V.hop(xp, c.y, w_so - 1 * s, c.cao, M.nut, BO_GOC * s)
        V.chu_giua(str(so_dung), xp, y, w_so, co, M.chu_nut)
        if c.dl.get('bam', mo):
            nap(vung, {'x': xp, 'y': c.y, 'w': w_so, 'h': c.cao,
                       'kieu': 'id_rieng', 'dl': dl, 'ten': ten})
        xp += w_so
    if w_gia:
        bat = bool(getattr(gt, 'use_fake_user', False))
        V.hop(xp, c.y, w_gia - 1 * s, c.cao,
              M.nut_nhan if bat else M.nut, BO_GOC * s)
        V.chu_giua(icon_chu('FAKE_USER_ON'), xp, y, w_gia, co, M.chu_nut)
        if c.dl.get('bam', mo):
            nap(vung, {'x': xp, 'y': c.y, 'w': w_gia, 'h': c.cao,
                       'kieu': 'tich', 'dl': gt, 'ten': 'use_fake_user'})
        xp += w_gia
    if w_moi:
        x4 = c.x + c.rong - w_moi - w_go
        V.hop(x4, c.y, w_moi - 1 * s, c.cao, M.nut, BO_GOC * s)
        V.chu_giua("New" if gt is None else "⧉", x4, y, w_moi, co,
                   M.chu_nut, dam=True)
        if c.dl.get('bam', mo):
            nap(vung, {'x': x4, 'y': c.y, 'w': w_moi, 'h': c.cao,
                       'kieu': 'nut', 'ma': c.dl['moi'], 'props': {}})

    # --- nut go lien ket: luon o mep PHAI cung
    if w_go:
        x3 = c.x + c.rong - w_go
        V.hop(x3, c.y, w_go, c.cao, M.nut, BO_GOC * s)
        V.vien(x3, c.y, w_go, c.cao, M.nut_vien, max(1.0, 1.0 * s))
        V.chu_giua("✕", x3, y, w_go, co, M.chu_nut)
        if c.dl.get('bam', mo):
            nap(vung, {'x': x3, 'y': c.y, 'w': w_go, 'h': c.cao,
                       'kieu': 'id_go', 'dl': dl, 'ten': ten})


# ⛔ `draw_item` KHONG PHAI LUC NAO CUNG NHAN DU CHIN THAM SO. Blender khai
# `index` va `flt_flag` co gia tri mac dinh, nen addon duoc phep viet ngan
# hon — `CAMERA_UL_list` cua DP_Camera chi nhan bay. Goi cung mot kieu cho
# moi lop la mot nua so danh sach im lang khong ve duoc gi.
# Do 23/09/2026 bang `do_bang_tu_ve.py`: "takes 8 positional arguments but 9
# were given", lap lai 27 lan trong mot luot ve.
_SO_THAM = {}


def _so_tham(lop):
    ten = lop.__name__
    if ten in _SO_THAM:
        return _SO_THAM[ten]
    n = 9
    try:
        import inspect
        ts = inspect.signature(lop.draw_item).parameters
        if any(p.kind == inspect.Parameter.VAR_POSITIONAL for p in ts.values()):
            n = 9
        else:
            n = max(0, len(ts) - 1)     # tru `self`
    except Exception:                                        # noqa: BLE001
        n = 9
    _SO_THAM[ten] = n
    return n


def _anh_cua_muc(muc):
    """Tam xem truoc cua mot dong danh sach — cai ma Blender truyen vao tham
    so `icon` cua `draw_item`. Khong co thi 0.

    Nho no ma danh sach vat lieu co qua cau vat lieu o dau dong, y panel N."""
    for duong in (muc, getattr(muc, 'material', None),
                  getattr(muc, 'object', None), getattr(muc, 'data', None)):
        if duong is None:
            continue
        try:
            p = duong.preview
            if p is not None and p.icon_id:
                return p.icon_id
            # ⛔ CHUA CO PREVIEW THI DONG TRONG MAI. `template_list` cua
            # Blender tu `preview_ensure` cho ID o dau dong; ta khong duoc goi
            # no trong draw — nho duong toi ID, hen gio lam ho. Do 24/09/2026:
            # dong vat lieu vua tao trong DP_MaxMat khong co qua cau.
            if p is None and isinstance(duong, bpy.types.ID):
                V.can_preview(duong)
        except Exception:                                    # noqa: BLE001
            continue
    return 0


def _goi_draw_item(lop, kh, dl, muc, i, dl_hd, ten_hd):
    doi = [bpy.context, kh, dl, muc, _anh_cua_muc(muc), dl_hd, ten_hd, i, 0]
    n = min(_so_tham(lop), len(doi))
    lop.draw_item(_GiaSelf(lop, kh), *doi[:n])


# ====================================================== prop_enum: mot nut
def _ve_nut_enum(c, s, vung):
    dl, ten = c.dl['dl'], c.dl['ten']
    mo = c.dl.get('mo', True)
    dang = getattr(dl, ten, None) == c.dl['gt']
    tro = mo and tro_trong(c.x, c.y, c.rong, c.cao)
    nen = M.nut_nhan if dang else (M.nut_tro if tro else M.nut)
    if not mo:
        nen = _tron_nhin(nen, M.nen_panel, 0.5)
    # ⛔ PHANG: khong vien, khong vet sang mep tren. Nut doc ra la
    #   nut nho SAC NEN, khong nho vien. Xem `_ve_nut`.
    V.hop(c.x, c.y, c.rong, c.cao, nen, BO_GOC * s)
    chu = c.dl.get('chu') or ''
    bieu = icon_chu(c.dl.get('icon'))
    if bieu:
        chu = (bieu + " " + chu) if chu else bieu
    co = CO_CHU * s
    V.chu_giua(chu, c.x, c.y + (c.cao - co) / 2 + 1 * s, c.rong, co,
               M.chu_nut if mo else M.chu_mo, dam=dang)
    if c.dl.get('bam', mo):
        nap(vung, {'x': c.x, 'y': c.y, 'w': c.rong, 'h': c.cao,
                   'kieu': 'dat_enum', 'dl': dl, 'ten': ten,
                   'gt': c.dl['gt']})


# ================================================ ngu canh gia cho menu
class VungGia:
    """`context.region` GIA — bao be ngang cua CHINH O, khong phai ca man hinh.

    ⛔ ADDON DOC `context.region.width` DE TU TINH CO. DP-PostProcessing lay
    `hist_scale(context.region.width, ...)` de chon co bieu do; Hub ve de len
    vung WINDOW nen `region.width` = 1520 px thay vi 360 px cua o → bieu do
    ra mot o vuong canh 1481 px, de lai mot LO 1.550 px va day 16/18 bang
    xuong duoi tam nhin. Do 23/09/2026.
    """

    def __init__(self, that, rong, cao):
        object.__setattr__(self, '_that', that)
        object.__setattr__(self, 'width', int(max(1, rong)))
        object.__setattr__(self, 'height', int(max(1, cao)))

    def __getattr__(self, ten):
        return getattr(object.__getattribute__(self, '_that'), ten)


class NguCanh:
    """`context` co them nhung gi addon da `context_pointer_set`.

    Khong dung duoc `bpy.context.temp_override` o day: cai do chi nhan nhung
    ten Blender biet truoc (`object`, `area`...), con `dp_sky_node` la ten
    rieng cua addon. Nen boc mot lop mong: hoi ten rieng truoc, khong co thi
    tra ve `context` that."""

    def __init__(self, that, them):
        object.__setattr__(self, '_that', that)
        object.__setattr__(self, '_them', dict(them or {}))

    def __getattr__(self, ten):
        them = object.__getattribute__(self, '_them')
        if ten in them:
            return them[ten]
        return getattr(object.__getattribute__(self, '_that'), ten)


# ================================================== prop_search
def _ve_tim(c, s, vung):
    """`prop_search` y panel N: MOT o — icon loai du lieu, ten, nut ✕ khi da
    co gia tri. Bam vao ten la MO HOP TIM (khong phai go chu tho).

    ⛔ Truoc day: o chu go tay + nut ▾ rieng, khong ✕, khong icon — agent
    DP_Tiles vong 2 so anh panel N "Base colour", 25/09/2026."""
    dl, ten = c.dl['dl'], c.dl['ten']
    mo = c.dl.get('mo', True)
    nhan = c.dl.get('chu')
    if nhan is None:
        pr = _rna(dl, ten)
        nhan = pr.name if pr else ten
    _cot_nhan(c, _hai_cham(c, nhan), s)
    gt = getattr(dl, ten, None)
    chu = (getattr(gt, 'name', '') if gt is not None and
           not isinstance(gt, str) else (gt or ""))
    co = CO_CHU * s
    y = c.y + (c.cao - co) / 2 + 1 * s
    tro = mo and tro_trong(c.x, c.y, c.rong, c.cao)
    V.hop(c.x, c.y, c.rong, c.cao, M.nut_tro if tro else M.o_chu,
          BO_GOC * s)
    V.vien(c.x, c.y, c.rong, c.cao, M.nut_vien, max(1.0, 1.0 * s))
    bieu = icon_chu(_icon_kho(c.dl))
    x = c.x + 5 * s
    if bieu:
        # V.chu, KHONG chu_cat: 🖼 rong hon 14 px bi cat thanh "…" (agent
        # DP_Tiles vong 4).
        V.chu(bieu, x, y, co, _mau_chu(c))
        x += V.do_chu(bieu, co)[0] + 4 * s
    w_xo = 18 * s if chu else 0.0
    V.chu_cat(chu, x, y, c.x + c.rong - w_xo - x - 4 * s, co, _mau_chu(c))
    if c.dl.get('bam', mo):
        nap(vung, {'x': c.x, 'y': c.y, 'w': c.rong - w_xo, 'h': c.cao,
                   'kieu': 'tim_xo', 'dl': dl, 'ten': ten,
                   'kho': c.dl['kho'], 'kho_ten': c.dl['kho_ten']})
    if w_xo:
        x2 = c.x + c.rong - w_xo
        tx = mo and tro_trong(x2, c.y, w_xo, c.cao)
        V.chu_giua("✕", x2, y, w_xo, co, M.chu if tx else M.chu_mo)
        if c.dl.get('bam', mo):
            nap(vung, {'x': x2, 'y': c.y, 'w': w_xo, 'h': c.cao,
                       'kieu': 'tim_xoa', 'dl': dl, 'ten': ten})


def _icon_kho(d):
    """Icon cua o `prop_search`: addon truyen `icon=` thi dung, khong thi lay
    theo loai phan tu trong kho (anh -> IMAGE_DATA...), y Blender."""
    ic = d.get('icon')
    if ic and ic != 'NONE':
        return ic
    try:
        loai = d['kho'].bl_rna.properties[d['kho_ten']].fixed_type.identifier
    except Exception:                                        # noqa: BLE001
        return None
    return {'Image': 'IMAGE_DATA', 'Material': 'MATERIAL',
            'Object': 'OBJECT_DATA', 'MeshUVLoopLayer': 'GROUP_UVS',
            'Collection': 'OUTLINER_COLLECTION', 'Camera': 'CAMERA_DATA',
            'Light': 'LIGHT_DATA', 'NodeTree': 'NODETREE',
            'Texture': 'TEXTURE', 'World': 'WORLD',
            'VertexGroup': 'GROUP_VERTEX'}.get(loai)


def _loc_danh_sach(lop, dl, ten, muc):
    """Loc va sap xep theo `UIList.filter_items()` cua chinh addon.

    ⛔ BO QUA CAI NAY LA MAT DU LIEU THAT. `CAMERA_UL_list` cua DP_Camera tro
    vao `scene.objects` roi tu loc ra camera. Khong loc thi danh sach hien ca
    Cube/Light, va nut 🗑 tren dong `Cube` goi `camera.delete` — XOA THAT mot
    object mesh. Do 23/09/2026: canh 8 object / 4 camera, panel N hien 4 dong,
    o tu ve hien 8 va da xoa nham mot lan.
    """
    chi_so = list(range(len(muc)))
    if lop is None or not hasattr(lop, 'filter_items'):
        return muc, chi_so
    try:
        gia = _GiaSelf(lop, None)
        co, thu_tu = lop.filter_items(gia, bpy.context, dl, ten)
    except Exception as e:                                   # noqa: BLE001
        print("[dp_bang] filter_items %s hong: %s" % (lop.__name__, e))
        return muc, chi_so
    cot = _SAN_CO['bitflag_filter_item']
    if co:
        giu = [i for i in range(len(muc))
               if i < len(co) and (co[i] & cot)]
        # ⛔ KHONG DUOC CO DIEU KIEN NAO O DAY. Truoc day cho nay viet
        # `if giu or any(co):` — mot cai chot "phong xa" hoa ra la cua hau cho
        # dung ca mat du lieu. Khi `filter_items` tra co TOAN SO 0 (canh CHUA
        # CO CAMERA NAO), `giu` rong va `any(co)` la False, nen danh sach GOC
        # duoc giu nguyen: o ve ra "Cube" va "Point", nut 🗑 tro thang vao
        # chung, bam mot cai la MAT THAT mot object mesh.
        # `CAMERA_OT_delete` goi `bpy.data.objects.remove()` khong kiem `type`.
        # Panel N that hien 0 dong. Do 23/09/2026, canh Cube + Point.
        # `if co:` o ngoai da loc truong hop khong co co nao roi.
        muc = [muc[i] for i in giu]
        chi_so = giu
    if thu_tu and len(thu_tu) == len(chi_so):
        cap = sorted(zip(thu_tu, chi_so, muc), key=lambda t: t[0])
        chi_so = [c for _, c, _ in cap]
        muc = [m for _, _, m in cap]
    return muc, chi_so


# ============================================ duong tep / thu muc
_DUONG_CO = {}       # duong -> (luc hoi, co ton tai)


def _duong_co(d):
    """Duong co ton tai khong. Rong = coi nhu co (khong to do).

    ⛔ NHO 2 GIAY: `os.path.exists` tren o NAS co the cham — khong duoc hoi
    moi luot ve (luat "khong quet nang trong draw")."""
    if not d:
        return True
    import os
    now = time.monotonic()
    cu = _DUONG_CO.get(d)
    if cu is not None and now - cu[0] < 2.0:
        return cu[1]
    try:
        co = os.path.exists(bpy.path.abspath(d))
    except Exception:                                        # noqa: BLE001
        co = True
    if len(_DUONG_CO) > 200:
        _DUONG_CO.clear()
    _DUONG_CO[d] = (now, co)
    return co


def _ve_duong(c, dl, ten, pr, nhan, s, vung, mo):
    """O duong dan, co NUT DUYET ben canh.

    ⛔ THIEU NUT DUYET LA BAT KHACH GO TAY CA DUONG DAN. `thu_muc_nuong` cua
    RAMchill la noi ghi map da nuong, "Export file" cua CADSync la noi ghi
    tep — go sai mot ky tu la ghi vao hu khong. Do 23/09/2026."""
    _cot_nhan(c, _hai_cham(c, nhan), s)
    thu_muc = (pr.subtype == 'DIR_PATH')
    w_nut = 22 * s
    w_o = max(20 * s, c.rong - w_nut - 2 * s)
    cu_rong = c.rong
    c.rong = w_o
    # ⛔ TO DO THEO LUAT CUA BLENDER, khong theo "ton tai hay khong". Do
    # panel N that 25/09/2026 (agent CAD Sync vong 3): chi do khi duong bat
    # dau "//" ma prop KHONG ho tro duong tuong doi; duong tuyet doi khong
    # ton tai van KHONG do.
    d_gt = getattr(dl, ten, '') or ''
    if d_gt.startswith('//') and not getattr(
            pr, 'is_path_supports_blend_relative', True):
        c.dl['do'] = True
    c.dl['cat_giua'] = True
    _ve_chuoi(c, dl, ten, "", s, vung, mo)
    c.rong = cu_rong
    x2 = c.x + w_o + 2 * s
    tro = tro_trong(x2, c.y, w_nut, c.cao)
    V.hop(x2, c.y, w_nut, c.cao, M.nut_tro if tro else M.nut, BO_GOC * s)
    V.vien(x2, c.y, w_nut, c.cao, M.vien_tro if tro else M.nut_vien,
           max(1.0, 1.0 * s))
    co = CO_CHU * s
    # Blender dung MOT icon thu muc cho ca nut duyet tep lan thu muc.
    V.chu_giua("🗀", x2,
               c.y + (c.cao - co) / 2 + 1 * s, w_nut, co, M.chu_nut)
    if c.dl.get('bam', mo):
        nap(vung, {'x': x2, 'y': c.y, 'w': w_nut, 'h': c.cao,
                   'kieu': 'duyet', 'dl': dl, 'ten': ten,
                   'thu_muc': thu_muc})


# ================================================ template_curve_mapping
# Kenh dang xem cua tung do thi. Khoa la duong cua chinh o do — khong dung
# `id()` vi `id()` cua mot `bpy_struct` doi moi lan lay ra.
KENH_CONG = {}


def _khoa_cong(dl, ten):
    try:
        return "%s|%s" % (dl.as_pointer(), ten)
    except Exception:                                        # noqa: BLE001
        return "%s|%s" % (type(dl).__name__, ten)


def _ve_cong(c, s, vung):
    dl, ten = c.dl['dl'], c.dl['ten']
    mo = c.dl.get('mo', True)
    try:
        cm = getattr(dl, ten)
        cong = list(cm.curves)
    except Exception:                                        # noqa: BLE001
        V.chu_cat("⚠ khong doc duoc duong cong", c.x, c.y + 4 * s, c.rong,
                  CO_CHU * s, M.do)
        return
    if not cong:
        return

    khoa = _khoa_cong(dl, ten)
    k = min(KENH_CONG.get(khoa, 0), len(cong) - 1)
    KENH_CONG[khoa] = k

    # ⛔ QUA BANG ANH XA — xem `_thu_tu_kenh()`. Dung thang `cong[k]` la lech
    # mot nac va khach khong the biet: the ghi "C" ma sua duong R.
    tt = _thu_tu_kenh(len(cong))
    cv = cong[tt[k] if k < len(tt) and tt[k] < len(cong) else k]

    # --- hang the kenh + hai nut cong cu ben phai
    #
    # ⛔ PHAI CO NUT XOA DIEM. Ducphan 23/09/2026: *"CURVE DEO DUNG DUOC
    #   LUON"*. Truoc day do thi THEM duoc diem ma khong XOA duoc cai nao:
    #   bam nham mot cai la no nam do vinh vien, va vi bam vao nen la them
    #   diem nen chi can vai cu bam lo la duong cong day diem rac, hong han.
    #   Blender co nut X xoa diem dang chon va muc "Reset Curve"; thieu ca hai
    #   thi cai do thi chi di duoc mot chieu.
    h_the = HANG * s
    ten_kenh = _ten_kenh(len(cong))
    # Mot duong duy nhat (Falloff...) thi panel N KHONG co the kenh "C".
    mot_kenh = len(cong) == 1
    nut_w = h_the
    rong_the = max(40 * s, c.rong - 2 * nut_w - 2 * s)
    w_the = rong_the / max(1, len(cong))
    for _ma, _bieu, _dx in (('cong_xoa', '✕', 2), ('cong_dat_lai', '↺', 1)):
        bx = c.x + c.rong - _dx * nut_w
        by = c.y + c.cao - h_the
        _tro = mo and tro_trong(bx, by, nut_w, h_the)
        V.hop(bx, by, nut_w - 1 * s, h_the,
              M.nut_tro if _tro else M.nut, BO_GOC * s)
        V.chu_giua(_bieu, bx, by + (h_the - CO_CHU * s) / 2, nut_w,
                   CO_CHU * s, M.chu_nut)
        if c.dl.get('bam', mo):
            nap(vung, {'x': bx, 'y': by, 'w': nut_w, 'h': h_the,
                       'kieu': _ma, 'cm': getattr(dl, ten), 'cv': cv})
    for i in range(0 if mot_kenh else len(cong)):
        tx = c.x + i * w_the
        chon = (i == k)
        tro = mo and tro_trong(tx, c.y + c.cao - h_the, w_the, h_the)
        V.hop(tx, c.y + c.cao - h_the, w_the - 1 * s, h_the,
              M.nut_nhan if chon else (M.nut_tro if tro else M.nut),
              BO_GOC * s)
        co = CO_CHU * s
        V.chu_giua(ten_kenh[i], tx, c.y + c.cao - h_the + (h_the - co) / 2,
                   w_the, co, M.chu_nut, dam=chon)
        if c.dl.get('bam', mo):
            nap(vung, {'x': tx, 'y': c.y + c.cao - h_the, 'w': w_the,
                       'h': h_the, 'kieu': 'cong_kenh', 'khoa': khoa,
                       'chi_so': i})

    # --- khung do thi
    gx = c.x
    gy = c.y
    gw = c.rong
    gh = c.cao - h_the - 3 * s
    V.hop(gx, gy, gw, gh, M.o_chu, BO_GOC * s)
    V.vien(gx, gy, gw, gh, M.nut_vien, max(1.0, 1.0 * s))
    for i in range(1, 4):                       # luoi 4x4
        V.hop(gx + gw * i / 4.0, gy, max(1.0, 1.0 * s), gh, M.hop_vien, 0)
        V.hop(gx, gy + gh * i / 4.0, gw, max(1.0, 1.0 * s), M.hop_vien, 0)

    try:
        cm.update()
    except Exception:                                        # noqa: BLE001
        pass

    # ⛔ O BAM CUA NEN DO THI NAP TRUOC CAC DIEM. `Khay._tim` quet nguoc; nap
    # nen sau la no che het cac diem dieu khien, va keo mot diem bien thanh
    # "them mot diem moi". Cung cai bay da tra gia o the, o danh sach, o khay.
    if c.dl.get('bam', mo):
        nap(vung, {'x': gx, 'y': gy, 'w': gw, 'h': gh,
                   'kieu': 'cong_nen', 'cm': cm, 'cv': cv, 's': s,
                   'khung': (gx, gy, gw, gh)})

    # --- duong cong: lay mau 48 diem roi noi bang cac doan
    # Kenh R/G/B ve DUNG MAU kenh, y panel N (agent DP Post 25/09/2026).
    mau_duong = {'R': (0.92, 0.36, 0.36, 1.0), 'G': (0.40, 0.82, 0.40, 1.0),
                 'B': (0.42, 0.56, 0.98, 1.0)}.get(
                     ten_kenh[k] if k < len(ten_kenh) else '', None)
    mau_duong = V.nang(mau_duong) if mau_duong else M.chu
    N = 48
    truoc = None
    for i in range(N + 1):
        t = i / float(N)
        # ⛔ PHAI LA `cm.evaluate(cv, t)`, KHONG PHAI `cv.evaluate(t)`.
        # `CurveMap` KHONG co ham `evaluate` — ham do nam tren `CurveMapping`
        # va nhan chinh duong lam doi so. Goi sai thi nem `AttributeError`,
        # nhanh du phong tra `v = t`, va do thi ve ra MOT DUONG CHEO THANG
        # cho moi duong cong tren doi. Keo diem thay diem nhuc nhich ma duong
        # dung yen — dung cai Ducphan thay 23/09/2026: *"CURVE DEO DUNG DUOC
        # LUON"*. Do lai bang Blender 5.2.2.
        try:
            v = cm.evaluate(cv, t)
        except Exception:                                    # noqa: BLE001
            v = t
        px = gx + t * gw
        py = gy + max(0.0, min(1.0, v)) * gh
        if truoc is not None:
            V._gach(truoc[0], truoc[1], px, py, max(1.4, 1.6 * s), mau_duong)
        truoc = (px, py)

    # --- cac diem dieu khien
    r = 4.0 * s
    for i, p in enumerate(cv.points):
        px = gx + max(0.0, min(1.0, p.location[0])) * gw
        py = gy + max(0.0, min(1.0, p.location[1])) * gh
        V.hop(px - r, py - r, 2 * r, 2 * r,
              M.cam if p.select else M.chu, r)
        if c.dl.get('bam', mo):
            nap(vung, {'x': px - r * 2, 'y': py - r * 2, 'w': r * 4,
                       'h': r * 4, 'kieu': 'cong_diem', 'cm': cm,
                       'cv': cv, 'diem': i,
                       'khung': (gx, gy, gw, gh)})


def _thu_tu_kenh(n):
    """The hien thi thu `i` ung voi `curves[?]`.

    ⛔ BLENDER XEP `CurveMapping.curves = [R, G, B, C]`, con Blender HIEN thi
    theo thu tu C · R · G · B. Truoc day `_ve_cong` dung thang `cong[k]`, nen
    moi the LECH MOT NAC: bam "C" lai sua duong R, "R" sua G, "G" sua B, "B"
    sua C. Do 23/09/2026 tren DP-PostProcessing — chinh addon do cung ghi ro
    `_IDX = {'r':0,'g':1,'b':2,'c':3}` trong `curve.py`.

    Hau qua: khach bam "C" (duong tong, cai 95% nguoi dung dung) roi keo len
    tuong phan, anh lai NGA DO — ma duong tong that thi nap sau the ghi "B".
    Keo diem va them diem tu chung chay dung, chi sai moi cho tro vao kenh nao.

    Dat ngay canh `_ten_kenh` de hai bang khong bao gio lech nhau nua.
    """
    if n >= 4:
        return (3, 0, 1, 2, 4)[:n]          # C R G B A  ->  chi so that
    return tuple(range(n))                  # 3 kenh (RGB) / 2 (XY) / 1: thang


def _ten_kenh(n):
    if n >= 4:
        return ("C", "R", "G", "B", "A")[:n]
    if n == 3:
        return ("R", "G", "B")
    if n == 2:
        return ("X", "Y")
    return ("C",)


# ==================================================== template_color_ramp
def _ve_dai_mau(c, s, vung):
    dl, ten = c.dl['dl'], c.dl['ten']
    mo = c.dl.get('mo', True)
    try:
        ramp = getattr(dl, ten)
        muc = list(ramp.elements)
    except Exception:                                        # noqa: BLE001
        V.chu_cat("⚠ khong doc duoc dai mau", c.x, c.y + 4 * s, c.rong,
                  CO_CHU * s, M.do)
        return

    h_thanh = HANG * s * 1.4
    ty = c.y + c.cao - h_thanh
    # --- thanh mau: ve bang 64 lat, moi lat mot mau
    N = 64
    for i in range(N):
        t = (i + 0.5) / N
        try:
            m = ramp.evaluate(t)
        except Exception:                                    # noqa: BLE001
            m = (t, t, t, 1.0)
        V.hop(c.x + c.rong * i / N, ty, c.rong / N + 1.0, h_thanh,
              tuple(m[:3]) + (1.0,), 0)
    V.vien(c.x, ty, c.rong, h_thanh, M.nut_vien, max(1.0, 1.0 * s))

    # --- moc
    r = 5.0 * s
    for i, e in enumerate(muc):
        px = c.x + max(0.0, min(1.0, e.position)) * c.rong
        V.hop(px - r, ty - r, 2 * r, r * 1.6,
              M.cam if getattr(ramp, 'active_index', -1) == i else M.chu, 2 * s)
        if c.dl.get('bam', mo):
            nap(vung, {'x': px - r * 1.6, 'y': ty - r, 'w': r * 3.2,
                       'h': h_thanh + r, 'kieu': 'moc_mau', 'ramp': ramp,
                       'chi_so': i, 'trai': c.x, 'rong': c.rong})

    # --- hang chinh moc dang chon
    try:
        i = int(getattr(ramp, 'active_index', 0))
        e = muc[i]
    except Exception:                                        # noqa: BLE001
        return
    kh = Khung(doc=False)
    kh.prop(e, "position", text="Pos", slider=True)
    kh.prop(e, "color", text="")
    kh.do(c.rong, s)
    kh.cao = HANG * s
    kh.ve(c.x, ty - 4 * s, s, vung)
