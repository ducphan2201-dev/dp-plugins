# -*- coding: utf-8 -*-
# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
"""NHO CHO O NAM O DAU — ghi ra mot file JSON ben canh cau hinh Blender.

⛔ KHONG GHI VAO FILE .blend. Vi tri cua khay la cua NGUOI DUNG, khong phai
cua canh quay: mo mot file .blend khach gui toi ma khay nhay di cho khac la
sai. Cung ly do, khong dung `bpy.types.Scene` de giu.

⛔ GHI PHAI KHONG BAO GIO LAM SAP BLENDER. O dia day, thu muc chi doc, JSON
hong — moi ca deu nuot va chay tiep voi bo mac dinh. Luat Ducphan 23/09/2026:
"khong duoc gay anh huong, vang, hay can tro qua trinh su dung".
"""
import json
import os

import bpy

TEN_FILE = "dp_hub_khay.json"


def duong():
    try:
        goc = bpy.utils.user_resource('CONFIG', path="dp_hub", create=True)
    except Exception:                                        # noqa: BLE001
        goc = os.path.join(os.path.expanduser("~"), ".cache", "dp_tam")
        try:
            os.makedirs(goc, exist_ok=True)
        except Exception:                                    # noqa: BLE001
            return None
    return os.path.join(goc, TEN_FILE)


def doc():
    d = duong()
    if not d or not os.path.exists(d):
        return {}
    try:
        with open(d, encoding="utf-8") as f:
            dl = json.load(f)
        return dl if isinstance(dl, dict) else {}
    except Exception as e:                                   # noqa: BLE001
        print("[dp_bang] doc %s hong (bo qua): %s" % (d, e))
        return {}


def ghi(dl):
    d = duong()
    if not d:
        return False
    try:
        tam = d + ".tam"
        with open(tam, "w", encoding="utf-8") as f:
            json.dump(dl, f, ensure_ascii=False, indent=1)
        os.replace(tam, d)          # thay MOT NHIP: dung dien mat file cu
        return True
    except Exception as e:                                   # noqa: BLE001
        print("[dp_bang] ghi %s hong (bo qua): %s" % (d, e))
        return False
