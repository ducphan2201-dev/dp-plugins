# -*- coding: utf-8 -*-
# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
"""KHAY CONG CU TU VE CUA DP_HUB.

Hub ve ho bang cua addon khac bang cach goi `Panel.draw()` GOC cua chinh addon
voi mot `layout` gia. Addon KHONG bi sua mot dong nao — luat Ducphan
23/09/2026.

    ve.py    ve pixel (gpu + blf), gom lenh ve, texture icon
    mau.py   bang mau cua nha DP (KHONG doc theme Blender)
    khung.py `UILayout` gia — ruot cua moi o
    o.py     mot the, va cai khay giu cac the
    nho.py   nho vi tri the ra file JSON
    lenh.py  operator rieng cua khay (hop chon tep)
    cua_so.py CUA SO OS ROI lam cho chua — keo ra ngoai khung Blender
"""
from . import ve, mau, khung, o, nho, lenh, cua_so   # noqa: F401
