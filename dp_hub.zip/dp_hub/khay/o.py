# -*- coding: utf-8 -*-
# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
"""MOT O, VA CAI KHAY GIU CAC O.

O = mot the vuong: thanh tieu de keo duoc, than cuon duoc, goc duoi phai keo
doi co. Ruot cua o la `draw()` THAT cua panel addon, chay qua `khung.Khung`.

⛔ O KHONG BIET NO NAM O DAU. Moi toa do tinh theo VUNG VE, khong theo man
hinh. Nho the ma ca cum o bung nguyen sang cua so roi ma khong phai sua gi.

⛔ KHONG CON KHAY XEP CANH. Ducphan bo han 23/09/2026: *"tao k can cai tray
ben trai lam j, cai tao can la 1 cua so rieng biet co the di chuyen ngoai
khung cua so blender"*. O nay chi con MOT kieu song: noi tu do trong cua so
chua (`cua_so.py`). Moi thu thuoc ve khay — `neo_bat`, `trong_khay`,
`cao_khay`, `_ve_khay`, `_xep_khay` — da go het, khong de lai duong cut.
"""
import bpy

from . import khung as K
from . import lenh
from . import nho
from . import ve as V

# ⛔ MAU KHAI MOT CHO DUY NHAT — `mau.py`. Khong che mau tai day.
# ⛔ DA TUNG SAI: `VIEN_CHON` truoc la mot bo so CHEP LAI ngay o day, nen doi
# mau trong `mau.py` khong an vao dau. Ducphan 23/09/2026: *"the deo nao lai
# co cai vien cam rat kho chiu"* — mau nam hai cho thi sua mot cho la vo ich.
M = K.M
VIEN_CHON = M.vien_chon

CAO_DAU = 24.0
GOC_KEO = 14.0


# Phien ban bo cuc ghi trong `nho`. 2 = the ghim mep tren, co dinh co
# (luat Ducphan 24/09/2026). Bo cuc ghi truoc do (1) duoc ghim lai mot lan.
BO_CUC = 2


class O:
    """Mot the chuc nang."""

    def __init__(self, ten, cac_lop, x=20, y=20, rong=300, cao=420):
        self.ten = ten
        self.cac_lop = cac_lop          # [lop panel goc, lop panel con...]
        self.x = x
        self.y = y                      # goc DUOI-trai
        self.rong = rong
        self.cao = cao
        self.cuon = 0.0
        self.gap = False
        self.loi = None
        # ⛔ KHONG TU CO THEO NOI DUNG. Ducphan 24/09/2026: *"tat ca cac
        # addon mo ra deu duoc can len tren dau cua window va co dinh kich
        # thuoc luc mo, dai ra ngan lai thi dung con lan thoi"*. Ruot dai
        # ngan the nao cung khong lam the nhay co — cuon bang con lan.
        self.tu_cao = False
        self.can_dat = False            # vua bat: cho khay biet be vung de ghim
        self._toi_da = 0.0              # cuon toi da (do lai moi luot ve)
        self.cao_toi_da = 0.0           # tran do khay dat (0 = khong tran)
        self._cao_ruot = 0.0
        self._ngu_canh = {}      # loai space -> ngu canh muon duoc

    def _ngu_canh_cho(self, context, lop):
        """Ngu canh de chay `poll()`/`draw()` cua MOT panel.

        Panel khai `bl_space_type` nao thi phai duoc thay `space_data` cua
        dung loai do. Xem ghi chu day du o `vung_cua_loai()`.

        ⛔ NHE: mot luot ve co the co hang chuc panel, nen ket qua duoc nho
        theo loai space. Luat Ducphan: *"khong quet nang trong draw()"*.

        ⛔ BO NHO CHI SONG TRONG MOT LUOT VE. `_dung_ruot` xoa no moi lan.
        Giu qua nhieu luot la giu mot `Area` co the da bi dong — va tham chieu
        vung da dong KHONG tu chet, doc no van ra so (con tro treo). Do la
        duong ngan nhat lam Blender vang, dung cai luat "khong duoc gay anh
        huong, vang" cam.

        ⛔ KHONG TRA VE NGU CANH THAT. Chi muon `space_data` va `area`; con
        `region` van phai la `VungGia` cua o, khong thi addon nao tu tinh co
        theo `context.region.width` se lay be ngang cua CUA SO KHAC.
        """
        loai = getattr(lop, 'bl_space_type', 'VIEW_3D')
        if loai == cua_so_loai():
            return context          # dang o dung loai roi, khong muon gi
        nho = self._ngu_canh
        if loai not in nho:
            v = vung_cua_loai(loai)
            nho[loai] = ({'space_data': v['space_data'], 'area': v['area']}
                         if v else None)
        them = nho[loai]
        if not them:
            # Tren man hinh khong co vung nao loai do. Tra nguyen ngu canh —
            # panel tu `poll()` ra False va bi bo qua, dung nhu panel N goc.
            return context
        return K.NguCanh(context, them)

    def _ruot(self, context, s):
        """Ruot cua o. LUON DUNG LAI, khong nho qua nhieu luot ve.

        ⛔ DA TUNG NHO LAI VA LAM BLENDER VANG. 23/09/2026 Ducphan bao
        *"blender vua crash khi dieu chinh cac khung cua so addon"*. Nhat ky
        `~/BlenderTemp/blender.crash.txt` chi thang:

            khung.py:1986 _ve_nut_enum      <- doc getattr(dl, ten)
            o.py ve                          <- duong TO MAU
            PyObject_GetOptionalAttr         <- con tro bpy_struct DA CHET

        Ly do: cay `Khung` giu tham chieu toi `bpy_struct` cua addon (`dl`,
        `pr`). Nho cay do lai qua nhieu luot ve nghia la giu nhung con tro do
        song lau hon Blender cho phep — Blender giai phong du lieu (doi canh,
        chay mot lenh, undo) roi luot TO MAU sau dam vao con tro treo, va do la
        mot cu vang o tang C, Python khong bat duoc.

        ⛔ KHONG KHOI PHUC LAI CAI NHO NAY. No chi tiet kiem 8,10 -> 6,74 ms
        (1,4 ms), vi tien nam o SO LENH VE chu khong o viec dat. Cai chua lag
        that su la HAM NHIP 30 Hz trong `khay_ui._ve_lai_ham()` — cai do an
        toan vi no khong giu gi lai ca. Doi 1,4 ms lay mot cu vang la lo.
        """
        return self._dung_ruot(context, s)

    # ------------------------------------------------------------- ve
    def _dung_ruot(self, context, s):
        """Chay `draw()` cua moi panel vao mot `Khung`, roi DO chieu cao.

        ⛔ PHAI LAM TRUOC KHI VE MOT NET NAO. The tu co theo noi dung thi phai
        biet ruot cao bao nhieu TRUOC khi ve cai nen — biet sau thi nen da ve
        sai co roi. Va ruot cua addon dai ngan tuy canh quay (danh sach camera,
        so anh trong gallery, so muc vat lieu), nen do lai moi luot."""
        le = 6 * s
        t_rong = self.rong - 2 * le
        # ⛔ XOA BO NHO NGU CANH MOI LUOT VE — xem `_ngu_canh_cho()`. Giu lai
        # la giu mot `Area` co the da bi khach dong.
        self._ngu_canh = {}
        # Addon nao tu tinh co theo `context.region.width` thi phai nhin thay
        # BE NGANG CUA O, khong phai be ngang ca vung ve.
        context = K.NguCanh(context, {
            'region': K.VungGia(getattr(context, 'region', None),
                                t_rong, self.cao)})
        kh = K.Khung()
        self.loi = None
        do_sau = {}
        # ⛔ SOAT LOP CHET TRUOC KHI VE. Xem ghi chu o `LAM_MOI`.
        if any(not getattr(c, 'is_registered', False) for c in self.cac_lop):
            f = LAM_MOI[0]
            if f is not None:
                try:
                    f()
                except Exception as e:                       # noqa: BLE001
                    print('[DP_Hub] lay lai danh sach panel hong: %r' % (e,))
        # ⛔ GAP BANG CHA LA GIAU HAN CA CAY CON, ke ca dau bang cua chung.
        # Panel N lam dung the. Truoc day `if gap: continue` chi bo THAN cua
        # chinh panel do, con panel con van ve ra nguyen: gap "Masks" xong
        # van con ba bang Area/Light/Colour lo lung. Nang hon: gap bang GOC
        # cua DP-PostProcessing khong thu gon duoc gi — ma ruot o do cao
        # ~4.200 px, nen do la cai nut khach bam dau tien. Do 23/09/2026.
        # `cac_lop` da xep cha-truoc-con nen mot vong la du.
        gap_cha = set()
        for lop in self.cac_lop:
            # Van con lop chet (addon vua go han) thi BO QUA, dung ve.
            if not getattr(lop, 'is_registered', False):
                continue
            _khoa = getattr(lop, 'bl_idname', None) or lop.__name__
            _cha = getattr(lop, 'bl_parent_id', '') or ''
            if _cha and _cha in gap_cha:
                gap_cha.add(_khoa)
                continue
            # Moi panel cua addon mot DAU BANG gap duoc — y nhu panel N goc.
            # Panel con thut vao mot chut de doc ra no thuoc panel nao.
            # ⛔ THUT LE THEO DO SAU. Bang cap 3 (`DPP_PT_mask_area` la
            # chau cua bang goc) thut bang bang cap 2 thi khong doc ra no
            # thuoc bang nao. Do 23/09/2026.
            khoa = getattr(lop, 'bl_idname', None) or lop.__name__
            sau = (do_sau.get(_cha, 0) + 1) if _cha else 0
            do_sau[khoa] = sau
            con = sau > 0
            mac = 'DEFAULT_CLOSED' in (getattr(lop, 'bl_options', None) or ())

            # ⛔ HOI `poll()` TRUOC KHI VE DAU BANG. Panel bi giau ma van ra
            # mot dau bang la khach thay mot muc bam vao khong co gi — panel N
            # goc giau han ca dong.
            # ⛔ MOI PHAN PHAI THAY DUNG LOAI SPACE CUA CHINH NO. Xem ghi
            # chu o `vung_cua_loai()`: cua so DP la TEXT_EDITOR, nen panel cua
            # IMAGE_EDITOR (DP Optimize · DP Post) `poll()` ra False va o hien
            # ra TRANG TRON. Muon `space_data` cua mot vung that dung loai.
            ctx_lop = self._ngu_canh_cho(context, lop)
            try:
                if hasattr(lop, 'poll') and not lop.poll(ctx_lop):
                    continue
            except Exception:                                # noqa: BLE001
                continue

            # --- dau bang: vo cua ta, chu cua addon
            dau = kh.row()
            dau._dau_bang = khoa
            dau._dau_dam = not con
            gap = K.dang_gap(khoa, mac)
            if gap:
                gap_cha.add(khoa)
            nhan = getattr(lop, 'bl_label', '') or ''
            if nhan:
                dau.label(text=nhan)
            if not K.chay_draw_header(lop, ctx_lop, dau) and not nhan:
                dau.label(text=khoa)
            K.chay_draw_header_preset(lop, ctx_lop, dau)
            if gap:
                continue                     # gap: KHONG chay draw() chut nao
            than = kh.column()
            for _ in range(min(sau, 3)):
                than = than.column()         # thut mot bac cho moi cap
            loi = K.chay_draw(lop, ctx_lop, than)
            if loi and loi != 'AN' and not self.loi:
                self.loi = loi
        self._cao_ruot = kh.do(t_rong, s)
        return kh

    def co_tu_nhien(self, s):
        """Chieu cao the vua khit ruot — de khay/khung goi khi tu co."""
        return self._cao_ruot + CAO_DAU * s + 12 * s

    def ve(self, context, s, vung, dang_chon=False):
        """Ve ca cai the, roi DONG DAU cai the nay len moi o bam vua sinh ra.

        ⛔ THIEU DAU NAY LA MOI NUT CHAY SAI VUNG. Do 23/09/2026:
        `_chay_op` hoi `v.get('o')` de biet nut nay thuoc addon nao ma dinh
        tuyen operator ve dung loai editor. Nhung chi NAM o khung the
        (`than`, `dau`, `dong`, `thanh_cuon`, `co`) duoc gan `'o'`; moi o
        bam cua NOI DUNG — tuc moi cai nut khach bam — deu khong co. Nen
        `loai_space_cua(None)` luon tra `VIEW_3D`, va ca doan dinh tuyen
        IMAGE_EDITOR la MA CHET.

        Hau qua do duoc: `dpp.mask_pick` ("Click The Material") — duong DUY
        NHAT doi mau mot vat lieu cua DP-PostProcessing — bung ong hut tren
        viewport 3D thay vi tren buc anh. Bam khong duoc gi, khong mot dong
        bao. Keo theo `dpp.mask_paint` va `dpp.mask_adjust`.
        """
        dau_vung = len(vung)
        try:
            self._ve_that(context, s, vung, dang_chon)
        finally:
            for v in vung[dau_vung:]:
                if 'o' not in v:
                    v['o'] = self

    def _ve_that(self, context, s, vung, dang_chon=False):
        kh = None
        if not self.gap:
            kh = self._ruot(context, s)
            if self.tu_cao:
                # Tu co theo noi dung, nhung khong vuot tran khay/man hinh.
                tran = self.cao_toi_da or self.cao
                self.cao = max(80.0, min(tran, self.co_tu_nhien(s)))
                # ⛔ KHONG NAN `y` O DAY. Da thu 23/09/2026 va bo: the tu
                # cao gan bang ca vung ve thi phep nan ep `y` ve sat 0, keo
                # tut ca cum o xuong va day noi dung ra ngoai tam nhin — bai
                # do tut tu 13/13 xuong 9/13. `Khay._nan_the` da keo the ve
                # trong man hinh o khung hinh ke tiep; cai gia la mot nhip
                # nhay, re hon nhieu so voi xo lech ca bo cuc.
        cao = CAO_DAU * s if self.gap else self.cao
        # ⛔ VUNG NEN THE PHAI NAP TRUOC NOI DUNG. `Khay._tim` quet NGUOC danh
        # sach (cai nap sau nam tren), nen nap nen the sau cung la no che het
        # moi cai nut ben trong — moi cu bam roi vao nen, khong nut nao an.
        # Da dam dung bay nay 23/09/2026: bai do ra 0/5 ma khong bao loi.
        if not self.gap:
            K.nap(vung, {'x': self.x, 'y': self.y, 'w': self.rong,
                         'h': self.cao, 'kieu': 'than', 'o': self})
        # ⛔ VIEN PHAI BO TRON THEO RUOT. `V.vien()` ve bon thanh thang nen
        #   goc luon vuong — Ducphan 23/09/2026: *"khung trong thi bo tron,
        #   xong ngoai thi van vuong nhon ???"*. `vien_tron` ve mot hinh bo
        #   tron mau vien roi de nen len tren, nen goc khop han.
        r_the = 6 * s
        V.vien_tron(self.x, self.y + self.cao - cao, self.rong, cao,
                    VIEN_CHON if dang_chon else M.nut_vien, M.nen_panel,
                    max(1.0, 1.0 * s), r_the)

        # --- thanh tieu de: BO TRON HAI GOC TREN, hai goc duoi vuong (no nam
        #     tren than the; bo tron ca bon la khoet hai cai khuyet vao than).
        dy = self.y + self.cao - CAO_DAU * s
        V.hop_tren_tron(self.x, dy, self.rong, CAO_DAU * s, M.nen_dau, r_the)
        co = K.CO_CHU * s
        V.chu("▾ " if not self.gap else "▸ ", self.x + 6 * s,
              dy + (CAO_DAU * s - co) / 2 + 1 * s, co, M.chu)
        V.chu_cat(self.ten, self.x + 20 * s,
                  dy + (CAO_DAU * s - co) / 2 + 1 * s,
                  self.rong - 46 * s, co, M.chu, dam=True)
        V.chu("✕", self.x + self.rong - 16 * s,
              dy + (CAO_DAU * s - co) / 2 + 1 * s, co, M.chu)
        K.nap(vung, {'x': self.x, 'y': dy, 'w': self.rong - 22 * s,
                     'h': CAO_DAU * s, 'kieu': 'dau', 'o': self})
        K.nap(vung, {'x': self.x + self.rong - 22 * s, 'y': dy,
                     'w': 22 * s, 'h': CAO_DAU * s, 'kieu': 'dong',
                     'o': self})
        if self.gap:
            return

        # --- than
        le = 6 * s
        tx = self.x + le
        t_rong = self.rong - 2 * le
        t_duoi = self.y + le
        t_cao = self.cao - CAO_DAU * s - 2 * le

        # (ruot da dung va do xong o `_dung_ruot`, ngay dau `ve`)
        toi_da = max(0.0, self._cao_ruot - t_cao)
        self.cuon = max(0.0, min(self.cuon, toi_da))

        K.cat_vao(tx, t_duoi, t_rong, t_cao)
        kh.ve(tx, t_duoi + t_cao + self.cuon, s, vung)
        K.cat_ra()

        # --- thanh cuon: PHAI NHIN THAY VA PHAI KEO DUOC
        # ⛔ Ban dau thanh nay rong 3 px va mo — do ra "khong ai doan duoc la
        # con noi dung ben duoi". Ruot mot so addon dai 1.200-3.500 px tuy
        # canh quay, nen day la duong duy nhat de biet minh dang o dau.
        self._toi_da = toi_da
        if toi_da > 0.5:
            wc = 8 * s
            xc = self.x + self.rong - wc - 2 * s
            V.hop(xc, t_duoi, wc, t_cao, M.o_chu, wc / 2)
            h = max(28 * s, t_cao * (t_cao / self._cao_ruot))
            p = self.cuon / toi_da
            yc = t_duoi + (t_cao - h) * (1.0 - p)
            tro = K.tro_trong(xc, t_duoi, wc, t_cao)
            V.hop(xc + 1 * s, yc, wc - 2 * s, h,
                  M.nut_tro if tro else M.nut, (wc - 2 * s) / 2)
            V.vien(xc + 1 * s, yc, wc - 2 * s, h,
                   M.vien_tro if tro else M.nut_vien, 1.0)
            K.nap(vung, {'x': xc, 'y': t_duoi, 'w': wc, 'h': t_cao,
                         'kieu': 'thanh_cuon', 'o': self,
                         'cao_thanh': h, 'duoi': t_duoi, 'vung_cao': t_cao})

        if self.loi:
            V.chu_cat("⚠ " + self.loi, tx, self.y + 2 * s, t_rong,
                      K.CO_CHU * s * 0.9, M.do)

        # --- goc keo doi co
        V.chu("◢", self.x + self.rong - 13 * s, self.y + 3 * s,
              K.CO_CHU * s, M.nut)
        K.nap(vung, {'x': self.x + self.rong - GOC_KEO * s, 'y': self.y,
                     'w': GOC_KEO * s, 'h': GOC_KEO * s,
                     'kieu': 'co', 'o': self})


class Khay:
    """Giu cac o, phan phoi cu bam, va nho ai dang o tren."""

    def __init__(self):
        self.cac_o = []
        self.vung = []
        self.danh_muc = []          # [{'ten','lop','o'}] — moi o CO THE bat
        self.rong_vung = 1200.0
        self.cao_vung = 800.0
        self.can_ghi = False        # co gi doi -> ghi lai khi tha tay
        self.mx = -1e9              # chuot dang o dau (de to sang o duoi no)
        self.my = -1e9
        self._tro_cu = None
        self.keo = None
        self.menu = None            # o chon enum dang xo ra
        self.noi = None             # luoi anh, hoac bang cua mot Menu/Popover
        self.soan = None            # o nhap chu dang go

    def them(self, o):
        self.cac_o.append(o)

    # ------------------------------------------------- danh muc o
    def dang_ky(self, ten, cac_lop):
        """Ghi ten mot o CO THE bat. Chua bat thi chua ve gi ca.

        ⛔ DANH SACH NAY = ADDON DA CAI VA DA BAT. Ai chua mua thi khong co o
        de bat — luat Ducphan 23/09/2026. Cho nay chi giu ten; viec loc "co
        quyen hay khong" da xay ra o cho khac (quet duoc = khach so huu)."""
        for m in self.danh_muc:
            if m['ten'] == ten:
                m['lop'] = cac_lop
                return m
        m = {'ten': ten, 'lop': cac_lop, 'o': None}
        self.danh_muc.append(m)
        return m

    def _muc(self, ten):
        for m in self.danh_muc:
            if m['ten'] == ten:
                return m
        return None

    def bat(self, ten):
        m = self._muc(ten)
        if m is None or m['o'] is not None:
            return m['o'] if m else None
        # ⛔ NHAN `ui_scale` cho moi be do. Dat so tran la tren may ui_scale
        # 1.5 the bay ra sai cho va sai co.
        s = K._ui()
        rong = 330 * s
        # Vi tri + chieu cao that dat o `_ghim_tren()` khi khay biet be vung
        # (luc bat co the chua ve lan nao, `cao_vung` con 0).
        o = O(ten, m['lop'], x=24 * s, y=12.0, rong=rong, cao=560 * s)
        o.can_dat = True
        o.thu_tu_mo = len(self.cac_o)
        m['o'] = o
        self.cac_o.append(o)
        self.can_ghi = True
        doi_roi()
        return o

    def tat(self, ten):
        m = self._muc(ten)
        if m is None or m['o'] is None:
            return False
        if m['o'] in self.cac_o:
            self.cac_o.remove(m['o'])
        m['o'] = None
        self.can_ghi = True
        return True

    def dao(self, ten):
        m = self._muc(ten)
        if m is None:
            return None
        return self.tat(ten) or self.bat(ten)

    def quen_trang_thai(self):
        """Bo MOI thu khay dang giu co chua `bpy_struct` qua nhieu luot ve.

        ⛔ GOI KHI ADDON DANG KY LAI LOP. Ducphan 23/09/2026: *"tao chuyen
        ngon ngu tieng viet sang tieng anh cua dp-lighting, no loi giao dien
        roi 1 luc sau vang luon"*.

        Doi ngon ngu -> `dp_lighting.dat_ngon_ngu()` GO roi GAN lai ca bo lop,
        ke ca `LightingSetupSettings`. `Scene.lighting_setup` cu bi GIAI PHONG
        va tao moi. `kh.vung` thi dung lai moi luot ve nen khong sao, NHUNG
        bon thu nay song qua nhieu luot va van om con tro cu:

            self.menu   bang xo dang mo      (giu `dl`)
            self.soan   o dang go chu/so     (giu `dl`)
            self.keo    cu keo dang do       (giu ca mot o bam)
            self.noi    luoi anh / bang Menu (giu `dl`)
            lenh.DICH   dich cua hop chon tep

        Dam vao mot trong so do sau khi dang ky lai la vang o tang C — Python
        khong bat duoc. Bo het thi khach mat mot bang xo dang mo; doi lai
        Blender khong chet.
        """
        self.menu = None
        self.noi = None
        self.keo = None
        if self.soan is not None:
            self.soan = None
            K.DANG_SOAN[0] = None
        self._tro_cu = None
        try:
            lenh.DICH[0] = None
        except Exception:                                    # noqa: BLE001
            pass

    def _ten_cua(self, o):
        for m in self.danh_muc:
            if m['o'] is o:
                return m['ten']
        return o.ten

    def _o_tren_cung(self, o):
        if o in self.cac_o:
            self.cac_o.remove(o)
            self.cac_o.append(o)

    # ------------------------------------------------------------- ve
    def ve(self, context, rong=None, cao=None):
        s = K._ui()
        # Chuyen vi tri chuot xuong tang ve, de widget duoi con tro sang len.
        K.TRO[0], K.TRO[1] = self.mx, self.my
        if rong:
            self.rong_vung = float(rong)
        if cao:
            self.cao_vung = float(cao)
        # ⛔ ADDON CO THE DANG KY LAI LOP GIUA CHUNG (doi ngon ngu cua
        # DP_Lighting). Luc do moi `bpy_struct` khay dang giu qua nhieu luot
        # ve deu thanh con tro treo, nen phai quen sach trang thai.
        #
        # ⛔ KHONG DUOC DEM `Panel.__subclasses__()`. Do la cach lam CU va no
        # SAI: con so do con TUT khi Python thu gom mot lop Panel chet, va
        # TANG khi bat ky script nao dinh nghia them mot lop — chang lien quan
        # gi toi addon cua the. Do 23/09/2026: 1255 -> 1245 giua hai khung
        # hinh ma khong ai dang ky lai gi, va khong deu. Moi lan tut la
        # `quen_trang_thai()` vut sach bang xo dang mo, bang chon mau dang
        # keo, chuoi dang go, cu keo dang do — ngau nhien, o CA 11 ADDON,
        # khong mot dong bao nao. Chinh no lam bo do bao
        # `enum muc_ho: 'NoneType' object has no attribute 'get'`.
        #
        # Hoi DUNG NHUNG LOP CUA CHINH CAC O: lop cu bi go thi `is_registered`
        # thanh False, lop moi thi `id()` khac. ~10 `getattr` mot o mot khung
        # hinh, so voi `Khay.ve()` 8,1 ms — khong dang ke.
        try:
            # ⛔ PHAI XEP LAI — DAU HIEU KHONG DUOC PHU THUOC THU TU.
            # `_o_tren_cung()` dua the vua bam len cuoi `cac_o` (de no nam
            # tren cung), nen mot cu bam binh thuong da lam dao thu tu. Do
            # 23/09/2026: bam mo mot bang xo la khung ve ke tiep thay "dau
            # hieu doi" roi `quen_trang_thai()` xoa luon chinh cai bang vua
            # mo — bai do tut tu 13/13 xuong 10/13, va tren tay khach thi la
            # "bam ra menu roi no tat ngay".
            # ⛔ LAY TU `danh_muc`, KHONG TU `cac_o`. Do 24/09/2026: bat them
            # mot o tu menu chuot phai la `cac_o` co them lop -> dau hieu doi
            # -> `quen_trang_thai()` dong mat chinh cai menu dang tich. Danh
            # muc chua lop cua MOI addon, du o dang mo hay khong.
            dau_lop = tuple(sorted(
                (id(c), bool(getattr(c, 'is_registered', False)))
                for m in self.danh_muc
                for c in (m.get('lop') or ())))
        except Exception:                                    # noqa: BLE001
            dau_lop = None
        if dau_lop is not None and dau_lop != getattr(self, '_dau_lop', dau_lop):
            self.quen_trang_thai()
        self._dau_lop = dau_lop

        self.vung = []
        kho = V.dang_kho()          # ve kho: khong dung toi `gpu` mot ty nao
        if not kho:
            import gpu
            gpu.state.blend_set('ALPHA')
        for o in self.cac_o:
            if o.can_dat and self.cao_vung > 0:
                self._ghim_tren(o)
        for o in self.cac_o:
            # ⛔ TRAN CHIEU CAO PHAI LA VUNG VE, KHONG PHAI CHIEU CAO HIEN CO.
            # Lay `o.cao` lam tran thi the chi co lai duoc, khong bao gio to
            # ra: mo them mot bang la ruot dai ra ma the dung nguyen — noi
            # dung moi bi cat mat. Do 23/09/2026 (do phu tut 71 -> 30).
            o.cao_toi_da = max(120.0, self.cao_vung - 16.0)
            self._nan_the(o)
            o.ve(context, s, self.vung, dang_chon=(o is self.cac_o[-1]))
        if self.menu:
            self._ve_menu(s)
        if self.noi:
            self._ve_noi(context, s)
        if not kho:
            V.xa()              # do not ro hinh con lai truoc khi tra GL
            import gpu
            gpu.state.blend_set('NONE')

    def _ghim_tren(self, o):
        """O VUA MO: ghim sat MEP TREN cua so DP, cao gan kin vung ve, CO
        DINH tu day (khong tu co). Xep thanh cot tu trai sang; het be ngang
        thi cot moi bat dau lai tu trai, lech 30 px, van sat mep tren.

        Ducphan 24/09/2026: *"can len tren dau cua window va co dinh kich
        thuoc luc mo"*."""
        s = K._ui()
        le = 12 * s
        x0 = 24 * s
        buoc = o.rong + 12 * s
        moi_hang = max(1, int((self.rong_vung - x0) // buoc))
        n = getattr(o, 'thu_tu_mo', 0)
        cot, vong = n % moi_hang, n // moi_hang
        o.cao = max(120.0, self.cao_vung - 2 * le)
        o.x = x0 + cot * buoc + vong * 30 * s
        o.y = self.cao_vung - le - o.cao          # goc duoi = tren - cao
        o.cuon = 0.0
        o.can_dat = False
        self.can_ghi = True

    def _nan_the(self, o):
        """Keo mot the noi tu do ve trong vung nhin thay.

        ⛔ THE MO RA NGOAI MAN HINH LA MAT CA THANH TIEU DE. Do 23/09/2026:
        the cao 560 px dat o y=100 tren may ui_scale 1.5 cho dinh 990 px trong
        khi vung ve chi 900 — khach thay mot o khong ten, khong nut dong,
        khong keo duoc, va hang tren cung bi cat."""
        o.rong = max(180.0, min(o.rong, self.rong_vung - 8.0))
        o.cao = max(80.0, min(o.cao, self.cao_vung - 8.0))
        o.x = max(0.0, min(o.x, self.rong_vung - o.rong))
        o.y = max(0.0, min(o.y, self.cao_vung - o.cao))

    def _ve_menu(self, s):
        """Bang xo cua mot o chon.

        ⛔ PHAI CUON DUOC VA PHAI NAN VAO MAN HINH. Enum 168 muc (mau phao
        DP_Sketch) hay 99 muc (vat lieu MatPro) ve thang ra la mot cot dai
        3.400 px — phan lon nam ngoai man hinh, khong cach nao voi toi.
        Ducphan 23/09/2026: *"dai thi phai co con lan chuot"*."""
        m = self.menu
        h = K.HANG * s
        n = len(m['muc'])
        w = m['w']
        le = 4 * s
        cao_can = n * h + 2 * le
        cao = min(cao_can, max(4 * h, self.cao_vung - 16 * s))
        x = min(max(4.0, m['x']), max(4.0, self.rong_vung - w - 4.0))
        y_tren = min(max(cao + 8 * s, m['y']), self.cao_vung - 4.0)
        y_duoi = y_tren - cao

        toi_da = max(0.0, cao_can - cao)
        m['toi_da'] = toi_da
        m['cuon'] = max(0.0, min(m.get('cuon', 0.0), toi_da))
        m['hop'] = (x, y_duoi, w, cao)

        V.hop(x, y_duoi, w, cao, M.xo_nen, 4 * s)
        V.vien(x, y_duoi, w, cao, VIEN_CHON, max(1.0, 1.0 * s))
        m['vung'] = []
        co = K.CO_CHU * s
        K.cat_vao(x, y_duoi, w, cao)
        for i, (ma, ten) in enumerate(m['muc']):
            yy = y_tren - le - (i + 1) * h + m['cuon']
            if yy + h < y_duoi or yy > y_tren:
                continue                     # ngoai tam nhin: khong ve
            if m.get('tich'):
                # Menu addon: dong dang bat to mau chon, co o tich ben trai
                # — y bang danh sach addon o panel N cua DP_Hub.
                mt = self._muc(ma)
                bat = mt is not None and mt['o'] is not None
                if bat:
                    V.hop(x + 2 * s, yy, w - 4 * s, h, M.ds_chon, 3 * s)
                elif K.tro_trong(x, yy, w, h):
                    V.hop(x + 2 * s, yy, w - 4 * s, h, M.hang_tro, 3 * s)
                c = co + 2 * s
                cx, cy = x + 8 * s, yy + (h - c) / 2
                if bat:
                    # Cung mau/cung dau tich voi o tich cua panel (khung.py)
                    V.hop(cx, cy, c, c, M.tich_bat, 3 * s)
                    V.dau_tich(cx, cy, c, (0.09, 0.10, 0.12, 1), s)
                else:
                    V.vien_tron(cx, cy, c, c, M.nut_vien, M.o_chu,
                                max(1.0, 1.0 * s), 3 * s)
                V.chu_cat(ten, cx + c + 8 * s, yy + (h - co) / 2 + 1 * s,
                          w - c - 28 * s, co, M.chu)
                m['vung'].append((x, yy, w, h, ma))
                continue
            if ma == m['dang']:
                V.hop(x + 2 * s, yy, w - 4 * s, h, M.ds_chon, 3 * s)
            elif K.tro_trong(x, yy, w, h):
                V.hop(x + 2 * s, yy, w - 4 * s, h, M.hang_tro, 3 * s)
            V.chu_cat(ten, x + 8 * s, yy + (h - co) / 2 + 1 * s,
                      w - 20 * s, co,
                      M.cam if ma == m['dang'] else M.chu)
            m['vung'].append((x, yy, w, h, ma))
        K.cat_ra()
        if toi_da > 0.5:
            _ve_thanh_cuon(x + w - 7 * s, y_duoi + 2 * s, 5 * s,
                           cao - 4 * s, m['cuon'], toi_da, cao_can, s)

    # ------------------------------------------------------- re chuot
    def ro(self, mx, my):
        """Chuot vua di qua. True neu CAN VE LAI.

        ⛔ CHI VE LAI KHI O DUOI CON TRO DOI. Ve lai moi lan chuot nhich mot
        pixel la tu minh pha cai luat "khay phai nhe" — chuot di ngang qua
        viewport sinh hang tram su kien mot giay."""
        self.mx, self.my = mx, my
        v = self._tim(mx, my)
        moi = None
        if v is not None:
            moi = (v['kieu'], v.get('ten'), v.get('ma'), v.get('chi_so'),
                   v.get('gt'), v.get('khoa'))
        if moi == self._tro_cu:
            return False
        self._tro_cu = moi
        return True

    def con_tro(self, mx, my):
        """Ten con tro chuot hop voi thu dang nam duoi (mx, my).

        ⛔ PHAI TU DAT CON TRO. Ducphan 23/09/2026: *"sao trong cua so nay con
        tro chuot luc nao cung la con tro soan thao van ban the"*.
        Cua so DP la mot `TEXT_EDITOR` (chon vi no re nhat — 0,15 ms/khung so
        voi 2,32 ms cua VIEW_3D). Keymap cua Text Editor tu dat con tro chu I
        cho ca vung, va no khong biet gi ve o cua ta. Khong tu dat de thi khach
        nhin thay con tro go chu tren MOI cai nut.
        """
        if self.keo:
            k = self.keo.get('kieu')
            if k == 'boi':
                return 'TEXT'
            if k == 'so':
                return 'MOVE_X'
            if k == 'co':
                return 'SCROLL_XY'
            return 'SCROLL_XY'
        if self.soan is not None and K.trong_o_soan(self.soan, mx, my):
            return 'TEXT'
        v = self._tim(mx, my)
        if v is None:
            return 'DEFAULT'
        k = v['kieu']
        if k in ('chuoi', 'so'):
            return 'TEXT'
        if k == 'keo':
            return 'MOVE_X'
        if k in ('co', 'dau'):
            return 'SCROLL_XY'
        if k in ('ds_lan', 'thanh_cuon'):
            return 'SCROLL_Y'
        return 'DEFAULT'

    def ra_ngoai(self):
        """Chuot roi khoi vung — tat moi diem sang."""
        if self._tro_cu is None and self.mx < -1e8:
            return False
        self.mx = self.my = -1e9
        self._tro_cu = None
        return True

    # --------------------------------------------------------- cu bam
    def _tim(self, mx, my, kieu=None):
        for v in reversed(self.vung):
            if kieu and v['kieu'] != kieu:
                continue
            if not (v['x'] <= mx <= v['x'] + v['w'] and
                    v['y'] <= my <= v['y'] + v['h']):
                continue
            # ⛔ O BAM TRAN RA NGOAI VUNG CUON VAN BAM DUOC neu khong hoi
            # cai nay: mat khong thay nut do (da bi cat) ma tay van bam trung.
            ct = v.get('cat')
            if ct and not (ct[0] <= mx <= ct[0] + ct[2] and
                           ct[1] <= my <= ct[1] + ct[3]):
                continue
            return v
        return None

    def bam(self, context, mx, my):
        """Tra ve True neu nuot cu bam."""
        doi_roi()          # bam co the doi gia tri -> lan sau dung lai ruot
        # ⛔ BAM VAO CHINH O DANG GO = DAT CON TRO + BAT DAU BOI DEN. Ducphan
        # 23/09/2026: *"boi den chu hoac so de sua van khong duoc"*. Truoc day
        # moi cu bam deu chot o dang go, ke ca cu bam roi vao chinh no.
        if self.soan is not None and K.trong_o_soan(self.soan, mx, my):
            d = self.soan
            _chuan_chon(d)
            i = K.chi_so_ky_tu(d, mx)
            d['vi_tri'] = d['neo'] = i
            self.keo = {'kieu': 'boi'}
            return True
        # ⛔ DANG GO CHU MA BAM CHO KHAC LA CHOT, khong phai vut. Blender lam
        # the, va nguoi dung go xong roi bam thang sang nut ben canh.
        if self.soan is not None:
            self._chot_soan()

        if self.noi:
            return self._bam_noi(mx, my)

        if self.menu:
            hp = self.menu.get('hop')
            if hp and not (hp[0] <= mx <= hp[0] + hp[2] and
                           hp[1] <= my <= hp[1] + hp[3]):
                self.menu = None
                return True
            for (x, y, w, h, ma) in self.menu.get('vung', ()):
                if x <= mx <= x + w and y <= my <= y + h:
                    # Menu addon: bat/tat o, GIU menu mo de tich tiep.
                    if self.menu.get('tich'):
                        self.dao(ma)
                        return True
                    # Menu CHUOT PHAI khong dat gia tri — no CHAY mot lenh.
                    if self.menu.get('lenh'):
                        v_goc = self.menu.get('v')
                        self.menu = None
                        self._lam_lenh(ma, v_goc)
                        return True
                    kho = self.menu.get('kho')
                    try:
                        # `template_ID` dat mot VAT, o chon enum dat mot CHUOI
                        setattr(self.menu['dl'], self.menu['ten'],
                                kho[ma] if kho is not None else ma)
                    except Exception as e:                   # noqa: BLE001
                        print("[dp_bang] dat %s hong: %s"
                              % (self.menu['ten'], e))
                    self.menu = None
                    return True
            self.menu = None
            return True

        v = self._tim(mx, my)
        if v is None:
            return False
        return self._xu_ly(context, v, mx, my)

    def bam_doi(self, mx, my):
        """Bam dup trong o dang go: boi den CA MOT TU, y Blender.
        True neu nuot."""
        d = self.soan
        if d is None or not K.trong_o_soan(d, mx, my):
            return False
        doi_roi()
        _chuan_chon(d)
        chu = d['chu']
        i = K.chi_so_ky_tu(d, mx)

        def _chu_so(c):
            return c.isalnum() or c in '_.'

        a = b = i
        while a > 0 and _chu_so(chu[a - 1]):
            a -= 1
        while b < len(chu) and _chu_so(chu[b]):
            b += 1
        if a == b:                  # bam vao khoang trang: chon het
            a, b = 0, len(chu)
        d['neo'], d['vi_tri'] = a, b
        self.keo = None
        return True

    def _xu_ly(self, context, v, mx, my):
        o = v.get('o')
        if o is not None:
            self._o_tren_cung(o)

        # Bam vao O NHAP TEN nam trong mot dong danh sach thi dong do cung
        # duoc chon — Blender lam dung the, va khong lam the thi nguoi dung
        # sua ten mot dong ma dong dang chon lai la dong khac.
        if v['kieu'] != 'ds_muc':
            d = self._tim(mx, my, 'ds_muc')
            if d is not None:
                try:
                    dang = int(getattr(d['dl_hd'], d['ten_hd']))
                except Exception:                            # noqa: BLE001
                    dang = -1
                try:
                    setattr(d['dl_hd'], d['ten_hd'], d['chi_so'])
                except Exception:                            # noqa: BLE001
                    pass
                # ⛔ MOT CU BAM = CHON DONG, KHONG PHAI DOI TEN. O ten do
                # `UIList.draw_item` ve phu gan het be ngang dong; khong chan
                # thi khach bam chon mot khe vat lieu la nhay thang vao che do
                # go — go gi tiep la doi ten vat lieu that. Blender doi bam
                # lan hai. Do 23/09/2026 tren MatPro.
                if v['kieu'] in ('chuoi', 'tim') and dang != d['chi_so']:
                    return True

        k = v['kieu']
        if k == 'dong':
            # ⛔ TAT QUA `tat()`, dung xoa thang khoi `cac_o`. Xoa thang thi
            # `danh_muc` van giu tham chieu cu -> den bao con sang, bam bat lai
            # khong len, va lan ghi nho sau con ghi mot o khong ton tai.
            ten = self._ten_cua(v['o'])
            if not self.tat(ten) and v['o'] in self.cac_o:
                self.cac_o.remove(v['o'])
            self.ghi_nho()
        elif k == 'dau':
            self.keo = {'kieu': 'dời', 'o': v['o'], 'mx': mx, 'my': my,
                        'x': v['o'].x, 'y': v['o'].y, 'da_dời': False}
        elif k == 'co':
            self.keo = {'kieu': 'co', 'o': v['o'], 'mx': mx, 'my': my,
                        'rong': v['o'].rong, 'cao': v['o'].cao}
        elif k == 'thanh_cuon':
            o = v['o']
            # Bam vao thanh cuon: nhay toi cho vua bam, roi keo tiep.
            _cuon_toi(o, v, my)
            self.keo = {'kieu': 'cuon', 'o': o, 'v': v}
        elif k == 'nut':
            self._chay_op(v)
        elif k == 'tich':
            try:
                setattr(v['dl'], v['ten'], not getattr(v['dl'], v['ten']))
            except Exception as e:                           # noqa: BLE001
                print("[dp_bang] tich hong:", e)
        elif k == 'enum':
            # ⛔ PHAI QUA `K.muc_enum`, dung lay thang `pr.enum_items`. Enum
            # DONG (MatPro 15 ho, Tiles 8 hoa van, Sketch 168 phao) tra ve 0
            # muc qua RNA — bam ra MOT MENU RONG ma khong bao gi.
            ds = K.muc_enum(v['dl'], v['ten'], v.get('pr'))
            if len(ds) < 2:
                # Enum dong cua CHINH BLENDER (view_transform, look...) khong
                # liet ke duoc bang duong nao. Nho Blender bay menu that cua
                # no ra — khach van chon du moi muc, y panel N.
                if self._menu_goc(v):
                    return True
            self.menu = {'dl': v['dl'], 'ten': v['ten'],
                         'dang': getattr(v['dl'], v['ten']),
                         'muc': [(ma, ten_m) for ma, ten_m, _ic in ds],
                         'x': v['x'], 'y': v['y'], 'w': max(v['w'], 160)}
        elif k == 'keo':
            self.keo = {'kieu': 'so', 'v': v, 'mx': mx, 'my': my,
                        'goc': _lay_so(v), 'di': False}
        elif k == 'ds_muc':
            try:
                setattr(v['dl_hd'], v['ten_hd'], v['chi_so'])
            except Exception as e:                           # noqa: BLE001
                print("[dp_bang] chon dong danh sach hong:", e)
        elif k == 'luoi_anh':
            self._mo_luoi(v)
        elif k == 'menu_lop':
            self._mo_khung(context, v)
        elif k == 'chuoi':
            self._mo_soan(v)
        elif k == 'dat_enum':
            try:
                setattr(v['dl'], v['ten'], v['gt'])
            except Exception as e:                           # noqa: BLE001
                print("[dp_bang] dat %s = %s hong: %s"
                      % (v['ten'], v['gt'], e))
        elif k == 'gap_bang':
            K.bat_tat_gap(v['khoa'])
        elif k == 'id_xo':
            self._mo_kho_id(v)
        elif k == 'mau':
            self._mo_mau(v)
        elif k == 'tim_xo':
            self._mo_tim(v)
        elif k == 'cong_kenh':
            K.KENH_CONG[v['khoa']] = v['chi_so']
        elif k == 'cong_diem':
            self._chon_diem_cong(v)
            self.keo = {'kieu': 'diem', 'v': v}
        elif k == 'cong_xoa':
            _xoa_diem_cong(v)
        elif k == 'cong_dat_lai':
            _dat_lai_cong(v)
        elif k == 'cong_nen':
            # Bam vao nen do thi: THEM mot diem o cho vua bam, y Blender
            self._them_diem_cong(v, mx, my)
        elif k == 'moc_mau':
            try:
                v['ramp'].active_index = v['chi_so']
            except Exception:                                # noqa: BLE001
                pass
            self.keo = {'kieu': 'moc', 'v': v}
        elif k == 'duyet':
            lenh.DICH[0] = (v['dl'], v['ten'])
            try:
                bpy.ops.dpbang.duyet('INVOKE_DEFAULT',
                                     thu_muc=bool(v.get('thu_muc')))
            except Exception as e:                           # noqa: BLE001
                print("[dp_bang] mo hop chon duong hong:", e)
        elif k == 'id_go':
            try:
                setattr(v['dl'], v['ten'], None)
            except Exception as e:                           # noqa: BLE001
                print("[dp_bang] go lien ket hong:", e)
        return True

    def _menu_goc(self, v):
        """Nho chinh Blender bay menu cua mot enum ta khong liet ke duoc.

        `wm.context_menu_enum` nhan mot duong du lieu tinh tu `context`, nen
        phai ghep lai: `path_from_id` cho phan duoi, con phan tren suy tu kieu
        cua khoi du lieu chu."""
        # ⛔ KHONG DUOC GOI KHI KHONG CO GIAO DIEN. `wm.context_menu_enum`
        # cuoi cung goi `popup_menu` cua Blender; chay `--background` thi
        # khong co cua so va Blender DUMP CORE — co `/tmp/blender.crash.txt`
        # lam bang. Do 23/09/2026. Luat nha: "khong duoc gay anh huong, vang".
        if bpy.app.background:
            return False
        try:
            if bpy.context.window is None or bpy.context.area is None:
                return False
        except Exception:                                    # noqa: BLE001
            return False
        duong = _duong_context(v['dl'], v['ten'])
        if not duong:
            return False
        try:
            bpy.ops.wm.context_menu_enum('INVOKE_DEFAULT', data_path=duong)
            return True
        except Exception as e:                               # noqa: BLE001
            print("[dp_bang] menu goc %s hong: %s" % (duong, e))
            return False

    def _chon_diem_cong(self, v):
        try:
            for i, p in enumerate(v['cv'].points):
                p.select = (i == v['diem'])
        except Exception:                                    # noqa: BLE001
            pass

    def _them_diem_cong(self, v, mx, my):
        """Bam TRUNG DUONG thi them mot diem dieu khien o do.

        ⛔ BAM VAO KHOANG TRONG THI KHONG DE RA DIEM NAO. Ducphan 23/09/2026:
        *"CURVE DEO DUNG DUOC LUON"*. Truoc day bam BAT CU DAU trong khung do
        thi cung sinh mot diem moi — ma bam vao do thi la viec khach lam luon
        luon (de nhin, de bo chon). Vai cu bam la duong cong day diem rac, va
        khong co nut nao xoa chung. Blender chi them diem khi bam trung duong;
        bam cho khac la bo chon. Lam dung the.
        """
        gx, gy, gw, gh = v['khung']
        if gw <= 0 or gh <= 0:
            return
        t = max(0.0, min(1.0, (mx - gx) / gw))
        u = max(0.0, min(1.0, (my - gy) / gh))
        s = v.get('s', 1.0)
        # ⛔ `cm.evaluate(cv, t)` — xem ghi chu o `khung.py::_ve_cong`.
        try:
            tren_duong = abs(v['cm'].evaluate(v['cv'], t) - u) * gh <= 8.0 * s
        except Exception:                                    # noqa: BLE001
            tren_duong = abs(t - u) * gh <= 8.0 * s
        if not tren_duong:
            try:
                for q in v['cv'].points:
                    q.select = False
            except Exception:                                # noqa: BLE001
                pass
            return
        try:
            p = v['cv'].points.new(t, u)
            for q in v['cv'].points:
                q.select = (q == p)
            v['cm'].update()
        except Exception as e:                               # noqa: BLE001
            print("[dp_bang] them diem duong cong hong:", e)

    def _mo_mau(self, v):
        """Bang chon mau DU BO, y nhu Blender: o vuong S-V, dai Hue, dai
        Alpha, o Hex, roi moi toi bon thanh R/G/B/A.

        ⛔ THIEU O VUONG LA BANG CHET. Ducphan 23/09/2026, kem anh: *"bam vao
        doi mau thi hien ra nhu trong anh thi dung kieu gi"* — luc do bang chi
        co bon thanh truot. Chon mau la viec cua MAT: keo trong o vuong thay
        ngay mau minh muon. Bat khach mo ba con so la bat ho lam viec cua may.

        ⛔ PHAI NHO SAC (`h`) TRONG LOP NOI. Do bao hoa ve 0 (mau xam) hay do
        sang ve 0 (mau den) thi RGB khong con giu duoc sac nao ca — tinh nguoc
        ra se cho 0. Khong nho thi keo xuong day o vuong mot cai la sac nhay
        ve do, keo len lai khong ve duoc mau cu.
        """
        so_kenh = v.get('so_kenh', 3)
        # ⛔ DUNG LAY TEN RNA LAM TIEU DE. `prop(sock, "default_value",
        # text="")` cho `chu=""`, roi tieu de bang ghi thang "default_value" —
        # khach doc khong hieu gi. Hoi RNA lay cai TEN NGUOI DOC DUOC truoc,
        # het duong moi danh dung ten thuoc tinh. Do 23/09/2026.
        _chu = v.get('chu') or ''
        _pr = v.get('pr') or K._rna(v['dl'], v['ten'])
        if not _chu:
            _chu = getattr(_pr, 'name', '') or v['ten']
        # ⛔ CA BANG LAM VIEC TRONG KHONG GIAN NHIN THAY. Gia tri cua o mau
        # `subtype='COLOR'` la scene-linear; o vuong S-V, dai Hue, dai Alpha
        # va o Hex deu phai theo mau MAT NHIN THAY, khong theo so tho — khong
        # thi bang chon mau toi hon han vet mau ngay canh no, va Hex ra mot
        # ma khac han Blender. Do 23/09/2026.
        _gamma = K.la_mau_linear(_pr)
        m = _doc_hien(v['dl'], v['ten'], _gamma)
        import colorsys
        h_hien = colorsys.rgb_to_hsv(m[0], m[1], m[2])[0]
        kh = K.Khung()
        ten_kenh = ("R", "G", "B", "A")
        for i in range(so_kenh):
            h = kh.row()
            h.label(text=ten_kenh[i])
            h.prop(v['dl'], v['ten'], index=i, slider=True, text="")
        self.noi = {'kieu': 'mau', 'kh': kh, 'dl': v['dl'], 'ten': v['ten'],
                    'chu': _chu, 'so_kenh': so_kenh, 'gamma': _gamma,
                    'h': h_hien, 'x': v['x'], 'y': v['y'],
                    'che_do': _CHE_DO_MAU[0],
                    'rong': max(v['w'], 240.0), 'giu': True}

    def _mo_tim(self, v):
        """Danh sach de chon cho `prop_search`."""
        try:
            kho = getattr(v['kho'], v['kho_ten'])
            ds = [(x.name, x.name) for x in kho]
        except Exception as e:                               # noqa: BLE001
            print("[dp_bang] doc kho tim hong:", e)
            return
        if not ds:
            return
        self.menu = {'dl': v['dl'], 'ten': v['ten'],
                     'dang': getattr(v['dl'], v['ten'], None),
                     'muc': ds, 'x': v['x'], 'y': v['y'],
                     'w': max(v['w'] * 6, 200)}

    def _mo_kho_id(self, v):
        """Xo ra danh sach khoi du lieu cho `template_ID`."""
        kho, kieu = K._kho_id(v.get('pr'))
        if kho is None:
            return
        dang = getattr(v['dl'], v['ten'], None)
        ds = [(x.name, x.name) for x in kho]
        if not ds:
            return
        self.menu = {'dl': v['dl'], 'ten': v['ten'],
                     'dang': dang.name if dang is not None else None,
                     'muc': ds, 'kho': kho,
                     'x': v['x'], 'y': v['y'], 'w': max(v['w'] * 6, 200)}

    # ------------------------------------------------- o nhap chu (go)
    def _mo_soan(self, v):
        gt = str(getattr(v['dl'], v['ten']) or "")
        # ⛔ O CHU CUNG BOI DEN y nhu o so — Blender mo o nhap la chon san
        # ca chuoi. Xem `khung.ve_boi_den`.
        self.soan = {'dl': v['dl'], 'ten': v['ten'], 'chu': gt,
                     'vi_tri': len(gt), 'cu': gt, 'chi_so': -1,
                     'boi_den': bool(gt)}
        K.DANG_SOAN[0] = self.soan

    def _mo_soan_so(self, v):
        gt = _lay_so(v)
        pr = v['pr']
        goc = K.la_goc(pr)
        if goc:
            import math
            gt = math.degrees(gt)       # go bang DO, y nhu Blender
        # ⛔ O DO DAI PHAI GO BANG DUNG DON VI DANG HIEN. Canh dat
        # MILLIMETERS thi o hien "100 mm"; khong doi o day thi hop go ra
        # "0.1" (don vi Blender tran), khach go "150" mong 150 mm va nhan
        # 150 m — sai MOT NGHIN LAN. Cung mot phep nhu `goc`/radian.
        dai = None
        if not goc and K.la_do_dai(pr) and pr.subtype != 'DISTANCE_CAMERA':
            dai = K.he_so_dai()
            if dai is not None:
                gt = gt * dai[0]
        chu = ("%d" % gt) if pr.type == 'INT' else ("%g" % round(gt, 4))
        # ⛔ SO CU PHAI DUOC BOI DEN. Blender mo o so la chon san ca chuoi; go
        # mot phim la THAY HAN. Khong lam the thi o dang `6`, go `7` ra `67` —
        # khach dat nham gia tri ma khong hieu vi sao. Do 23/09/2026.
        #
        # ⛔ PHAI CAT `goc` VAO DAY. Da dam 23/09/2026: cho nay tinh ra `goc`
        # de HIEN thanh do, roi khong cat vao `self.soan`. `_chot_so()` doc
        # `d.get('goc')` nen luon nhan None, va `math.radians()` duoi do thanh
        # MA CHET. Hau qua: o hien "0.0°", khach go "15" mong 15 do, Blender
        # nhan 15 RADIAN = 859 do — gach xoay gan hai vong ruoi. Dinh ca 5 o
        # "Rotate" cua DP_MaxImporter va 2 o cua DP_Tiles.
        self.soan = {'dl': v['dl'], 'ten': v['ten'], 'chu': chu,
                     'vi_tri': len(chu), 'cu': chu, 'so': True, 'pr': pr,
                     'boi_den': True, 'goc': goc, 'dai': dai,
                     'chi_so': v.get('chi_so', -1)}
        K.DANG_SOAN[0] = self.soan

    def _chot_soan(self):
        d = self.soan
        self.soan = None
        K.DANG_SOAN[0] = None
        if d is None or d['chu'] == d['cu']:
            return
        if d.get('so'):
            self._chot_so(d)
            return
        if d.get('hex'):
            m = _tu_hex(d['chu'])
            if m is not None:
                _ghi_hien(d['dl'], d['ten'], m, d.get('so_kenh', 3),
                          d.get('gamma'))
            return
        try:
            setattr(d['dl'], d['ten'], d['chu'])
        except Exception as e:                               # noqa: BLE001
            print("[dp_bang] ghi o nhap chu hong:", e)

    def _chot_so(self, d):
        pr = d['pr']
        try:
            gt = float(eval(d['chu'], {"__builtins__": {}}, {}))
        except Exception:                                    # noqa: BLE001
            try:
                gt = float(d['chu'].strip().replace(",", "."))
            except Exception:                                # noqa: BLE001
                return              # go rac thi bo qua, giu gia tri cu
        if d.get('goc'):
            import math
            gt = math.radians(gt)       # nguoi go DO, Blender giu RADIAN
        dai = d.get('dai')
        if dai and dai[0]:
            gt = gt / dai[0]            # nguoi go mm/cm..., Blender giu BU
        gt = max(pr.hard_min, min(pr.hard_max, gt))
        if pr.type == 'INT':
            gt = int(round(gt))
        try:
            if d.get('chi_so', -1) >= 0:
                m = list(getattr(d['dl'], d['ten']))
                m[d['chi_so']] = gt
                setattr(d['dl'], d['ten'], m)
            else:
                setattr(d['dl'], d['ten'], gt)
        except Exception as e:                               # noqa: BLE001
            print("[dp_bang] ghi o so hong:", e)

    def _bo_soan(self):
        self.soan = None
        K.DANG_SOAN[0] = None

    def phim(self, event):
        """Phim go vao o nhap chu. True = da nuot, dung day tiep cho Blender.

        ⛔ CHI NUOT KHI DANG GO. Nuot phim luc khong soan la cuop het phim tat
        cua Blender — dung luat Ducphan 23/09/2026: dieu khien duoc addon
        nhung khong duoc can tro viec dang lam."""
        d = self.soan
        if d is None:
            return False
        doi_roi()          # go phim la doi chuoi dang soan
        _chuan_chon(d)
        t = event.type
        # ⛔ BA NEN: Ctrl tren Windows/Linux, Cmd (`oskey`) tren macOS.
        lenh = bool(getattr(event, 'ctrl', False) or
                    getattr(event, 'oskey', False))
        shift = bool(getattr(event, 'shift', False))
        chu = d['chu']
        if t == 'RET' or t == 'NUMPAD_ENTER':
            self._chot_soan()
        elif t == 'ESC':
            self._bo_soan()
        elif lenh and t == 'A':
            d['neo'], d['vi_tri'] = 0, len(chu)
        elif lenh and t in ('C', 'X'):
            r = K.vung_chon(d)
            if r:
                try:
                    bpy.context.window_manager.clipboard = chu[r[0]:r[1]]
                except Exception:                            # noqa: BLE001
                    pass
                if t == 'X':
                    _xoa_chon(d)
        elif lenh and t == 'V':
            try:
                dan = bpy.context.window_manager.clipboard or ''
            except Exception:                                # noqa: BLE001
                dan = ''
            dan = dan.replace('\r', '').replace('\n', ' ')
            if dan:
                _chen(d, dan)
        elif t == 'BACK_SPACE':
            if not _xoa_chon(d):
                i = d['vi_tri']
                if i > 0:
                    d['chu'] = chu[:i - 1] + chu[i:]
                    d['vi_tri'] = i - 1
        elif t == 'DEL':
            if not _xoa_chon(d):
                i = d['vi_tri']
                d['chu'] = chu[:i] + chu[i + 1:]
        elif t in ('LEFT_ARROW', 'RIGHT_ARROW', 'HOME', 'END'):
            r = K.vung_chon(d)
            if shift:
                if d.get('neo') is None:
                    d['neo'] = d['vi_tri']
            elif r and t in ('LEFT_ARROW', 'RIGHT_ARROW'):
                # Dang boi den ma bam mui ten: nhay ve mep doan, y Blender.
                d['vi_tri'] = r[0] if t == 'LEFT_ARROW' else r[1]
                d['neo'] = None
                return True
            else:
                d['neo'] = None
            if t == 'LEFT_ARROW':
                d['vi_tri'] = max(0, d['vi_tri'] - 1)
            elif t == 'RIGHT_ARROW':
                d['vi_tri'] = min(len(chu), d['vi_tri'] + 1)
            elif t == 'HOME':
                d['vi_tri'] = 0
            else:
                d['vi_tri'] = len(chu)
        else:
            ky = getattr(event, 'unicode', '')
            if lenh or not ky or ord(ky[0]) < 32:
                return True          # nuot, nhung khong them gi
            _chen(d, ky)             # dang boi den: phim dau THAY ca doan
        return True

    # --------------------------------------------- luoi anh / bang menu
    def _mo_luoi(self, v):
        """Xo ra luoi anh cua mot o enum.

        ⛔ GOM DANH SACH MOT LAN LUC MO, khong goi lai moi khung hinh. Enum
        dong cua Sketch co 168 muc — goi ham `items=` moi lan ve la tu minh
        lam cham cai minh vua hua la nhe."""
        ds = K.muc_enum(v['dl'], v['ten'], v.get('pr'))
        if not ds:
            return
        self.noi = {'kieu': 'luoi', 'dl': v['dl'], 'ten': v['ten'],
                    'muc': ds, 'dang': getattr(v['dl'], v['ten'], None),
                    'ti_le': v.get('ti_le', 5.0),
                    'x': v['x'], 'y': v['y'] + v['h'], 'vung': []}

    def _mo_khung(self, context, v):
        """Xo ra bang cua mot lop Menu / Popover — dung lai cai meo cu:
        goi `draw()` GOC cua no vao mot `Khung` cua minh."""
        lop = v['lop']
        kh = K.Khung()
        # Ngu canh addon da dat bang `context_pointer_set` phai di theo, neu
        # khong menu se doc khong ra vat cua no va xo ra RONG.
        nc = K.NguCanh(context, v.get('nc'))
        loi = K.chay_draw(lop, nc, kh)
        if loi:
            kh = K.Khung()
            kh.label(text="⚠ " + loi)
        self.noi = {'kieu': 'khung', 'kh': kh, 'x': v['x'],
                    'y': v['y'], 'rong': max(v['w'], 200.0)}

    def _ve_noi(self, context, s):
        n = self.noi
        if n['kieu'] == 'luoi':
            self._ve_luoi(n, s)
        elif n['kieu'] == 'mau':
            self._ve_bang_mau(n, s)
        else:
            self._ve_khung(n, s)

    def _ve_luoi(self, n, s):
        o = K.HANG * s * n['ti_le'] * 0.9          # canh mot tam
        le = 6 * s
        # ⛔ SO COT PHAI THEO BE NGANG CON LAI, KHONG PHAI HANG SO 6.
        # Da dam 23/09/2026, hai agent cung chi vao: truoc day `cot` chot cung
        # `min(6, so_muc)` roi `w = cot*o + (cot+1)*le` — ra 690 px co dinh.
        # Ham nan CHIEU CAO va nan `x`, nhung KHONG bao gio nan `w`. Keo cua so
        # DP hep lai (viec tu nhien nhat voi DP_Tiles: mot o mot cua so) thi
        # luoi chia han ra ngoai mep:
        #     vung 500 px -> 4/15 ho vat lieu MatPro khong bam toi
        #     vung 380 px -> 3/8 hoa van Tiles (HERRINGBONE, CHEVRON, BASKET)
        # Nay tinh nguoc: con bao nhieu cho thi xep bay nhieu cot, y Blender.
        rong_cho = max(o + 2 * le, self.rong_vung - 8 * s)
        cot_vua = max(1, int((rong_cho - le) // (o + le)))
        cot = max(1, min(6, len(n['muc']), cot_vua))
        hang = (len(n['muc']) + cot - 1) // cot
        w = cot * o + (cot + 1) * le
        # ⛔ MOT TAM DA RONG HON CA VUNG VE thi khong so cot nao cuu duoc —
        # phai co canh tam lai. Man hinh nho / ui_scale cao gap ca nay.
        if w > rong_cho:
            o = max(16.0, (rong_cho - 2 * le))
            cot, hang = 1, len(n['muc'])
            w = o + 2 * le
        h = hang * o + (hang + 1) * le
        # ⛔ NAN VAO TRONG VUNG VE. Luoi 168 mau phao cua DP_Sketch cao
        # 3198 px: khong nan thi 156/168 tam nam ngoai man hinh.
        cao_can = h
        h = min(h, max(2 * o, self.cao_vung - 16 * s))
        x = min(max(4.0, n['x']), max(4.0, self.rong_vung - w - 4.0))
        y = min(max(4.0, n['y']), max(4.0, self.cao_vung - h - 4.0))
        toi_da = max(0.0, cao_can - h)
        n['toi_da'] = toi_da
        n['cuon'] = max(0.0, min(n.get('cuon', 0.0), toi_da))
        n['hop'] = (x, y, w, h)
        V.hop(x, y, w, h, M.xo_nen, 5 * s)
        V.vien(x, y, w, h, VIEN_CHON, max(1.0, 1.0 * s))
        n['vung'] = []
        K.cat_vao(x, y, w, h)
        for i, (ma, ten, ic) in enumerate(n['muc']):
            c, r = i % cot, i // cot
            ox = x + le + c * (o + le)
            oy = y + h - le - (r + 1) * o - r * le + n['cuon']
            if oy + o < y or oy > y + h:
                continue
            if ma == n['dang']:
                # ⛔ KHONG DUNG CAM CHO CA MOT MANG. `mau.py` chot cam chi
                # danh cho vet NHO. Cho nay to ca o 112x112 px (con to hon o
                # ui_scale 1.5) — mot mang cam dac sau tam anh dang chon.
                # Blender to muc dang chon bang MAU CHON, va bang mau nha DP
                # da co san `ds_chon`. Do 23/09/2026.
                V.hop(ox - 2 * s, oy - 2 * s, o + 4 * s, o + 4 * s,
                      M.ds_chon, 3 * s)
            V.hop(ox, oy, o, o, M.o_chu, 3 * s)
            tex = K._tex_cua_muc(ma, ic)
            if tex is not None:
                V.anh(ox, oy, o, o, tex)
            else:
                V.chu_giua(ten[:12], ox, oy + o / 2, o, K.CO_CHU * s * 0.85,
                           M.chu_mo)
            n['vung'].append((ox, oy, o, o, ma))
        K.cat_ra()
        if toi_da > 0.5:
            _ve_thanh_cuon(x + w - 7 * s, y + 2 * s, 5 * s, h - 4 * s,
                           n['cuon'], toi_da, cao_can, s)

    def _ve_bang_mau(self, n, s):
        """Ve bang chon mau: tieu de · o vuong S-V + dai Hue · dai Alpha ·
        o Hex · bon thanh R/G/B/A.

        ⛔ KHONG CUON. Bang nay cao co dinh va luon vua man hinh; them thanh
        cuon vao mot thu dang KEO bang chuot la tu chuoc ro.
        """
        import colorsys
        le = 8 * s
        w = n['rong']
        cot_hue = 14 * s
        canh = max(60.0, w - 2 * le - cot_hue - le)
        co_alpha = 14 * s if n['so_kenh'] >= 4 else 0.0
        cao_chu = K.HANG * s
        kh = n['kh']
        rgb = n.get('che_do', 'RGB') == 'RGB'
        so_thanh = 3 + (1 if n['so_kenh'] >= 4 else 0)
        khe = 2 * s
        if rgb:
            cao_kh = kh.do(w - 2 * le, s)
        else:
            cao_kh = so_thanh * cao_chu + (so_thanh - 1) * khe
        cao = (le + cao_chu + le + canh + le +
               ((co_alpha + le) if co_alpha else 0.0) +
               cao_chu + le + cao_chu + le + cao_kh + le)

        x = min(max(4.0, n['x']), max(4.0, self.rong_vung - w - 4.0))
        y_tren = min(max(cao + 8 * s, n['y']), self.cao_vung - 4.0)
        y = y_tren - cao
        n['hop'] = (x, y, w, cao)
        V.hop(x, y, w, cao, M.xo_nen, 5 * s)
        V.vien(x, y, w, cao, VIEN_CHON, max(1.0, 1.0 * s))

        m = _doc_hien(n['dl'], n['ten'], n.get('gamma'))
        hs, ss, vs = colorsys.rgb_to_hsv(m[0], m[1], m[2])
        # Sac chi tin duoc khi con mau; xam/den thi giu sac da nho.
        if ss > 1e-4 and vs > 1e-4:
            n['h'] = hs
        h_dung = n['h']

        cy = y_tren - le - cao_chu
        V.chu(n['chu'], x + le, cy + 3 * s, K.CO_CHU * s, M.chu_dau,
              dam=True)

        # ---- o vuong S-V ---------------------------------------------
        sx, sy = x + le, cy - le - canh
        # ⛔ VE BANG DAI DUC, KHONG CHONG MOT LOP DEN TRONG SUOT LEN.
        # Da do 23/09/2026 va chup lai: chong lop thi ca o vuong ra DEN SI —
        # gia tri alpha tren dinh khong an vao dau trong luot ve cua ta. Nen
        # tinh thang mau tung dai: dinh dai la hsv(h, s, 1), day dai la den.
        # Do sang giam tuyen tinh tu dinh xuong day dung bang v, nen ket qua
        # y het o vuong S-V cua Blender ma khong nho gi toi phep tron.
        _n = 32
        _b = canh / _n
        for _i in range(_n):
            _c0 = colorsys.hsv_to_rgb(h_dung, _i / _n, 1.0) + (1.0,)
            _c1 = colorsys.hsv_to_rgb(h_dung, (_i + 1.0) / _n, 1.0) + (1.0,)
            V.hop_4goc(sx + _i * _b, sy, _b, canh,
                       (0, 0, 0, 1), (0, 0, 0, 1), _c1, _c0)
        V.vien(sx, sy, canh, canh, M.hop_vien, max(1.0, 1.0 * s))
        n['sv'] = (sx, sy, canh, canh)
        _ve_moc_tron(sx + ss * canh, sy + vs * canh, 4 * s)

        # ---- dai Hue (doc) -------------------------------------------
        hx, hy = sx + canh + le, sy
        buoc = canh / 6.0
        for i in range(6):
            c1 = colorsys.hsv_to_rgb(i / 6.0, 1.0, 1.0) + (1.0,)
            c2 = colorsys.hsv_to_rgb((i + 1) / 6.0, 1.0, 1.0) + (1.0,)
            V.hop_4goc(hx, hy + i * buoc, cot_hue, buoc, c1, c1, c2, c2)
        V.vien(hx, hy, cot_hue, canh, M.hop_vien, max(1.0, 1.0 * s))
        n['hue'] = (hx, hy, cot_hue, canh)
        _ve_vach_ngang(hx, hy + h_dung * canh, cot_hue, 2 * s)

        day = sy - le
        # ---- dai Alpha -----------------------------------------------
        if co_alpha:
            ax, ay = x + le, day - co_alpha
            rong_a = w - 2 * le
            # Cung ly do nhu o vuong S-V: tron TAY voi nen xam, ve dac.
            nen = (0.35, 0.35, 0.35)

            def _tron(a):
                return tuple(nen[j] * (1.0 - a) + m[j] * a
                             for j in range(3)) + (1.0,)

            _n2 = 32
            _b2 = rong_a / _n2
            for _i in range(_n2):
                _c0 = _tron(_i / _n2)
                _c1 = _tron((_i + 1.0) / _n2)
                V.hop_4goc(ax + _i * _b2, ay, _b2, co_alpha,
                           _c0, _c1, _c1, _c0)
            V.vien(ax, ay, rong_a, co_alpha, M.hop_vien, max(1.0, 1.0 * s))
            n['alpha'] = (ax, ay, rong_a, co_alpha)
            _ve_vach_doc(ax + m[3] * rong_a, ay, co_alpha, 2 * s)
            day = ay - le
        else:
            n['alpha'] = None

        # ---- o Hex ----------------------------------------------------
        hxx, hxy = x + le, day - cao_chu
        rong_nhan = 34 * s
        V.chu('Hex', hxx, hxy + 4 * s, K.CO_CHU * s, M.chu)
        ox = hxx + rong_nhan
        ow = w - 2 * le - rong_nhan
        V.hop(ox, hxy, ow, cao_chu, M.o_chu, K.BO_GOC * s)
        V.vien(ox, hxy, ow, cao_chu, M.hop_vien, max(1.0, 1.0 * s))
        d = self.soan
        if d is not None and d.get('hex'):
            K.ve_o_soan(d, ox, hxy, ow, cao_chu, s)
        else:
            V.chu(_ra_hex(m), ox + 5 * s, hxy + 4 * s, K.CO_CHU * s, M.chu)
        n['hex'] = (ox, hxy, ow, cao_chu)

        # ---- hang the RGB / HSV / HSL --------------------------------
        # ⛔ Ducphan 23/09/2026: *"bang pick mau can hien thi them che do HSL
        # nua"*. Blender dat ba the nay ngay tren cac thanh truot.
        co = K.CO_CHU * s
        ty = hxy - le - cao_chu
        rong_the = (w - 2 * le) / 3.0
        n['the'] = []
        for i, ten_the in enumerate(TEN_CHE_DO):
            tx = x + le + i * rong_the
            dang = ten_the == n.get('che_do', 'RGB')
            V.hop(tx, ty, rong_the, cao_chu, M.nut_nhan if dang else M.nut,
                  K.BO_GOC * s)
            V.vien(tx, ty, rong_the, cao_chu, M.nut_vien, max(1.0, 1.0 * s))
            V.chu_giua(ten_the, tx, ty + (cao_chu - co) / 2 + 1 * s, rong_the,
                       co, M.chu_nut if dang else M.chu)
            n['the'].append((tx, ty, rong_the, cao_chu, ten_the))

        # ---- bon thanh R/G/B/A hoac H/S/V(L)/A -----------------------
        n['vung'] = []
        n['thanh'] = []
        if rgb:
            kh.ve(x + le, ty - le, s, n['vung'])
            return
        # ⛔ H/S/V KHONG CO THUOC TINH RNA NAO de goi `prop()` — tu ve, tu
        # keo. Tinh trong KHONG GIAN NHIN THAY nhu phan con lai cua bang.
        ba = _ba_so(n, m)
        gia = list(ba) + ([m[3]] if so_thanh > 3 else [])
        nhan = ('H', 'S', 'L' if n['che_do'] == 'HSL' else 'V', 'A')
        for i in range(so_thanh):
            ry = ty - le - (i + 1) * cao_chu - i * khe
            V.chu(nhan[i], x + le, ry + 4 * s, co, M.chu)
            V.hop(ox, ry, ow, cao_chu, M.o_chu, K.BO_GOC * s)
            p = max(0.0, min(1.0, gia[i]))
            if p > 0.001:
                V.hop(ox, ry, ow * p, cao_chu, M.truot_ruot, K.BO_GOC * s)
            V.vien(ox, ry, ow, cao_chu, M.nut_vien, max(1.0, 1.0 * s))
            V.chu_giua('%.3f' % gia[i], ox, ry + (cao_chu - co) / 2 + 1 * s,
                       ow, co, M.chu)
            n['thanh'].append((ox, ry, ow, cao_chu, i))

    def _ve_khung(self, n, s):
        kh = n['kh']
        cao_can = kh.do(n['rong'] - 12 * s, s) + 12 * s
        cao = min(cao_can, max(3 * K.HANG * s, self.cao_vung - 16 * s))
        x = min(max(4.0, n['x']),
                max(4.0, self.rong_vung - n['rong'] - 4.0))
        y_tren = min(max(cao + 8 * s, n['y']), self.cao_vung - 4.0)
        y_duoi = y_tren - cao
        toi_da = max(0.0, cao_can - cao)
        n['toi_da'] = toi_da
        n['cuon'] = max(0.0, min(n.get('cuon', 0.0), toi_da))
        n['hop'] = (x, y_duoi, n['rong'], cao)
        V.hop(x, y_duoi, n['rong'], cao, M.xo_nen, 5 * s)
        V.vien(x, y_duoi, n['rong'], cao, VIEN_CHON, max(1.0, 1.0 * s))
        n['vung'] = []
        K.cat_vao(x, y_duoi, n['rong'], cao)
        kh.ve(x + 6 * s, y_tren - 6 * s + n['cuon'], s, n['vung'])
        K.cat_ra()
        if toi_da > 0.5:
            _ve_thanh_cuon(x + n['rong'] - 7 * s, y_duoi + 2 * s, 5 * s,
                           cao - 4 * s, n['cuon'], toi_da, cao_can, s)

    def _bam_noi(self, mx, my):
        n = self.noi
        # ⛔ BAM PHAI NAM TRONG KHUNG CUA LOP NOI. Luoi 168 mau phao co hang
        # cuoi nho ra ngoai day hop — mat khong thay (da bi cat) ma tay bam
        # van trung, chon nham mot mau khong nhin thay. Do 23/09/2026.
        hp = n.get('hop')
        if hp and not (hp[0] <= mx <= hp[0] + hp[2] and
                       hp[1] <= my <= hp[1] + hp[3]):
            self.noi = None
            return True
        if n['kieu'] == 'mau':
            return self._bam_bang_mau(n, mx, my)
        if n['kieu'] == 'luoi':
            for (x, y, w, h, ma) in n.get('vung', ()):
                if x <= mx <= x + w and y <= my <= y + h:
                    try:
                        setattr(n['dl'], n['ten'], ma)
                    except Exception as e:                   # noqa: BLE001
                        print("[dp_bang] chon anh hong:", e)
                    self.noi = None
                    return True
            self.noi = None
            return True
        # bang menu / bang chinh mau: cu bam roi vao ruot thi cho no chay
        # nhu thuong. Bang chinh mau phai GIU LAI (`giu`) — dong ngay sau mot
        # cu bam thi khong keo noi mot thanh mau nao.
        vung_cu, self.vung = self.vung, list(n.get('vung', ()))
        try:
            v = self._tim(mx, my)
            if v is None:
                self.noi = None
                return True
            if not n.get('giu'):
                self.noi = None
            self._xu_ly(bpy.context, v, mx, my)
        finally:
            self.vung = vung_cu
        return True

    def _bam_bang_mau(self, n, mx, my):
        """Bam trong bang chon mau.

        ⛔ BAM LA BAT DAU MOT CU KEO, khong phai mot cu dat roi thoi. Chon mau
        bang mat la viec keo: dat con tro roi re quanh cho toi khi dung mau.
        """
        for ma in ('sv', 'hue', 'alpha'):
            r = n.get(ma)
            if r and r[0] <= mx <= r[0] + r[2] and r[1] <= my <= r[1] + r[3]:
                self.keo = {'kieu': ma, 'n': n}
                _keo_bang_mau(n, ma, mx, my)
                return True
        r = n.get('hex')
        if r and r[0] <= mx <= r[0] + r[2] and r[1] <= my <= r[1] + r[3]:
            self._mo_soan_hex(n)
            return True
        for (x, y, w, h, ten_the) in n.get('the', ()):
            if x <= mx <= x + w and y <= my <= y + h:
                n['che_do'] = ten_the
                _CHE_DO_MAU[0] = ten_the        # lan mo sau van giu, y Blender
                return True
        # ⛔ KEO TUONG DOI, y thanh so cua Blender: cham vao khong nhay gia
        # tri, di het be ngang thanh la di het dai 0..1.
        for (x, y, w, h, i) in n.get('thanh', ()):
            if x <= mx <= x + w and y <= my <= y + h:
                m = _doc_hien(n['dl'], n['ten'], n.get('gamma'))
                gia = list(_ba_so(n, m)) + [m[3]]
                self.keo = {'kieu': 'kenh', 'n': n, 'kenh': i,
                            'goc': gia[i], 'mx': mx, 'w': w}
                return True
        # Roi vao bon thanh R/G/B/A: cho chung chay nhu o thuong.
        vung_cu, self.vung = self.vung, list(n.get('vung', ()))
        try:
            v = self._tim(mx, my)
            if v is not None:
                self._xu_ly(bpy.context, v, mx, my)
        finally:
            self.vung = vung_cu
        return True

    def _mo_soan_hex(self, n):
        """Mo o Hex de go tay. `_chot_soan` doc co `hex` de ghi nguoc lai."""
        chu = _ra_hex(_doc_hien(n['dl'], n['ten'], n.get('gamma')))
        self.soan = {'dl': n['dl'], 'ten': n['ten'], 'chu': chu,
                     'vi_tri': len(chu), 'cu': chu, 'hex': True,
                     'so_kenh': n['so_kenh'], 'gamma': n.get('gamma'),
                     'boi_den': True}
        K.DANG_SOAN[0] = self.soan

    def _chay_op(self, v):
        """Chay operator cua addon, TRONG DUNG LOAI VUNG ma no can.

        ⛔ NHIEU OPERATOR DOI DUNG MOT LOAI VUNG. `dp_sketch.modal_base` tu
        huy ngay neu `context.area.type != 'VIEW_3D'` — 22/47 nut cua
        DP_Sketch. Ma huy la `{'CANCELLED'}`, khong phai loi, nen khong co gi
        in ra: khach bam, khong co gi xay ra, khong co loi giai thich nao.

        ⛔ DUNG CHOT CUNG VIEW_3D. Da dam 23/09/2026: ham nay truoc goi
        `_vung_3d()`, luon di tim VIEW_3D. Ba nut cua DP Post —
        `dpp.mask_pick` ("Click The Material", duong DUY NHAT doi mau vat
        lieu), `dpp.mask_paint`, `dpp.mask_adjust` — deu can mot vung
        `IMAGE_EDITOR` de biet khach bam vao diem nao tren anh. Dua cho chung
        mot viewport 3D thi con tro hut mau hien ra roi tat, khong mot dong
        bao nao. Nay lay dung loai vung ma chinh o do khai.

        ⛔ KHONG TIM DUOC VUNG THI PHAI NOI RA. Truoc day roi xuong chay
        `op()` khong override, tuc chay trong `TEXT_EDITOR` cua chinh cua so
        DP — operator `poll()` that bai, loi bi nuot, khach bam vao hu vo.
        """
        try:
            mod, ham = v['ma'].split('.', 1)
            op = getattr(getattr(bpy.ops, mod), ham)
        except Exception as e:                               # noqa: BLE001
            print("[dp_bang] khong thay operator %s: %s" % (v['ma'], e))
            return
        props = v.get('props', {})
        # ⛔ LOAI VUNG LAY TU CHINH O DANG BAM, khong phai tu `self`.
        # `_chay_op` la phuong thuc cua `Khay`, ma `cac_lop` thi nam o `O`.
        o = v.get('o')
        loai = loai_space_cua(o)
        if _mo_giao_dien(v['ma']):
            # Operator nay tu bay ra bang cua no -> bay TRONG CUA SO DP.
            vung = _vung_dp() or vung_cua_loai(loai) or _vung_3d()
            try:
                if vung is not None:
                    with bpy.context.temp_override(**vung):
                        op('INVOKE_DEFAULT', **props)
                    return
            except Exception as e:                           # noqa: BLE001
                print("[dp_bang] chay %s hong: %s" % (v['ma'], e))
                return
        vung = vung_cua_loai(loai)
        if vung is None and loai != 'VIEW_3D':
            # ⛔ CHAY NHO VUNG KHAC THI PHAI NOI RA. Da do 23/09/2026:
            # `dpp.mask_pick` ("Click The Material") bung ong hut tren
            # viewport 3D thay vi tren buc anh, va khach khong duoc mot dong
            # bao nao. Van chay (con hon khong lam gi), nhung viet ro len mat
            # o rang no can mot vung nao.
            vung = _vung_3d()
            if o is not None:
                o.loi = ('needs an open %s area'
                         % loai.replace('_', ' ').title())
        try:
            if vung is not None:
                with bpy.context.temp_override(**vung):
                    op('INVOKE_DEFAULT', **props)
            else:
                # ⛔ NOI RA TREN MAT O, dung chay chui roi im lang.
                if o is not None:
                    o.loi = ('needs an open %s area'
                             % loai.replace('_', ' ').title())
                print("[dp_bang] khong co vung %s de chay %s"
                      % (loai, v['ma']))
        except Exception as e:                               # noqa: BLE001
            # ⛔ NOI RA TREN MAT O, dung in vao console roi thoi. `poll()`
            # that bai la truong hop hay gap nhat, va addon da viet san cau
            # tra loi bang `poll_message_set` ("Select at least one mesh
            # object first") — panel N hien no khi re chuot, con o Hub truoc
            # day VUT DI. Khach bam, khong gi xay ra, khong mot chu nao.
            # Do 23/09/2026 tren 5 nut proxy cua DP_MaxImporter.
            if o is not None:
                t = str(e)
                if 'poll()' in t:
                    t = t.split('poll()', 1)[-1].strip(' ,.')
                    t = t.replace('failed, ', '')
                o.loi = t[:160]
            print("[dp_bang] chay %s hong: %s" % (v['ma'], e))

    # ------------------------------------------------- menu chuot phai
    def chuot_phai(self, context, mx, my):
        """Bam chuot PHAI len mot o -> bay menu ngu canh, y panel N.

        ⛔ Ducphan 23/09/2026, thu tay: *"cac thao tac chuot phai len cac cua
        so npanel dang khong co tac dung"*. Truoc day `modal` khong bat
        `RIGHTMOUSE` chut nao, nen cu bam roi thang xuong `TEXT_EDITOR` ben
        duoi va khong lam gi.

        ⛔ KHONG DUNG DUOC MENU GOC CUA BLENDER. `WM_MT_button_context` va ho
        `ui.*` (`ui.reset_default_button`, `ui.copy_data_path_button`...) deu
        bam vao "cai nut Blender dang tro toi". Widget cua ta la pixel ta tu
        ve — Blender khong biet no ton tai, nen khong co nut nao de bam vao.
        Vi the phai tu dung menu va tu lam tung viec bang Python.
        """
        v = self._tim(mx, my)
        if v is None:
            if self.menu or self.noi:
                self.menu = None
                self.noi = None
                return True
            return self._menu_addon(mx, my)
        if v['kieu'] == 'nut' and self._menu_nut(context, v, mx, my):
            return True
        if not v.get('dl') or not v.get('ten'):
            return False
        # ⛔ KHONG DOI O PHAI MANG SAN `pr`. Da dam 23/09/2026: Ducphan bao
        # *"chuc nang chuot phai cua dp maxmat khong su dung duoc"*. Rat nhieu
        # o cua DP_MaxMat la socket cua node — chung khong duoc nap kem `pr`
        # trong o bam, nen cho nay tra False va bam phai im luon.
        # Khong co san thi TRA CUU, dung tu choi.
        pr = v.get('pr') or K._rna(v['dl'], v['ten'])
        if pr is None:
            return False

        muc = [('mac_dinh', 'Reset to Default Value'),
               ('chep_gt', 'Copy Value'),
               ('dan_gt', 'Paste Value'),
               ('chep_duong', 'Copy Data Path')]
        try:
            if not pr.is_never_none and getattr(pr, 'is_animatable', False):
                muc += [('khoa_hinh', 'Insert Keyframe'),
                        ('xoa_khoa_hinh', 'Delete Keyframe')]
        except Exception:                                    # noqa: BLE001
            pass

        self.menu = {'dl': v['dl'], 'ten': v['ten'], 'dang': None,
                     'lenh': True, 'v': v, 'muc': muc,
                     'x': mx, 'y': my, 'w': 240}
        return True

    def _menu_addon(self, mx, my):
        """Chuot phai vao KHOANG TRONG cua cua so DP -> danh sach moi addon
        co o, dau tich = dang bat. Bam mot dong la bat/tat o do, menu van mo.

        Ducphan 24/09/2026: *"click chuot phai vao khoang khong nay co the
        hien thi ra danh sach addon da duoc bat va chua duoc bat"*."""
        if not self.danh_muc:
            return False
        muc = [(m['ten'], m['ten']) for m in self.danh_muc]
        self.menu = {'tich': True, 'dang': None, 'muc': muc,
                     'x': mx, 'y': my, 'w': 220}
        return True

    def _menu_nut(self, context, v, mx, my):
        """Bam chuot phai len mot NUT -> bay menu ma chinh addon cam vao
        `UI_MT_button_context_menu`.

        ⛔ DAY LA CAI DUCPHAN BAO HONG. 23/09/2026: *"chuc nang chuot phai
        cua dp maxmat khong su dung duoc"*. O map — thu khach bam nhieu nhat
        cua DP_MaxMat — la `kieu='nut'`, khong mang `dl`/`ten`, nen
        `chuot_phai` tra False ngay dong dau va cu bam roi vao hu khong.
        Mat sach: Copy map · Cut map · Paste map · Pick image in this file...
        · Clear map · Add map... · Clear channel · Copy/Cut channel. Khong mot
        duong nao khac trong Hub lam duoc nhung viec do.

        ⛔ PHAI DUA CHO ADDON MOT `button_operator` GIA. DP_MaxMat thay han
        `UI_MT_button_context_menu.draw` roi doc `type(op).__name__` de biet
        dang noi ve nut nao. Widget cua ta khong phai nut Blender nen khong co
        `button_operator` that; ta dung mot vat rong DAT DUNG TEN LOP cua
        operator, gan len no cac thuoc tinh cua chinh cu bam.

        ⛔ `UI_MT_button_context_menu.draw` GOC LA PYTHON THUAN (no chi ve lai
        cac muc cua lop cu `WM_MT_button_context`), nen goi no voi mot `self`
        gia la an toan — da doc ma Blender 5.2.2 truoc khi lam.
        """
        ma = v.get('ma') or ''
        lop = getattr(bpy.types, 'UI_MT_button_context_menu', None)
        if lop is None or not ma:
            return False
        try:
            mod, ham = ma.split('.', 1)
            ten_lop = getattr(getattr(bpy.ops, mod),
                              ham).get_rna_type().identifier
        except Exception:                                    # noqa: BLE001
            return False
        try:
            gia = type(str(ten_lop), (object,), {})()
        except Exception:                                    # noqa: BLE001
            return False
        for k, gt in (v.get('props') or {}).items():
            try:
                setattr(gia, k, gt)
            except Exception:                                # noqa: BLE001
                pass
        kh = K.Khung()
        nc = K.NguCanh(context, {'button_operator': gia})
        try:
            lop.draw(K._GiaSelf(lop, kh), nc)
        except Exception as e:                               # noqa: BLE001
            print("[dp_bang] menu chuot phai cua nut %s hong: %s" % (ma, e))
            return False
        if not kh._con:
            return False        # khong addon nao nhan cai nut nay
        self.noi = {'kieu': 'khung', 'kh': kh, 'x': mx, 'y': my,
                    'rong': max(v['w'] * 2, 240.0)}
        return True

    def _lam_lenh(self, ma, v):
        """Chay mot muc cua menu chuot phai. Hong thi in ra, khong nem tiep."""
        if v is None:
            return
        dl, ten = v['dl'], v['ten']
        pr = v.get('pr')
        ci = v.get('chi_so', -1)
        try:
            if ma == 'mac_dinh':
                _dat_mac_dinh(dl, ten, pr, ci)
            elif ma == 'chep_gt':
                _KHO_CHEP[0] = _lay_so(v) if v['kieu'] in ('keo',) \
                    else getattr(dl, ten)
                if ci >= 0:
                    _KHO_CHEP[0] = list(getattr(dl, ten))[ci]
            elif ma == 'dan_gt':
                if _KHO_CHEP[0] is None:
                    return
                if ci >= 0:
                    m = list(getattr(dl, ten))
                    m[ci] = _KHO_CHEP[0]
                    setattr(dl, ten, m)
                else:
                    setattr(dl, ten, _KHO_CHEP[0])
            elif ma == 'chep_duong':
                duong = _duong_context(dl, ten) or ten
                bpy.context.window_manager.clipboard = duong
            elif ma == 'khoa_hinh':
                dl.keyframe_insert(data_path=ten,
                                   index=ci if ci >= 0 else -1)
            elif ma == 'xoa_khoa_hinh':
                dl.keyframe_delete(data_path=ten,
                                   index=ci if ci >= 0 else -1)
        except Exception as e:                               # noqa: BLE001
            print("[dp_bang] menu chuot phai '%s' hong: %s" % (ma, e))

    # Cu keo nao CHAM VAO DU LIEU CUA CANH. Ba cai nay doi gia tri that:
    #   so    keo con so / thanh truot
    #   diem  keo mot diem tren duong cong
    #   moc   keo mot moc tren dai mau
    # Con 'dời' / 'co' / 'cuon' chi doi CHO NGOI cua cai the — canh khong
    # nhuc nhich, nen viewport khong co gi phai ve lai.
    KEO_CHAM_DU_LIEU = ('so', 'diem', 'moc', 'sv', 'hue', 'alpha', 'kenh')

    def keo_cham_du_lieu(self):
        """Cu keo dang do co doi gia tri that trong canh khong.

        ⛔ DUNG DE QUYET DINH CO DANH THUC VIEWPORT HAY KHONG. Ducphan
        23/09/2026: *"me kiep gio thi co gang di chuyen vi tri cua so addon
        cung vang luon blender"*. Truoc do moi cu nhich chuot khi keo deu goi
        `ve_lai_ca_hai()` — danh dau ve lai MOI vung cua MOI cua so khach,
        vai tram lan mot cu keo. Dat cai the sang cho khac thi canh khong doi
        gi ca; bat Blender dung lai ca N-panel va viewport 3D vai tram lan la
        vua cham vua nguy.
        """
        return bool(self.keo) and \
            self.keo.get('kieu') in self.KEO_CHAM_DU_LIEU

    def di(self, mx, my):
        """Chuot di chuyen. True neu dang giu cai gi do."""
        if not self.keo:
            return False
        k = self.keo
        if k.get('kieu') in self.KEO_CHAM_DU_LIEU:
            doi_roi()      # cu keo nay doi gia tri that -> dung lai ruot
        if k['kieu'] == 'dời':
            o = k['o']
            o.x = k['x'] + (mx - k['mx'])
            o.y = k['y'] + (my - k['my'])
            self.can_ghi = True
        elif k['kieu'] == 'co':
            o = k['o']
            cao_moi = max(80.0, k['cao'] - (my - k['my']))
            o.tu_cao = False            # keo tay roi thi thoi tu co
            o.rong = max(180.0, k['rong'] + (mx - k['mx']))
            o.y += o.cao - cao_moi
            o.cao = cao_moi
            self.can_ghi = True
        elif k['kieu'] in ('sv', 'hue', 'alpha'):
            _keo_bang_mau(k['n'], k['kieu'], mx, my)
        elif k['kieu'] == 'kenh':
            _keo_kenh(k, mx)
        elif k['kieu'] == 'boi':
            if self.soan is not None:
                self.soan['vi_tri'] = K.chi_so_ky_tu(self.soan, mx)
        elif k['kieu'] == 'diem':
            _keo_diem_cong(k['v'], mx, my)
        elif k['kieu'] == 'moc':
            _keo_moc_mau(k['v'], mx)
        elif k['kieu'] == 'cuon':
            _cuon_toi(k['o'], k['v'], my)
        elif k['kieu'] == 'so':
            if abs(mx - k['mx']) > 3 or abs(my - k.get('my', my)) > 3:
                k['di'] = True
            if k['di']:
                _dat_so(k['v'], k['goc'], mx - k['mx'])
        return True

    def tha(self):
        co = self.keo is not None
        if co and self.keo.get('kieu') in self.KEO_CHAM_DU_LIEU:
            doi_roi()
        if co and self.keo['kieu'] in ('dời', 'co'):
            self.can_ghi = True
        # ⛔ BAM MA KHONG KEO = MO O GO SO. Blender lam dung the, va khong co
        # duong nay thi moi o so chi keo duoc — khong dat noi mot con so chinh
        # xac. Do 23/09/2026 tren DP_Sketch, DP-PostProcessing, DP_CADSync.
        if co and self.keo['kieu'] == 'so' and not self.keo.get('di'):
            self._mo_soan_so(self.keo['v'])
        self.keo = None
        if self.can_ghi:
            self.ghi_nho()
        return co

    # --------------------------------------------------- nho vi tri
    def ghi_nho(self):
        """⛔ GHI LUC THA TAY, khong ghi moi lan chuot nhich. Keo mot the qua
        man hinh la vai tram su kien; ghi file moi su kien la tu minh pha cai
        luat "khay phai nhe"."""
        self.can_ghi = False
        dl = nho.doc()          # giu lai `cua_so_mo` cua `cua_so.py`
        dl['o'] = {}
        for m in self.danh_muc:
            o = m['o']
            if o is None:
                dl['o'][m['ten']] = {'bat': False}
                continue
            dl['o'][m['ten']] = {
                'bat': True,
                'x': round(o.x, 1), 'y': round(o.y, 1),
                'rong': round(o.rong, 1), 'cao': round(o.cao, 1),
                'gap': bool(o.gap),
                'thu_tu': self.cac_o.index(o)}
        dl['bo_cuc'] = BO_CUC
        nho.ghi(dl)

    def doc_nho(self):
        """Dung lai cac o theo lan truoc. Goi SAU khi da `dang_ky` het."""
        dl = nho.doc()
        if not dl:
            return False
        cac = dl.get('o') or {}
        # dung lai dung thu tu chong cua lan truoc
        ten_theo_tt = sorted(
            (k for k, v in cac.items() if v.get('bat')),
            key=lambda k: cac[k].get('thu_tu', 0))
        # ⛔ BO CUC CU (the con tu co, xep tu duoi len) GHIM LAI MOT LAN theo
        # luat 24/09. Bo cuc da ghi theo luat moi thi giu nguyen — do la
        # cach khach tu sap.
        cu = dl.get('bo_cuc', 1) < BO_CUC
        for ten in ten_theo_tt:
            v = cac[ten]
            o = self.bat(ten)
            if o is None:
                continue
            if cu:
                o.gap = bool(v.get('gap', False))
                continue                 # `_ghim_tren` dat o khung ve dau
            o.can_dat = False
            o.x = float(v.get('x', o.x))
            o.y = float(v.get('y', o.y))
            o.rong = max(180.0, float(v.get('rong', o.rong)))
            o.cao = max(80.0, float(v.get('cao', o.cao)))
            o.gap = bool(v.get('gap', False))
        self.can_ghi = False
        return True

    def lan(self, mx, my, len_xuong):
        """Lan chuot. Danh sach con ben trong duoc cuon TRUOC ca the —
        chuot dang o tren mot `template_list` thi nguoi dung muon cuon no."""
        # ⛔ BUOC LAN PHAI THEO DO DAI RUOT. Dan cung 30 px thi ruot 3.500 px
        # cua DP_Sketch can hon 100 not lan chuot moi xuong toi day.
        o_tro = self._tim(mx, my, 'than')
        dai = o_tro['o']._cao_ruot if o_tro else 0.0
        buoc = max(60.0, min(240.0, dai / 20.0))
        buoc = buoc if len_xuong else -buoc

        # Lop noi (bang xo, luoi anh, bang menu) nam TREN het — lan chuot khi
        # con tro dang o tren no phai cuon CHINH NO.
        for lop in (self.noi, self.menu):
            if not lop:
                continue
            hp = lop.get('hop')
            if not hp or not (hp[0] <= mx <= hp[0] + hp[2] and
                              hp[1] <= my <= hp[1] + hp[3]):
                continue
            td = lop.get('toi_da', 0.0)
            if td <= 0.5:
                return True             # nuot, khong cuon xuyen xuong duoi
            b = max(40.0, min(200.0, td / 8.0))
            lop['cuon'] = max(0.0, min(td, lop.get('cuon', 0.0) +
                                       (b if len_xuong else -b)))
            return True
        v = self._tim(mx, my, 'ds_lan')
        if v is not None and v.get('toi_da', 0.0) > 0.5:
            cu_c = K.CUON_DS.get(v['khoa'], 0.0)
            moi_c = max(0.0, min(v['toi_da'], cu_c + buoc))
            if abs(moi_c - cu_c) > 1e-6:
                K.CUON_DS[v['khoa']] = moi_c
                return True
            # ⛔ DANH SACH CON DA HET THI TRA CU LAN LAI CHO CA THE. Nuot cu
            # lan khi no khong con cuon duoc nua la khoa cung ca o: con tro
            # dung tren mot `template_list` thi the KHONG BAO GIO xuong duoc
            # phan duoi. Do 23/09/2026 tren DP_MaxImporter: thẻ ket o 840 px,
            # 44/92 o ben duoi khong bao gio voi toi.
        v = self._tim(mx, my, 'than')
        if v is None:
            return False
        v['o'].cuon = max(0.0, v['o'].cuon + buoc)
        return True


def _xoa_diem_cong(v):
    """Xoa cac diem DANG CHON tren duong cong.

    ⛔ GIU LAI IT NHAT HAI DIEM. `CurveMap` phai con hai dau mut, xoa het la
    Blender tu dung day mot duong moi — hoac te hon.
    """
    try:
        cv = v['cv']
        for p in [q for q in cv.points if q.select]:
            if len(cv.points) <= 2:
                break
            cv.points.remove(p)
        v['cm'].update()
    except Exception as e:                                   # noqa: BLE001
        print("[dp_bang] xoa diem duong cong hong:", e)


def _dat_lai_cong(v):
    """Dat lai duong cong ve duong cheo goc — "Reset Curve" cua Blender.

    ⛔ KHONG CO `bpy.ops` NAO LAM VIEC NAY CHO MOT `CurveMapping` bat ky, nen
    phai tu don: bo het diem giua roi keo hai dau mut ve (0,0) va (1,1).
    """
    try:
        cv = v['cv']
        while len(cv.points) > 2:
            cv.points.remove(cv.points[1])
        cv.points[0].location = (0.0, 0.0)
        cv.points[1].location = (1.0, 1.0)
        for q in cv.points:
            q.select = False
        v['cm'].update()
    except Exception as e:                                   # noqa: BLE001
        print("[dp_bang] dat lai duong cong hong:", e)


def _keo_diem_cong(v, mx, my):
    """Keo mot diem dieu khien. ⛔ `CurveMapping.update()` PHAI goi sau moi
    lan doi, khong thi duong ve ra van la duong CU."""
    gx, gy, gw, gh = v['khung']
    if gw <= 0 or gh <= 0:
        return
    t = max(0.0, min(1.0, (mx - gx) / gw))
    u = max(0.0, min(1.0, (my - gy) / gh))
    try:
        p = v['cv'].points[v['diem']]
        p.location = (t, u)
        v['cm'].update()
    except Exception as e:                                   # noqa: BLE001
        print("[dp_bang] keo diem duong cong hong:", e)


def _keo_moc_mau(v, mx):
    if v['rong'] <= 0:
        return
    t = max(0.0, min(1.0, (mx - v['trai']) / v['rong']))
    try:
        v['ramp'].elements[v['chi_so']].position = t
    except Exception as e:                                   # noqa: BLE001
        print("[dp_bang] keo moc dai mau hong:", e)


def _ve_thanh_cuon(x, y, w, h, cuon, toi_da, cao_can, s):
    """Thanh cuon cho lop noi. Ve thoi — keo thi lan chuot lo."""
    V.hop(x, y, w, h, M.o_chu, w / 2)
    ht = max(20 * s, h * (h / max(1.0, cao_can)))
    p = cuon / max(1e-6, toi_da)
    V.hop(x, y + (h - ht) * (1.0 - p), w, ht, M.nut, w / 2)


def _cuon_toi(o, v, my):
    """Dat vi tri cuon theo cho vua bam tren thanh cuon."""
    h = v['cao_thanh']
    duoi = v['duoi']
    cao = v['vung_cao']
    con = max(1.0, cao - h)
    p = 1.0 - max(0.0, min(1.0, (my - duoi - h / 2.0) / con))
    o.cuon = max(0.0, getattr(o, '_toi_da', 0.0) * p)


# ⛔ SO THE HE — DO 23/09/2026, DAY LA CHO TON TIEN NHAT CUA CA KHAY.
#
# Ducphan thu tay: *"thao chuot tren cac cua so rat lag"*. Do ra:
#       Khay.ro()  0,004 ms      (re)
#       Khay.ve()  8,097 ms      voi 9 o dang bat
#       ro() tra True 81/100 cu di chuot
# Tuc re chuot ngang qua mot o la 81 lan x 8,1 ms. Moi lan do deu chay LAI
# `draw()` GOC cua moi panel cua MOI o — trong khi bo cuc khong doi mot ly
# nao, chi co mot o sang len vi con tro di qua.
#
# Nen tach hai viec: DUNG RUOT (dat, chay draw() cua addon — dat) va TO MAU
# (re). Ruot chi dung lai khi co gi doi THAT. So nay tang khi:
#   · bam / keo / go / tha lam doi mot gia tri
#   · canh doi (depsgraph, undo, redo, doi khung hinh)
#   · bat/tat mot o, gap/mo mot dau bang, doi co o
# Re chuot KHONG tang no.
# Moc `khay_ui` cam vao: goi no de LAY LAI danh sach lop Panel cua moi o.
#
# ⛔ ADDON CO THE DANG KY LAI LOP PANEL GIUA CHUNG. Ducphan 23/09/2026:
# *"tao chuyen ngon ngu tieng viet sang tieng anh cua dp-lighting, no loi giao
# dien roi 1 luc sau vang luon"*.
# `dp_lighting.update_language` go roi dang ky lai CA BO LOP o nhip sau (nhan
# va tooltip thi Blender chi doc luc dang ky). O cua ta van giu LOP CU — lop
# Python con song nhung RNA da chet. Ve no ra thi truoc la sai chu, sau la vang.
LAM_MOI = [None]

THE_HE = [0]


def _doc_mau(dl, ten):
    """Bon so mau cua mot o, luon du bon phan tu."""
    try:
        m = list(getattr(dl, ten))
    except Exception:                                        # noqa: BLE001
        m = []
    while len(m) < 4:
        m.append(1.0)
    return [float(x) for x in m[:4]]


def _doc_hien(dl, ten, gamma):
    """Mau NHIN THAY cua mot o — da nang linear -> sRGB neu can."""
    m = _doc_mau(dl, ten)
    return list(V.mau_hien(m)) if gamma else m


def _ghi_hien(dl, ten, d, so_kenh, gamma):
    """Ghi nguoc mot mau NHIN THAY ve gia tri that cua canh."""
    _ghi_mau(dl, ten, list(V.mau_that(d)) if gamma else d, so_kenh)


def _ghi_mau(dl, ten, m, so_kenh):
    """Ghi nguoc mau vao o, chi dung so kenh ma o do that su co."""
    try:
        cu = list(getattr(dl, ten))
        for i in range(min(so_kenh, len(cu), len(m))):
            cu[i] = max(0.0, min(1.0, float(m[i])))
        setattr(dl, ten, cu)
    except Exception as e:                                   # noqa: BLE001
        print("[dp_bang] ghi mau hong:", e)


def _chuan_chon(d):
    """Doi co cu `boi_den` (ca chuoi) thanh khoang `neo`..`vi_tri`.

    Ba cho mo o go (`_mo_soan`, `_mo_soan_so`, `_mo_soan_hex`) van dat
    `boi_den=True` y nhu truoc; tu day moi phep sua chi doc mot kieu.
    """
    if d.pop('boi_den', False):
        d['neo'] = 0
        d['vi_tri'] = len(d.get('chu') or '')


def _xoa_chon(d):
    """Xoa doan dang boi den. True neu co doan de xoa."""
    r = K.vung_chon(d)
    d['neo'] = None
    if not r:
        return False
    d['chu'] = d['chu'][:r[0]] + d['chu'][r[1]:]
    d['vi_tri'] = r[0]
    return True


def _chen(d, ky):
    """Go chu vao con tro — dang boi den thi THAY doan do, y Blender."""
    _xoa_chon(d)
    i = d['vi_tri']
    d['chu'] = d['chu'][:i] + ky + d['chu'][i:]
    d['vi_tri'] = i + len(ky)


def _ra_hex(m):
    return '#%02X%02X%02X' % tuple(
        max(0, min(255, int(round(c * 255.0)))) for c in m[:3])


def _tu_hex(t):
    """'#RRGGBB' hay 'RGB' -> [r, g, b]. None neu khong doc duoc."""
    t = (t or '').strip().lstrip('#')
    if len(t) == 3:
        t = ''.join(c * 2 for c in t)
    if len(t) != 6:
        return None
    try:
        return [int(t[i:i + 2], 16) / 255.0 for i in (0, 2, 4)]
    except ValueError:
        return None


def _keo_bang_mau(n, ma, mx, my):
    """Dat lai mau theo cho con tro dang o trong bang chon mau."""
    import colorsys
    r = n.get(ma)
    if not r:
        return
    x, y, w, h = r
    ga = n.get('gamma')
    m = _doc_hien(n['dl'], n['ten'], ga)
    if ma == 'alpha':
        m[3] = max(0.0, min(1.0, (mx - x) / w if w else 0.0))
        _ghi_hien(n['dl'], n['ten'], m, n['so_kenh'], ga)
        return
    hs, ss, vs = colorsys.rgb_to_hsv(m[0], m[1], m[2])
    if ss <= 1e-4 or vs <= 1e-4:
        hs = n.get('h', hs)
    if ma == 'hue':
        hs = max(0.0, min(1.0, (my - y) / h if h else 0.0))
        n['h'] = hs
    else:                                   # o vuong S-V
        ss = max(0.0, min(1.0, (mx - x) / w if w else 0.0))
        vs = max(0.0, min(1.0, (my - y) / h if h else 0.0))
        hs = n.get('h', hs)
    rr, gg, bb = colorsys.hsv_to_rgb(hs, ss, vs)
    m[0], m[1], m[2] = rr, gg, bb
    _ghi_hien(n['dl'], n['ten'], m, n['so_kenh'], ga)


# Che do cua bang chon mau — song qua cac lan mo bang, y Blender.
TEN_CHE_DO = ('RGB', 'HSV', 'HSL')
_CHE_DO_MAU = ['RGB']


def _ba_so(n, m):
    """(H, S, V) hoac (H, S, L) cua mau nhin thay `m`, theo che do cua bang.

    ⛔ `colorsys.rgb_to_hls` TRA H, L, S — khong phai H, S, L. Doi thu tu o
    day de ca bang chi thay mot kieu (h, s, x).

    ⛔ NHO SAC VA BAO HOA KHI CHUNG MAT NGHIA. Den (V=0), hay den/trang (L=0,
    L=1) thi RGB khong con giu S; xam thi khong con giu H. Khong nho thi keo
    V xuong 0 roi keo len lai, bao hoa nhay ve 0 — cung benh `n['h']` o
    `_mo_mau`.
    """
    import colorsys
    hsl = n.get('che_do') == 'HSL'
    if hsl:
        h, x, s = colorsys.rgb_to_hls(m[0], m[1], m[2])
        s_ro = 1e-4 < x < 1.0 - 1e-4
    else:
        h, s, x = colorsys.rgb_to_hsv(m[0], m[1], m[2])
        s_ro = x > 1e-4
    k = 's_hsl' if hsl else 's_hsv'
    if s_ro:
        n[k] = s
    else:
        s = n.get(k, s)
    if not (s_ro and s > 1e-4):
        h = n.get('h', h)
    return h, s, x


def _keo_kenh(k, mx):
    """Keo mot thanh H/S/V(L)/A trong bang chon mau."""
    import colorsys
    n = k['n']
    w = k['w'] or 1.0
    gt = max(0.0, min(1.0, k['goc'] + (mx - k['mx']) / w))
    ga = n.get('gamma')
    m = _doc_hien(n['dl'], n['ten'], ga)
    i = k['kenh']
    if i == 3:
        m[3] = gt
    else:
        ba = list(_ba_so(n, m))
        ba[i] = gt
        if i == 0:
            n['h'] = gt
        elif i == 1:
            n['s_hsl' if n.get('che_do') == 'HSL' else 's_hsv'] = gt
        h, s_, x = ba
        if n.get('che_do') == 'HSL':
            m[0], m[1], m[2] = colorsys.hls_to_rgb(h, x, s_)
        else:
            m[0], m[1], m[2] = colorsys.hsv_to_rgb(h, s_, x)
    _ghi_hien(n['dl'], n['ten'], m, n['so_kenh'], ga)


def _ve_moc_tron(x, y, r):
    """Vong tron nho danh dau cho dang chon trong o S-V — vien den long vien
    trang de nhin ro tren ca nen sang lan nen toi."""
    V.vien(x - r - 1, y - r - 1, 2 * r + 2, 2 * r + 2, (0, 0, 0, 1), 1.0)
    V.vien(x - r, y - r, 2 * r, 2 * r, (1, 1, 1, 1), 1.0)


def _ve_vach_ngang(x, y, w, day):
    V.hop(x, y - day / 2 - 1, w, day + 2, (0, 0, 0, 1), 0)
    V.hop(x, y - day / 2, w, day, (1, 1, 1, 1), 0)


def _ve_vach_doc(x, y, h, day):
    V.hop(x - day / 2 - 1, y, day + 2, h, (0, 0, 0, 1), 0)
    V.hop(x - day / 2, y, day, h, (1, 1, 1, 1), 0)


def doi_roi():
    """Bao co gi do vua doi — lan ve sau phai dung lai ruot."""
    THE_HE[0] += 1


# Gia tri vua "Copy Value" — mot cho cho ca phien, y nhu Blender.
_KHO_CHEP = [None]


def _dat_mac_dinh(dl, ten, pr, ci=-1):
    """Tra mot o ve gia tri mac dinh cua chinh no.

    ⛔ Doc tu RNA (`pr.default` / `pr.default_array`), khong doan. O vector thi
    chi tra ve dung mot thanh phan neu dang bam vao mot thanh phan.
    """
    if pr is None:
        return
    if ci >= 0:
        m = list(getattr(dl, ten))
        try:
            m[ci] = pr.default_array[ci]
        except Exception:                                    # noqa: BLE001
            m[ci] = pr.default
        setattr(dl, ten, m)
        return
    if getattr(pr, 'is_array', False):
        try:
            setattr(dl, ten, list(pr.default_array))
            return
        except Exception:                                    # noqa: BLE001
            pass
    setattr(dl, ten, pr.default)


def loai_space_cua(o):
    """Loai editor ma panel cua o `o` song trong do (theo panel dau tien).

    ⛔ KHONG PHAI O NAO CUNG VIEW_3D. `DP Post` khai 17 panel trong
    `IMAGE_EDITOR`, `DP Optimize` cung the. Khong biet thi doan VIEW_3D —
    da so o la the, va do cung la duong lui cu.
    """
    try:
        for lop in (getattr(o, 'cac_lop', None) or ()):
            t = getattr(lop, 'bl_space_type', None)
            if t:
                return t
    except Exception:                                        # noqa: BLE001
        pass
    return 'VIEW_3D'


def cua_so_loai():
    """Loai space ma cua so DP dang dung — panel cung loai thi khong phai
    muon `space_data` cua ai."""
    try:
        from . import cua_so
        return cua_so.KIEU
    except Exception:                                        # noqa: BLE001
        return 'TEXT_EDITOR'


def vung_cua_loai(loai):
    """Mot vung THAT dang mo dung `loai` space, de `temp_override` / muon
    `space_data`. None neu tren man hinh khong co vung nao nhu the.

    ⛔ VI SAO PHAI MUON `space_data`. Da dam 23/09/2026: cua so DP la
    `TEXT_EDITOR`, nen `context.space_data` la `SpaceTextEditor`. Panel nao
    `poll()` doc thuoc tinh cua space rieng cua no thi hong im lang:

        DPOPT_PT_vfb (DP Optimize) doc `context.space_data.image`
        -> SpaceTextEditor khong co `.image` -> poll() luon False
        -> khach bat o "DP Optimize" ra mot HOP TRANG TRON, khong mot chu nao.

    Dinh ca DP Post (18 panel, cung `IMAGE_EDITOR`). Nen moi panel duoc dua
    dung loai space ma chinh no khai, muon tu mot vung that tren man hinh.

    ⛔ BO QUA CUA SO DP. Muon lai chinh minh la quay ve diem xuat phat.
    """
    try:
        from . import cua_so
    except Exception:                                        # noqa: BLE001
        cua_so = None
    try:
        for w in bpy.context.window_manager.windows:
            if cua_so is not None and cua_so.la_cua_dp(w):
                continue
            for a in w.screen.areas:
                if a.type != loai:
                    continue
                for r in a.regions:
                    if r.type == 'WINDOW':
                        return {'window': w, 'screen': w.screen,
                                'area': a, 'region': r,
                                'space_data': a.spaces.active}
    except Exception:                                        # noqa: BLE001
        pass
    return None


# Operator nao TU BAY RA GIAO DIEN (hop thoai / popup / hop chon tep).
# Hoi mot lan roi nho — `inspect.getsource` khong duoc goi moi cu bam.
_CO_HOP = {}


def _mo_giao_dien(ma):
    """Operator `ma` co tu bay ra mot bang/hop thoai cua rieng no khong."""
    if ma in _CO_HOP:
        return _CO_HOP[ma]
    ra = False
    try:
        import inspect
        lop = None
        for c in bpy.types.Operator.__subclasses__():
            if getattr(c, 'bl_idname', '') == ma:
                lop = c
                break
        if lop is not None:
            if any(getattr(b, '__name__', '') in ('ImportHelper', 'ExportHelper')
                   for b in lop.__mro__):
                ra = True
            elif 'invoke' in lop.__dict__:
                nguon = inspect.getsource(lop.__dict__['invoke'])
                ra = any(t in nguon for t in (
                    'invoke_props_dialog', 'invoke_popup', 'invoke_props_popup',
                    'invoke_search_popup', 'fileselect_add'))
    except Exception:                                        # noqa: BLE001
        ra = False
    _CO_HOP[ma] = ra
    return ra


def _vung_dp():
    """Ngu canh cua CHINH cua so DP.

    ⛔ HOP THOAI PHAI HIEN RA O CHO KHACH VUA BAM. Blender bay popup theo
    CUA SO duoc `temp_override`; ma luat "nut tac dong vao viewport chinh"
    bat `_chay_op` override sang cua so khach, nen moi hop thoai deu bung o
    cua so Blender chinh. Do 23/09/2026: keo cua so DP sang man hinh thu hai
    roi bam ba nut "Tao Den Nhanh" cua DP_Lighting — truoc mat khong co gi
    xay ra, ma Blender dang bi mot hop thoai modal chan o man hinh kia.
    Dinh ca `camera.create_360`, `camera.quick_pick`, `lighting.chon_ies`,
    `lighting.load_hdri`, `susync.import_skp` va hop dan ma cua cua khoa.

    Da do: chay chung trong ngu canh cua so DP thi `poll()` van True, va
    `execute` cua chung chi doc `scene`/`view_layer`/`selected_objects` —
    nhung thu cua so nao cung co.
    """
    try:
        from . import cua_so
        for w in bpy.context.window_manager.windows:
            if not cua_so.la_cua_dp(w):
                continue
            for a in w.screen.areas:
                for r in a.regions:
                    if r.type == 'WINDOW':
                        return {'window': w, 'screen': w.screen,
                                'area': a, 'region': r}
    except Exception:                                        # noqa: BLE001
        pass
    return None


def _vung_3d():
    """Vung VIEW_3D de `temp_override` khi chay nut cua addon. None neu khong co.

    ⛔ BO QUA CUA SO DP. Ducphan chot 23/09/2026: nut trong cua so roi tac
    dong vao VIEWPORT CHINH, dung nhu bam tu panel N — khong phai vao cai
    cua so dang chua o. Hien cua so DP la `TEXT_EDITOR` nen no khong co vung
    VIEW_3D nao de nham; nhung neu mai nay ai doi kieu no, cho loc nay la
    thu duy nhat con giu dung y do.

    ⛔ CUA SO CHINH TRUOC. `wm.windows[0]` la cua so khach dang lam viec; tim
    thay o do thi dung luon, dung di lang thang sang cua so phu.
    """
    try:
        from . import cua_so
    except Exception:                                        # noqa: BLE001
        cua_so = None
    try:
        for w in bpy.context.window_manager.windows:
            if cua_so is not None and cua_so.la_cua_dp(w):
                continue
            for a in w.screen.areas:
                if a.type != 'VIEW_3D':
                    continue
                for r in a.regions:
                    if r.type == 'WINDOW':
                        return {'window': w, 'screen': w.screen,
                                'area': a, 'region': r}
    except Exception:                                        # noqa: BLE001
        pass
    return None


# ------------------------------------------------------------- so hoc
def _lay_so(v):
    gt = getattr(v['dl'], v['ten'])
    if v.get('chi_so', -1) >= 0:
        gt = gt[v['chi_so']]
    return gt


def _dat_so(v, goc, dx):
    """⛔ DO NHAY PHAI TINH THEO BE NGANG O, KHONG PHAI MOT HANG SO.

    Truoc day lay `(soft_max - soft_min) / 200` cho MOI o. Hai hau qua do
    duoc 23/09/2026:
      · `exposure` (−5..5) trong o rong 328 px: keo 100 px ra +5.000 (dung
        tran) trong khi slider that cua Blender ra +3.05 — nhay gap 3,3 lan;
      · `sweep_rong` cua DP_Sketch (0..100000): MOT pixel = 500 mm.
    Thanh truot that: keo tu mep trai sang mep phai la di het min -> max. O so
    thuong thi theo `step` cua chinh o do, y Blender."""
    pr = v['pr']
    lo, hi = pr.soft_min, pr.soft_max
    rong = float(v.get('w') or 0.0)
    if v.get('truot') and rong > 1.0 and lo > -1e30 and hi < 1e30 and hi > lo:
        nhay = (hi - lo) / rong
    else:
        nhay = max(getattr(pr, 'step', 3) / 100.0, 1e-4)
    gt = goc + dx * nhay
    gt = max(pr.hard_min, min(pr.hard_max, gt))
    if pr.type == 'INT':
        gt = int(round(gt))
    try:
        if v.get('chi_so', -1) >= 0:
            m = list(getattr(v['dl'], v['ten']))
            m[v['chi_so']] = gt
            setattr(v['dl'], v['ten'], m)
        else:
            setattr(v['dl'], v['ten'], gt)
    except Exception as e:                                   # noqa: BLE001
        print("[dp_bang] dat so hong:", e)


# =================================== duong du lieu tinh tu `context`
# Dung cho `wm.context_menu_enum`. Chi lam nhung kieu hay gap; khong biet thi
# tra ve chuoi rong va ta lui ve menu tu ve (van con hon khong co gi).
_GOC_ID = {
    'Scene': 'scene',
    'Object': 'object',
    'World': 'scene.world',
    'Material': 'object.active_material',
    'Mesh': 'object.data',
    'Camera': 'object.data',
    'Light': 'object.data',
    'Image': None,
    'Brush': 'tool_settings.image_paint.brush',
}


def _duong_context(dl, ten):
    try:
        duoi = dl.path_from_id(ten)
    except Exception:                                        # noqa: BLE001
        return ""
    if not duoi:
        return ""
    try:
        chu = dl.id_data
        goc = _GOC_ID.get(type(chu).__name__)
    except Exception:                                        # noqa: BLE001
        return ""
    if not goc:
        return ""
    return "%s.%s" % (goc, duoi)
