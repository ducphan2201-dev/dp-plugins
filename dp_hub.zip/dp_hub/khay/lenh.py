# -*- coding: utf-8 -*-
# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
"""OPERATOR RIENG CUA KHAY — nhung viec Python thuan khong lam duoc.

Hien chi co mot: mo hop chon tep/thu muc. `wm.fileselect_add` chi goi duoc tu
mot operator, nen phai co mot lop that.

⛔ DICH DEN KHONG TRUYEN QUA THUOC TINH OPERATOR DUOC. Thuoc tinh operator chi
nhan so, chuoi, bool — khong nhan mot `bpy_struct`. Nen dat dich vao mot bien
module ngay truoc khi goi. Mot luc chi mo mot hop chon, nen the la du.
"""
import bpy

DICH = [None]          # (du_lieu, ten_thuoc_tinh)


class DPBANG_OT_duyet(bpy.types.Operator):
    """Choose a file or a folder"""
    bl_idname = "dpbang.duyet"
    # ⛔ CHU CUA KHAY LA TIENG ANH — Ducphan chot 23/09/2026.
    bl_label = "Choose path"
    bl_options = {'INTERNAL'}

    filepath: bpy.props.StringProperty(subtype='FILE_PATH')
    directory: bpy.props.StringProperty(subtype='DIR_PATH')
    # ⛔ PHAI CO `subtype='FILE_NAME'`. Thieu no thi moi cu bam nut duyet
    # in ra console: `WARNING fileselect_add: "filename" expected a string
    # with a 'FILE_NAME' subtype`. Hop chon van mo dung, nhung mot canh bao
    # moi lan bam la rac. Do 23/09/2026.
    filename: bpy.props.StringProperty(subtype='FILE_NAME')
    # ⛔ PHAI AN. Thieu `options={'HIDDEN'}` thi hop chon tep bay ra voi
    # mot o tich ten "thu_muc" o cot phai — mot thuoc tinh noi bo cua Hub,
    # viet khong dau, nam giua san pham ban cho khach. Do 23/09/2026.
    thu_muc: bpy.props.BoolProperty(default=False,
                                    options={'HIDDEN'})

    def invoke(self, context, event):
        if DICH[0] is None:
            return {'CANCELLED'}
        dl, ten = DICH[0]
        try:
            cu = str(getattr(dl, ten) or "")
        except Exception:                                    # noqa: BLE001
            cu = ""
        if cu:
            if self.thu_muc:
                self.directory = bpy.path.abspath(cu)
            else:
                self.filepath = bpy.path.abspath(cu)
        else:
            # ⛔ O TRONG thi van PHAI DAT duong (chi thu muc, ten tep rong) —
            # khong dat thi Blender tu dien ten .blend dang mo, bam Accept la
            # "Export file" tro vao chinh file .blend (agent CAD Sync vong 2).
            # Nut goc `buttons.file_browse` cung luon dat.
            goc = bpy.path.abspath('//') if bpy.data.filepath else ''
            if self.thu_muc:
                self.directory = goc
            else:
                self.filepath = goc
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        if DICH[0] is None:
            return {'CANCELLED'}
        dl, ten = DICH[0]
        DICH[0] = None
        duong = self.directory if self.thu_muc else self.filepath
        if not duong:
            return {'CANCELLED'}
        try:
            setattr(dl, ten, duong)
        except Exception as e:                               # noqa: BLE001
            self.report({'WARNING'}, "could not write: %s" % e)
            return {'CANCELLED'}
        return {'FINISHED'}


LOP = (DPBANG_OT_duyet,)


def dang_ky():
    for c in LOP:
        try:
            bpy.utils.register_class(c)
        except Exception:                                    # noqa: BLE001
            pass       # da dang ky roi — khong sao


def go():
    for c in reversed(LOP):
        try:
            bpy.utils.unregister_class(c)
        except Exception:                                    # noqa: BLE001
            pass
