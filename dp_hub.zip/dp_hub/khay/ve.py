# -*- coding: utf-8 -*-
# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
"""VE PIXEL — tang thap nhat cua o tu ve.

Chi co hinh va chu. Khong biet gi ve addon, khong biet gi ve bo cuc.

⛔ `bgl` DA BI GO KHOI BLENDER 5.2. Moi vi du cu tren mang dung `bgl` la vut;
o day chi dung `gpu` + `gpu_extras` + `blf`.

⛔ KHONG DUNG `TRI_FAN`. Blender 5 bo kieu ve do (Metal khong co). Hinh bo goc
dung ra thanh `TRIS` + chi so, dung cach `dp_sketch/overlay.py:397` da lam.

⛔ MAU PHAI DOI sRGB -> LINEAR truoc khi day vao shader. Ghi thang so mau da
chon thi anh ra NHAT hon — bay nay `dp_tiles/pick.py:37` da dam phai.
"""
import math
import time

import blf
import gpu
from gpu_extras.batch import batch_for_shader

_SHADER = {}
_CHU = {}

# ⛔ VE KHO — de bai do chay duoc KHONG CAN GPU.
#
# `gpu` doi mot ngu canh ve; `blender --background` khong co. Nhung ca cai bo
# may bo cuc (do chieu cao, chia cot, nap o bam) thi KHONG can GPU mot ty nao
# — chi may ham ve pixel o duoi day can. Bat co nay len thi chung tra ve ngay,
# con `Khung.ve()` van chay du va van nap day o bam.
#
# Nho the mot bai do "bam thu moi widget cua 11 addon" chay duoc trong
# `--background`, trong vai giay, khong can man hinh. `blf` do be ngang chu
# VAN CHAY duoc o che do nen (da do: `blf.dimensions` ra so that).
_KHO = [False]


def kho(bat=True):
    """Bat/tat che do ve kho. Tra ve tri cu."""
    cu = _KHO[0]
    _KHO[0] = bool(bat)
    return cu


def dang_kho():
    return _KHO[0]


def shader(ten='UNIFORM_COLOR'):
    if ten not in _SHADER:
        _SHADER[ten] = gpu.shader.from_builtin(ten)
    return _SHADER[ten]


def tuyen_tinh(m):
    """sRGB -> linear. Bon so (r, g, b, a); alpha giu nguyen."""
    def _m(c):
        return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4
    return (_m(m[0]), _m(m[1]), _m(m[2]), m[3] if len(m) > 3 else 1.0)


def len_srgb(x):
    """linear -> sRGB, mot kenh."""
    if x <= 0.0031308:
        return max(0.0, 12.92 * x)
    return min(1.0, 1.055 * (x ** (1.0 / 2.4)) - 0.055)


def xuong_linear(x):
    """sRGB -> linear, mot kenh. Nguoc cua `len_srgb`."""
    if x <= 0.04045:
        return max(0.0, x / 12.92)
    return min(1.0, ((x + 0.055) / 1.055) ** 2.4)


def mau_hien(m):
    """Mot mau THAT cua canh (scene-linear) -> mau de VE.

    ⛔ MAU CUA CANH VA MAU CUA BANG DI HAI DUONG KHAC NHAU.
    Mau trong `mau.py` da duoc bu nguoc o `_bu_gamma`, nen `hop()` phai ha
    chung xuong linear bang `tuyen_tinh`. Nhung gia tri mau cua CANH
    (`FloatVectorProperty(subtype='COLOR')`, `default_value` cua socket) DA
    la linear san — ha them mot lan nua la toi di hon ba lan.
    Do 23/09/2026, dem pixel cung mot o `mau_a` cua DP_MatPro:
        panel N that cua Blender : 188, 188, 188
        o tu ve cua Hub          :  58,  58,  58
    Blender NANG linear -> sRGB de hien; ta lam y the roi moi dua vao `hop()`.

    ⛔ CHI DUNG CHO `subtype='COLOR'`. `COLOR_GAMMA` da la mau hien san.
    """
    return (len_srgb(m[0]), len_srgb(m[1]), len_srgb(m[2]),
            m[3] if len(m) > 3 else 1.0)


def mau_that(d):
    """Nguoc cua `mau_hien`: mau nhin thay -> gia tri that cua canh."""
    return (xuong_linear(d[0]), xuong_linear(d[1]), xuong_linear(d[2]),
            d[3] if len(d) > 3 else 1.0)


def font(duong=None, dam=False):
    """Nap font rieng. Khong co file thi dung font san cua Blender (id 0)."""
    k = 'dam' if dam else 'thuong'
    if k not in _CHU:
        _CHU[k] = 0
        if duong:
            try:
                import os
                if os.path.exists(duong):
                    _CHU[k] = blf.load(duong)
            except Exception:                                # noqa: BLE001
                _CHU[k] = 0
    return _CHU[k]


def _hcn_bo(x, y, w, h, r, doan=None, ra=None):
    """Dinh + chi so tam giac cua mot hinh chu nhat bo goc.

    `ra` (neu dua vao) nhan them huong phap tuyen ra ngoai cua tung dinh
    tren chu vi — `hop()` dung no de dung vanh khu rang cua."""
    r = max(0.0, min(r, w / 2.0, h / 2.0))
    if r < 0.5:
        v = [(x, y), (x + w, y), (x + w, y + h), (x, y + h)]
        return v, [(0, 1, 2), (0, 2, 3)]
    if doan is None:
        # Goc to (nut tron, diem dieu khien phong to) can them doan, khong
        # thi vanh AA lo ra canh da giac. Goc nho giu 4 doan nhu cu.
        doan = max(4, min(12, int(r / 2.5)))
    v = []
    for cx, cy, a0 in ((x + w - r, y + h - r, 0.0),
                       (x + r, y + h - r, math.pi / 2),
                       (x + r, y + r, math.pi),
                       (x + w - r, y + r, math.pi * 1.5)):
        for i in range(doan + 1):
            a = a0 + (math.pi / 2) * i / doan
            ca, sa = math.cos(a), math.sin(a)
            v.append((cx + r * ca, cy + r * sa))
            if ra is not None:
                ra.append((ca, sa))
    v.append((x + w / 2.0, y + h / 2.0))
    c = len(v) - 1
    return v, [(c, i, (i + 1) % c) for i in range(c)]


# ================================================ KHU RANG CUA (nhe nhat)
# Ducphan 24/09/2026: *"bo sung antialiasing (loai nhe nhang nhat) cho cac
# giao dien, bieu do, bieu tuong, tich chon"*.
#
# ⛔ KHONG DUNG MSAA / OFFSCREEN. Ca hai deu ton mot lan ve them cho ca vung.
# Cach re nhat: mot VANH ROT 1 PX quanh mep hinh — dinh trong mang mau that,
# dinh ngoai cung mau nhung alpha 0, GPU tu noi. Van nam trong ro gom
# `SMOOTH_COLOR` nen KHONG them lenh ve nao, chi them vai tam giac.
#
# Vanh nam GIUA mep (±0,5 px): mep trung dung le pixel thi pixel trong phu
# du, pixel ngoai bang 0 — hinh chu nhat thang hang ve ra y het khong AA,
# chi goc bo va net cheo moi mem di.
AA = 1.0          # be rong vanh, px. 0 = tat han


def _vanh(tam, ra, m, doi):
    """Nap vanh AA cho mot da giac loi da xep trong `_RO`.

    `tam`: dinh tren chu vi, `ra`: phap tuyen don vi, `m`: mau linear,
    `doi`: vong kin (noi dinh cuoi ve dinh dau). Dinh ngoai = tam + ra * AA,
    alpha 0."""
    n = len(_RO['v'])
    k = len(tam)
    trong = list(tam)
    ngoai = [(px + nx * AA, py + ny * AA) for (px, py), (nx, ny)
             in zip(tam, ra)]
    m0 = (m[0], m[1], m[2], 0.0)
    _RO['v'].extend(trong)
    _RO['v'].extend(ngoai)
    _RO['c'].extend([m] * k)
    _RO['c'].extend([m0] * k)
    for i in range(k if doi else k - 1):
        j = (i + 1) % k
        a, b, c, d = n + i, n + j, n + k + j, n + k + i
        _RO['i'].append((a, b, c))
        _RO['i'].append((a, c, d))


# ============================================ GOM HINH LAM MOT LENH VE
# ⛔ MOI HINH MOT LENH VE LA CHO TON NHAT. Do 23/09/2026 tren the DP_MatPro:
# 170 lan goi `hop()` moi khung hinh, ton 3,52 ms — **78% ca luot ve**, trong
# khi bo cuc va `draw()` cua addon cong lai chi 0,20 ms. Moi lan goi la mot
# `batch_for_shader` (cap phat VBO moi) cong mot lenh ve: ~20 micro giay.
#
# Nen gom: `hop()` chi XEP dinh vao mot ro; `xa()` do ca ro thanh MOT batch.
# Thu tu ve giu nguyen vi tam giac duoc rasterise theo thu tu nap.
#
# ⛔ PHAI XA TRUOC KHI DOI VUNG CAT, ve chu, hay ve anh. `scissor` la trang
# thai GL luc VE, khong phai luc xep — xep vat cua hai vung cat khac nhau vao
# cung mot ro thi ca ro an theo vung cat CUOI CUNG.
_RO = {'v': [], 'c': [], 'i': []}
_RO_CHU = []


# ============================================ NHO HINH DANG (nhe nhat)
# ⛔ DUNG LAI HINH MOI KHUNG LA CHO TON NHAT SAU KHI GOM. Do 24/09/2026 bang
# cProfile, 8 o mo: `hop()` + `_hcn_bo` + `_vanh` an 52% moi luot ve — 540
# hinh bo goc/khung, moi hinh tinh lai luong giac, vanh AA, danh sach dinh
# bang Python thuan, trong khi 99% hinh y het khung truoc.
#
# Nen: NHO hinh theo (loai, rong, cao, bo goc, mau) o GOC TOA DO 0, dang
# mang numpy. Khung sau chi tra dict + nap (hinh, x, y); `xa()` doi CA RO
# bang mot phep cong numpy. Keo/cuon o chi doi (x, y) nen VAN TRUNG bo nho.
#
# ⛔ KHONG NHO `bpy_struct` NAO — chi so thuc va mang pixel-khong-lien-quan.
import numpy as _np

_KHOI = {}           # khoa -> (dinh (n,2), mau (n,4), chi so (m,3)) goc 0
_DS = []             # [(hinh, x, y)] theo dung thu tu ve
_TRAN_KHOI = 6000    # qua so hinh nay thi xoa bo nho (co o lien tuc)


def _khoi(k, x, y, dung):
    """Nap mot hinh vao ro. `dung()` ghi hinh o goc 0 vao `_RO` (chi goi
    khi bo nho chua co)."""
    e = _KHOI.get(k)
    if e is None:
        cu = (_RO['v'], _RO['c'], _RO['i'])
        _RO['v'], _RO['c'], _RO['i'] = [], [], []
        try:
            dung()
            e = (_np.array(_RO['v'], dtype=_np.float32).reshape(-1, 2),
                 _np.array(_RO['c'], dtype=_np.float32).reshape(-1, 4),
                 _np.array(_RO['i'], dtype=_np.int32).reshape(-1, 3))
        finally:
            _RO['v'], _RO['c'], _RO['i'] = cu
        if len(_KHOI) > _TRAN_KHOI:
            _KHOI.clear()
        _KHOI[k] = e
    if len(e[0]):
        _DS.append((e, x, y))


def xa():
    """Do ca ro: MOT lenh ve cho tat ca hinh, roi moi toi chu.

    ⛔ CHU PHAI XEP RIENG, KHONG DUOC BAT XA RO HINH. Ban dau moi `chu()` xa
    ro mot lan — 56 lan xa moi khung hinh, va thoi gian chi chuyen tu cot
    "hinh" sang cot "chu" (3,52 -> 0,80 nhung chu 0,74 -> 2,16). Trong cung
    mot vung cat, cac widget KHONG de len nhau, nen ve het hinh roi ve het chu
    cho ra dung mot ket qua ma chi ton MOT lenh ve.
    """
    n = 0
    if _DS:
        # ⛔ BAT LAI HOA MAU MOI LAN DO RO. `blf.draw` cua lan xa truoc de
        # trang thai blend khac ALPHA -> vanh AA (alpha 1 -> 0) ve ra DAC,
        # mep van gay bac thang. Do 24/09/2026 bang anh chup phong to.
        gpu.state.blend_set('ALPHA')
        ds = _DS[:]
        del _DS[:]
        so_v = _np.fromiter((len(e[0]) for e, _x, _y in ds), _np.int32,
                            len(ds))
        so_i = _np.fromiter((len(e[2]) for e, _x, _y in ds), _np.int32,
                            len(ds))
        V = _np.concatenate([e[0] for e, _x, _y in ds])
        V += _np.repeat(_np.array([(x, y) for _e, x, y in ds],
                                  dtype=_np.float32), so_v, axis=0)
        C = _np.concatenate([e[1] for e, _x, _y in ds])
        goc = _np.cumsum(so_v) - so_v
        I = _np.concatenate([e[2] for e, _x, _y in ds]) + \
            _np.repeat(goc, so_i)[:, None].astype(_np.int32)
        sh = shader('SMOOTH_COLOR')
        b = batch_for_shader(sh, 'TRIS', {"pos": V, "color": C}, indices=I)
        b.draw(sh)
        n = len(I)
    if _RO_CHU:
        for (t, x, y, co, mau, dam, duong) in _RO_CHU:
            f = font(duong, dam)
            blf.size(f, co)
            blf.color(f, mau[0], mau[1], mau[2],
                      mau[3] if len(mau) > 3 else 1.0)
            blf.position(f, x, y, 0)
            blf.draw(f, t)
        del _RO_CHU[:]
    return n


def hop(x, y, w, h, mau, r=0.0):
    if _KHO[0] or w <= 0 or h <= 0:
        return
    _khoi(('h', w, h, tuple(mau), r, AA), x, y,
          lambda: _dung_hop(0.0, 0.0, w, h, mau, r))


def _dung_hop(x, y, w, h, mau, r):
    m = tuyen_tinh(mau)
    # ⛔ CHI GOC BO MOI CAN VANH. Hinh chu nhat thang (vien 1 px, thanh
    # ngang, nen) giu nguyen — ho chiem da so lan goi, them vanh la phi.
    if AA > 0 and r >= 0.5 and w > 2 * AA and h > 2 * AA:
        h2 = AA / 2.0
        ra = []
        v, idx = _hcn_bo(x + h2, y + h2, w - AA, h - AA,
                         max(0.0, r - h2), ra=ra)
        if ra:
            n = len(_RO['v'])
            _RO['v'].extend(v)
            _RO['c'].extend([m] * len(v))
            _RO['i'].extend([(a + n, b + n, c + n) for a, b, c in idx])
            _vanh(v[:-1], ra, m, True)
            return
    v, idx = _hcn_bo(x, y, w, h, r)
    n = len(_RO['v'])
    _RO['v'].extend(v)
    _RO['c'].extend([m] * len(v))
    _RO['i'].extend([(a + n, b + n, c + n) for a, b, c in idx])


def hop_4goc(x, y, w, h, m_td, m_pd, m_pt, m_tt):
    """Hinh chu nhat BON GOC BON MAU — chuyen mau muot giua chung.

    ⛔ DUNG CHO BANG CHON MAU. O vuong S-V cua Blender la hai lop chong nhau:
    mot lop ngang trang -> mau thuan, mot lop doc den dac -> trong suot. Khong
    co ham nay thi khong ve noi lop nao trong hai lop do.

    Ro gom dang chay bang shader `SMOOTH_COLOR` — moi dinh mot mau, GPU tu noi
    — nen them kieu hinh nay khong ton them mot lenh ve nao.

    Thu tu goc: trai-duoi, phai-duoi, phai-tren, trai-tren.
    """
    if _KHO[0] or w <= 0 or h <= 0:
        return
    k = ('4', w, h, tuple(m_td), tuple(m_pd), tuple(m_pt), tuple(m_tt))
    _khoi(k, x, y, lambda: _dung_4goc(0.0, 0.0, w, h, m_td, m_pd, m_pt, m_tt))


def _dung_4goc(x, y, w, h, m_td, m_pd, m_pt, m_tt):
    n = len(_RO['v'])
    _RO['v'].extend([(x, y), (x + w, y), (x + w, y + h), (x, y + h)])
    _RO['c'].extend([tuyen_tinh(m_td), tuyen_tinh(m_pd),
                     tuyen_tinh(m_pt), tuyen_tinh(m_tt)])
    _RO['i'].extend([(n, n + 1, n + 2), (n, n + 2, n + 3)])


def vien(x, y, w, h, mau, day=1.0, r=0.0):
    """Vien ve bang bon thanh mong — re hon LINE_LOOP va khong rang cua.

    ⛔ `r` CHI DUNG DUOC KHI CO `nen`. Bon thanh thang thi goc luon VUONG, du
    cai nen ben trong da bo tron. Ducphan 23/09/2026: *"khung trong thi bo
    tron, xong ngoai thi van vuong nhon ???"*. Muon vien bo tron thi goi
    `vien_tron()`.
    """
    hop(x, y, w, day, mau, 0)
    hop(x, y + h - day, w, day, mau, 0)
    hop(x, y, day, h, mau, 0)
    hop(x + w - day, y, day, h, mau, 0)


def vien_tron(x, y, w, h, mau, nen, day=1.0, r=0.0):
    """Vien BO TRON: ve mot hinh bo tron mau vien, roi de mot hinh bo tron mau
    nen thut vao `day`.

    Phai biet mau NEN moi lam duoc — do la cai gia phai tra de goc vien tron
    theo dung goc cua ruot.
    """
    hop(x, y, w, h, mau, r)
    if w > 2 * day and h > 2 * day:
        hop(x + day, y + day, w - 2 * day, h - 2 * day, nen,
            max(0.0, r - day))


def hop_tren_tron(x, y, w, h, mau, r):
    """Hinh chu nhat bo tron HAI GOC TREN, hai goc duoi vuong.

    Thanh tieu de nam tren than the: bo tron ca bon goc thi hai goc duoi khoet
    vao than, nhin ra hai cai khuyet.
    """
    hop(x, y, w, h, mau, r)
    if h > r:
        hop(x, y, w, min(r, h), mau, 0)


def _gach(x1, y1, x2, y2, day, mau):
    """Mot doan thang co be day — ve bang hai tam giac."""
    if _KHO[0]:
        return
    dx, dy = x2 - x1, y2 - y1
    _khoi(('g', dx, dy, day, tuple(mau)), x1, y1,
          lambda: _dung_gach(0.0, 0.0, dx, dy, day, mau))


def _dung_gach(x1, y1, x2, y2, day, mau):
    dx, dy = x2 - x1, y2 - y1
    d = math.hypot(dx, dy)
    if d < 1e-6:
        return
    ux, uy = -dy / d, dx / d                 # phap tuyen don vi
    m = tuyen_tinh(mau)
    # Net cheo la cho rang cua ro nhat (dau tich, duong cong): loi thut vao
    # nua vanh, hai ben mot vanh AA. Hai dau doan KHONG rot — cac doan duong
    # cong noi tiep nhau, rot dau thi hien vet dut o moi khop.
    nua = max(0.25, day / 2.0 - (AA / 2.0 if AA > 0 else 0.0))
    nx, ny = ux * nua, uy * nua
    v = [(x1 + nx, y1 + ny), (x2 + nx, y2 + ny),
         (x2 - nx, y2 - ny), (x1 - nx, y1 - ny)]
    n = len(_RO['v'])
    _RO['v'].extend(v)
    _RO['c'].extend([m] * 4)
    _RO['i'].extend([(n, n + 1, n + 2), (n, n + 2, n + 3)])
    if AA > 0:
        _vanh([v[0], v[1]], [(ux, uy), (ux, uy)], m, False)
        _vanh([v[2], v[3]], [(-ux, -uy), (-ux, -uy)], m, False)


def _net_gay(diem, day, mau):
    """Mot NET GAY LIEN (polyline) co moi noi vat + vanh AA hai ben va hai
    dau. Khac `_gach` goi nhieu lan: khong co cho hai doan chong nhau (cho
    chong sam mau hon va cong len mot cuc o khop)."""
    if _KHO[0] or len(diem) < 2:
        return
    x0, y0 = diem[0]
    tuong = tuple((px - x0, py - y0) for px, py in diem)
    _khoi(('n', tuong, day, tuple(mau)), x0, y0,
          lambda: _dung_net_gay(list(tuong), day, mau))


def _dung_net_gay(diem, day, mau):
    k = len(diem)
    if k < 2:
        return
    m = tuyen_tinh(mau)
    m0 = (m[0], m[1], m[2], 0.0)
    pt = []                                   # phap tuyen don vi tung doan
    for i in range(k - 1):
        dx = diem[i + 1][0] - diem[i][0]
        dy = diem[i + 1][1] - diem[i][1]
        d = math.hypot(dx, dy)
        if d < 1e-6:
            return
        pt.append((-dy / d, dx / d))
    nua = max(0.35, day / 2.0 - (AA / 2.0 if AA > 0 else 0.0))
    lech = []                                 # vector vat tai moi dinh
    for i in range(k):
        if i == 0:
            nx, ny = pt[0]
            lech.append((nx, ny))
            continue
        if i == k - 1:
            nx, ny = pt[-1]
            lech.append((nx, ny))
            continue
        ax, ay = pt[i - 1]
        bx, by = pt[i]
        mx, my = ax + bx, ay + by
        dm = math.hypot(mx, my)
        if dm < 1e-6:
            lech.append((ax, ay))
            continue
        mx, my = mx / dm, my / dm
        c = max(0.35, mx * ax + my * ay)     # chan moi vat qua nhon
        lech.append((mx / c, my / c))

    def _vong(r, mau_v):
        n0 = len(_RO['v'])
        for (px, py), (lx, ly) in zip(diem, lech):
            _RO['v'].append((px + lx * r, py + ly * r))
        _RO['c'].extend([mau_v] * k)
        return n0

    L = _vong(nua, m)
    R = _vong(-nua, m)
    for i in range(k - 1):
        _RO['i'].append((L + i, L + i + 1, R + i + 1))
        _RO['i'].append((L + i, R + i + 1, R + i))
    if AA <= 0:
        return
    Lo = _vong(nua + AA, m0)
    Ro = _vong(-(nua + AA), m0)
    for a, b in ((L, Lo), (R, Ro)):
        for i in range(k - 1):
            _RO['i'].append((a + i, a + i + 1, b + i + 1))
            _RO['i'].append((a + i, b + i + 1, b + i))
    # Hai dau net: rot ra AA theo huong doan
    for dau, i_seg, huong in ((0, 0, -1.0), (k - 1, k - 2, 1.0)):
        nx, ny = pt[i_seg]
        tx, ty = ny * huong, -nx * huong      # tiep tuyen huong ra ngoai
        n0 = len(_RO['v'])
        for v_i in (L + dau, R + dau, Lo + dau, Ro + dau):
            vx, vy = _RO['v'][v_i]
            _RO['v'].append((vx + tx * AA, vy + ty * AA))
        _RO['c'].extend([m0] * 4)
        for a, b, c, d in ((L + dau, R + dau, n0 + 1, n0),
                           (Lo + dau, L + dau, n0, n0 + 2),
                           (R + dau, Ro + dau, n0 + 3, n0 + 1)):
            _RO['i'].append((a, b, c))
            _RO['i'].append((a, c, d))


def dau_tich(x, y, canh, mau, s=1.0):
    """Dau tich chu V, ve bang MOT net gay lien co khu rang cua.

    ⛔ Ducphan 24/09/2026: *"cac dau tick trong giao dien trong rat dai"*.
    Ban truoc la hai `_gach` roi chong len nhau: khop phinh ra mot cuc, hai
    dau cut vuong, net day 16% canh — nhin vung. Nay theo ti le dau tich
    cua Blender: chan ngan 45 do, chan dai vuot len goc phai, net ~10%."""
    if _KHO[0] or canh <= 0:
        return
    day = max(1.3, canh * 0.105)
    _net_gay([(x + canh * 0.27, y + canh * 0.52),
              (x + canh * 0.43, y + canh * 0.35),
              (x + canh * 0.74, y + canh * 0.68)], day, mau)


def do_chu(s, co, dam=False, duong=None):
    f = font(duong, dam)
    blf.size(f, co)
    return blf.dimensions(f, s)


def chu(s, x, y, co, mau, dam=False, duong=None):
    if _KHO[0] or not s:
        return
    _RO_CHU.append((s, x, y, co, mau, dam, duong))


def chu_cat(s, x, y, rong, co, mau, dam=False, duong=None):
    """Ve chu, dai qua thi cat bot va them dau ba cham."""
    if do_chu(s, co, dam, duong)[0] <= rong:
        chu(s, x, y, co, mau, dam, duong)
        return
    t = s
    while t and do_chu(t + "…", co, dam, duong)[0] > rong:
        t = t[:-1]
    chu(t + "…", x, y, co, mau, dam, duong)


def chu_giua(s, x, y, rong, co, mau, dam=False, duong=None):
    """⛔ PHAI CAT BOT KHI DAI QUA. Ban dau ham nay chi can giua ma khong cat,
    nen mot nut hep mang chu dai ("Copy Settings to Checked", 221 px trong nut
    152 px) tran ca ra ngoai mep o va de len nut ben canh. Do 23/09/2026."""
    w = do_chu(s, co, dam, duong)[0]
    if w > rong:
        t = s
        while t and do_chu(t + "…", co, dam, duong)[0] > rong:
            t = t[:-1]
        s = t + "…"
        w = do_chu(s, co, dam, duong)[0]
    chu(s, x + (rong - w) / 2.0, y, co, mau, dam, duong)


def cat_bat(x, y, w, h):
    """Chi cho ve trong hinh chu nhat nay — dung cho o cuon."""
    if _KHO[0]:
        return
    xa()                       # ro cu thuoc vung cat cu
    gpu.state.scissor_test_set(True)
    gpu.state.scissor_set(int(x), int(y), max(1, int(w)), max(1, int(h)))


def cat_thoi():
    if _KHO[0]:
        return
    xa()
    gpu.state.scissor_test_set(False)


# ==================================================================== anh
# TAM ICON CUA ADDON -> MOT `GPUTexture` TA VE DUOC.
#
# `template_icon_view` va cot icon cua `template_list` deu chi cho ta MOT SO:
# `icon_value` (tuc `ImagePreview.icon_id`). Blender khong co ham nao tra
# nguoc tu so do ve tam anh, nen ta tu dung ban do.
#
# ⛔ KHONG CO SO DANG KY KHO ANH. `bpy.utils.previews._uuid_open` chi giu
# CHUOI uuid, khong giu chinh cai kho. Duong duy nhat lay duoc vat that la
# hoi `gc` moi `ImagePreviewCollection` con song — addon nao cung giu kho cua
# no trong mot bien module, nen chung con song chung nao addon con bat.
#
# ⛔ QUET LAI KHI HUT, DUNG QUET MOI KHUNG HINH. `gc.get_objects()` duyet ca
# trieu vat — goi no trong `draw()` la tut xuong vai khung hinh mot giay.
_TEX = {}
_BAN_DO = {}
_DA_QUET = [False]

# ⛔ PREVIEW CUA MOT ID (vat lieu, map) KHONG TU CO PIXEL. Do 24/09/2026 tren
# Blender 5.2.2 that:
#     preview_ensure()                  -> 0x0, khong mot pixel nao
#     ... cho 4 giay, khong ai ve       -> van 0x0
#     ed.lib_id_generate_preview        -> 128x128 day du sau < 1 giay
# Panel N cua Blender tu xin ve khi no VE icon do; cua so DP khong ve icon
# Blender nao nen khong ai xin — o map, qua cau vat lieu trong rong hoac DEN
# XI (Ducphan 24/09/2026). Luc ve chua xong thi pixel toan 0; ban cu cat
# texture den do vao `_TEX` va khong bao gio doc lai.
#
# Nen: gap preview rong/den -> XIN VE (hen gio, NGOAI draw handler) roi doc
# lai moi 0,4 s toi khi co pixel. Sua vat lieu/map -> xin ve lai y Blender.
#
# ⛔ KHONG GIU `bpy_struct` CUA ID QUA KHUNG HINH (xem `o.O._ruot`). Chi nho
# (ten kho, ten, thu vien) roi tra lai trong `bpy.data` moi lan dung.
_NGUON = {}          # icon_id -> ('materials', ten, duong thu vien | None)
_DOI = {}            # icon_id -> han chot con doc lai (dang cho Blender ve)
_CHO = {}            # icon_id -> lan doc lai ke tiep som nhat
_XIN = {}            # icon_id -> (so lan da xin, luc xin gan nhat)
_HANG = {}           # icon_id -> luc chay lenh xin ve (don nhieu cu keo)
_HEN = [False]       # hen gio xu ly hang dang song
_PX = {}             # id(tex) -> mang pixel (h, w, 4) de thu nho co AA
_NHO = {}            # (id(tex), w, h) -> texture da thu nho
_KHO_ID = ('images', 'materials', 'textures', 'worlds', 'brushes')
DOC_LAI = 0.4        # s giua hai lan doc lai pixel khi dang cho
CHO_TOI_DA = 4.0     # s — qua han ma van rong thi thoi
XIN_TOI_DA = 3       # lan xin ve cho mot preview rong


def _quet_kho_anh():
    """Ban do icon_id -> ImagePreview, gom tu moi kho anh dang song."""
    import gc
    try:
        import bpy.utils.previews as PV
    except ImportError:
        return {}
    bd = {}
    for o in gc.get_objects():
        if not isinstance(o, PV.ImagePreviewCollection):
            continue
        try:
            for p in o.values():
                bd[p.icon_id] = p
        except Exception:                                    # noqa: BLE001
            pass
    # ⛔ PREVIEW CUA MOT ID KHONG NAM TRONG KHO PREVIEW NAO. `Image.preview`,
    # `Material.preview`... Blender tu giu, khong qua `bpy.utils.previews`.
    # DP_MaxMat ve o map bang `img.preview.icon_id`, DP_MatPro ve qua cau vat
    # lieu bang `mat.preview`. Khong quet chung thi kenh DA CO map lai trong
    # rong hon kenh chua co — do 23/09/2026 tren cua so that.
    #
    # ⛔ KHONG GOI `preview_ensure()` O DAY. Day la duong VE; sinh preview
    # trong draw handler la duong vao treo may. Addon da lo phan do.
    # Preview cua ID chi nho DUONG TOI no (`_NGUON`), khong nho vat.
    _quet_id()
    return bd


def _quet_id():
    """Nap `_NGUON`: icon_id -> duong toi ID. Chi duyet `bpy.data`, re."""
    import bpy as _bpy
    for _ten in _KHO_ID:
        try:
            for x in getattr(_bpy.data, _ten, ()):
                pv = x.preview
                i = pv.icon_id if pv is not None else 0
                if i:
                    lib = x.library
                    _NGUON[i] = (_ten, x.name,
                                 lib.filepath if lib is not None else None)
        except Exception:                                    # noqa: BLE001
            pass


def _id_cua(icon_id):
    """ID song ung voi icon_id, tra lai tu `bpy.data`. None neu da mat."""
    d = _NGUON.get(icon_id)
    if d is None:
        return None
    import bpy as _bpy
    try:
        kho = getattr(_bpy.data, d[0])
        x = kho.get((d[1], d[2])) if d[2] else kho.get(d[1])
        if x is None or x.preview is None or x.preview.icon_id != icon_id:
            return None
        return x
    except Exception:                                        # noqa: BLE001
        return None


def _srgb_mang(px):
    """sRGB -> linear cho ca mang, giu nguyen kenh alpha."""
    import numpy as np
    m = px.reshape(-1, 4)
    rgb = m[:, :3]
    m[:, :3] = np.where(rgb <= 0.04045, rgb / 12.92,
                        ((rgb + 0.055) / 1.055) ** 2.4)
    return px


def _doc_pixel(p):
    """(w, h, mang float32) cua mot ImagePreview; (0, 0, None) neu RONG.

    Rong = 0x0 HOAC toan so 0 (Blender da cap bo dem nhung chua ve xong)."""
    import numpy as np
    w, h = tuple(p.image_size)
    nguon = p.image_pixels_float
    if w <= 0 or h <= 0 or len(nguon) < w * h * 4:
        w, h = tuple(p.icon_size)
        nguon = p.icon_pixels_float
    if w <= 0 or h <= 0 or len(nguon) < w * h * 4:
        return 0, 0, None
    px = np.empty(w * h * 4, dtype=np.float32)
    nguon.foreach_get(px)
    if not px.any():
        return 0, 0, None
    return w, h, px


def _lam_tex(w, h, px):
    px = _srgb_mang(px)
    tex = gpu.types.GPUTexture((w, h), format='RGBA16F',
                               data=gpu.types.Buffer('FLOAT', w * h * 4, px))
    _PX[id(tex)] = px.reshape(h, w, 4)
    return tex


def _bo_tex(tex):
    if tex is None:
        return
    k = id(tex)
    _PX.pop(k, None)
    for kk in [kk for kk in _NHO if kk[0] == k]:
        del _NHO[kk]


def texture(icon_id):
    """`GPUTexture` cua mot icon_value. None neu khong tim ra (hoac dang cho
    Blender ve preview — goi lai khung sau)."""
    if _KHO[0] or not icon_id:
        return None
    now = time.monotonic()
    cu = _TEX.get(icon_id)
    if icon_id in _TEX and icon_id not in _DOI:
        return cu
    if _CHO.get(icon_id, 0.0) > now:
        return cu                    # dang cho: giu tam cu (co the None)

    if icon_id in _NGUON:
        idb = _id_cua(icon_id)
        p = idb.preview if idb is not None else None
    else:
        p = _BAN_DO.get(icon_id)
        if p is None and icon_id not in _NGUON:
            _BAN_DO.update(_quet_kho_anh())
            _DA_QUET[0] = True
            p = _BAN_DO.get(icon_id)
            if p is None and icon_id in _NGUON:
                idb = _id_cua(icon_id)
                p = idb.preview if idb is not None else None
    if p is None:
        _DOI.pop(icon_id, None)
        _TEX[icon_id] = cu
        return cu

    try:
        w, h, px = _doc_pixel(p)
        if px is None:
            # Chua co pixel: ID thi xin Blender ve, roi doc lai sau.
            if icon_id in _NGUON and _xin_ve(icon_id):
                _CHO[icon_id] = now + DOC_LAI
                _DOI.setdefault(icon_id, now + CHO_TOI_DA)
                return cu
            _DOI.pop(icon_id, None)
            _TEX[icon_id] = cu
            return cu
        moi = _lam_tex(w, h, px)
    except Exception as e:                                   # noqa: BLE001
        print("[dp_bang] lam texture %s hong: %s" % (icon_id, e))
        _DOI.pop(icon_id, None)
        _TEX[icon_id] = cu
        return cu
    if cu is not None and cu is not moi:
        _bo_tex(cu)
    _TEX[icon_id] = moi
    han = _DOI.get(icon_id)
    if han is not None:
        # Dang doi Blender ve lai (vua sua vat lieu): doc tiep toi het han,
        # vi pixel CU van khac 0 — khong biet luc nao ban moi toi.
        if now >= han or icon_id not in _HANG and _XIN.get(icon_id, (0,))[0] == 0:
            _DOI.pop(icon_id, None)
        else:
            _CHO[icon_id] = now + DOC_LAI
    return moi


# ------------------------------------------------ xin Blender ve preview
def _xin_ve(icon_id, tre=0.0, ep=False):
    """Dua icon_id vao hang xin ve. False neu da xin du lan ma van rong."""
    now = time.monotonic()
    n, t = _XIN.get(icon_id, (0, -1e9))
    if not ep:
        if n >= XIN_TOI_DA:
            return False
        if now - t < 1.5 or icon_id in _HANG:
            return True              # vua xin, dang cho
        _XIN[icon_id] = (n + 1, now)
    _HANG[icon_id] = now + tre
    if not _HEN[0]:
        _HEN[0] = True
        try:
            import bpy as _bpy
            _bpy.app.timers.register(_chay_hang, first_interval=0.05,
                                     persistent=True)
        except Exception:                                    # noqa: BLE001
            _HEN[0] = False
    return True


_CAN = {}            # (ten kho, ten, thu vien) -> luc ghi — ID chua co preview


def can_preview(idb):
    """Goi TRONG draw duoc: ghi lai mot ID chua co preview de hen gio
    `preview_ensure` + xin ve ho. Khong dung vao ID ngay tai day."""
    if _KHO[0]:
        return
    try:
        kho = {'Material': 'materials', 'Image': 'images',
               'World': 'worlds', 'Texture': 'textures',
               'Brush': 'brushes'}.get(idb.bl_rna.identifier)
        if kho is None:
            return
        lib = idb.library
        k = (kho, idb.name, lib.filepath if lib is not None else None)
    except Exception:                                        # noqa: BLE001
        return
    if k in _CAN or lib is not None:
        return
    _CAN[k] = time.monotonic()
    if not _HEN[0]:
        _HEN[0] = True
        try:
            import bpy as _bpy
            _bpy.app.timers.register(_chay_hang, first_interval=0.05,
                                     persistent=True)
        except Exception:                                    # noqa: BLE001
            _HEN[0] = False


def _lam_cac_can():
    """Trong hen gio: `preview_ensure` cho cac ID da ghi, roi dua vao hang
    xin ve nhu moi preview rong khac. Moi ID chi mot lan (`_CAN` giu dau)."""
    import bpy as _bpy
    for k, luc in list(_CAN.items()):
        if luc is None:
            continue
        _CAN[k] = None
        try:
            x = getattr(_bpy.data, k[0]).get(k[1])
            if x is None:
                continue
            if x.preview is None:
                x.preview_ensure()
            i = x.preview.icon_id if x.preview is not None else 0
        except Exception:                                    # noqa: BLE001
            continue
        if i:
            _NGUON[i] = k
            _TEX.pop(i, None)
            _xin_ve(i)
            now = time.monotonic()
            _DOI[i] = now + CHO_TOI_DA
            _CHO[i] = now + DOC_LAI
    try:
        from . import cua_so
        cua_so.ve_lai()
    except Exception:                                        # noqa: BLE001
        pass


def _chay_hang():
    """Hen gio (NGOAI draw handler): chay lenh ve preview, danh thuc cua so.

    ⛔ `ed.lib_id_generate_preview` KHONG ve ngay — no mo mot job nen. Nen
    hen gio nay con song toi khi het preview dang doi, moi nhip danh thuc
    cua so DP de `texture()` doc lai."""
    import bpy as _bpy
    if any(v is not None for v in _CAN.values()):
        _lam_cac_can()
    now = time.monotonic()
    for i, luc in list(_HANG.items()):
        if luc > now:
            continue
        del _HANG[i]
        idb = _id_cua(i)
        if idb is None or idb.library is not None:
            continue
        try:
            # Hen gio khong co cua so trong ngu canh; muon mot cai cua
            # Blender (khong phai cua so DP — no la TEXT_EDITOR rong).
            ws = list(_bpy.context.window_manager.windows)
            kw = {'id': idb}
            if ws:
                kw['window'] = ws[0]
            with _bpy.context.temp_override(**kw):
                _bpy.ops.ed.lib_id_generate_preview()
        except Exception as e:                               # noqa: BLE001
            print("[dp_bang] xin ve preview %s hong: %s" % (idb.name, e))
    for i, han in list(_DOI.items()):
        if now >= han:
            _DOI.pop(i, None)
            _CHO.pop(i, None)
            _TEX.setdefault(i, None)
    if _DOI:
        try:
            from . import cua_so
            cua_so.ve_lai()
        except Exception:                                    # noqa: BLE001
            pass
    if _HANG or _DOI:
        return DOC_LAI / 2.0
    _HEN[0] = False
    return None


def id_doi(ids):
    """Moc canh doi goi: cac ID vua sua -> xin ve lai preview cua chung.

    `ids` la cac cap (ten kho, ten). Don nhieu nhip keo thanh mot lan ve:
    ve sau 0,35 s ke tu nhip CUOI (Blender tu lam y the trong panel N)."""
    if not ids or not _NGUON:
        return
    now = time.monotonic()
    for i, d in list(_NGUON.items()):
        if (d[0], d[1]) not in ids:
            continue
        _XIN[i] = (0, now)
        _xin_ve(i, tre=0.35, ep=True)
        _DOI[i] = now + 0.35 + CHO_TOI_DA
        _CHO[i] = now + 0.35 + DOC_LAI


def quen_anh():
    """Addon tat/bat lai thi icon_id doi. Goi cai nay de quet lai tu dau."""
    _TEX.clear()
    _BAN_DO.clear()
    _NGUON.clear()
    _DOI.clear()
    _CHO.clear()
    _XIN.clear()
    _PX.clear()
    _NHO.clear()
    _CAN.clear()
    _DA_QUET[0] = False


# ------------------------------------------------ thu nho anh co AA
# ⛔ SHADER `IMAGE` LAY MAU KIEU GAN NHAT, KHONG MIPMAP. Anh 128 px ep vao
# o 20 px thi moi pixel o chi lay DUNG MOT pixel anh — map vat lieu ra rang
# cua lam nham. Cach nhe nhat: thu nho SAN bang numpy (trung binh dien tich,
# tach hai chieu = hai phep nhan ma tran nho) dung kich thuoc o, cat lai, roi
# ve 1:1 thang le pixel. Moi (anh, co) chi lam mot lan.
def _ma_tran(n_nguon, n_dich):
    """Ma tran (n_dich x n_nguon): thu nho = trung binh dien tich, phong to
    = noi suy tuyen tinh."""
    import numpy as np
    A = np.zeros((n_dich, n_nguon), dtype=np.float32)
    if n_dich <= n_nguon:
        k = n_nguon / float(n_dich)
        for j in range(n_dich):
            a, b = j * k, (j + 1) * k
            i0, i1 = int(a), min(n_nguon, int(math.ceil(b)))
            for i in range(i0, i1):
                A[j, i] = min(b, i + 1) - max(a, i)
            A[j] /= max(1e-6, A[j].sum())
    else:
        for j in range(n_dich):
            t = (j + 0.5) * n_nguon / float(n_dich) - 0.5
            t = max(0.0, min(n_nguon - 1.0, t))
            i0 = int(t)
            i1 = min(n_nguon - 1, i0 + 1)
            f = t - i0
            A[j, i0] += 1.0 - f
            A[j, i1] += f
    return A


def _tex_vua(tex, w, h):
    """Texture da doi dung (w, h) px. Khong lam duoc thi tra chinh `tex`."""
    px = _PX.get(id(tex))
    if px is None or w < 1 or h < 1:
        return tex
    sh, sw = px.shape[0], px.shape[1]
    if (sw, sh) == (w, h) or w > 1024 or h > 1024:
        return tex
    k = (id(tex), w, h)
    t = _NHO.get(k)
    if t is not None:
        return t
    try:
        import numpy as np
        # Nhan truoc alpha: khong thi vien trong suot keo mau den vao mep.
        a = px[:, :, 3:4]
        pm = np.concatenate([px[:, :, :3] * a, a], axis=2)
        Ah, Aw = _ma_tran(sh, h), _ma_tran(sw, w)
        ra = np.einsum('ij,jkc->ikc', Ah, pm)
        ra = np.einsum('kj,ijc->ikc', Aw, ra)
        al = ra[:, :, 3:4]
        ra[:, :, :3] = np.where(al > 1e-6, ra[:, :, :3] / np.maximum(al, 1e-6),
                                0.0)
        ra = np.ascontiguousarray(ra, dtype=np.float32).ravel()
        t = gpu.types.GPUTexture((w, h), format='RGBA16F',
                                 data=gpu.types.Buffer('FLOAT', w * h * 4, ra))
    except Exception as e:                                   # noqa: BLE001
        print("[dp_bang] thu nho anh hong:", e)
        t = tex
    if len(_NHO) > 256:
        _NHO.clear()
    _NHO[k] = t
    return t


def anh(x, y, w, h, tex):
    """Ve mot texture vao hinh chu nhat. ⛔ KHONG TRI_FAN (xem dau file)."""
    if _KHO[0] or tex is None or w <= 0 or h <= 0:
        return False
    xa()                       # anh nam TREN nhung hinh da xep
    try:
        # Cat le pixel + doi anh dung co o: moi pixel o = mot texel.
        xi, yi = int(round(x)), int(round(y))
        wi, hi = max(1, int(round(w))), max(1, int(round(h)))
        t = _tex_vua(tex, wi, hi) if AA > 0 else tex
        if t is not tex:
            x, y, w, h = xi, yi, wi, hi
        # ⛔ BAT LAI HOA MAU NGAY TRUOC KHI VE ANH. Do 24/09/2026: preview
        # vat lieu co alpha 0 o goc (dem pixel that) ma o ve ra NEN DEN DAC —
        # trang thai blend luc nay khong con la ALPHA (`blf` ve chu trong
        # `xa()` ngay truoc do). Qua cau hien thanh o vuong den: cai "den xi"
        # Ducphan thay.
        gpu.state.blend_set('ALPHA')
        sh = shader('IMAGE')
        b = batch_for_shader(
            sh, 'TRIS',
            {"pos": [(x, y), (x + w, y), (x + w, y + h), (x, y + h)],
             "texCoord": [(0, 0), (1, 0), (1, 1), (0, 1)]},
            indices=[(0, 1, 2), (0, 2, 3)])
        sh.uniform_sampler("image", t)
        b.draw(sh)
        return True
    except Exception as e:                                   # noqa: BLE001
        print("[dp_bang] ve anh hong:", e)
        return False


def texture_theo_ten(ten):
    """Tim tam anh theo TEN key trong kho, khi icon_id khong dung duoc.

    ⛔ CHAY `--background` THI MOI `icon_id` DEU BANG 0. Blender chi cap so
    icon khi co giao dien. Do la ly do phai co duong tra theo ten: bai do
    chay nen van biet tam anh co that hay khong."""
    if _KHO[0] or not ten:
        return None
    k = ('ten', ten)
    if k in _TEX:
        return _TEX[k]
    import gc
    try:
        import bpy.utils.previews as PV
    except ImportError:
        _TEX[k] = None
        return None
    for o in gc.get_objects():
        if not isinstance(o, PV.ImagePreviewCollection):
            continue
        try:
            p = o.get(ten)
        except Exception:                                    # noqa: BLE001
            p = None
        if p is None:
            continue
        cu = _TEX.get(p.icon_id)
        if cu is None and p.icon_id:
            cu = texture(p.icon_id)
        if cu is None:
            _BAN_DO[-abs(hash(ten)) or -1] = p
            cu = _tu_preview(p)
        _TEX[k] = cu
        return cu
    _TEX[k] = None
    return None


def _tu_preview(p):
    """Dung `GPUTexture` thang tu mot `ImagePreview` — khong qua icon_id."""
    try:
        w, h, px = _doc_pixel(p)
        if px is None:
            return None
        return _lam_tex(w, h, px)
    except Exception as e:                                   # noqa: BLE001
        print("[dp_bang] texture tu preview hong:", e)
        return None
