# -*- coding: utf-8 -*-
"""DP_Hub — bảng điều khiển chung cho mọi plugin của Ducphan.

Khách cài MỘT addon này, rồi mọi việc còn lại làm ngay trong đó: xem danh mục
plugin trên máy chủ, cài, cập nhật, dán mã kích hoạt, mở trang mua.

Tác giả khai báo plugin mới bằng cách sửa MỘT file `catalog.json` trên máy chủ
— không phải phát hành lại Hub.

Addon kiểu CŨ (bl_info, không dùng blender_manifest.toml) cho khớp với các
addon còn lại của dự án.
"""
bl_info = {
    'name': 'DP_Hub',
    'author': 'Ducphan',
    'version': (1, 6, 15),
    'blender': (4, 2, 0),
    'location': 'View3D > Sidebar (N) > DP',
    'description': 'Bang dieu khien chung: cai, cap nhat va kich hoat plugin',
    'category': 'System',
}

__version__ = '1.6.15'

if 'bpy' in locals():
    # Nạp lại khi người dùng bấm Reload Scripts: không có đoạn này thì Blender
    # giữ nguyên module cũ trong bộ nhớ và mọi sửa đổi "không có tác dụng".
    import importlib
    from . import catalog, install, ui_hub
    from .dp_license import gate, machine_id, rsa_verify
    from .dp_license import ui as _lic_ui
    for _m in (gate, machine_id, rsa_verify, _lic_ui, catalog, install, ui_hub):
        importlib.reload(_m)

import bpy     # noqa: E402,F401

from . import ui_hub     # noqa: E402


def register():
    ui_hub.register()


def unregister():
    ui_hub.unregister()
