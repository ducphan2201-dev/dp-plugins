# -*- coding: utf-8 -*-
# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
"""CUA SO DP — phan noi vao DP_Hub.

Luat Ducphan (xem `CODEAPP/AGENTS.md`):

  · Khay va moi o tu ve NAM TRONG DP_Hub; giao dien goi ra tu Hub.
  · KHONG duoc lam anh huong addon goc — Hub goi `Panel.draw()` cua addon voi
    mot `layout` gia. Addon ban ra khong doi mot dong, khong them mot file.
  · Moi addon MOT O, ruot giu nguyen y panel hien nay.
  · Khach mua addon nao moi bat duoc o cua addon do — danh sach o = addon DA
    CAI va DA BAT, ma muon cai duoc thi phai qua cua khoa cua Hub.
  · Ma het han thi KHONG dong o: ruot tu hien hop "KEY EXPIRED" vi Hub goi
    `draw()` goc chu khong ve lai.
  · Panel N cu GIU NGUYEN lam duong lui.

═══════════════════════════════════════════════════════════════════════════
BO KHAY XEP CANH — Ducphan chot 23/09/2026
═══════════════════════════════════════════════════════════════════════════

  *"tao k can cai tray ben trai lam j, cai tao can la 1 cua so rieng biet co
  the di chuyen ngoai khung cua so blender"*
  *"co chuc nang nay roi thi bo cai windowlayout toolbox di"*
  *"mo 1 cua so khong co bat cu noi dung j, la noi de chua cac cua so addon"*

Nen khong con ve de len viewport nua. Moi thu nam trong MOT cua so he dieu
hanh roi (`khay/cua_so.py`) — keo sang man hinh khac duoc, o ben trong theo
ra ngoai khung Blender.

⛔ NUT CUA ADDON TAC DONG VAO VIEWPORT CHINH, khong vao cua so DP. Ducphan
chot the. Nho the ma cua so DP duoc phep la `TEXT_EDITOR` (0,15 ms/khung)
thay vi `VIEW_3D` (2,32 ms/khung) — re hon 94%, vi VIEW_3D con phai dung ca
canh 3D phia sau roi ta phu o kin len. Viec doi ngu canh nam o
`khay/o.py::_vung_3d()`.

⛔ MODAL BAM THEO CUA SO, KHONG BAM THEO `context.area`. Da dam mot lan
23/09/2026: trong `modal()`, `context.area` la vung DUOI CON TRO. Dua chuot
ra cho khac la tuong "khay bi dong" roi tra `{'FINISHED'}` — modal chet, lop
ve con nguyen, khach thay mot cai bang chet cung. Ducphan: *"tao moi bat len
thi cac khung treo me no roi mac du blender van hoat dong"*.
"""
import time

import bpy

from . import khay
from .khay import o as O
from .khay import ve as V
from .khay import cua_so
from .dp_license import toolbox

_KHAY = [None]          # mot Khay duy nhat, song trong cua so DP
_CHAY = [False]         # co mot modal dang nhan su kien khong

# ⛔ HAM NHIP VE LAI KHI CHI RE CHUOT — do 23/09/2026 sau khi Ducphan bao
#    *"thao chuot tren cac cua so rat lag, kiem tra lai"*.
#
#    So do tren 9 o dang bat:
#        Khay.ro()  0,009 ms   (hoi "o duoi con tro co doi khong" — RE)
#        Khay.ve()  6,742 ms   (TO MAU lai ca cua so DP — DAT)
#        ro() tra True 96/100 cu di chuot
#
#    Chuot gui su kien nhanh hon 60 Hz rat nhieu (125-1000 Hz). Ve lai 96%
#    so cu la vuot xa ngan sach mot khung hinh, va do chinh la cai lag.
#
#    Tach ruot khoi to mau (`o.THE_HE`) chi cuu 8,1 -> 6,7 ms, vi tien nam o
#    SO LENH VE chu khong o viec dat. Nen phai ham nhip: diem sang chi can
#    theo kip MAT NGUOI, 30 lan/giay la du va khong ai thay cham.
#
#    ⛔ CHI HAM DUONG DIEM SANG. Bam, keo, go — tuc DOI GIA TRI THAT — ve lai
#    ngay lap tuc, khong qua cho nay.
NHIP = 1.0 / 30.0
_LAN_VE = [0.0]
_CHO = [False]          # co mot cu re chuot da bi bo, dang cho ve bu


# ===================================================== danh sach o co the bat
# ⛔ TAB KHONG DUA VAO CUA SO DP. Ducphan chot 25/09/2026: *"bo qua dp
# optimize tren dp window"* — ruot that cua DP_Optimize nam o Properties >
# Render, o chi con thanh ben VFB nen gan nhu trong. Khach dung no o cho cu.
TAB_BO = {'DP Optimize'}


def cac_tab():
    """[(ten_tab, loai_space)] cua moi addon DA CAI VA DA BAT.

    Dung lai `toolbox.tabs()` — no da loc dung nhung tab cua nha DP, va da
    chon dung loai editor khi mot tab song o hai noi.
    """
    try:
        return [(cat, space) for cat, space, _n in toolbox.tabs()
                if cat not in TAB_BO]
    except Exception as e:                                   # noqa: BLE001
        print('[DP_Hub] doc danh sach tab hong: %r' % (e,))
        return []


def _thu_tu_dang_ky(lops):
    """{lop: vi tri dang ky} suy tu khuon cua nha DP: goi goc co
    `_MODULES` (hoac `modules`), moi module co `classes`, va `register()` goi
    lan luot theo dung thu tu do. None neu khong tim du moi lop."""
    import sys
    ra = {}
    try:
        goc_ten = {c.__module__.split('.')[0] for c in lops}
        for g in sorted(goc_ten):
            goc = sys.modules.get(g)
            if goc is None:
                return None
            mods = (getattr(goc, '_MODULES', None)
                    or getattr(goc, 'modules', None) or ())
            for m in list(mods) + [goc]:
                # Moi tuple/list CHI CHUA LOP trong module, theo thu tu khai
                # bao — ten tuy addon: `classes`, `_CLASSES`, `_LOP`
                # (DP_Sketch)...
                for ds in list(vars(m).values()):
                    if not (isinstance(ds, (list, tuple)) and ds and
                            all(isinstance(c, type) for c in ds)):
                        continue
                    for c in ds:
                        if c not in ra:
                            ra[c] = len(ra)
    except Exception:                                        # noqa: BLE001
        return None
    if all(c in ra for c in lops):
        return ra
    return None


def panel_cua_tab(tab, space):
    """Moi lop Panel cua mot tab, CHA TRUOC CON SAU, dung thu tu khai bao.

    ⛔ `bpy.types.Panel.__subclasses__()` GIU THU TU KHAI BAO; `dir(bpy.types)`
    thi sap theo chu cai. Dung cai sau thi bang dau tien cua DP_Sketch tro
    thanh "Dimensions" trong khi panel N that mo dau bang "Tools".

    ⛔ PHAI LOC `is_registered`. `__subclasses__()` tra ca lop da bi go dang ky
    — go addon xong ma module con trong `sys.modules` thi lop Python van song.
    """
    tat = []
    try:
        for c in bpy.types.Panel.__subclasses__():
            if not getattr(c, 'is_registered', False):
                continue
            if getattr(c, 'bl_region_type', '') != 'UI':
                continue
            if getattr(c, 'bl_category', '') != tab:
                continue
            if getattr(c, 'bl_space_type', 'VIEW_3D') != space:
                continue
            if 'INSTANCED' in (getattr(c, 'bl_options', None) or ()):
                continue
            tat.append(c)
    except Exception as e:                                   # noqa: BLE001
        print('[DP_Hub] gom panel cua %s hong: %r' % (tab, e))
        return []
    # ⛔ THU TU DANG KY, KHONG PHAI THU TU KHAI BAO. Panel N xep theo luc
    # `register_class`; `__subclasses__()` theo luc dinh nghia lop. DP_Tiles
    # ("Common sizes" roi xuong day) va DP_Sketch (Sweep Profile len dau o
    # panel N, xuong cuoi o Hub) lech vi cho nay (agent 25/09/2026). Chi dung
    # khi TIM DU moi panel trong danh sach dang ky — thieu mot cai thi giu
    # cach cu, dung tron hai thu tu.
    dk = _thu_tu_dang_ky(tat)
    if dk is not None:
        tat.sort(key=lambda c: (getattr(c, 'bl_order', 0), dk[c]))
    else:
        tat.sort(key=lambda c: getattr(c, 'bl_order', 0))
    # ⛔ LONG BAO NHIEU CAP CUNG PHAI DUNG THU TU. Truoc day cho nay chi
    # long MOT cap: panel goc, roi con truc tiep cua no. DP-PostProcessing co
    # ba bang `DPP_PT_mask_area/light/colour` la CHAU (cha cua chung la
    # `DPP_PT_masks`), nen chung roi vao nhanh "con mo coi cha" va bi day
    # xuong DAY o — sau ca Export va Copy/Sync. Khach them mot mask xong thi
    # moi thanh truot chinh no nam cach do ~2.800 px xuong duoi.
    # Do 23/09/2026.
    def _cay(idn, con_lai):
        ra = []
        for x in list(con_lai):
            if (getattr(x, 'bl_parent_id', '') or '') != idn:
                continue
            con_lai.remove(x)
            ra.append(x)
            ra.extend(_cay(getattr(x, 'bl_idname', None) or x.__name__,
                           con_lai))
        return ra

    con_lai = list(tat)
    cha = [c for c in tat if not getattr(c, 'bl_parent_id', '')]
    ra = []
    for c in cha:
        if c in con_lai:
            con_lai.remove(c)
        ra.append(c)
        ra.extend(_cay(getattr(c, 'bl_idname', None) or c.__name__, con_lai))
    ra.extend(con_lai)                  # panel con mo coi cha
    return ra


# ================================================================= cai khay
def lay_khay(tao=False):
    """Mot Khay DUY NHAT cho ca phien — no song trong cua so DP.

    Truoc day moi vung VIEW_3D mot Khay rieng (ve de len viewport). Bo khay
    xep canh roi thi chi con mot cho de ve, nen cung chi con mot Khay.
    """
    kh = _KHAY[0]
    if kh is None and tao:
        kh = O.Khay()
        _KHAY[0] = kh
        nap_danh_muc(kh)
        kh.doc_nho()
    return kh


def nap_danh_muc(kh):
    """Ghi ten moi o CO THE bat. Chua bat thi chua ve gi ca."""
    for tab, space in cac_tab():
        lop = panel_cua_tab(tab, space)
        if lop:
            kh.dang_ky(tab, lop)


# ══════════════════════════════════════════════════════════════════════════
# CAI LAU THI HUB KHOA — Ducphan chot 24/09/2026
# ══════════════════════════════════════════════════════════════════════════
# *"cai lau thi hub khoa luon chu xu ly the nao"*. Luat cu "quet duoc = da
# mua" hong o mot cho: zip chep tu may khac, cai thang qua Preferences, khong
# di qua nut Install cua Hub. Addon do van co tab -> van len cua so DP.
#
# Nay moi tab hoi trang thai ma THAT (`gate.verify_text` + cho ngoi, y
# `ui_hub.product_state` — KHONG phai `gate.check`, xem `_trang_thai_khoa`)
# theo ma san pham cua addon chu tab:
#   · mien phi / khong co trong danh muc  -> cho qua (khong phai hang cua ta
#     hoac khong khoa)
#   · addon chay BAN DEV (tu ma nguon)     -> cho qua (may dev khong co ma)
#   · OK                                   -> cho qua
#   · EXPIRED / SEAT_TAKEN                 -> CHO QUA. Luat 23/09: het han
#     khong dong o, ruot addon tu hien hop dan ma. Doi may thi van la chu that.
#   · NO_PUBKEY                            -> cho qua (loi dong goi cua TA,
#     khong bat khach tra gia)
#   · con lai (NO_KEY, BAD_KEY, WRONG_PRODUCT, WRONG_MACHINE, SEAT_REVOKED)
#                                          -> KHOA: khong co trong menu, o
#     dang mo thi dong.
#
# ⛔ KHONG CHAY TRONG draw(). Kiem ma = doc dia + kiem chu ky RSA. Chi chay o
# `lam_moi` (mo cua so, chuot phai cho trong) va co dem 5 giay.
#
# Bang du phong module -> ma: danh muc da ghi co the mat/chua tai — xoa file
# dem danh muc khong duoc thanh duong mo khoa.
_MA_DU_PHONG = {
    'max_importer_pro': 'dpmax', 'dp_lighting': 'dplight',
    'dp_camera': 'dpcam', 'dp_postprocess': 'dppost',
    'dp_su_sync': 'dpsusync', 'dp_tiles': 'dptiles',
    'dp_matpro': 'dpmatpro', 'dp_sketch': 'dpsketch',
    'dp_cadsyncblender': None, 'dp_optimize': None, 'dp_ramchill': None,
}
_DEM_KHOA = {}          # ma -> (luc, cho_phep)
_TTL_KHOA = 5.0


def _ma_cua_module():
    """{module: ma san pham | None neu mien phi}."""
    bd = dict(_MA_DU_PHONG)
    try:
        from . import catalog
        ds, _at = catalog.load_cached()
        for p in ds:
            bd[p['module']] = None if p.get('free') else p['code']
    except Exception as e:                                   # noqa: BLE001
        print('[DP_Hub] doc danh muc de soat khoa hong: %r' % (e,))
    return bd


def _addon_la_ban_dev(mo):
    """True neu addon `mo` dang chay BAN DEV (tu ma nguon, `RELEASE_BUILD`
    cua ban `dp_license` chep trong no = False). Ban phat hanh bat co nay."""
    import sys
    g = sys.modules.get(mo + '.dp_license.gate')
    return g is not None and not getattr(g, 'RELEASE_BUILD', True)


def _trang_thai_khoa(ma):
    """Trang thai THAT cua ma san pham tren may nay — y `ui_hub.product_state`.

    ⛔ KHONG DUNG `gate.check`. Do 24/09/2026 (agent ra soat, tren chinh goi
    dong ra): Hub la ban dev (`RELEASE_BUILD=False`, co y — xem dau
    `ui_hub.py`), nen `check` luon tra DEV va MOI addon cai lau deu lot qua.
    Bai `thu_khoa_lau` cu dat 28/28 chi vi no tu bat `RELEASE_BUILD`."""
    from .dp_license import gate
    text = gate.load_key(ma)
    st = gate.verify_text(text, ma)[0]
    if st == gate.OK:
        st = gate._seat_state(text)
    return st


def _duoc_mo(ma, mo=None, soat=True):
    """True neu cua so DP duoc phep hien addon (module `mo`, ma `ma`).

    `soat=False` (duong draw): chi dung ket qua da dem, bat ke cu bao lau;
    chua co thi moi kiem mot lan."""
    if not ma:
        return True
    k = (ma, mo)
    now = time.monotonic()
    d = _DEM_KHOA.get(k)
    if d is not None and (not soat or now - d[0] < _TTL_KHOA):
        return d[1]
    try:
        from .dp_license import gate
        if mo and _addon_la_ban_dev(mo):
            # May dev (chay tu nguon) khong co file ma nao — khong khoa.
            # Ban cai tu zip phat hanh (ke ca zip chep lau) luon bat co.
            ok = True
        else:
            st = _trang_thai_khoa(ma)
            ok = st in (gate.OK, gate.EXPIRED, gate.SEAT_TAKEN,
                        gate.NO_PUBKEY)
    except Exception as e:                                   # noqa: BLE001
        # Cua khoa hong la loi cua TA — khong khoa khach vi no.
        print('[DP_Hub] soat khoa %s hong: %r' % (ma, e))
        ok = True
    _DEM_KHOA[k] = (now, ok)
    return ok


def _tab_duoc_mo(lop, bang_ma, soat=True):
    """Mot tab duoc mo khi MOI addon gop panel vao no deu duoc mo."""
    for mo in {c.__module__.split('.')[0] for c in lop}:
        if not _duoc_mo(bang_ma.get(mo), mo, soat):
            return False
    return True


_BANG_MA = [None]


def lam_moi(kh, soat=True):
    """Cai lai danh sach lop panel — goi khi cai/go addon giua phien.

    `soat=False` la duong goi tu trong draw (`_lay_lai_lop`): khong doc lai
    danh muc tu dia, khong kiem lai chu ky — chi dung ket qua da co."""
    if soat or _BANG_MA[0] is None:
        _BANG_MA[0] = _ma_cua_module()
    bang_ma = _BANG_MA[0]
    for tab, space in cac_tab():
        lop = panel_cua_tab(tab, space)
        if lop and not _tab_duoc_mo(lop, bang_ma, soat):
            # CAI LAU: go khoi danh muc, o dang mo thi dong han.
            if kh._muc(tab) is not None:
                kh.tat(tab)
                kh.danh_muc = [m for m in kh.danh_muc if m['ten'] != tab]
            continue
        if lop:
            m = kh.dang_ky(tab, lop)
            if m.get('o') is not None:
                m['o'].cac_lop = lop


def dang_bat(context=None):
    return cua_so.dang_mo()


# =============================================================== lop ve
def _ve():
    """⛔ CHI VE TRONG CUA SO DP. Lop ve dang ky theo LOAI SPACE, nen moi
    `TEXT_EDITOR` dang mo tren may deu goi vao day — khong hoi lai cua so thi
    khach mo mot cua so soan chu la thay ca cum o de len."""
    ct = bpy.context
    if not cua_so.la_cua_dp(getattr(ct, 'window', None)):
        return
    kh = _KHAY[0]
    if kh is None:
        return
    reg = ct.region
    if reg is None or reg.type != 'WINDOW':
        return
    try:
        kh.ve(ct, reg.width, reg.height)
    except Exception as e:                                   # noqa: BLE001
        # ⛔ MOT LOI TRONG RUOT ADDON KHONG DUOC LAM DEN MAN HINH. Bat tai
        # cho, in ra, va van tra ve — luat "khong duoc gay anh huong, vang".
        print('[DP_Hub] ve khay hong: %r' % (e,))
        try:
            V.xa()
        except Exception:                                    # noqa: BLE001
            pass


# ============================================================== operator
class DPHUB_OT_khay(bpy.types.Operator):
    """Open the DP window - a floating window you can drag anywhere"""
    bl_idname = 'dphub.khay'
    bl_label = 'DP window'
    bl_options = {'REGISTER'}

    def invoke(self, context, event):
        # ⛔ CHOT CHONG MO HAI LAN. Da do 23/09/2026: bam "Open DP window"
        # lan hai KHONG sinh cua so thu hai (`cua_so.mo` tra lai cai cu), nhung
        # `invoke` van chay tiep va goi `modal_handler_add` them mot lan nua.
        # Mot cu MOUSEMOVE sau do duoc HAI the modal cung xu ly; bam 10 lan la
        # 10 modal, moi su kien chuot quet `_tim()` 10 luot. Dung cai luat
        # "khay phai nhe" cam. Va khi mot modal thoat, no ha `_CHAY` trong khi
        # nhung modal kia con song -> trang thai sai.
        if _CHAY[0] and cua_so.dang_mo():
            cua_so.ve_lai()
            return {'CANCELLED'}
        kh = lay_khay(tao=True)
        if kh is None:
            return {'CANCELLED'}
        lam_moi(kh)
        w = cua_so.mo(_ve)
        if w is None:
            self.report({'WARNING'}, 'Could not open the DP window')
            return {'CANCELLED'}
        cua_so.nho_dang_mo(True)

        # ⛔ MODAL PHAI GAN VAO CHINH CUA SO DP. `modal_handler_add` gan vao
        # `context.window`; goi thang tu panel N la gan nham vao cua so chinh
        # va cua so DP khong nhan duoc cu bam nao. Da do 23/09/2026: modal
        # goi trong cua so roi nhan 3/3 su kien cua no, 0/3 cua cua so chinh.
        ar, reg = cua_so.vung()
        if ar is None or reg is None:
            cua_so.dong()
            self.report({'WARNING'}, 'The DP window has no area to draw in')
            return {'CANCELLED'}
        try:
            with context.temp_override(window=w, area=ar, region=reg):
                context.window_manager.modal_handler_add(self)
        except Exception as e:                               # noqa: BLE001
            print('[DP_Hub] gan modal hong: %r' % (e,))
            cua_so.dong()
            return {'CANCELLED'}
        _CHAY[0] = True
        cua_so.ve_lai()
        return {'RUNNING_MODAL'}

    def _het(self):
        _CHAY[0] = False
        return {'FINISHED'}

    def cancel(self, context):
        """Blender goi day khi modal bi huy — KE CA khi cua so giu no bi dong.

        ⛔ DAY LA DUONG DON DUY NHAT KHI KHACH BAM ✕. Modal duoc gan VAO CHINH
        cua so DP; Blender giai phong modal handler cua mot cua so khi cua so
        do dong, nen `modal()` KHONG BAO GIO chay nua — nhanh don trong do chet
        kho. Da do 23/09/2026: sau khi bam ✕, `_CHAY` van True va lop ve van
        con dang ky tren `SpaceTextEditor` cho toi khi tat addon. Cung duong
        nay cuu ca truong hop File ▸ New / File ▸ Open (da do: Blender goi
        `cancel()` khi doc file moi).

        ⛔ KHONG GOI `bpy.ops` O DAY. Luc nay Blender dang giai phong cua so;
        chi dat lai bien Python.
        """
        _CHAY[0] = False
        try:
            cua_so.quen()
            cua_so.nho_dang_mo(False)
        except Exception as e:                               # noqa: BLE001
            print('[DP_Hub] cancel don hong: %r' % (e,))

    # --------------------------------------------------------------- modal
    def modal(self, context, event):
        kh = _KHAY[0]
        # Khach tu bam X dong cua so DP -> khong con gi de nhan nua.
        if kh is None or not cua_so.dang_mo():
            cua_so.quen()
            return self._het()

        # ⛔ KHONG DOC `context.area` DE QUYET DINH SONG CHET — no la vung
        # duoi con tro. Chi hoi mot cau: su kien nay co phai cua CUA SO DP
        # khong. Khong phai thi tra het lai cho Blender, va VAN SONG.
        trong_cua = cua_so.la_cua_dp(getattr(context, 'window', None))

        # ⛔ DANG KEO THI BAM THEO CHUOT TOI CUNG, du no di ra khoi cua so DP.
        # Ducphan 23/09/2026, thu tay: *"khi di chuot vao cho de co dan cua so
        # addon thi bi dinh chuot lai"*.
        # Goc benh: goc co dan nam o MEP PHAI DUOI cua o, nen keo sang phai la
        # con tro ra khoi cua so DP chi sau vai chuc pixel. Luc do nhanh nay
        # tra `PASS_THROUGH` NGAY, truoc khi kip xu ly cu NHA chuot — `tha()`
        # khong bao gio chay, `kh.keo` ket lai, va tu do moi cu di chuot deu
        # tiep tuc co dan o. Khach tha tay roi ma o van dinh theo chuot.
        # Blender cung lam the: modal da bat mot cu keo thi giu toi luc nha.
        if not trong_cua and kh.keo is None:
            # ⛔ TAT DIEM SANG KHI CHUOT DI CHO KHAC. Da do 23/09/2026:
            # `Khay.ra_ngoai()` co san ma KHONG AI GOI, nen dua chuot sang cua
            # so chinh thi nut cuoi cung van sang nhu dang re chuot len no.
            if kh.ra_ngoai():
                cua_so.ve_lai()
            _TRO_CU[0] = None       # ra khoi cua so DP: quen con tro da dat
            # ⛔ LENH CHAY TU PANEL N CUNG PHAI HIEN TREN O. Scan cua
            # RAMchill ghi `bao_cao` ma khong qua depsgraph -> moc
            # `_canh_doi` khong chay, o DP hien so cu toi khi re chuot vao
            # (agent RAMchill vong 2, 25/09/2026). Nha chuot / Enter o cua so
            # khac -> dung lai ruot MUON mot nhip (lenh chay xong da).
            if event.value == 'RELEASE' and event.type in (
                    'LEFTMOUSE', 'RET', 'NUMPAD_ENTER'):
                cua_so.ve_sau_lenh()
            return {'PASS_THROUGH'}

        ar, reg = cua_so.vung()
        if ar is None or reg is None:
            # Vung khong con ma tay van dang keo -> bo cu keo, dung de ket.
            if kh.keo is not None:
                kh.tha()
            return {'PASS_THROUGH'}
        mx = event.mouse_x - reg.x
        my = event.mouse_y - reg.y

        # Dang keo ma su kien den tu cua so khac: chi quan tam DI va NHA.
        if not trong_cua:
            # ⛔ KHONG BAO GIO TRA `RUNNING_MODAL` CHO SU KIEN CUA CUA SO
            # KHAC. Ducphan 23/09/2026: *"gio thi co gang di chuyen vi tri
            # cua so addon cung vang luon blender"* — SIGSEGV, khong mot
            # khung Python nao trong vet, toan ma C cua WM.
            # Modal nay duoc gan VAO CUA SO DP. Tra `RUNNING_MODAL` la bao
            # "toi da nuot su kien nay"; khi su kien do thuoc cua so khac,
            # Blender van dang trao area/region theo handler cua cua so kia.
            # Nuot cheo cua so nhu the la tu tay lam roi trang thai WM.
            # Van XU LY cu keo (khong thi dinh chuot — benh cu), nhung tra
            # `PASS_THROUGH` de Blender tiep tuc phat su kien cho chu that
            # su cua no. Chuot dang giu nut trai nen khong lenh nao cua cua
            # so kia khoi dong tu mot cu MOUSEMOVE tran.
            if event.type == 'MOUSEMOVE':
                if kh.di(mx, my):
                    _ve_sau_keo(kh)
            elif event.type == 'LEFTMOUSE' and event.value == 'RELEASE':
                cham = kh.keo_cham_du_lieu()
                kh.tha()
                cua_so.ve_lai_ca_hai() if cham else cua_so.ve_lai()
            return {'PASS_THROUGH'}

        if event.type == 'MOUSEMOVE':
            _dat_con_tro(context, kh, mx, my)
            if kh.di(mx, my):
                # ⛔ KEO GIA TRI -> viewport phai thay NGAY. Con keo cho ngoi
                # cua the thi chi ve lai cua so DP. Xem
                # `khay/o.py::Khay.keo_cham_du_lieu()`.
                _ve_sau_keo(kh)
                return {'RUNNING_MODAL'}
            if kh.ro(mx, my):
                _ve_lai_ham()
            # ⛔ NUOT CU RE CHUOT TRONG CUA SO DP — khong thi con tro luon la
            # chu I. Ducphan 23/09/2026, thu tay: *"con tro chuot van kieu con
            # tro chuot soan thao van ban"*. `_dat_con_tro` co dat dung, nhung
            # tra `PASS_THROUGH` thi Blender chay tiep phan "vung duoi chuot"
            # (`ED_screen_set_active_region`, chi chay khi modal KHONG nuot) va
            # vung do la TEXT_EDITOR: no dat lai con tro go chu, de len cai cua
            # ta. Cua so DP chi de chua o — Text Editor ben duoi khong can cu
            # re chuot nao. Chi nuot su kien CUA CHINH CUA SO DP (su kien cua
            # cua so khac da tra `PASS_THROUGH` o tren — luat chong vang).
            return {'RUNNING_MODAL'}

        if event.type == 'LEFTMOUSE':
            if event.value == 'DOUBLE_CLICK':
                # Bam dup trong o dang go: boi den mot tu, y Blender.
                if kh.bam_doi(mx, my):
                    cua_so.ve_lai()
                    return {'RUNNING_MODAL'}
            if event.value == 'PRESS':
                if kh.bam(context, mx, my):
                    cua_so.ve_lai_ca_hai()
                    return {'RUNNING_MODAL'}
            elif event.value == 'RELEASE':
                cham = kh.keo_cham_du_lieu()
                if kh.tha():
                    cua_so.ve_lai_ca_hai() if cham else cua_so.ve_lai()
                    return {'RUNNING_MODAL'}
            return {'PASS_THROUGH'}

        # ⛔ CHUOT PHAI PHAI CO TAC DUNG. Ducphan 23/09/2026, thu tay:
        # *"cac thao tac chuot phai len cac cua so npanel dang khong co tac
        # dung"*. Truoc day khong bat `RIGHTMOUSE` chut nao nen cu bam roi
        # thang xuong TEXT_EDITOR ben duoi. Xem `Khay.chuot_phai`.
        # ⛔ NUOT CHUOT PHAI, KE CA KHI TA KHONG CO MENU NAO DE BAY.
        # Do 23/09/2026: cua so DP la mot `TEXT_EDITOR`, va keymap `Text` cua
        # Blender co `RIGHTMOUSE -> wm.call_menu TEXT_MT_context_menu`. Bam
        # chuot phai len mot cai NHAN, len dau bang, hay len nen the thi bung
        # menu "Top of File / Bottom of File / Run Script / Cut / Copy..."
        # cua trinh soan thao van ban, phu len o. Cua so DP chi de chua o —
        # khong co ly do nao tra chuot phai ve cho TEXT_EDITOR ben duoi.
        if event.type == 'RIGHTMOUSE':
            # Chuot phai vao cho trong bung danh sach addon — quet lai truoc
            # de addon vua cai/go giua phien cung co mat. Chi quet luc do.
            if event.value == 'PRESS' and kh._tim(mx, my) is None \
                    and not kh.menu and not kh.noi:
                try:
                    lam_moi(kh)
                except Exception:                            # noqa: BLE001
                    pass
            if event.value == 'PRESS' and kh.chuot_phai(context, mx, my):
                cua_so.ve_lai()
            return {'RUNNING_MODAL'}

        if event.type in ('WHEELUPMOUSE', 'WHEELDOWNMOUSE') and \
                event.value == 'PRESS':
            if kh.lan(mx, my, event.type == 'WHEELDOWNMOUSE'):
                ar.tag_redraw()          # chi cuon, khong doi gia tri nao
                return {'RUNNING_MODAL'}
            return {'PASS_THROUGH'}

        # ⛔ CHI CUOP PHIM KHI DANG GO MOT O NHAP. `kh.phim` tu tra False luc
        # khong soan — moi phim tat cua Blender con nguyen.
        if event.value == 'PRESS' and kh.phim(event):
            cua_so.ve_lai_ca_hai()
            return {'RUNNING_MODAL'}
        return {'PASS_THROUGH'}


class DPHUB_OT_khay_dong(bpy.types.Operator):
    """Close the DP window"""
    bl_idname = 'dphub.khay_dong'
    bl_label = 'Close DP window'
    bl_options = {'REGISTER'}

    def execute(self, context):
        kh = _KHAY[0]
        if kh is not None:
            try:
                kh.ghi_nho()
            except Exception:                                # noqa: BLE001
                pass
        cua_so.dong()
        cua_so.nho_dang_mo(False)
        # modal tu thay cua so khong con va thoat o nhip su kien ke tiep.
        return {'FINISHED'}


class DPHUB_OT_khay_o(bpy.types.Operator):
    """Show or hide this plugin's box in the DP window"""
    bl_idname = 'dphub.khay_o'
    bl_label = 'Toggle box'
    bl_options = {'REGISTER'}

    ten: bpy.props.StringProperty()

    def execute(self, context):
        kh = lay_khay(tao=True)
        if kh is None:
            return {'CANCELLED'}
        lam_moi(kh)
        kh.dao(self.ten)
        kh.ghi_nho()
        # ⛔ CO HINH THI PHAI CO NGUOI NHAN PHIM. Da dam 23/09/2026: bat mot o
        # khi chua mo cua so thi o duoc VE RA ma khong modal nao chay — khach
        # thay mot cai bang chet cung. Nay tu mo cua so DP luon.
        if not cua_so.dang_mo() or not _CHAY[0]:
            try:
                bpy.ops.dphub.khay('INVOKE_DEFAULT')
            except Exception as e:                           # noqa: BLE001
                print('[DP_Hub] khong mo duoc cua so DP: %r' % (e,))
        cua_so.ve_lai()
        return {'FINISHED'}


# ================================================ khoi ve trong panel N
def ve_khoi(layout, context):
    """Khoi "DP window" trong panel N cua Hub.

    ⛔ PANEL N GIU NGUYEN LAM DUONG LUI. Card tu choi bien dich shader, chay
    `--background`, hay may khong GPU thi khach van dung duoc moi addon qua
    panel N nhu cu. Khoi nay chi la cho BAT cua so, khong thay the gi.
    """
    hop = layout.box()
    hang = hop.row(align=True)
    hang.label(text='DP window', icon='WINDOW')
    tabs = cac_tab()
    if not tabs:
        hop.label(text='No plugin panels found yet', icon='INFO')
        return

    mo = cua_so.dang_mo()
    h = hop.row(align=True)
    # Da mo roi thi tat nut — xem chot chong mo hai lan o `invoke`.
    h1 = h.row(align=True)
    h1.enabled = not mo
    h1.operator('dphub.khay', text='Open DP window', icon='WINDOW')
    h2 = h.row(align=True)
    h2.enabled = mo
    h2.operator('dphub.khay_dong', text='', icon='X')

    kh = _KHAY[0]
    cot = hop.column(align=True)
    for tab, _space in tabs:
        dang = False
        if kh is not None:
            m = kh._muc(tab)
            dang = bool(m and m.get('o') is not None)
        r = cot.row(align=True)
        r.operator('dphub.khay_o', text=tab,
                   icon='CHECKBOX_HLT' if dang else 'CHECKBOX_DEHLT',
                   depress=dang).ten = tab


# ================================================================ dang ky
LOP = (DPHUB_OT_khay, DPHUB_OT_khay_dong, DPHUB_OT_khay_o)


def _ve_sau_keo(kh):
    """Ve lai dung cho sau mot nhip keo.

    ⛔ CHI DANH THUC VIEWPORT KHI CU KEO DOI GIA TRI THAT. Xem ghi chu day
    du o `khay/o.py::Khay.keo_cham_du_lieu()`.
    """
    if kh.keo_cham_du_lieu():
        cua_so.ve_lai_ca_hai()
    else:
        cua_so.ve_lai()


_TRO_CU = [None]


def _dat_con_tro(context, kh, mx, my):
    """Dat con tro chuot cho hop voi o dang nam duoi no.

    ⛔ DAT MOI CU DI CHUOT, KHONG NHO "DA DAT ROI". Truoc day chi dat khi ten
    doi — nhung Blender tu dat lai con tro sau lung ta (vao/ra cua so, doi
    tieu diem), va ta cu tuong con tro van dung nen khong dat lai: con tro chu
    I dinh luon. Goi lai moi nhip chi la mot lenh C re.
    """
    try:
        ten = kh.con_tro(mx, my)
        _TRO_CU[0] = ten
        context.window.cursor_set(ten)
    except Exception:                                        # noqa: BLE001
        pass


def _ve_lai_ham():
    """Ve lai vi DIEM SANG doi — nhung khong qua `NHIP` lan mot giay.

    Cu re chuot bi bo thi dat mot hen gio ve bu, khong thi chuot dung lai
    dung luc vua bo la diem sang ket o o cu.
    """
    gio = time.monotonic()
    if gio - _LAN_VE[0] >= NHIP:
        _LAN_VE[0] = gio
        cua_so.ve_lai()
        return
    if not _CHO[0]:
        _CHO[0] = True
        # ⛔ persistent=True: mo file dung luc dang cho thi hen gio bi xoa,
        # `_CHO` ket o True va tu do khong con nhip ve bu nao nua.
        bpy.app.timers.register(_ve_bu, first_interval=NHIP, persistent=True)


def _ve_bu():
    _CHO[0] = False
    if cua_so.dang_mo():
        _LAN_VE[0] = time.monotonic()
        cua_so.ve_lai()
    return None


def _lay_lai_lop():
    """Cai lai danh sach lop Panel cho moi o dang bat.

    ⛔ Goi tu trong `draw()`, nen phai NHE va khong duoc nem loi. `lam_moi`
    chi quet `Panel.__subclasses__()` mot luot — cung cai viec `ve_khoi` da
    lam moi lan panel N ve lai.
    """
    kh = _KHAY[0]
    if kh is not None:
        lam_moi(kh, soat=False)


def _da_dong():
    """`cua_so` goi khi cua so DP khong con — dung cho `_CHAY` ket o True."""
    _CHAY[0] = False


def register():
    khay.lenh.dang_ky()
    for c in LOP:
        bpy.utils.register_class(c)
    cua_so.khi_dong(_da_dong)
    # Addon dang ky lai lop Panel giua chung (vi du doi ngon ngu cua
    # DP_Lighting) thi `o.py` goi vao day de lay danh sach moi.
    O.LAM_MOI[0] = _lay_lai_lop
    # Canh doi (chon vat khac, chay mot lenh, undo) -> cua so DP
    # phai ve lai ngay, khong doi khach quet chuot vao.
    cua_so.bat_theo_canh()
    # Dong cua so DP truoc khi Blender ghi file, mo lai ngay sau — de no
    # khong dinh vao file .blend cua khach. Xem ghi chu o `cua_so.py`.
    cua_so.bat_giu_file(_ve)


def unregister():
    kh = _KHAY[0]
    if kh is not None:
        try:
            kh.ghi_nho()
        except Exception:                                    # noqa: BLE001
            pass
    _KHAY[0] = None
    _CHAY[0] = False
    O.LAM_MOI[0] = None
    cua_so.tat_theo_canh()
    cua_so.khi_dong(None)
    cua_so.go_giu_file()
    try:
        cua_so.dong()
    except Exception:                                        # noqa: BLE001
        pass
    for c in reversed(LOP):
        try:
            bpy.utils.unregister_class(c)
        except Exception:                                    # noqa: BLE001
            pass
    khay.lenh.go()
