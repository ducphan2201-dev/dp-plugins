# -*- coding: utf-8 -*-
"""Danh mục plugin — MỘT file JSON trên máy chủ, tác giả sửa một chỗ là xong.

VÌ SAO LÀ FILE TĨNH CHỨ KHÔNG PHẢI SERVER
-----------------------------------------
Khai báo plugin mới = sửa `catalog.json` rồi đẩy lên GitHub. Không có tiến
trình nào phải chạy, không có gì để sập lúc nửa đêm, và lịch sử sửa đổi có sẵn.
Link tải zip để công khai cũng không mất gì: khoá bản quyền nằm trong GÓI DỮ
LIỆU chứ không nằm ở đường tải — tải về mà không có mã thì panel vẫn trống.

CHỈ TẢI KHI NGƯỜI DÙNG BẤM NÚT
------------------------------
Addon KHÔNG tự gọi mạng lúc mở Blender. Bản đã tải được ghi lại xuống đĩa nên
lần mở sau vẫn thấy danh mục cũ mà không cần mạng; dòng ngày tháng trên panel
nói rõ nó cũ tới đâu.

MỘT MỤC HỎNG KHÔNG ĐƯỢC LÀM HỎNG CẢ DANH MỤC
--------------------------------------------
Mục nào thiếu trường thì bỏ mục đó, giữ phần còn lại, và ĐẾM SỐ MỤC ĐÃ BỎ để
panel nói ra. Bỏ lặng lẽ thì tác giả gõ sai một dấu phẩy sẽ không bao giờ biết.
"""
import os
import io
import json
import time
import zipfile

# Địa chỉ danh mục. Repo phải CÔNG KHAI — `raw.githubusercontent.com` không đọc
# được repo riêng tư nếu không kèm token, mà token thì không được đi vào bản
# phát hành. Người dùng đổi được địa chỉ này trong Preferences của addon.
DEFAULT_URL = ('https://raw.githubusercontent.com/'
               'ducphan2201-dev/dp-plugins/main/catalog.json')

TIMEOUT = 8             # giây — nút bấm mà chờ lâu hơn thì người ta tưởng treo
MAX_BYTES = 2 * 1024 * 1024

_REQUIRED = ('code', 'module', 'name', 'version')


def store_dir():
    """Chỗ ghi bản danh mục đã tải. Cùng gốc với chỗ lưu mã kích hoạt."""
    try:
        import bpy
        p = bpy.utils.user_resource('CONFIG', path='dp_license', create=True)
        if p:
            return p
    except Exception:
        pass
    base = os.environ.get('LOCALAPPDATA') or os.path.expanduser('~')
    p = os.path.join(base, 'DP_License')
    os.makedirs(p, exist_ok=True)
    return p


def cache_path():
    return os.path.join(store_dir(), 'catalog.json')


# ------------------------------------------------------------------ tải về
def http_get(url, timeout=TIMEOUT, max_bytes=MAX_BYTES, key=None):
    """Tải một địa chỉ về dạng bytes. Ném ngoại lệ nếu hỏng.

    Ưu tiên `requests` vì Blender có đóng gói sẵn nó KÈM `certifi` — chứng chỉ
    HTTPS của Python trần trên Windows có máy đọc được có máy không. Không có
    thì lùi về `urllib` để chỗ nào cũng chạy được.

    `key` = mã kích hoạt, gửi kèm cho đường tải có cửa kiểm. Nó đi trong ĐẦU
    ĐỀ chứ không nằm trong địa chỉ: địa chỉ bị ghi vào nhật ký của mọi máy chủ
    trung gian, còn mã kích hoạt là thứ của riêng khách.
    """
    headers = {'User-Agent': 'DP_Hub'}
    if key:
        headers['X-DP-Key'] = key
    try:
        import requests
        resp = requests.get(url, timeout=timeout, stream=True, headers=headers)
        resp.raise_for_status()
        return resp.raw.read(max_bytes + 1, decode_content=True)
    except ImportError:
        pass
    import urllib.request
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=timeout) as fh:
        return fh.read(max_bytes + 1)


def http_post(url, data, timeout=60, content_type='application/octet-stream'):
    """Gửi `data` (bytes) lên `url` bằng POST. Trả bytes máy chủ đáp lại.

    Dùng cho nút *Send order*: ảnh biên lai đi THẲNG trong thân yêu cầu, không
    base64 và không multipart. Mức miễn phí của cửa kiểm giới hạn THỜI GIAN
    TÍNH TOÁN mỗi lượt, mà giải mã một ảnh 3 MB là đủ chạm trần — còn nhận
    nguyên byte rồi cất thì gần như không tốn gì.

    Ném ngoại lệ y như `http_get` khi hỏng, và ném theo cùng một khuôn để
    `http_status` đọc được mã HTTP ở cả hai đường (`requests` và `urllib`).
    """
    headers = {'User-Agent': 'DP_Hub', 'Content-Type': content_type}
    try:
        import requests
        resp = requests.post(url, data=data, timeout=timeout, headers=headers)
        resp.raise_for_status()
        return resp.content
    except ImportError:
        pass
    import urllib.request
    req = urllib.request.Request(url, data=data, headers=headers,
                                 method='POST')
    with urllib.request.urlopen(req, timeout=timeout) as fh:
        return fh.read(MAX_BYTES)


def http_status(exc):
    """Mã HTTP trong một ngoại lệ của `http_get`, hoặc None.

    Phải hỏi ở ĐÂY vì chỉ chỗ này biết `http_get` có hai đường: `urllib` ném
    `HTTPError` (có `.code`), còn `requests` ném `HTTPError` của riêng nó — thứ
    KHÔNG có `.code` mà giấu mã trong `.response.status_code`. Blender đóng gói
    sẵn `requests`, nên đường chạy trên máy khách thật là đường thứ hai; hỏi mỗi
    `.code` là trên máy khách không bao giờ đọc ra mã nào.
    """
    code = getattr(exc, 'code', None)
    if isinstance(code, int):
        return code
    resp = getattr(exc, 'response', None)
    code = getattr(resp, 'status_code', None)
    return code if isinstance(code, int) else None


def _price(raw):
    """Giá bằng ĐỒNG, luôn là số nguyên >= 0. Thứ gì lạ cũng thành 0.

    Danh mục đi qua mạng: một ngày nào đó nó có thể mang chuỗi, số thực, hay
    `null`. Ném ngoại lệ ở đây là bảng Hub trống trơn vì một ô giá gõ sai; coi
    như chưa định giá thì khách chỉ mất nút tick của đúng sản phẩm đó.
    """
    try:
        n = int(raw or 0)
    except (TypeError, ValueError):
        return 0
    return n if n > 0 else 0


def _safe_qr_url(url):
    """Địa chỉ ảnh QR có an toàn để tải không.

    `https` là bắt buộc với mọi địa chỉ đi qua mạng: ai đứng giữa đường truyền
    cũng thay được ảnh, mà thay ảnh QR nghĩa là **đổi số tài khoản nhận tiền**.

    Riêng loopback (`127.0.0.1` / `localhost`) thì `http` vẫn nhận: gói tin
    không rời khỏi máy nên không có "đường truyền" nào để ai chen vào. Đây là
    thứ các bài kiểm chạy trên máy chủ tạm dùng — không có ngoại lệ này thì
    cơ chế QR sẽ không bao giờ được đo thật lần nào.
    """
    low = (url or '').lower()
    if low.startswith('https://'):
        return True
    return low.startswith(('http://127.0.0.1', 'http://localhost'))


def payment_of(data):
    """Khối thanh toán trong danh mục: {'qr': <địa chỉ ảnh>, 'note': <chữ>}.

    Cả hai đều có thể rỗng — tác giả chưa khai, hoặc cố ý gỡ đi. Rỗng thì bảng
    KHÔNG hiện khối chuyển khoản; đừng bao giờ dựng một ô ảnh trống, người
    dùng sẽ tưởng Hub hỏng hoặc mạng lỗi.

    Chỉ nhận địa chỉ https. Ảnh tải theo địa chỉ http trần thì ai đứng giữa
    đường truyền cũng thay được MÃ QR — tức là đổi luôn số tài khoản nhận tiền.
    """
    pay = data.get('payment') if isinstance(data, dict) else None
    if not isinstance(pay, dict):
        return {'qr': '', 'note': ''}
    qr = str(pay.get('qr') or '').strip()
    if qr and not _safe_qr_url(qr):
        print('[DP_Hub] bo qua ma QR: dia chi khong phai https (%s)' % qr[:60])
        qr = ''
    return {'qr': qr, 'note': str(pay.get('note') or '').strip()}


def normalise(data):
    """(danh_sách_sản_phẩm, số_mục_bỏ_qua) từ dữ liệu ĐÃ đọc thành đối tượng."""
    items = data.get('products') if isinstance(data, dict) else data
    if not isinstance(items, list):
        raise ValueError('catalog is not a list of products')
    good, skipped = [], 0
    for it in items:
        if not isinstance(it, dict) or not all(it.get(k) for k in _REQUIRED):
            skipped += 1
            continue
        good.append({
            'code': str(it['code']),
            'module': str(it['module']),
            'name': str(it['name']),
            'version': str(it['version']),
            'free': bool(it.get('free')),
            # Giá bán bằng ĐỒNG. 0 / thiếu / hỏng = CHƯA ĐỊNH GIÁ: bảng không
            # cho tick mua sản phẩm đó, chỉ ghi "Contact for price". Không bao
            # giờ coi giá lạ là 0 rồi cộng vào tổng — khách sẽ chuyển đúng số
            # tiền đó, tức là không chuyển gì cả.
            'price': _price(it.get('price')),
            'desc': str(it.get('desc') or ''),
            'zip': str(it.get('zip') or ''),
            'buy': str(it.get('buy') or ''),
            'video': str(it.get('video') or ''),
            # LOGO của sản phẩm. Đi theo DANH MỤC chứ không nằm trong gói
            # addon: bảng phải vẽ được logo của cả những món khách CHƯA mua,
            # mà những món đó thì trên máy họ không có gì cả. Cùng lý do với
            # mã QR — đổi logo mà phải phát hành lại DP_Hub cho mọi khách thì
            # không ai đổi bao giờ.
            'icon': str(it.get('icon') or ''),
            # `released`: bản này ĐÃ nằm trên kho phát hành hay chưa. Chưa thì
            # bảng bôi xám khối cài và không bày nút Install/Update — bày ra là
            # mời khách bấm vào một thứ chắc chắn trả 404.
            #
            # Danh mục cũ (trước 01/08/2026) không có trường này. Suy từ chỗ có
            # đường tải hay không: đó đúng là ý nghĩa nó vẫn mang từ trước, nên
            # máy khách chưa kịp nhận danh mục mới vẫn hiện đúng như cũ.
            'released': bool(it.get('released', bool(it.get('zip')))),
            # `gated`: đường tải đi qua cửa kiểm mã. Kho zip là repo RIÊNG TƯ,
            # cửa giữ token GitHub ở phía máy chủ — không có gì bí mật nằm
            # trong addon. Không có mã kích hoạt thì không tải được.
            'gated': bool(it.get('gated')),
            # NỬA KIA của sản phẩm — hiện chỉ DP_SU Sync có: bản cài phía
            # SketchUp (.rbz). Nó KHÔNG phải một sản phẩm riêng và không bao
            # giờ được đếm thành một dòng trong bảng; nó là một nút tải phụ
            # nằm trong chính khối của sản phẩm đó.
            #
            # Địa chỉ công khai, không qua cửa kiểm: cửa chỉ biết zip addon
            # Blender, và khách phải có FILE trên đĩa mới cài được vào SketchUp
            # bằng Extension Manager.
            'companion': _companion(it.get('companion')),
        })
    return good, skipped


def _companion(c):
    """Chuẩn hoá khối `companion`, hoặc None nếu thiếu/hỏng.

    Thiếu địa chỉ thì trả None chứ không trả một khối rỗng: bảng chỉ hỏi "có
    hay không", và một khối rỗng sẽ thành một nút bấm không dẫn đi đâu.
    """
    if not isinstance(c, dict):
        return None
    url = str(c.get('url') or '').strip()
    if not _safe_qr_url(url):
        return None
    return {
        'kind': str(c.get('kind') or ''),
        'label': str(c.get('label') or 'extra download'),
        'version': str(c.get('version') or ''),
        'file': str(c.get('file') or ''),
        'size': int(c.get('size') or 0),
        'url': url,
    }


def gate_of(data):
    """Địa chỉ CỬA KIỂM lấy từ danh mục, hoặc '' nếu danh mục không khai.

    ĐỌC TỪ DANH MỤC chứ không cắm cứng ở đây. Địa chỉ này do Cloudflare ghép
    theo TÊN TÀI KHOẢN, và ngày 02/08/2026 đã có một bản cắm cứng nhầm
    (`dp-gate.ducphan...`, một địa chỉ chưa bao giờ tồn tại) — nút bấm trỏ vào
    hư không mà bảng không kêu được, vì với nó chỉ là một lỗi mạng.

    `rollout.py --publish-catalog` sinh trường này từ chính hằng số nó dùng để
    dựng đường tải, nên hai chỗ không thể lệch nhau.

    Chỉ nhận `https://`: một địa chỉ `http://` trong danh mục nghĩa là mã máy
    của khách đi trên đường không mã hoá — và thứ trả về là **giấy phép**.

    Loopback vẫn nhận `http`, cùng một ngoại lệ và cùng một lý do với
    `_safe_qr_url`: gói tin không rời khỏi máy nên không có đường truyền nào để
    ai chen vào, và không có ngoại lệ này thì nút "Get my key" sẽ không bao giờ
    được đo thật một lần nào.
    """
    if not isinstance(data, dict):
        return ''
    url = str(data.get('gate') or '').strip()
    return url if _safe_qr_url(url) else ''


def hub_of(data):
    """Khối `hub` trong danh mục: {'version', 'module', 'zip'}. Luôn trả dict.

    Đây là cách DP_Hub tự cập nhật CHÍNH NÓ. Trước 03/08/2026 Hub được phát
    tay: mỗi lần đổi cách nó làm việc là tác giả phải gửi file zip cho từng
    khách, và khách nào chưa cài lại thì kẹt — bản 1.1.0 không đặt được đơn nữa
    vì đơn thiếu email.

    Danh mục cũ không có khối này, và bản Hub cũ không đọc nó: cả hai chiều đều
    phải chịu được nhau, nên thiếu là im lặng bỏ qua chứ không phải lỗi.

    `zip` phải là `https` — hoặc loopback cho các bài kiểm, cùng ngoại lệ với
    `_safe_qr_url`. Đây là thứ sẽ GHI ĐÈ mã đang chạy trên máy khách, nên một
    địa chỉ không mã hoá ở đây là ai đứng giữa đường truyền cũng thay được
    addon.
    """
    hub = data.get('hub') if isinstance(data, dict) else None
    if not isinstance(hub, dict):
        return {}
    ver = str(hub.get('version') or '').strip()
    url = str(hub.get('zip') or '').strip()
    mod = str(hub.get('module') or '').strip()
    if not (ver and url and mod):
        return {}
    if not _safe_qr_url(url):
        print('[DP_Hub] bo qua ban moi cua Hub: dia chi khong phai https (%s)'
              % url[:60])
        return {}
    return {'version': ver, 'module': mod, 'zip': url}


def parse(raw):
    """(danh_sách_sản_phẩm, số_mục_bỏ_qua) từ nội dung JSON thô."""
    return normalise(json.loads(
        raw.decode('utf-8') if isinstance(raw, bytes) else raw))


def fetch(url, cache=None):
    """Tải danh mục và GHI LẠI xuống đĩa. Trả (danh_sách, số_bỏ_qua).

    `cache` = đường dẫn file đệm. Hàm này CÓ THỂ chạy ở luồng nền, mà
    `cache_path()` lại gọi `bpy` — nên chỗ gọi phải tính sẵn đường dẫn trên
    luồng chính rồi truyền vào. Bỏ trống thì tự tính (dùng cho luồng chính).
    """
    raw = http_get(url)
    if len(raw) > MAX_BYTES:
        raise ValueError('catalog too big (> %d bytes)' % MAX_BYTES)
    data = json.loads(raw.decode('utf-8') if isinstance(raw, bytes) else raw)
    products, skipped = normalise(data)
    # GHI CẢ KHỐI THANH TOÁN xuống đệm. Chỉ ghi `products` thì mã QR biến mất
    # ngay lần mở Blender sau — bảng vẫn có danh mục nên trông như bình thường,
    # chỉ riêng chỗ chuyển khoản trống, và không ai đoán ra vì sao.
    # GHI CẢ SỐ NGÀY DÙNG THỬ, cùng một lý do và cùng một cái bẫy. Bảng đọc
    # con số này TỪ ĐỆM chứ không từ bản vừa tải (`load_cached_trial_days`),
    # nên thiếu nó ở đây là số ngày đọc ra 0 trên MỌI máy, mãi mãi — mà 0 nghĩa
    # là "tác giả đã tắt dùng thử", tức nút "Try free" không bao giờ hiện ra và
    # không có một dòng lỗi nào. Cả tuyến dùng thử im lặng không tồn tại.
    with open(cache or cache_path(), 'w', encoding='utf-8') as fh:
        json.dump({'at': time.time(), 'url': url, 'products': products,
                   'payment': payment_of(data), 'gate': gate_of(data),
                   'hub': hub_of(data), 'trial_days': trial_days_of(data)},
                  fh, ensure_ascii=False, indent=1)
    return products, skipped


def load_cached():
    """(danh_sách, thời_điểm_tải) của bản đã ghi. ([], 0) nếu chưa có.

    Hỏng thì trả rỗng để bảng vẫn vẽ được, nhưng PHẢI in lý do ra console:
    nuốt lặng lẽ thì một file đệm rách sẽ hiện thành "chưa tải lần nào" và
    không ai lần ra được vì sao bấm mãi vẫn không thấy danh mục.
    """
    path = cache_path()
    if not os.path.exists(path):
        return [], 0.0
    try:
        with open(path, encoding='utf-8') as fh:
            data = json.load(fh)
        products, _ = normalise(data)
        return products, float(data.get('at') or 0)
    except Exception as exc:
        print('[DP_Hub] doc lai danh muc da ghi loi (%s): %r' % (path, exc))
        return [], 0.0


def load_cached_payment():
    """Khối thanh toán của bản danh mục đã ghi. Luôn trả dict, không ném."""
    path = cache_path()
    if not os.path.exists(path):
        return {'qr': '', 'note': ''}
    try:
        with open(path, encoding='utf-8') as fh:
            return payment_of(json.load(fh))
    except Exception as exc:
        print('[DP_Hub] doc khoi thanh toan loi (%s): %r' % (path, exc))
        return {'qr': '', 'note': ''}


def load_cached_gate():
    """Địa chỉ cửa kiểm của bản danh mục đã ghi. '' nếu chưa có. Không ném.

    Cùng khuôn với `load_cached_payment` và cùng một lý do: bảng phải dùng
    được ngay lúc mở Blender, trước khi có ai bấm Refresh.
    """
    path = cache_path()
    if not os.path.exists(path):
        return ''
    try:
        with open(path, encoding='utf-8') as fh:
            return gate_of(json.load(fh))
    except Exception as exc:
        print('[DP_Hub] doc dia chi cua kiem loi (%s): %r' % (path, exc))
        return ''


def trial_days_of(data):
    """`trial_days` của một danh mục. 0 = tác giả đã tắt dùng thử."""
    try:
        n = int((data or {}).get('trial_days') or 0)
    except (TypeError, ValueError):
        return 0
    return n if 1 <= n <= 365 else 0


def load_cached_trial_days():
    """Số ngày dùng thử của bản danh mục đã ghi. 0 nếu chưa có. Không ném.

    Cùng khuôn với `load_cached_gate`, và cùng một lý do: bảng phải dùng được
    ngay lúc mở Blender, trước khi có ai bấm Refresh.
    """
    path = cache_path()
    if not os.path.exists(path):
        return 0
    try:
        with open(path, encoding='utf-8') as fh:
            return trial_days_of(json.load(fh))
    except Exception as exc:
        print('[DP_Hub] doc so ngay dung thu loi (%s): %r' % (path, exc))
        return 0


def load_cached_hub():
    """Khối `hub` của bản danh mục đã ghi. {} nếu chưa có. Không ném."""
    path = cache_path()
    if not os.path.exists(path):
        return {}
    try:
        with open(path, encoding='utf-8') as fh:
            return hub_of(json.load(fh))
    except Exception as exc:
        print('[DP_Hub] doc khoi hub loi (%s): %r' % (path, exc))
        return {}


# ------------------------------------------------------- đơn đang chờ duyệt
# Khách bấm *Send order* xong thì đóng Blender đi ăn cơm. Mở lại, bảng phải
# nhớ là họ đang chờ — không nhớ thì họ tưởng đơn bay mất và gửi lần nữa, hoặc
# tệ hơn là chuyển khoản lần nữa.
#
# GHI XUỐNG ĐĨA chứ không giữ trong bộ nhớ, và ghi CẠNH danh mục đã tải: đây là
# thứ của riêng máy này, không được đi vào file .blend của khách.
def order_path():
    return os.path.join(store_dir(), 'pending_order.json')


def save_pending_order(rec):
    """Ghi đơn đang chờ. Không ném — mất dòng trạng thái không phải lý do để
    cả nút gửi đơn báo hỏng sau khi đơn ĐÃ lên tới máy chủ."""
    try:
        with open(order_path(), 'w', encoding='utf-8') as fh:
            json.dump(rec, fh, ensure_ascii=False, indent=1)
        return True
    except Exception as exc:
        print('[DP_Hub] khong ghi duoc don dang cho: %r' % (exc,))
        return False


def load_pending_order():
    """Đơn đang chờ duyệt, hoặc {} nếu không có. Không ném."""
    path = order_path()
    if not os.path.exists(path):
        return {}
    try:
        with open(path, encoding='utf-8') as fh:
            rec = json.load(fh)
        return rec if isinstance(rec, dict) and rec.get('order') else {}
    except Exception as exc:
        print('[DP_Hub] doc don dang cho loi (%s): %r' % (path, exc))
        return {}


def clear_pending_order():
    """Xoá đơn đang chờ — gọi khi mã đã về tới máy. Không ném."""
    try:
        if os.path.exists(order_path()):
            os.remove(order_path())
    except OSError as exc:
        print('[DP_Hub] khong xoa duoc don dang cho: %r' % (exc,))


def qr_cache_path():
    """Chỗ ghi ảnh QR đã tải. Cạnh file đệm danh mục."""
    return os.path.join(store_dir(), 'payment_qr.png')


def icon_cache_path(code):
    """Chỗ ghi logo đã tải của một sản phẩm.

    Tên file lấy theo MÃ sản phẩm, và mã thì do danh mục của tác giả đặt —
    không phải chuỗi người dùng gõ vào. Vẫn lọc: danh mục là file tải từ mạng
    về, và một mã kiểu `../../x` sẽ ghi ra ngoài thư mục đệm.
    """
    an_toan = ''.join(c for c in str(code) if c.isalnum() or c in '-_')
    return os.path.join(store_dir(), 'icon_%s.png' % (an_toan or 'x'))


def fetch_icon(code, url, dest=None):
    """Tải logo một sản phẩm về đĩa. Trả đường dẫn, hoặc None.

    KHÔNG ném và KHÔNG tải lại nếu đã có: bảng vẽ lại rất nhiều lần mỗi giây,
    và mỗi lần vẽ mà gọi mạng là Blender đứng hình. Muốn lấy logo mới thì bấm
    Refresh — chỗ đó xoá đệm đi.
    """
    dest = dest or icon_cache_path(code)
    if os.path.isfile(dest) and os.path.getsize(dest) > 0:
        return dest
    try:
        raw = http_get(url, max_bytes=512 * 1024)
        if not raw:
            raise ValueError('anh rong')
        if not (raw[:8].startswith(b'\x89PNG') or raw[:3] == b'\xff\xd8\xff'):
            raise ValueError('khong phai PNG/JPG')
        with open(dest, 'wb') as fh:
            fh.write(raw)
        return dest
    except Exception as exc:
        # Mất logo là bảng xấu đi, không phải bảng hỏng. Nói ra một lần rồi
        # thôi — bảng vẽ lại liên tục, in mỗi lần vẽ là ngập cả cửa sổ.
        print('[DP_Hub] khong tai duoc logo %s (%s): %r' % (code, url, exc))
        return None


def fetch_qr(url, dest=None):
    """Tải ảnh QR về đĩa. Trả đường dẫn, hoặc None nếu không tải được.

    KHÔNG ném: mất mã QR là bất tiện, không phải lý do để cả bảng không vẽ.
    Nhưng phải in lý do — im lặng thì tác giả không bao giờ biết khách của
    mình đang không nhìn thấy chỗ chuyển khoản.
    """
    dest = dest or qr_cache_path()
    try:
        raw = http_get(url, max_bytes=2 * 1024 * 1024)
        if not raw:
            raise ValueError('anh rong')
        # Blender chỉ nạp được ảnh thật. Nhận về một trang HTML báo lỗi rồi
        # ghi ra .png thì lỗi nổ ở chỗ khác hẳn, rất khó lần.
        if not (raw[:8].startswith(b'\x89PNG') or raw[:3] == b'\xff\xd8\xff'):
            raise ValueError('khong phai PNG/JPG')
        with open(dest, 'wb') as fh:
            fh.write(raw)
        return dest
    except Exception as exc:
        print('[DP_Hub] khong tai duoc ma QR (%s): %r' % (url, exc))
        return None


# ------------------------------------------------------------------ phiên bản
def version_tuple(text):
    """'3.12.0' -> (3, 12, 0). Phần không phải số bị bỏ, không ném lỗi.

    So sánh bằng SỐ chứ không bằng chuỗi: '3.9.0' > '3.12.0' nếu so chuỗi, và
    người dùng sẽ được báo 'đã mới nhất' trong khi bản mới đang nằm sẵn đó.
    """
    out = []
    for part in str(text).replace('-', '.').replace('_', '.').split('.'):
        digits = ''.join(c for c in part if c.isdigit())
        if not digits:
            break
        out.append(int(digits))
    return tuple(out) or (0,)


def zip_bl_info_version(source):
    """Đọc `bl_info["version"]` ngay trong gói, không cần cài.

    `source` là BYTES (gói vừa tải, còn nằm trong RAM) hoặc đường dẫn file.

    Dùng để KIỂM CHỨNG bản vừa tải đúng là bản danh mục hứa hẹn: danh mục ghi
    3.12.0 mà gói lại là 3.10.0 thì người dùng bấm cập nhật xong vẫn thấy nút
    cập nhật, không hiểu vì sao.
    """
    import io as _io
    src = _io.BytesIO(source) if isinstance(source, bytes) else source
    with zipfile.ZipFile(src) as zf:
        names = [n for n in zf.namelist() if n.endswith('__init__.py')]
        names.sort(key=lambda n: n.count('/'))
        for name in names:
            text = zf.read(name).decode('utf-8', 'replace')
            for line in io.StringIO(text):
                s = line.strip()
                if s.startswith('"version"') or s.startswith("'version'"):
                    nums = ''.join(c if c.isdigit() else ' '
                                   for c in s.split(':', 1)[-1])
                    parts = nums.split()
                    if parts:
                        return tuple(int(p) for p in parts)
            break
    return None
