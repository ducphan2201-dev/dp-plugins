# -*- coding: utf-8 -*-
"""Giao diện kích hoạt — mã máy + ô dán mã + dòng trạng thái.

Addon chỉ cần ba dòng:

    from .dp_license import ui as lic_ui
    PRODUCT = 'dpmax'

    def register():   lic_ui.register_product(PRODUCT)
    def unregister(): lic_ui.unregister_product(PRODUCT)

rồi trong `draw()` của panel cần khoá:

    if not lic_ui.draw_gate(layout, PRODUCT):
        return          # chưa kích hoạt -> hộp hướng dẫn đã được vẽ ở trên

MỖI SẢN PHẨM MỘT BỘ OPERATOR RIÊNG — VÌ SAO
-------------------------------------------
`dp_license/` được CHÉP vào từng addon, nên hai addon cùng cài là hai bản copy
cùng chạy. Nếu cả hai đăng ký `dplic.activate` thì bản sau đè bản trước, và
người dùng TẮT một addon là nút của addon KIA chết theo. Vì vậy tên operator
mang theo mã sản phẩm (`dplic.activate_dpmax`) và lớp được sinh động lúc đăng
ký. Đã đo: đăng ký hai sản phẩm rồi gỡ một, operator của sản phẩm còn lại vẫn
gọi được.

VÌ SAO CÓ BỘ NHỚ ĐỆM TRẠNG THÁI
-------------------------------
`draw()` chạy lại mỗi lần chuột đi qua panel. Không đệm thì mỗi nhịp vẽ là một
lần đọc registry + đọc file + một phép luỹ thừa modular. Đệm có HẠN 2 giây nên
mã hết hạn vẫn bị bắt gần như tức thì, còn `invalidate()` được gọi ngay sau khi
dán/xoá mã để nút bấm có tác dụng THẤY ĐƯỢC LIỀN.

CHỮ TRONG PANEL
---------------
Cột N-panel cắt chữ ở khoảng 26–30 ký tự và Blender KHÔNG tự xuống dòng. Mọi
câu dài phải đi qua `wrap()`. Chuỗi hiện cho người dùng viết KHÔNG DẤU: addon
đi kèm bản kiểm tra chặn chữ tiếng Việt trong string literal.

KHÔNG BAO GIỜ `self.report({'ERROR'})`
--------------------------------------
`bpy.ops` biến ERROR thành RuntimeError và huỷ cả thao tác đang chạy. Mã dán
sai là chuyện thường ngày của người dùng, không phải sự cố — nó ra WARNING.
"""
import re
import time

import bpy

from . import gate
from . import machine_id

# Bề rộng chữ vừa cột N-panel ở kích thước mặc định. Đo bằng ảnh chụp, không
# phải đoán: 28 ký tự còn đọc đủ, 32 đã bị cắt đuôi.
WRAP_WIDTH = 28

# Mã sản phẩm phải hợp lệ làm ĐUÔI TÊN operator của Blender (chỉ chữ thường,
# số và gạch dưới). Sai thì hỏng lúc đăng ký chứ không lặng lẽ mất nút.
_PRODUCT_RE = re.compile(r'^[a-z][a-z0-9_]{0,15}$')

_TTL = 2.0                  # giây — hạn của bộ nhớ đệm trạng thái
_status_cache = {}          # product -> (hết_hạn_lúc, trạng_thái, payload)
_machine_cache = {}         # đọc registry một lần cho cả phiên
_registered = {}            # product -> tuple lớp đã đăng ký


# ------------------------------------------------------------------ chữ nghĩa
def wrap(text, width=WRAP_WIDTH):
    """Cắt `text` thành danh sách dòng, mỗi dòng dài tối đa `width` ký tự."""
    lines = []
    line = ''
    for word in str(text).split():
        while len(word) > width:            # một từ dài hơn cả dòng: cắt cứng
            if line:
                lines.append(line)
                line = ''
            lines.append(word[:width])
            word = word[width:]
        if not line:
            line = word
        elif len(line) + 1 + len(word) <= width:
            line += ' ' + word
        else:
            lines.append(line)
            line = word
    if line:
        lines.append(line)
    return lines or ['']


# ------------------------------------------------------------------ số máy
def machine_string():
    """Chuỗi ~104 ký tự khách copy gửi tác giả. Đọc registry MỘT lần mỗi phiên."""
    if 'export' not in _machine_cache:
        _machine_cache['export'] = machine_id.export()
        _machine_cache['fp'] = machine_id.fingerprint()
    return _machine_cache['export']


def fingerprint():
    """Vân tay ngắn AAAA-BBBB-CCCC-DDDD để khách đối chiếu bằng mắt."""
    machine_string()
    return _machine_cache['fp']


# ------------------------------------------------------------------ trạng thái
def invalidate(product=None):
    """Bỏ trạng thái đã đệm. Gọi ngay sau khi dán hoặc xoá mã.

    Bỏ luôn đệm của GÓI DỮ LIỆU. Quên chỗ này thì khách dán mã xong panel vẫn
    trống cho tới lần mở Blender sau — họ sẽ nghĩ mã hỏng và đi đòi tiền, chứ
    không nghĩ tới việc khởi động lại.
    """
    if product is None:
        _status_cache.clear()
    else:
        _status_cache.pop(product, None)
    try:
        from . import datapack
        datapack.invalidate(product)
    except Exception as exc:
        # Addon cũ chưa có datapack.py thì bỏ qua - nhưng phải NÓI RA, im lặng
        # ở đây là chỗ nuốt lỗi kinh điển.
        print('[dp_license] khong bo duoc dem goi du lieu: %r' % (exc,))


def status(product):
    """(trạng_thái, payload) của `product`, có đệm 2 giây."""
    hit = _status_cache.get(product)
    now = time.time()
    if hit and hit[0] > now:
        return hit[1], hit[2]
    st, payload = gate.check(product)
    _status_cache[product] = (now + _TTL, st, payload)
    return st, payload


def days_left(payload):
    """Số ngày còn lại, hoặc None nếu mã vĩnh viễn / không có payload.

    LÀM TRÒN LÊN. Mã bán "365 ngày" mà mở Blender ra thấy "364 ngày" thì khách
    nghĩ mình bị bớt một ngày; và ngày cuối cùng còn dùng được phải hiện "1
    ngày" chứ không phải "0 ngày" — số 0 làm khách tưởng mã đã chết.
    """
    exp = (payload or {}).get('x') or 0
    if not exp:
        return None
    left = exp - time.time()
    return -int(-left // 86400)


# ------------------------------------------------------------------ operator
def _check_product(product):
    if not _PRODUCT_RE.match(product or ''):
        raise ValueError(
            'ma san pham phai la [a-z][a-z0-9_]{0,15}: %r' % (product,))
    return product


def copy_idname(product):
    return 'dplic.copy_%s' % _check_product(product)


def activate_idname(product):
    return 'dplic.activate_%s' % _check_product(product)


def clear_idname(product):
    return 'dplic.clear_%s' % _check_product(product)


def _copy_class(product):
    def execute(self, context):
        text = machine_string()
        # Clipboard của Blender: chỗ duy nhất khách với tới được mà không cần
        # mở file. In ra console luôn để còn đường lấy tay khi clipboard hỏng
        # (máy ảo, phiên remote).
        try:
            context.window_manager.clipboard = text
            self.report({'INFO'}, 'Machine code copied - send it to the author')
        except Exception as exc:
            self.report({'WARNING'}, 'Copy failed - see the Console window')
            print('[dp_license] clipboard loi: %r' % (exc,))
        print('[dp_license] MA MAY (%s): %s' % (fingerprint(), text))
        return {'FINISHED'}

    return type('DPLIC_OT_copy_%s' % product, (bpy.types.Operator,), {
        'bl_idname': copy_idname(product),
        'bl_label': 'Copy machine code',
        'bl_description': 'Copy this machine code so you can send it to the author',
        'bl_options': {'REGISTER'},
        'execute': execute,
    })


def _activate_class(product):
    def invoke(self, context, event):
        # Khách vừa copy mã từ Telegram: điền sẵn nếu clipboard ĐÚNG LÀ một mã
        # đọc được. Không điền bừa — dán nhầm nội dung khác vào ô thì khách
        # tưởng addon tự nghĩ ra mã.
        try:
            clip = (context.window_manager.clipboard or '').strip()
        except Exception:
            clip = ''
        if clip and gate.parse(clip)[0] is not None:
            self.key = clip
        return context.window_manager.invoke_props_dialog(self, width=520)

    def draw(self, context):
        col = self.layout.column()
        col.label(text='Paste the activation key sent to you:')
        col.prop(self, 'key', text='')
        col.label(text='Machine code: %s' % fingerprint())

    def execute(self, context):
        ok, why = gate.save_key(product, self.key)
        invalidate(product)
        if not ok:
            self.report({'WARNING'}, gate.message(why))
            return {'CANCELLED'}
        self.report({'INFO'}, 'Activated')
        return {'FINISHED'}

    return type('DPLIC_OT_activate_%s' % product, (bpy.types.Operator,), {
        'bl_idname': activate_idname(product),
        'bl_label': 'Paste activation key',
        'bl_description': 'Paste the activation key you bought',
        'bl_options': {'REGISTER'},
        '__annotations__': {
            'key': bpy.props.StringProperty(
                name='Activation key', default='',
                description='The whole key the author sent you'),
        },
        'invoke': invoke,
        'draw': draw,
        'execute': execute,
    })


def _clear_class(product):
    def execute(self, context):
        gate.clear_key(product)
        invalidate(product)
        self.report({'INFO'}, 'Activation key removed from this PC')
        return {'FINISHED'}

    def invoke(self, context, event):
        # Xoá xong là phải xin mã lại -> hỏi trước.
        return context.window_manager.invoke_confirm(self, event=event)

    return type('DPLIC_OT_clear_%s' % product, (bpy.types.Operator,), {
        'bl_idname': clear_idname(product),
        'bl_label': 'Remove activation key',
        'bl_description': 'Remove the activation key from this PC',
        'bl_options': {'REGISTER'},
        'invoke': invoke,
        'execute': execute,
    })


def make_classes(product):
    """Ba lớp operator RIÊNG cho `product`. Addon tự đăng ký nếu muốn."""
    _check_product(product)
    return (_copy_class(product), _activate_class(product),
            _clear_class(product))


def register_product(product):
    """Đăng ký operator cho `product`. Gọi lại lần nữa là không làm gì."""
    if product in _registered:
        return _registered[product]
    classes = make_classes(product)
    for cls in classes:
        bpy.utils.register_class(cls)
    _registered[product] = classes
    return classes


def wrap_operators(classes, product, label='', require=None):
    """Bọc `execute`/`invoke` của mọi Operator trong `classes` bằng cửa kiểm mã.

    `require` là một hàm không tham số, trả None nếu được phép chạy, hoặc một
    câu giải thích nếu không. Dùng cho TẦNG BẢO VỆ THỨ BA: addon nào cần dữ
    liệu trong gói đã mã hoá thì truyền vào đây một hàm kiểm gói. Nhờ vậy người
    xoá đoạn kiểm mã ở trên vẫn không chạy được — cái chặn không nằm ở câu lệnh
    `if`, mà ở chỗ không có mã hợp lệ thì không có dữ liệu.

    Gọi TRƯỚC `bpy.utils.register_class` — bọc sau thì Blender đã giữ con trỏ
    hàm cũ và lớp bọc không bao giờ chạy.

        lic_ui.wrap_operators(classes, PRODUCT, 'DP_Camera')

    VÌ SAO BỌC HÀNG LOẠT THAY VÌ SỬA TỪNG OPERATOR: những addon một file có
    14–16 operator. Chép tay từng cái là sớm muộn sót một, và cái sót đó không
    kêu tiếng nào — người chưa mua vẫn gọi được nó từ menu tìm kiếm F3 hoặc từ
    phím tắt. Bọc một chỗ thì operator viết thêm sau này cũng tự có khoá.

    CHỮ KÝ PHẢI ĐÚNG SỐ THAM SỐ. Blender ĐẾM tham số của `execute`/`invoke` lúc
    `register_class` và từ chối thẳng:

        Error: expected Operator, ... class "invoke" function to have 3 args,
        found 2

    Cả `(self, context, *args)` LẪN `(self, context, _inner=fn)` đều hỏng —
    tham số có giá trị mặc định vẫn bị đếm. Vì vậy giữ hàm gốc bằng CLOSURE và
    mỗi tên một lớp bọc riêng. Cả hai cách sai ở trên đều đã đo được 01/08/2026.

    Trả WARNING chứ KHÔNG phải ERROR: `bpy.ops` biến ERROR thành RuntimeError
    và huỷ cả thao tác đang chạy; chưa có mã là chuyện thường ngày của người
    dùng, không phải sự cố.

    Ở bản dev `gate.ok()` thoát ngay ở dòng đầu (`RELEASE_BUILD = False`) nên
    đoạn này không tốn gì và KHÔNG CHẶN GÌ — máy dev không bao giờ bị khoá.
    """
    _check_product(product)
    prefix = ('%s: ' % label) if label else ''

    def _blocked(op):
        """Trả lời cho khách khi chưa có mã. None nghĩa là được phép chạy."""
        if not gate.ok(product):
            st, _ = gate.check(product)
            op.report({'WARNING'}, '%s%s' % (prefix, gate.message(st)))
            return {'CANCELLED'}
        if require is not None:
            try:
                why = require()
            except Exception as exc:
                # Hàm kiểm gói hỏng thì CHẶN, không cho qua. Nuốt lỗi rồi chạy
                # tiếp là biến tầng ba thành thứ trang trí.
                why = 'data package error: %r' % (exc,)
            if why:
                op.report({'WARNING'}, '%s%s' % (prefix, why))
                return {'CANCELLED'}
        return None

    def _make_invoke(inner):
        def invoke(self, context, event):
            return _blocked(self) or inner(self, context, event)
        invoke.__doc__ = inner.__doc__
        return invoke

    def _make_execute(inner):
        def execute(self, context):
            return _blocked(self) or inner(self, context)
        execute.__doc__ = inner.__doc__
        return execute

    n = 0
    for cls in classes:
        if not (isinstance(cls, type) and issubclass(cls, bpy.types.Operator)):
            continue                # Panel, PropertyGroup, UIList - bỏ qua
        # `__dict__` chứ không phải `getattr`: hàm kế thừa từ lớp cha
        # (ImportHelper…) mà bọc thì lớp bọc dính vào LỚP CON, còn Blender vẫn
        # gọi bản của lớp cha — và bọc hai lần nếu có nhiều lớp con.
        fn = cls.__dict__.get('invoke')
        if fn is not None:
            cls.invoke = _make_invoke(fn)
        fn = cls.__dict__.get('execute')
        if fn is not None:
            cls.execute = _make_execute(fn)
        n += 1
    return n


def unregister_product(product):
    """Gỡ operator của RIÊNG `product` — không đụng tới sản phẩm khác."""
    for cls in reversed(_registered.pop(product, ())):
        try:
            bpy.utils.unregister_class(cls)
        except Exception as exc:
            print('[dp_license] go lop %s loi: %r' % (cls.__name__, exc))
    invalidate(product)


# ------------------------------------------------------------------ vẽ
# Dòng tiêu đề của hộp khoá. MỖI TRẠNG THÁI MỘT CÂU RIÊNG: bản đầu để chung
# 'CHUA KICH HOAT' cho mọi trạng thái, ảnh chụp cho thấy mã hết hạn hiện tiêu
# đề 'CHUA KICH HOAT' ngay trên câu 'Ma kich hoat da het han' — hai dòng cãi
# nhau, và khách sẽ đi hỏi thay vì đi gia hạn.
_HEADS = {
    gate.NO_KEY: 'NOT ACTIVATED',
    gate.BAD_KEY: 'INVALID KEY',
    gate.WRONG_MACHINE: 'ANOTHER MACHINE',
    gate.EXPIRED: 'KEY EXPIRED',
    gate.WRONG_PRODUCT: 'WRONG PRODUCT',
    gate.NO_PUBKEY: 'PACKAGING ERROR',
}


def draw_gate(layout, product, contact=''):
    """Vẽ hộp hướng dẫn nếu chưa kích hoạt. Trả True nếu được phép chạy tiếp.

    Chưa kích hoạt thì hiện HƯỚNG DẪN, không tắt phụt: khách nhìn panel trống
    không có chữ nào sẽ nghĩ addon hỏng rồi đòi hoàn tiền thay vì đi gia hạn.
    """
    st, payload = status(product)
    if st == gate.DEV:
        return True                    # bản dev: không thêm gì vào panel
    if st == gate.OK:
        left = days_left(payload)
        if left is not None and left <= 30:
            row = layout.row()
            row.alert = left <= 7
            row.label(text='License: %d days left' % max(left, 0), icon='TIME')
        return True

    box = layout.box()
    box.label(text=_HEADS.get(st, 'NOT ACTIVATED'), icon='LOCKED')
    # align=True: các dòng của CÙNG một câu phải dính nhau, không thì người đọc
    # thấy ba dòng rời rạc chứ không ra một đoạn văn.
    col = box.column(align=True)
    for line in wrap(gate.message(st)):
        col.label(text=line)
    box.separator()
    # KHÔNG in vân tay ngắn ra đây nữa (03/08/2026).
    #
    # Trước đây chỗ này hiện `Your machine code: E5AC-7161-38AD-B042`. Khách nào
    # không hiểu nút bấm sẽ làm việc tự nhiên nhất: đọc dãy đó trên màn hình rồi
    # gõ vào Telegram, hoặc đọc qua điện thoại. Mã cấp từ dãy đó KHÔNG BAO GIỜ
    # chạy — nó không mang yếu tố nào mà `machine_id.matches()` đếm.
    #
    # Tức là màn hình vừa có sẵn đường tự động (một nút), vừa bày ra trước mắt
    # khách một đường thủ công dẫn xuống hố. Khách sẽ chọn đường họ NHÌN THẤY.
    # Nay chỉ còn đúng một đường, và nó là một nút bấm.
    col = box.column(align=True)
    for line in wrap('Click the button below, then send what it copied '
                     'to the author.'):
        col.label(text=line)
    box.operator(copy_idname(product), icon='COPYDOWN')
    box.operator(activate_idname(product), icon='KEYINGSET')
    if contact:
        box.separator()
        col = box.column(align=True)
        for line in wrap(contact):
            col.label(text=line)
    return False


def draw_status(layout, product, contact=''):
    """Khối đầy đủ cho phần Preferences của addon: trạng thái + đổi/xoá mã.

    Panel chính chỉ cần `draw_gate`. Chỗ này thêm nút XOÁ — thứ khách cần khi
    đổi máy, nhưng không nên nằm cạnh nút làm việc hằng ngày.
    """
    st, payload = status(product)
    col = layout.column()
    col.label(text='Status: %s' % st.upper(),
              icon='CHECKMARK' if st in (gate.OK, gate.DEV) else 'LOCKED')
    for line in wrap(gate.message(st), 60):
        col.label(text=line)
    if payload:
        if payload.get('e'):
            col.label(text='Issued to: %s' % payload['e'])
        left = days_left(payload)
        col.label(text='Expires: %s' % ('never' if left is None
                                    else 'in %d days' % max(left, 0)))
    col.separator()
    # Không in vân tay ngắn — cùng lý do với `draw_gate` ở trên: dãy chữ hiện
    # trên màn hình là thứ khách sẽ gõ tay, và mã cấp từ nó không bao giờ chạy.
    # MỖI NÚT MỘT DÒNG. Ảnh chụp bản đầu: hai nút chung một dòng thì trong cột
    # N-panel nhãn bị cắt thành 'Dan ma kich h...'.
    col.operator(copy_idname(product), icon='COPYDOWN')
    col.operator(activate_idname(product), icon='KEYINGSET')
    if st in (gate.OK, gate.EXPIRED, gate.WRONG_MACHINE, gate.WRONG_PRODUCT):
        col.operator(clear_idname(product), icon='TRASH')
    if contact:
        col.separator()
        for line in wrap(contact, 60):
            col.label(text=line)
