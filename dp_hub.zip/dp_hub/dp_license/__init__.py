# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
# -*- coding: utf-8 -*-
"""dp_license — khoa ban quyen theo may, dung chung cho moi addon Blender.

CACH CAM VAO MOT ADDON
----------------------
1. Chep NGUYEN thu muc `dp_license/` vao trong goi addon.
2. Chep khoa cong khai vao `gate.py` (hai dong PUBLIC_N / PUBLIC_E), lay tu
   `%LOCALAPPDATA%\\DP_License\\keys\\public.py` do `tools/keygen.py` sinh ra.
3. Trong `__init__.py` cua addon, dat ma san pham va hoi cong:

       from .dp_license import gate
       PRODUCT = 'dpmax'            # ma rieng cua tung addon

       # trong ham draw() cua panel can khoa:
       st, _ = gate.check(PRODUCT)
       if st not in (gate.OK, gate.DEV):
           layout.label(text=gate.message(st))
           return

MOT MA CO THE MO NHIEU SAN PHAM: truong `p` trong ma la MOT DANH SACH, nen ban
le tung addon hay ban tron bo deu duoc ma khong phai sua thiet ke.

KHONG PHAI MA HOA. Ma nguon van doc va sua duoc binh thuong. Thu duy nhat khong
the lam gia la CHU KY, vi khoa bi mat khong bao gio di kem ban phat hanh.
"""
from . import gate           # noqa: F401
from . import machine_id     # noqa: F401
from . import rsa_verify     # noqa: F401

# `ui` CO Y KHONG nam trong danh sach tren: no `import bpy`, ma cong cu chay
# NGOAI Blender (tools/selftest.py, tools/make_key.py) lai import goi nay. Addon
# tu goi `from .dp_license import ui` khi can - luc do chac chan dang o trong
# Blender.

__version__ = '1.1.0'
