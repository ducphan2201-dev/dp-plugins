# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
# -*- coding: utf-8 -*-
"""Cho phep DANG KY class Blender DA DICH ra ma may (.pyd).

VI SAO CAN CAI NAY
------------------
Tang sau dich ma nguon addon thanh .pyd. Nhung Blender dang ky mot Operator /
Panel bang cach SOI so tham so cua `poll`/`execute`/`draw`... o TANG C - no doc
thang truong `co_argcount` trong cau truc ham CPython. Ham do Cython dich ra la
`cython_function_or_method`, KHONG phai cau truc do, nen Blender doc trung o
nho rac va nem:

    ValueError: expected Operator, X class "poll" function to have 2 args,
                found 1275068491

Do that 11/08/2026: chinh cac hook nay la cho duy nhat vuong. Ban than class,
thuoc tinh `bpy.props`, than ham - deu dich va chay binh thuong.

CACH CHUA
---------
Truoc khi `register_class`, thay MOI hook Blender soi bang mot VO HAM PYTHON
THAT co dung chu ky, chuyen tiep vao ham da dich. Blender soi cai vo (ham
Python that, doc duoc so tham so); vo goi vao lõi da dich. Than ma van nam
trong .pyd - vo chi la vai dong chuyen tiep khong mang logic gi.

`install()` vá `bpy.utils.register_class` de tu boc moi class truoc khi dang
ky. Chi dong toi ham Cython; class thuong (cua addon khac, cua Blender) di qua
khong suy suyen. Idempotent - goi nhieu lan chi vá mot lan.
"""

# Cac hook Blender SOI CHU KY o tang C. Chi nhung ten nay moi can vo; than ham
# noi bo thi Blender khong dong toi, giu nguyen ham da dich cho nhanh.
HOOKS = (
    'poll', 'execute', 'invoke', 'modal', 'cancel', 'check', 'description',
    'draw', 'draw_header', 'draw_header_preset', 'draw_item', 'filter_items',
    # FileHandler (duong keo-tha file vao khung nhin). Blender soi `poll_drop`
    # y het `poll`. Thieu ten nay thi addon nao co cua keo-tha se do dung o
    # `register_class` voi so tham so rac - gap that 11/08/2026 tren dpmax.
    'poll_drop',
)


def _la_ham_cython(fn):
    return type(fn).__name__ == 'cython_function_or_method'


def _tham_so(fn):
    """(danh sach ten tham so, co *args, co **kwargs) doc TU ham da dich.

    binding=True lam ham Cython co `__code__` that, nen doc duoc chu ky chinh
    xac - khong phai doan. Tra None neu khong doc duoc.
    """
    code = getattr(fn, '__code__', None)
    if code is None:
        return None
    try:
        n = code.co_argcount
        ten = list(code.co_varnames[:n])
        co_args = bool(code.co_flags & 0x04)      # CO_VARARGS
        co_kw = bool(code.co_flags & 0x08)        # CO_VARKEYWORDS
        # tham so chi-keyword (sau dau *)
        nkw = getattr(code, 'co_kwonlyargcount', 0)
        ten_kw = list(code.co_varnames[n:n + nkw]) if nkw else []
        return ten, co_args, co_kw, ten_kw
    except Exception:
        return None


def _vo(impl, sig):
    """Sinh mot ham Python THAT dung chu ky `sig`, chuyen tiep vao `impl`."""
    ten, co_args, co_kw, ten_kw = sig
    khai, goi = list(ten), list(ten)
    if co_args:
        khai.append('*_a'); goi.append('*_a')
    elif ten_kw:
        khai.append('*')
    for k in ten_kw:
        khai.append(k); goi.append('%s=%s' % (k, k))
    if co_kw:
        khai.append('**_k'); goi.append('**_k')
    src = 'def _tram(%s):\n    return _impl(%s)\n' % (', '.join(khai),
                                                      ', '.join(goi))
    ns = {'_impl': impl}
    exec(src, ns)                                              # noqa: S102
    return ns['_tram']


def boc_class(cls):
    """Boc cac hook da dich cua MOT class bang vo Python that. Tra chinh class."""
    for ten in HOOKS:
        raw = cls.__dict__.get(ten)
        if raw is None:
            continue
        kind = None
        if isinstance(raw, classmethod):
            fn, kind = raw.__func__, 'c'
        elif isinstance(raw, staticmethod):
            fn, kind = raw.__func__, 's'
        else:
            fn = raw
        if not _la_ham_cython(fn):
            continue
        sig = _tham_so(fn)
        if sig is None:
            continue
        tram = _vo(fn, sig)
        if kind == 'c':
            setattr(cls, ten, classmethod(tram))
        elif kind == 's':
            setattr(cls, ten, staticmethod(tram))
        else:
            setattr(cls, ten, tram)
    return cls


# Cac tham so cua `bpy.props.*` nhan MOT HAM ma Blender soi chu ky: `items`
# cua EnumProperty (enum dong), va `update`/`get`/`set`/`poll`. Ham da dich
# truyen thang vao day cung bi tu choi y het hook cua class.
PROP_CB = ('items', 'update', 'get', 'set', 'poll')


def _boc_cb(fn):
    """Boc mot callback da dich bang vo Python that. Tra nguyen fn neu khong can."""
    if not _la_ham_cython(fn):
        return fn
    sig = _tham_so(fn)
    if sig is None:
        return fn
    return _vo(fn, sig)


def persistent(fn):
    """Thay `bpy.app.handlers.persistent` cho ma DA DICH.

    `bpy.app.handlers.persistent` la thuoc tinh CHI DOC (khong va de duoc) va
    doi HAM PYTHON THAT, nen mot handler da dich bi tu choi ngay luc import
    module. Ham nay boc handler bang vo Python that roi moi danh dau persistent.

    Bo dich TU DOI dong `from bpy.app.handlers import persistent` sang
    `from ...dp_license.bpy_shim import persistent` truoc khi dich - xem
    `bien_dich._doi_persistent`.
    """
    import bpy
    return bpy.app.handlers.persistent(_boc_cb(fn))


_da_va = [False]


def install():
    """Vá `bpy.utils.register_class` VA `bpy.props.*` de class + thuoc tinh da
    dich dang ky duoc.

    An toan goi nhieu lan. Chi boc ham da dich, nen khong dong toi class hay
    thuoc tinh thuong (cua addon khac, cua Blender). KHONG NEM: loi o day khong
    duoc phep chan addon bat len - cung tinh than voi `codepack.install`.

    PHAI chay TRUOC khi cac module da dich (co dinh nghia thuoc tinh trong than
    class) duoc import: vá `bpy.props` sau do thi khong con kip boc callback.
    Loi goi duoc chen o DAU `__init__.py` nen dat dieu do.
    """
    if _da_va[0]:
        return
    try:
        import bpy
    except Exception:
        return

    goc = bpy.utils.register_class

    def register_class_va(cls, *a, **k):
        try:
            boc_class(cls)
        except Exception as exc:                              # noqa: BLE001
            print('[dp_license] bpy_shim boc class that bai cho %r: %r'
                  % (cls, exc))
        return goc(cls, *a, **k)

    register_class_va._dp_goc = goc
    bpy.utils.register_class = register_class_va

    # `@bpy.app.handlers.persistent` KHONG va duoc o day (thuoc tinh chi doc),
    # nen bo dich doi thang dong import trong nguon sang `bpy_shim.persistent`.
    # Xem `bien_dich._doi_persistent` va ham `persistent` o tren.

    # Vá tung ham tao thuoc tinh: boc callback da dich trong tham so.
    import bpy.props as props
    for ten in ('EnumProperty', 'BoolProperty', 'IntProperty', 'FloatProperty',
                'StringProperty', 'FloatVectorProperty', 'IntVectorProperty',
                'BoolVectorProperty', 'PointerProperty', 'CollectionProperty'):
        goc_prop = getattr(props, ten, None)
        if goc_prop is None or getattr(goc_prop, '_dp_va', False):
            continue

        def lam(goc_prop):
            def prop_va(*a, **k):
                for cb in PROP_CB:
                    if callable(k.get(cb)):
                        try:
                            k[cb] = _boc_cb(k[cb])
                        except Exception:                     # noqa: BLE001
                            pass
                return goc_prop(*a, **k)
            prop_va._dp_va = True
            prop_va._dp_goc = goc_prop
            return prop_va
        setattr(props, ten, lam(goc_prop))
    _da_va[0] = True
