# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
# -*- coding: utf-8 -*-
"""DP Toolbox — bê panel addon ra một cửa sổ Blender rời, chia nhiều cột.

VẤN ĐỀ
------
Sidebar (N-panel) của Blender chỉ hiện được MỘT tab tại một thời điểm. Người
dùng có 9 tab DP và ba màn hình: muốn dùng MaxImporter cùng Lighting là phải
bấm qua bấm lại, trong khi màn hình thứ hai bỏ không.

Module này mở một cửa sổ Blender riêng, chia thành nhiều cột, mỗi cột ghim cứng
một tab. Kéo cửa sổ đó sang màn hình 2 là xong.

KHÔNG CÓ CỬA LỌC QUYỀN Ở ĐÂY — CÓ CHỦ Ý
---------------------------------------
Câu hỏi tự nhiên: "khách chưa mua plugin thì sao?". Câu trả lời là chuyện đó đã
được quyết ở TẦNG KHÁC rồi. `dp_hub` từ chối cài một sản phẩm có khoá khi
`gate.verify_text(...) != OK` (ui_hub.py, nút Install), và cửa phía máy chủ kiểm
lần nữa. Tức là **đã cài nghĩa là đã mua**, và một tab chỉ tồn tại khi addon đã
cài VÀ đã bật. Danh sách quét được ở `tabs()` do đó CHÍNH LÀ danh sách khách sở
hữu.

Thêm một lần `gate.check()` nữa ở đây chỉ chép lại một quyết định đã có, và tạo
ra chỗ để hai tầng lệch nhau về sau. Nó còn làm hỏng hai tab KHÔNG thuộc sản
phẩm nào - `DP` (Hub, không khoá) và `DP_Sketch` - vốn phải luôn có mặt.

Mã hết hạn hoặc đổi máy giữa chừng cũng không cần xử ở đây: panel trong cột vẫn
gọi `ui.draw_gate()` y như khi nó nằm trong N-panel, nên nó tự chuyển sang hộp
"KEY EXPIRED" kèm nút dán mã. Cột ở nguyên đó. Đóng phụt một cột là biến cái
khoá thành "addon hỏng".

BA THỨ BLENDER KHÔNG CHO, ĐÃ ĐO CHỨ KHÔNG ĐOÁN (Blender 5.2)
-----------------------------------------------------------
1. `Window.x/y/width/height` là CHỈ ĐỌC. Không có API nào đặt vị trí cửa sổ.
   Người dùng kéo tay một lần; muốn nó quay lại thì phải nhờ Blender lưu layout,
   và đó là lý do có hai chế độ ở dưới.
2. Region của một cửa sổ vừa tạo CHƯA được bố trí trong cùng nhịp `execute()`.
   Ghi `active_panel_category` ngay lúc đó là ghi vào chỗ chưa tồn tại. Vì vậy
   mọi việc dựng cột nằm trong một nhịp `bpy.app.timers` hoãn lại.
3. `wm.window_new` nhân bản CẢ layout hiện tại (viewport + outliner + ...), chứ
   không phải một area. Muốn cửa sổ chỉ có panel thì phải dẹp bớt area đi.

HAI CHẾ ĐỘ, VÀ CHÚNG KHÁC NHAU ĐÚNG MỘT CHỖ
-------------------------------------------
    MODE_MAIN  'Top bar'  wm.window_new_main + dẹp bớt area
                          Có thanh topbar của Blender, đổi được workspace/scene
                          ngay trong cửa sổ đó.
    MODE_TEMP  'Compact'  screen.area_dupli
                          Không topbar nên gọn hơn hẳn.

ĐÍNH CHÍNH 05/08/2026 — BẢN ĐẦU NÓI SAI. Nhãn cũ hứa rằng chỉ `MODE_MAIN` mới
được Blender nhớ, còn `MODE_TEMP` là cửa sổ tạm nên mất sau khi khởi động lại.
Đo thật (mở -> Save Startup File -> thoát hẳn -> mở lại) thì **CẢ HAI đều quay
lại đủ số cột**. Cái quyết định không phải loại cửa sổ, mà là người dùng có lưu
Startup File hay không. Nhãn đã sửa theo số đo.

CHỮ TRONG FILE NÀY
------------------
Chuỗi hiện cho người dùng viết TIẾNG ANH - addon có bài kiểm chặn chữ tiếng Việt
trong string literal, và docstring của Operator chính là tooltip nên cũng tính.
Tiếng Việt chỉ nằm trong comment.
"""
import io
import os
import json
import time

import bpy

from . import gate

# KHÔNG CÓ TRẦN SỐ CỘT, VÀ KHÔNG CÓ Ô TICK NÀO.
#
# Hai bản trước đều sai theo hai kiểu. Bản đầu chặn cứng 4 cột - con số tôi bịa,
# không phải giới hạn của Blender. Bản sau bỏ trần nhưng bắt người dùng đi tick
# từng tab, tức là đẩy một câu hỏi mà addon TỰ TRẢ LỜI ĐƯỢC sang cho khách.
#
# Nay: mở ra là hiện ĐÚNG những plugin khách đang có, mỗi cái một cột. Khách
# không phải khai gì, không phải nhớ gì.
#
# MỘT HÀNG NGANG, KHÔNG PHẢI LƯỚI. Có một bản giữa chừng xếp 9 tab thành lưới
# 3x3 cho vừa Full HD; sai trọng tâm. Bảng của addon dài theo CHIỀU DỌC - danh
# sách vật liệu, danh sách camera, cây thông số - nên cắt chiều cao xuống một
# phần ba là thứ đau nhất, còn cột hẹp thì chỉ cụt vài dòng chữ. Một hàng ngang,
# mỗi cột full chiều cao cửa sổ.
MODE_MAIN = 'main'
MODE_TEMP = 'temp'
MODES = (MODE_MAIN, MODE_TEMP)

# Dấu nhận cửa sổ toolbox. Đặt lên `Screen` chứ không phải `Window`: `Screen` là
# một ID nên nhận được ID-property, còn `Window` thì không.
MARK = 'dp_toolbox'

# Tab của Ducphan. Tất cả bắt đầu bằng 'DP' trừ một cái, nên nhận bằng tiền tố
# cộng một bộ ngoại lệ.
#
# Luật này CỐ Ý lỏng: một addon của người khác lỡ đặt category bắt đầu bằng 'DP'
# thì nó lọt vào danh sách, và hậu quả là... nó hiện ra một cột chạy tốt. Không
# có gì hỏng. Đổi lại, thêm addon DP mới thì không phải sửa file này.
CATEGORY_PREFIX = 'DP'
EXTRA_CATEGORIES = ('SU Sync',)

# BẢNG DP_Hub KHÔNG VÀO TOOLBOX. Nó là chỗ mua, cài, dán mã - việc làm một lần
# rồi thôi, không phải thứ cần nhìn song song trong lúc dựng cảnh. Chiếm một cột
# cho nó là lấy mất chỗ của một plugin đang dùng thật, mà số cột thì có hạn.
EXCLUDED_CATEGORIES = ('DP',)

_TTL = 2.0                   # giây - cùng nhịp với đệm trạng thái ở ui.py
_tabs_cache = None
_tabs_at = 0.0


# ------------------------------------------------------------------ danh sách tab
def _is_ours(category):
    if not category or category in EXCLUDED_CATEGORIES:
        return False
    return (category.startswith(CATEGORY_PREFIX)
            or category in EXTRA_CATEGORIES)


def tabs(force=False):
    """[(category, space_type, so_panel)] của mọi tab DP đang đăng ký.

    Quét runtime chứ không chép bảng cứng: cài thêm addon là tab mới tự có mặt.

    CÓ ĐỆM 2 GIÂY, và `ui.invalidate()` bỏ đệm này. Cần cả hai: `draw()` chạy lại
    mỗi nhịp chuột đi qua panel nên không đệm là phí, nhưng `dp_hub.install_owned()`
    cài thêm plugin GIỮA PHIÊN nên đệm vĩnh viễn thì tab mới không bao giờ hiện.

    Không bao giờ ném lỗi: hàm này bị gọi từ trong `draw()`.
    """
    global _tabs_cache, _tabs_at
    now = time.time()
    if not force and _tabs_cache is not None and (now - _tabs_at) < _TTL:
        return _tabs_cache
    # MỘT TAB CÓ THỂ SỐNG Ở HAI LOẠI EDITOR. `DP Post` có 13 panel trong
    # `IMAGE_EDITOR` và MỘT panel mồi trong `VIEW_3D`. Chọn nhầm cái sau thì cột
    # mở ra chỉ có đúng một nút, trông y như addon hỏng. Vì vậy đếm theo CẶP
    # (tab, loại editor) rồi lấy loại nào nhiều panel hơn.
    counts = {}
    try:
        for cls in bpy.types.Panel.__subclasses__():
            # PHẢI LỌC `is_registered` — ĐO ĐƯỢC 05/08/2026. `__subclasses__()`
            # trả cả lớp đã bị `unregister_class`: gỡ addon xong thì module vẫn
            # nằm trong `sys.modules` và lớp Python vẫn sống, chỉ mất đăng ký
            # RNA. Không lọc thì bảng chọn còn hiện tab của plugin ĐÃ GỠ, tick
            # vào là mở ra một cột rỗng.
            if not getattr(cls, 'is_registered', False):
                continue
            if getattr(cls, 'bl_region_type', '') != 'UI':
                continue
            cat = getattr(cls, 'bl_category', '')
            if not _is_ours(cat):
                continue
            space = getattr(cls, 'bl_space_type', 'VIEW_3D')
            counts[(cat, space)] = counts.get((cat, space), 0) + 1
    except Exception as exc:
        print('[dp_license] khong quet duoc danh sach tab: %r' % (exc,))
    best = {}
    for (cat, space), n in counts.items():
        if cat not in best or n > best[cat][1]:
            best[cat] = (space, n)
    _tabs_cache = [(cat, best[cat][0], best[cat][1]) for cat in sorted(best)]
    _tabs_at = now
    return _tabs_cache


def invalidate():
    """Bỏ đệm danh sách tab. `ui.invalidate()` gọi tới."""
    global _tabs_cache
    _tabs_cache = None


def space_of(category):
    """Loại editor mà tab này sống trong đó. Sai chỗ này thì cột trống trơn.

    `DP Post` là `IMAGE_EDITOR`; tám tab còn lại là `VIEW_3D`.
    """
    for cat, space, _n in tabs():
        if cat == category:
            return space
    return 'VIEW_3D'


# ------------------------------------------------------------------ thiết lập
def _settings_path():
    # ĐÚNG THƯ MỤC MÃ KÍCH HOẠT ĐANG NẰM. `dp_license/` được CHÉP vào từng addon
    # nên 7 addon là 7 bản module riêng: để lựa chọn trong biến module thì mỗi
    # addon nhớ một danh sách khác nhau. Phải là một file dùng chung.
    return os.path.join(gate._store_dir(), 'toolbox.json')


def settings():
    """{'mode': 'main'|'temp'}. Không bao giờ ném lỗi.

    CHỈ CÒN MỘT LỰA CHỌN Ở ĐÂY. Bản trước còn lưu danh sách tab người dùng tick;
    bỏ rồi - danh sách tab là thứ addon TỰ BIẾT (xem `tabs()`), hỏi lại khách là
    bắt họ khai một thứ đã nằm sẵn trên máy họ.
    """
    data = {}
    try:
        with io.open(_settings_path(), encoding='utf-8') as fh:
            data = json.load(fh)
    except Exception:
        pass                            # chưa có file - lần đầu chạy
    if not isinstance(data, dict):
        data = {}
    mode = data.get('mode')
    return {'mode': mode if mode in MODES else MODE_MAIN}


def set_mode(mode):
    mode = mode if mode in MODES else MODE_MAIN
    try:
        with io.open(_settings_path(), 'w', encoding='utf-8') as fh:
            fh.write(json.dumps({'mode': mode}, ensure_ascii=False, indent=1))
    except OSError as exc:
        print('[dp_license] khong ghi duoc %s: %r' % (_settings_path(), exc))
    return mode


# ------------------------------------------------------------------ cửa sổ
def toolbox_window():
    """Cửa sổ toolbox đang mở, hoặc None."""
    try:
        for win in bpy.context.window_manager.windows:
            scr = getattr(win, 'screen', None)
            if scr is not None and scr.get(MARK):
                return win
    except Exception:
        pass
    return None


def _main_region(area):
    for r in area.regions:
        if r.type == 'WINDOW':
            return r
    return None


def _ui_region(area):
    for r in area.regions:
        if r.type == 'UI':
            return r
    return None


def _pick_source_area(context):
    """Area để nhân bản ra cửa sổ mới. Ưu tiên chính area đang bấm nút."""
    area = getattr(context, 'area', None)
    if area is not None and area.type == 'VIEW_3D':
        return area
    scr = getattr(context, 'screen', None)
    if scr is None:
        return None
    biggest = None
    for a in scr.areas:
        if a.type == 'VIEW_3D' and (biggest is None
                                    or a.width * a.height > biggest.width * biggest.height):
            biggest = a
    return biggest or (scr.areas[0] if scr.areas else None)


def _override(win, area=None, region=None):
    """Context trỏ ĐÚNG vào cửa sổ toolbox.

    ĐÃ ĐO 05/08/2026, VÀ ĐÂY LÀ CÁI BẪY CHÍNH: thiếu `window=`/`screen=` thì
    `temp_override(area=..., region=...)` vẫn chạy, không ném lỗi, nhưng operator
    làm việc trên màn hình của CỬA SỔ ĐANG HOẠT ĐỘNG. Kết quả là `area_close` và
    `area_split` im lặng không có tác dụng gì lên cửa sổ mới, còn cửa sổ mới thì
    giữ nguyên bố cục nhân bản (viewport + outliner + properties + timeline).
    """
    kw = {'window': win, 'screen': win.screen}
    if area is not None:
        kw['area'] = area
        r = region if region is not None else _main_region(area)
        if r is not None:
            kw['region'] = r
    return bpy.context.temp_override(**kw)


# Màu nền vùng bảng, ĐO BẰNG CÁCH LẤY MẪU PIXEL trên ảnh chụp thật (Blender Dark):
#   vùng viewport thừa  0.2471
#   nền bảng            0.1765     <- muốn khớp cái này
# Không lấy từ API theme được: `view_3d.space` của Blender 5.2 là
# `ThemeSpaceGradient`, chỉ phơi ra `gradients.high_gradient` (nền viewport), KHÔNG
# có màu nền vùng bảng.
_PANEL_BG_SRGB = 0.1765

# Giá trị TUYẾN TÍNH thật sự đem gán, hiệu chỉnh bằng số đo chứ không bằng công
# thức. `View3DShading.background_color` có subtype `COLOR` nên là màu tuyến
# tính, và phép quy đổi sRGB thuần cho ra 0.0262 — nhưng ảnh chụp lại đo được
# 0.1922 thay vì 0.1765: viewport còn áp một biến đổi màu riêng lên nền. Chia
# ngược theo tỉ lệ đo được (1.1725) ra con số dưới đây.
#
# Vòng đo: đặt giá trị -> chụp -> lấy mẫu pixel -> so với 0.1765. Đừng sửa số
# này bằng cách tính lại công thức; sửa xong phải chụp lại.
_PANEL_BG_LINEAR = 0.0224


def _panel_bg():
    """Màu tô nền cột, ở KHÔNG GIAN TUYẾN TÍNH (xem ghi chú ngay trên)."""
    return (_PANEL_BG_LINEAR,) * 3


def _strip_area(area):
    """Tắt mọi thứ thừa của một cột: chỉ để lại sidebar.

    Cột này để BẤM NÚT, không để nhìn cảnh - nhưng vẫn phải là một editor thật,
    vì panel của addon đăng ký ở `VIEW_3D`/`IMAGE_EDITOR` chứ không lơ lửng được.
    """
    space = area.spaces.active
    for attr, value in (('show_region_ui', True),
                        ('show_region_toolbar', False),
                        ('show_region_header', False),
                        ('show_region_tool_header', False),
                        ('show_gizmo', False)):
        try:
            setattr(space, attr, value)
        except Exception:
            pass                        # editor này không có công tắc đó
    try:
        space.overlay.show_overlays = False
    except Exception:
        pass
    # NỀN VIEWPORT TÔ TRÙNG MÀU NỀN BẢNG. Không ẩn được vùng viewport (đã đo:
    # `screen.region_toggle(region_type='WINDOW')` chạy không lỗi mà vùng vẫn
    # nguyên 519x925), nên phần thừa bên trái mỗi cột là thứ phải sống chung.
    # Tô nó trùng màu nền bảng thì cái khe xám biến mất về mặt thị giác, cột
    # nhìn ra một dải liền chứ không phải một cái bảng lọt thỏm trong hộp.
    # `hasattr` TRƯỚC, không phải bắt ngoại lệ rồi in ra. Cột `DP Post` là
    # `IMAGE_EDITOR` và nó KHÔNG có `shading` - đó là chuyện bình thường, không
    # phải sự cố. Bắt rồi in thì mỗi lần mở toolbox lại có một dòng đỏ vô cớ
    # trong Console, và dòng đỏ vô cớ là thứ làm người ta thôi đọc Console.
    shading = getattr(space, 'shading', None)
    if shading is not None:
        try:
            shading.type = 'SOLID'
            shading.background_type = 'VIEWPORT'
            shading.background_color = _panel_bg()
        except Exception as exc:
            print('[dp_license] khong dat duoc nen cot: %r' % (exc,))
    # TẮT MỌI LOẠI ĐỐI TƯỢNG TRONG CỘT NÀY. Không chỉ cho sạch mắt: phần thừa
    # bên trái mỗi cột là một viewport 3D THẬT, và nó vẽ lại cảnh mỗi khung hình.
    # Ba cột như vậy trên một nội thất 79k mặt là ba lần dựng hình vô ích chạy
    # song song với cửa sổ chính. Tắt hết đối tượng thì nó chỉ còn tô một mảng
    # nền - gần như không tốn gì.
    #
    # Duyệt theo TÊN THUỘC TÍNH chứ không liệt kê tay: Blender thêm loại đối
    # tượng mới qua từng bản (curves, pointcloud, volume...), và một danh sách
    # chép tay sẽ lặng lẽ bỏ sót đúng loại nặng nhất.
    try:
        for name in space.bl_rna.properties.keys():
            if name.startswith('show_object_viewport_'):
                setattr(space, name, False)
    except Exception as exc:
        print('[dp_license] khong tat duoc doi tuong trong cot: %r' % (exc,))
    area.tag_redraw()


def _pin(area, category):
    """Ghim tab vào sidebar của `area`. Trả True nếu ghim ĂN.

    PHẢI KIỂM LẠI SAU KHI GHI, và phải gọi lại ở nhịp sau nếu chưa ăn: Blender
    chỉ nhận một tên tab mà vùng đó ĐÃ BIẾT, và nó chỉ biết sau khi vẽ ít nhất
    một lần. Area vừa đổi loại (`area.type = ...`) thì chưa vẽ lần nào, nên lần
    ghi đầu tiên trượt mà KHÔNG ném lỗi - đo được 05/08/2026: 1/3 cột ăn.
    """
    region = _ui_region(area)
    if region is None:
        return False
    if region.active_panel_category == category:
        return True
    try:
        region.active_panel_category = category
        region.tag_redraw()
    except Exception as exc:
        print('[dp_license] khong ghim duoc tab %r: %r' % (category, exc))
        return False
    return region.active_panel_category == category


def _split(win, area, factor, direction='VERTICAL'):
    """Cắt `area` trong cửa sổ `win`. Trả True nếu THẬT SỰ có thêm area.

    ĐẾM LẠI SỐ AREA, KHÔNG TIN GIÁ TRỊ TRẢ VỀ. `bpy.ops` chỉ ném lỗi khi operator
    trả ERROR hoặc trượt `poll`; Blender từ chối cắt vì phần còn lại quá hẹp thì
    nó trả CANCELLED - lặng lẽ, không ngoại lệ nào. Tin vào việc "không ném lỗi"
    là báo cho người dùng rằng đã thêm cột trong khi không có cột nào.
    """
    before = len(win.screen.areas)
    try:
        with _override(win, area):
            bpy.ops.screen.area_split(direction=direction, factor=factor)
    except Exception as exc:
        print('[dp_license] khong cat duoc cot: %r' % (exc,))
        return False
    if len(win.screen.areas) > before:
        return True
    # NÓI RA CẢ KHI BỊ TỪ CHỐI LẶNG LẼ. Không có dòng này thì một ô thiếu chỉ
    # hiện ra dưới dạng "cửa sổ trông sai" mà không có manh mối nào.
    print('[dp_license] Blender tu choi cat %s factor=%.3f tren area '
          '%dx%d tai (%d,%d)'
          % (direction, factor, area.width, area.height, area.x, area.y))
    return False


def _collapse_to_one(win):
    """Dẹp bớt cho tới khi cửa sổ chỉ còn MỘT area. Trả số area còn lại.

    `wm.window_new_main` nhân bản CẢ bố cục (outliner, properties, timeline...).
    Đóng dần từ area NHỎ NHẤT, giữ lại cái to nhất.

    CHẤP NHẬN THẤT BẠI: Blender từ chối đóng một area khi không hàng xóm nào nuốt
    được chỗ trống nó để lại. Dẹp được đến đâu hay đến đó rồi dựng cột trong phần
    còn lại - thà một cửa sổ hơi thừa còn hơn một operator ném lỗi đỏ.
    """
    for _round in range(16):
        areas = sorted(win.screen.areas, key=lambda a: a.width * a.height)
        if len(areas) <= 1:
            break
        closed = False
        for a in areas[:-1]:            # thử từ nhỏ nhất, chừa cái to nhất
            try:
                with _override(win, a):
                    bpy.ops.screen.area_close()
                closed = True
                break
            except Exception:
                continue
        if not closed:
            break
    return len(win.screen.areas)


# Bề rộng cột N-panel khi CHƯA đo được từ giao diện đang chạy. Không phải số
# đoán: đo trên Blender 5.2 ở Full HD, Resolution Scale 1.0 -> 420px.
FALLBACK_CELL = 420

# Dưới ngưỡng này thì con số đo được KHÔNG phải bề rộng thật của một cột.
_MIN_REAL_CELL = 100


def _cell_width(win):
    """Bề rộng một cột, ĐO từ sidebar đang mở ở bất kỳ cửa sổ nào.

    Không chép một con số vào mã nguồn: bề rộng cột N-panel đổi theo Resolution
    Scale, theo theme, và theo việc người dùng đã kéo rộng nó ra hay chưa.

    HAI CÁI BẪY, CẢ HAI ĐỀU ĐO ĐƯỢC 05/08/2026:

    1. Sidebar đang ĐÓNG báo rộng **1px**, không phải 0. Bản đầu kiểm `> 0` nên
       nhận luôn số 1 làm bề rộng cột: "1572 chia 1" ra 1572 cột, và cái trần
       biến mất trong im lặng.
    2. Quét MỌI cửa sổ rồi lấy số lớn nhất thì vớ phải sidebar của editor khác
       (đo được 630px), ra ít cột hơn thực tế. Chỉ đo trong CHÍNH cửa sổ toolbox
       - các cột đều nhân bản từ area nguồn của nó nên đó mới là con số đúng.
    """
    best = 0
    screen = getattr(win, 'screen', None)
    for area in (screen.areas if screen is not None else ()):
        region = _ui_region(area)
        if region is not None and region.width > best:
            best = region.width
    if best >= _MIN_REAL_CELL:
        return best
    try:
        scale = bpy.context.preferences.system.ui_scale or 1.0
    except Exception:
        scale = 1.0
    return max(_MIN_REAL_CELL, int(FALLBACK_CELL * scale))


def _column_count(win, n):
    """Số cột dựng được, tính từ bề rộng THẬT của cửa sổ. Không bao giờ dưới 1.

    VÌ SAO PHẢI CHẶN, DÙ NGƯỜI DÙNG MUỐN THẤY HẾT
    ---------------------------------------------
    Cột N-panel cần đúng bề rộng tự nhiên của nó (đo được 420px) mới vẽ ra nội
    dung. Hẹp hơn thì Blender KHÔNG thu nhỏ chữ - nó xén luôn cả vùng vẽ, chỉ
    chừa lại dải tab dọc.

    Đo 05/08/2026 trên cửa sổ 1572px: chín tab -> mỗi cột 170px -> ảnh chụp cho
    thấy CHÍN cột trống trơn, không cột nào hiện được một dòng nào. Bảng số lúc
    đó vẫn báo "ghim được 9/9" - đúng nhưng vô nghĩa.

    Nên thà dựng ít cột mà đọc được. KHÔNG MẤT TAB NÀO: dải tab dọc của mỗi cột
    liệt kê đủ mọi plugin, bấm một cái là cột đó đổi sang plugin khác.
    """
    unit = _cell_width(win)
    fits = max(1, int(win.width // unit))
    cols = min(n, fits)
    print('[dp_license] toolbox: %d tab | cua so %dpx | cot %dpx -> dung %d cot'
          % (n, win.width, unit, cols))
    return cols


def _step_layout(win, n):
    """Cắt thêm ĐÚNG MỘT cột. Trả True nếu vẫn còn cột phải cắt.

    MỖI NHỊP MỘT NHÁT — ĐIỀU KIỆN BẮT BUỘC, KHÔNG PHẢI THẬN TRỌNG THỪA. Blender
    chỉ bố trí lại màn hình khi VẼ LẠI, nên ngay sau `area_split` thì mọi
    `area.x/y/width/height` vẫn là số CŨ. Cắt liên tiếp trong một nhịp là phép
    "chọn area rộng nhất" đọc số của bố cục trước đó và cắt trúng nhầm chỗ.

    Đo được 05/08/2026 bằng cách in hình học ở mỗi lần gọi: bốn lần cắt liên
    tiếp đều báo đúng một khung `(0, 0, 1572, 931)`, và 9 tab chỉ ra 5 ô lệch
    nhau, có ô rộng 53px.

    Vì vậy hàm này KHÔNG lặp: nhìn bố cục đã cập nhật, cắt một nhát, rồi trả
    quyền cho Blender vẽ lại.
    """
    areas = list(win.screen.areas)
    if not areas or len(areas) >= n:
        return False
    # Luôn cắt cột RỘNG NHẤT, và cắt sao cho phần tách ra bằng các cột đã có ->
    # N cột đều nhau mà không phải tính trước vị trí nào.
    target = max(areas, key=lambda a: a.width)
    return _split(win, target, 1.0 / (n - len(areas) + 1)) or False


def _assign_types(win, categories):
    """Đặt loại editor cho từng ô. KHÔNG ghim tab ở đây - xem `_pin`."""
    n_cells = len(win.screen.areas)
    for i, category in enumerate(categories):
        if i >= n_cells:
            break
        # Lấy lại danh sách ở mỗi vòng: `area.type = ...` dựng lại space của
        # area đó, đừng giữ tham chiếu cũ qua nó.
        cells = sorted(win.screen.areas, key=lambda a: (-a.y, a.x))
        area = cells[i]
        want = space_of(category)
        if area.type != want:
            try:
                area.type = want
            except Exception as exc:
                print('[dp_license] khong doi duoc area sang %s: %r'
                      % (want, exc))
        _strip_area(sorted(win.screen.areas, key=lambda a: (-a.y, a.x))[i])
    return n_cells


def _pin_all(win, categories):
    """Ghim tab cho mọi ô. Trả số ô đã ăn."""
    done = 0
    for i, cat in enumerate(categories):
        cells = sorted(win.screen.areas, key=lambda a: (-a.y, a.x))
        if i >= len(cells):
            break
        if _pin(cells[i], cat):
            done += 1
    return done


def _find_new_window(before):
    for win in bpy.context.window_manager.windows:
        if win.as_pointer() not in before:
            return win
    return None


def open_toolbox(context, categories=None, mode=None):
    """Mở cửa sổ toolbox với ĐÚNG những plugin máy này đang có.

    `categories=None` (đường thường dùng) nghĩa là LẤY HẾT: khách mua bao nhiêu
    addon thì hiện bấy nhiêu. Tham số chỉ còn để bộ kiểm dựng cảnh cố định.

    Trả (thành_công, câu_để_report).
    """
    cfg = settings()
    if categories is None:
        categories = [r[0] for r in tabs()]
    cats = [c for c in categories if c]
    # Bỏ trùng mà GIỮ thứ tự - `set()` sẽ xáo thứ tự cột mỗi lần mở.
    seen = set()
    cats = [c for c in cats if not (c in seen or seen.add(c))]
    if not cats:
        return False, 'No DP plugin panels found in this Blender'
    if toolbox_window() is not None:
        return False, 'The toolbox window is already open'

    mode = mode if mode in MODES else cfg['mode']
    source = _pick_source_area(context)
    if source is None:
        return False, 'Open this from a 3D viewport'

    before = set(w.as_pointer() for w in context.window_manager.windows)
    region = _main_region(source)
    try:
        with context.temp_override(window=context.window, screen=context.screen,
                                   area=source,
                                   region=region or source.regions[0]):
            if mode == MODE_TEMP:
                # Cửa sổ chỉ chứa ĐÚNG một area - không phải dẹp gì thêm.
                # 'INVOKE_DEFAULT' là bắt buộc: operator này chỉ có `invoke`,
                # gọi kiểu EXEC thì nó không làm gì và cũng không kêu tiếng nào.
                bpy.ops.screen.area_dupli('INVOKE_DEFAULT')
            else:
                bpy.ops.wm.window_new_main()
    except Exception as exc:
        return False, 'Blender refused to open a new window: %r' % (exc,)

    win = _find_new_window(before)
    if win is None:
        return False, 'The new window did not appear'
    try:
        win.screen[MARK] = 1
        # Tên screen hiện trong bộ chọn layout; đặt cho dễ nhận ra cái nào là gì.
        win.screen.name = 'DP Toolbox'
    except Exception:
        pass

    # DỰNG DẦN QUA NHIỀU NHỊP. Hai lý do khác nhau, cùng một gốc: Blender chỉ
    # cập nhật bố cục và dựng vùng vẽ khi VẼ LẠI.
    #   pha 0  dẹp bố cục nhân bản còn một ô, rồi tính lưới
    #   pha 1  cắt - MỖI NHỊP MỘT NHÁT (xem `_step_layout`)
    #   pha 2  đặt loại editor
    #   pha 3  ghim tab, thử lại cho tới khi ăn hết (xem `_pin`)
    state = {'phase': 0, 'tries': 0, 'cuts': 0, 'cols': len(cats),
             'shown': list(cats)}

    def _later():
        try:
            n = state['cols']
            if state['phase'] == 0:
                _collapse_to_one(win)
                state['cols'] = _column_count(win, len(cats))
                state['shown'] = cats[:state['cols']]
                state['phase'] = 1
                return 0.05
            if state['phase'] == 1:
                # Trần số nhát cắt để một lần bị từ chối không thành vòng lặp
                # vô tận: cần đúng n-1 nhát, cho dư vài nhịp.
                if state['cuts'] < n + 2 and _step_layout(win, n):
                    state['cuts'] += 1
                    return 0.05
                state['phase'] = 2
                return 0.05
            if state['phase'] == 2:
                _assign_types(win, state['shown'])
                state['phase'] = 3
                return 0.05
            done = _pin_all(win, state['shown'])
            state['tries'] += 1
            if done >= n:
                return None
            if state['tries'] >= 8:
                # NÓI RA. Một cột rơi về tab mặc định trông y như addon hỏng, và
                # im lặng ở đây là biến một lỗi thành một bí ẩn.
                print('[dp_license] toolbox: chi ghim duoc %d/%d cot sau %d nhip'
                      % (done, n, state['tries']))
                return None
            return 0.1
        except Exception as exc:
            print('[dp_license] toolbox dung cot loi: %r' % (exc,))
            return None

    bpy.app.timers.register(_later, first_interval=0.0)
    return True, ('Toolbox opened - drag it to another monitor, and widen it '
                  'for more columns')


def cells():
    """{tab: area} của cửa sổ toolbox đang mở. Rỗng nếu chưa mở. Dùng để đo."""
    win = toolbox_window()
    out = {}
    if win is None or win.screen is None:
        return out
    for area in win.screen.areas:
        region = _ui_region(area)
        if region is not None and region.active_panel_category:
            out[region.active_panel_category] = area
    return out


# ĐÃ BỎ `add_column` / `remove_column` / bảng tick (05/08/2026).
#
# Chúng ra đời để người dùng tự chọn hiện addon nào. Nhưng addon TỰ BIẾT khách
# có gì - một tab chỉ tồn tại khi plugin đã cài, mà đã cài nghĩa là đã mua. Bắt
# khách tick lại danh sách đó là hỏi một câu mà máy đã có sẵn câu trả lời, và
# thêm hai đường code phải nuôi. Nay chỉ còn: bấm một nút, hiện đúng những gì
# đang có, tự xếp cho vừa màn hình.


def close_toolbox():
    """Đóng cửa sổ toolbox. Trả (thành_công, câu_report)."""
    win = toolbox_window()
    if win is None:
        return False, 'The toolbox window is not open'
    try:
        with bpy.context.temp_override(window=win):
            bpy.ops.wm.window_close()
    except Exception as exc:
        return False, 'Blender refused to close the window: %r' % (exc,)
    return True, 'Toolbox closed'


# ------------------------------------------------------------------ operator
def popout_idname(product):
    """Tên operator RIÊNG cho từng sản phẩm.

    Cùng lý do đã ghi ở đầu `ui.py`: `dp_license/` được chép vào từng addon, nên
    hai addon cùng cài là hai bản copy cùng chạy. Dùng chung một `bl_idname` thì
    bản đăng ký sau đè bản trước, và TẮT addon này là chết nút của addon KIA.
    """
    from . import ui
    return 'dplic.toolbox_%s' % ui._check_product(product)


def _toolbox_class(product):
    def execute(self, context):
        # Nút nào cũng mở ra CÙNG một cửa sổ chứa TẤT CẢ plugin đang có. Không
        # còn "nút này mở tab này": khách bấm ở đâu cũng ra cùng một kết quả, và
        # đó chính là thứ họ muốn - thấy hết mọi thứ mình đã mua.
        ok, msg = open_toolbox(context)
        self.report({'INFO'} if ok else {'WARNING'}, msg)
        return {'FINISHED'} if ok else {'CANCELLED'}

    return type('DPLIC_OT_toolbox_%s' % product, (bpy.types.Operator,), {
        'bl_idname': popout_idname(product),
        'bl_label': 'Open toolbox window',
        # Docstring của Operator LÀ tooltip - nên nó phải là tiếng Anh.
        'bl_description': ('Show all your DP plugin panels side by side in a '
                           'separate window you can drag to another monitor'),
        'bl_options': {'REGISTER'},
        'execute': execute,
    })


def make_class(product):
    return _toolbox_class(product)


# ------------------------------------------------------------------ vẽ
def draw_button(layout, product, category=None):
    """Nút nhỏ ở header panel. Không bao giờ ném lỗi - nó chạy trong `draw()`.

    KHÔNG VẼ KHI ĐANG Ở TRONG CHÍNH CỬA SỔ TOOLBOX. Nút này để mở toolbox; nằm
    bên trong toolbox rồi thì nó là một nút không làm gì, nhân lên đúng bằng số
    cột. Bớt được một thứ thừa trên mỗi cột.

    `category` không còn dùng tới; giữ tham số để bản panel cũ gọi vào vẫn chạy.
    """
    # ⛔ TOOLBOX CU DA BI BO — Ducphan chot 23/09/2026, noi hai lan:
    #       *"co chuc nang nay roi thi bo cai windowlayout toolbox di"*
    #       *"toolbox cung chua bo di"*
    #
    #   Thay cho no la CUA SO DP (`dp_hub/khay/cua_so.py`): mot cua so he dieu
    #   hanh roi, keo ra ngoai khung Blender duoc, ben trong la o cua tung
    #   addon do Hub ve ho. Hai loi lam cung mot viec la khach bam nham, va hai
    #   he giao dien chay song song thi sua mot ben khong an sang ben kia.
    #
    # ⛔ GIU LAI CAI HAM, chi bo phan VE. Panel cua 5 addon dang goi
    #   `toolbox.draw_button(...)` trong `draw_header_preset()`; xoa han ham la
    #   nam addon do ra `AttributeError` ngay giua `draw()`. Giu vo rong thi
    #   chung chay tiep, khong ve gi, va KHONG phai sua mot dong nao ben addon.
    #
    # ⛔ `open_toolbox()` va cac operator `dplic.toolbox_*` VAN CON dang ky —
    #   chung khong con loi vao nao tren giao dien nua (day la loi vao duy
    #   nhat), nhung ma cu goi thang van chay. Bo han chung la viec rieng, va
    #   phai ra soat ca 11 addon truoc.
    return
