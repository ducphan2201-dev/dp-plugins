# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
# -*- coding: utf-8 -*-
"""TẦNG BẢO VỆ THỨ NĂM — MÃ NGUỒN addon nằm trong gói đã mã hoá.

Ducphan chốt 10/08/2026: mã hoá hết, không chỉ dữ liệu.

TẦNG NÀY KHÁC TẦNG BA Ở CHỖ NÀO
-------------------------------
Tầng ba (`datapack`) giấu **dữ liệu** addon cần để làm việc. Xoá đoạn kiểm mã
thì addon vẫn bật được, chỉ là panel trống rỗng.

Tầng này giấu **chính mã nguồn**. Bản bán ra không còn file `.py` nào của addon
ngoài `__init__.py` và thư mục khoá — mọi module khác nằm trong `data/code.dpk`,
mã hoá bằng đúng khoá đi theo mã kích hoạt của khách. Không có mã hợp lệ thì
addon **không nạp được**, chứ không phải nạp xong rồi từ chối làm việc.

CÁCH NÓ CHẠY
------------
`__init__.py` của bản bán ra gọi `install()` ở dòng đầu, TRƯỚC mọi `from . import`.
`install()` cắm một bộ tìm module vào `sys.meta_path`. Từ đó, mỗi lần Python đi
tìm `<addon>.<module>`, bộ tìm này nhận, giải gói, và dựng module bằng `exec`.

    data/code.idx   BẢN RÕ — chỉ là danh sách TÊN module. Tên không lộ gì cả,
                    và có nó thì lúc thiếu khoá addon báo được câu tử tế thay vì
                    ném ImportError trần.
    data/code.dpk   mã nguồn thật, đã mã hoá.

VÌ SAO CẤT MÃ NGUỒN CHỨ KHÔNG CẤT BYTECODE
------------------------------------------
Bytecode `.pyc` dính chặt vào ĐỜI Python. Blender 5.2 mang một đời, bản sau
mang đời khác, và một gói bytecode đóng hôm nay sẽ chết câm trên bản Blender
năm sau — hỏng theo kiểu không ai đoán ra nguyên nhân. Mã nguồn thì đời nào
cũng biên dịch được. Đổi lại là mất khoảng một phần mười giây lúc bật addon,
đã đo chứ không đoán.

GIỚI HẠN THẬT, NÓI THẲNG RA ĐỂ KHÔNG AI TRÔNG CHỜ QUÁ
-----------------------------------------------------
Người MUA THẬT có mã hợp lệ, nên máy họ giải được gói — và thứ gì Python nạp
được thì cũng đọc lại được từ bộ nhớ. Tầng này **không** chặn được người mua
thật moi mã nguồn ra; nó chặn người KHÔNG có mã. Đó là trần của mọi cách bảo
vệ chạy trên máy người khác, không phải khuyết điểm của cách làm này.

Đừng để tầng này làm việc của tầng khác: nó không thay thế cửa kiểm mã, khoá
theo máy, hay tầng chỗ ngồi.

KHÔNG BAO GIỜ NÉM LỖI NGOÀI Ý MUỐN
----------------------------------
`install()` nuốt mọi lỗi và trả về 0. Lý do: nó chạy ở dòng đầu `__init__.py`,
và ném ở đó thì Blender không bật được addon mà cũng không nói được vì sao.
Thiếu khoá là chuyện BÌNH THƯỜNG (khách chưa kích hoạt) — lúc đó module nào bị
gọi tới sẽ ném `ImportError` KÈM CÂU GIẢI THÍCH, đúng chỗ Blender in ra được.
"""
import io
import os
import sys
import json
import importlib.util

from . import datapack

INDEX = 'code.idx'
PACK = 'code.dpk'

# Câu hiện ra khi khách chưa kích hoạt. Tiếng Anh vì nó nổi lên GIAO DIỆN
# Blender (hộp báo lỗi lúc bật addon), không phải chỉ nằm trong console.
THIEU_KHOA = ('%s: this build is locked. Paste a valid activation key in '
              'DP_Hub (Edit > Preferences > Add-ons > DP_Hub), then enable the '
              'add-on again.')

# Bộ tìm đang cắm, theo tên gói addon. Bật/tắt addon nhiều lần thì thay chứ
# không chồng thêm — hai bộ tìm cùng nhận một tên module là một thứ rất khó
# lần ra khi nó hỏng.
_dang_cam = {}


class _Loader(object):
    """Dựng một module từ mã nguồn đã giải."""

    def __init__(self, finder, ten, rel):
        self.finder = finder
        self.ten = ten
        self.rel = rel

    def create_module(self, spec):
        return None                      # dùng module mặc định

    def exec_module(self, module):
        src = self.finder.nguon(self.ten)
        if src is None:
            raise ImportError(THIEU_KHOA % self.finder.nhan)
        # `__file__` phải trỏ tới ĐƯỜNG DẪN THẬT dù file không còn trên đĩa:
        # mã addon tính đường tới `data/pack.dpk` bằng `os.path.dirname(__file__)`,
        # và tên file cũng là thứ hiện ra trong traceback.
        path = os.path.join(self.finder.goc, *self.rel.split('/'))
        module.__file__ = path
        exec(compile(src, path, 'exec'), module.__dict__)   # noqa: S102


class _Finder(object):
    """Nhận đúng những tên module có trong gói, không nhận gì khác.

    KHÔNG nhận bừa mọi tên bắt đầu bằng tên gói: `dp_license/` và các file được
    khai MIỄN mã hoá vẫn nằm trên đĩa dưới dạng `.py`, và cướp tên của chúng là
    làm hỏng chính bộ khoá.
    """

    def __init__(self, goi, goc, product, nhan, bang):
        self.goi = goi
        self.tien_to = goi + '.'
        self.goc = goc
        self.product = product
        self.nhan = nhan
        self.bang = bang                 # {'ten.module': 'duong/dan.py'}
        self._nguon = None               # đã giải, hoặc None nếu chưa mở được

    # -- Python gọi hàm này mỗi lần đi tìm một module --------------------
    def find_spec(self, fullname, path=None, target=None):
        if not fullname.startswith(self.tien_to):
            return None
        ten = fullname[len(self.tien_to):]
        rel = self.bang.get(ten)
        if rel is None:
            return None
        la_goi = rel.endswith('/__init__.py')
        duong = os.path.join(self.goc, *rel.split('/'))
        spec = importlib.util.spec_from_loader(
            fullname, _Loader(self, ten, rel), origin=duong, is_package=la_goi)
        if la_goi:
            spec.submodule_search_locations = [os.path.dirname(duong)]
        return spec

    # -- giải gói, một lần cho cả phiên ----------------------------------
    def nguon(self, ten):
        """Mã nguồn của một module. None nếu chưa mở được gói.

        CHỈ NHỚ KHI MỞ ĐƯỢC. Nhớ cả lần thất bại thì khách dán mã xong vẫn phải
        tắt Blender mới dùng được.
        """
        if self._nguon is None:
            self._nguon = self._giai()
        return (self._nguon or {}).get(ten)

    def _giai(self):
        master = datapack.master_key(self.product)
        if master is None:
            return None
        try:
            with open(os.path.join(self.goc, 'data', PACK), 'rb') as fh:
                blob = fh.read()
        except OSError:
            return None
        return datapack.unseal(blob, master)


def doc_bang(goc):
    """Đọc `data/code.idx`. Trả {} nếu bản này không mã hoá mã nguồn.

    Bản DEV không có file này, và đó là chuyện bình thường: mã nguồn nằm nguyên
    trên đĩa, Python tự tìm thấy, không cần bộ tìm nào cả.
    """
    try:
        with io.open(os.path.join(goc, 'data', INDEX), encoding='utf-8') as fh:
            bang = json.load(fh)
    except (OSError, ValueError):
        return {}
    return bang if isinstance(bang, dict) else {}


def install(module_file, goi, product, nhan=None):
    """Cắm bộ nạp. Trả về SỐ MODULE nó nhận (0 = bản này không mã hoá).

    Gọi ở dòng đầu `__init__.py` của bản bán ra, TRƯỚC mọi `from . import`:

        from .dp_license import codepack as _dp_codepack
        _dp_codepack.install(__file__, __name__, 'dpmax', 'DP_MaxImporter')

    KHÔNG BAO GIỜ NÉM. Xem phần cuối docstring đầu file.
    """
    try:
        goc = os.path.dirname(os.path.abspath(module_file))
        bang = doc_bang(goc)
        if not bang:
            return 0
        cu = _dang_cam.pop(goi, None)
        if cu is not None and cu in sys.meta_path:
            sys.meta_path.remove(cu)
        f = _Finder(goi, goc, product, nhan or goi, bang)
        sys.meta_path.insert(0, f)
        _dang_cam[goi] = f
        return len(bang)
    except Exception as exc:                                   # noqa: BLE001
        print('[dp_license] khong cam duoc bo nap ma nguon: %r' % (exc,))
        return 0


def quen(goi=None):
    """Bỏ nhớ mã nguồn đã giải. Gọi ngay sau khi dán hoặc xoá mã."""
    for k, f in list(_dang_cam.items()):
        if goi is None or k == goi:
            f._nguon = None
