# -*- coding: utf-8 -*-
"""Ký / kiểm chữ ký RSA PKCS#1 v1.5 — CHỈ dùng thư viện chuẩn của Python.

VÌ SAO TỰ VIẾT THAY VÌ DÙNG THƯ VIỆN
------------------------------------
Blender KHÔNG đóng gói sẵn `cryptography`, `pynacl` hay `jwt` (đã kiểm trên
Blender 5.2: site-packages có `requests`, `urllib3`, `certifi`, `numpy`, nhưng
không có thư viện mã hoá nào). Bắt người dùng tự cài thư viện vào Python của
Blender là đường chắc chắn sinh lỗi hỗ trợ.

May là phần MÌNH CẦN lại nhỏ: kiểm chữ ký RSA chỉ là MỘT phép luỹ thừa modular,
mà Python có sẵn số nguyên lớn và hàm `pow(a, b, n)` chạy bằng C:

    kiểm:  pow(chữ_ký, e, n)  ==  khối đệm chứa SHA-256 của nội dung

Toàn bộ phần chạy TRONG ADDON chỉ cần khoá CÔNG KHAI `(n, e)`. Khoá bí mật `d`
nằm trên máy tác giả, không bao giờ đi kèm bản phát hành — nên người dùng đọc
được hết mã nguồn này vẫn KHÔNG tự sinh được mã kích hoạt hợp lệ.

VỀ ĐỆM PKCS#1 v1.5
------------------
KHÔNG được ký/kiểm trên hash trần. RSA trần có tính nhân: từ vài chữ ký hợp lệ
có thể chế ra chữ ký cho nội dung khác. Đệm chuẩn chặn việc đó bằng cách bắt
khối phải có đúng dạng:

    0x00 0x01 0xFF...0xFF 0x00 || DigestInfo(SHA-256) || hash(32 byte)

`DigestInfo` là chuỗi DER cố định của SHA-256, chép nguyên từ RFC 8017 mục 9.2.
So sánh khối phải là SO SÁNH TOÀN BỘ, không được chỉ so 32 byte cuối - nếu chỉ
so đuôi thì phần đệm thành vô nghĩa và lỗ hổng quay lại y như cũ.
"""
import hashlib
import hmac as _hmac

# DigestInfo DER của SHA-256 (RFC 8017, mục 9.2). Hằng số, không tự chế.
_SHA256_DER = bytes((
    0x30, 0x31, 0x30, 0x0d, 0x06, 0x09, 0x60, 0x86, 0x48, 0x01, 0x65,
    0x03, 0x04, 0x02, 0x01, 0x05, 0x00, 0x04, 0x20,
))


def _emsa_pkcs1_v15(message: bytes, em_len: int) -> bytes:
    """Khối đã đệm cho `message`, dài đúng `em_len` byte."""
    h = hashlib.sha256(message).digest()
    t = _SHA256_DER + h
    if em_len < len(t) + 11:
        raise ValueError('khoa RSA qua ngan cho SHA-256')
    ps = b'\xff' * (em_len - len(t) - 3)
    return b'\x00\x01' + ps + b'\x00' + t


def verify(message: bytes, signature: bytes, n: int, e: int = 65537) -> bool:
    """True nếu `signature` đúng là chữ ký của `message` bằng khoá bí mật của `n`.

    Đây là hàm DUY NHẤT mà addon phát hành cần tới.
    """
    k = (n.bit_length() + 7) // 8
    if len(signature) != k:
        return False
    try:
        m = pow(int.from_bytes(signature, 'big'), e, n)
    except Exception:
        return False
    em = m.to_bytes(k, 'big')
    try:
        expect = _emsa_pkcs1_v15(message, k)
    except ValueError:
        return False
    # So sánh THỜI GIAN KHÔNG ĐỔI và so TOÀN BỘ khối, không chỉ phần đuôi.
    return _hmac.compare_digest(em, expect)


def sign(message: bytes, n: int, d: int) -> bytes:
    """Ký `message`. CHỈ chạy trên máy tác giả - cần khoá bí mật `d`.

    Hàm này KHÔNG được đi vào bản phát hành cho khách; nó nằm ở đây để phần ký
    và phần kiểm dùng CHUNG một cách đệm, tránh cảnh hai bên lệch nhau rồi mất
    cả buổi dò. `tools/make_key.py` là chỗ gọi nó.
    """
    k = (n.bit_length() + 7) // 8
    em = _emsa_pkcs1_v15(message, k)
    return pow(int.from_bytes(em, 'big'), d, n).to_bytes(k, 'big')
