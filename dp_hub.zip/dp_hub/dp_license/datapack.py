# -*- coding: utf-8 -*-
"""TẦNG BẢO VỆ THỨ BA — gói dữ liệu khoá bằng chính mã kích hoạt.

VẤN ĐỀ HAI TẦNG KIA KHÔNG GIẢI ĐƯỢC
-----------------------------------
Cài xong thì mã nguồn addon nằm nguyên trong thư mục add-ons. Ai cũng mở
`gate.py` ra, sửa `def ok(): return True`, và cả hai tầng trước bay hết — cửa
kiểm mã lẫn khoá theo máy đều là những dòng lệnh mà người ta xoá được.

Tầng này không dựa vào việc người dùng KHÔNG xoá gì. Dữ liệu addon cần để làm
việc (bảng preset vật liệu, thư viện thương hiệu, bảng ClassID→tên modifier)
không nằm trong mã nguồn nữa mà nằm trong một gói **đã mã hoá**. Khoá mở gói
nằm TRONG mã kích hoạt của khách. Xoá đoạn kiểm tra thì addon vẫn mở bình
thường — và panel TRỐNG RỖNG, vì không có gì để vẽ.

CHỖ NÀY KHÔNG CHẶN ĐƯỢC
-----------------------
Người MUA THẬT có mã hợp lệ nên giải được gói, và trích dữ liệu ra được. Đó là
giới hạn không thể vượt: addon chạy trên máy khách thì mọi thứ nó đọc được,
khách cũng đọc được. Đừng trông chờ tầng này làm việc của tầng khác.

VÌ SAO TỰ VIẾT MÃ HOÁ THAY VÌ DÙNG THƯ VIỆN
-------------------------------------------
Blender không kèm `cryptography` và không cài thêm được trên máy khách. Chỉ có
`hashlib`/`hmac` của thư viện chuẩn. Ở đây dựng một dòng khoá kiểu bộ đếm
(counter mode) trên SHA-256, kèm HMAC-SHA256 để chống sửa gói.

ĐÂY KHÔNG PHẢI MẬT MÃ CẤP QUÂN SỰ, và không cần phải là: kẻ tấn công đã có
sẵn khoá trong tay nếu họ mua một bản. Việc của nó chỉ là làm cho gói **không
đọc được nếu KHÔNG có mã hợp lệ**.

DẠNG GÓI
--------
    b'DPK1' | 4 byte độ dài phần thân | 32 byte HMAC | phần thân đã mã hoá

Kiểm HMAC TRƯỚC khi giải: gói bị sửa thì từ chối hẳn chứ không giải ra rác rồi
để addon vẽ bậy.
"""
import io
import os
import json
import hmac
import zlib
import struct
import base64
import hashlib

from . import gate

MAGIC = b'DPK1'
_HEAD = len(MAGIC) + 4 + 32          # magic + độ dài + HMAC

# Trường trong mã kích hoạt chứa khoá mở gói, theo từng sản phẩm:
#     payload['k'] = {'dpmax': '<khoá base64>', ...}
KEY_FIELD = 'k'

_cache = {}                          # product -> dữ liệu đã giải, đệm cả phiên


def _keystream(key, n):
    """n byte dòng khoá = SHA256(key || bộ_đếm) nối lại."""
    out = bytearray()
    counter = 0
    while len(out) < n:
        out += hashlib.sha256(key + struct.pack('>I', counter)).digest()
        counter += 1
    return bytes(out[:n])


def _xor(data, key):
    ks = _keystream(key, len(data))
    return bytes(a ^ b for a, b in zip(data, ks))


def _subkeys(master):
    """Tách khoá ký và khoá mã hoá. Dùng chung một khoá cho hai việc là thói
    quen xấu: lộ một là lộ cả hai."""
    return (hashlib.sha256(b'dpk-mac' + master).digest(),
            hashlib.sha256(b'dpk-enc' + master).digest())


def seal(obj, master):
    """Đóng gói `obj` (JSON được) thành bytes. Dùng ở máy tác giả."""
    raw = zlib.compress(
        json.dumps(obj, separators=(',', ':'), sort_keys=True,
                   ensure_ascii=False).encode('utf-8'), 9)
    mac_key, enc_key = _subkeys(master)
    body = _xor(raw, enc_key)
    tag = hmac.new(mac_key, body, hashlib.sha256).digest()
    return MAGIC + struct.pack('>I', len(body)) + tag + body


def unseal(blob, master):
    """Giải gói. Trả về đối tượng, hoặc None nếu gói hỏng / sai khoá.

    KHÔNG BAO GIỜ NÉM LỖI. Hàm này chạy trong `draw()` của panel; ném lỗi ở đó
    là Blender in traceback đỏ mỗi nhịp vẽ chuột đi qua.
    """
    try:
        if not blob or blob[:4] != MAGIC or len(blob) < _HEAD:
            return None
        n = struct.unpack('>I', blob[4:8])[0]
        tag = blob[8:_HEAD]
        body = blob[_HEAD:_HEAD + n]
        if len(body) != n:
            return None
        mac_key, enc_key = _subkeys(master)
        # So sánh HẰNG THỜI GIAN. So bằng `==` thì thời gian trả lời rò rỉ
        # từng byte của thẻ đúng.
        if not hmac.compare_digest(
                tag, hmac.new(mac_key, body, hashlib.sha256).digest()):
            return None
        return json.loads(zlib.decompress(_xor(body, enc_key)).decode('utf-8'))
    except Exception:
        return None


def master_key(product):
    """Khoá mở gói lấy từ mã kích hoạt ĐANG LƯU. None nếu chưa kích hoạt.

    Ở BẢN DEV (`RELEASE_BUILD = False`) `gate.check` trả về DEV và không có
    payload — lúc đó dùng khoá phát triển đọc từ biến môi trường, để máy tác
    giả mở được gói mà KHÔNG cần tự cấp mã cho chính mình.
    """
    st, payload = gate.check(product)
    if st == gate.DEV:
        return _dev_key(product)
    if st != gate.OK or not payload:
        return None
    k = (payload.get(KEY_FIELD) or {}).get(product)
    if not k:
        # Mã cấp TRƯỚC khi có tầng này thì không mang khoá gói. Trả None để
        # panel trống còn hơn vẽ bừa - và đó là dấu hiệu phải cấp lại mã.
        return None
    try:
        return base64.urlsafe_b64decode(k + '=' * (-len(k) % 4))
    except Exception:
        return None


def _dev_key(product):
    """Khoá dùng lúc phát triển. Đọc từ `DP_LICENSE_KEYS/datakeys.json`.

    Máy dev KHÔNG BAO GIỜ BỊ KHOÁ — kể cả ở tầng này. Không có file khoá thì
    trả None và panel trống, nhưng đó là máy chưa cài kho khoá chứ không phải
    máy bị chặn.
    """
    base = os.environ.get('DP_LICENSE_KEYS') or os.path.join(
        os.environ.get('LOCALAPPDATA') or os.path.expanduser('~'),
        'DP_License', 'keys')
    path = os.path.join(base, 'datakeys.json')
    try:
        with io.open(path, encoding='utf-8') as fh:
            d = json.load(fh)
        k = d[product]
        return base64.urlsafe_b64decode(k + '=' * (-len(k) % 4))
    except Exception:
        return None


def load(path, product, reload=False):
    """Đọc và giải một file `.dpk`. Trả về dữ liệu, hoặc None.

    Có đệm theo sản phẩm: `draw()` chạy lại mỗi nhịp chuột đi qua panel, giải
    gói mỗi nhịp là vừa tốn vừa vô ích.
    """
    if not reload and product in _cache:
        return _cache[product]
    master = master_key(product)
    if master is None:
        return None
    try:
        with open(path, 'rb') as fh:
            blob = fh.read()
    except OSError:
        return None
    data = unseal(blob, master)
    if data is not None:
        _cache[product] = data
    return data


def addon_pack(module_file, product):
    """Đọc `<thư mục addon>/data/pack.dpk`. Trả dữ liệu, hoặc None.

    Đường dẫn tính theo `__file__` của addon chứ KHÔNG theo thư mục làm việc:
    `draw()` và các operator chạy với thư mục làm việc bất kỳ.

        from .dp_license import datapack
        data = datapack.addon_pack(__file__, PRODUCT)

    Không bao giờ ném lỗi — nó bị gọi từ trong `draw()`.
    """
    try:
        path = os.path.join(os.path.dirname(os.path.abspath(module_file)),
                            'data', 'pack.dpk')
        return load(path, product)
    except Exception as exc:
        print('[dp_license] khong doc duoc goi du lieu: %r' % (exc,))
        return None


def invalidate(product=None):
    """Bỏ đệm. Gọi ngay sau khi dán hoặc xoá mã."""
    if product is None:
        _cache.clear()
    else:
        _cache.pop(product, None)
