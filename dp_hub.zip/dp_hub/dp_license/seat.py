# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
# -*- coding: utf-8 -*-
"""Chỗ ngồi: một mã kích hoạt chỉ thuộc về MÁY KÍCH HOẠT ĐẦU TIÊN.

VÌ SAO CẦN, KHI ĐÃ BUỘC THEO MÁY
--------------------------------
`machine_id.matches()` đòi khớp hai trên ba yếu tố đã băm. Máy khác hẳn thì
khớp 0/3 nên bị chặn — nhưng máy **ghost từ cùng một image** mang ba yếu tố y
hệt nhau, nên nó không phân biệt nổi. Một công ty ghost 10 máy từ một image là
một mã mở cả 10.

Chỗ ngồi phân biệt được, vì mỗi BẢN CÀI tự sinh một `install_id` ngẫu nhiên lúc
kích hoạt: image sạch thì mười máy sinh ra mười chuỗi khác nhau, và cửa kiểm chỉ
nhận chuỗi đầu tiên.

BẮT ĐƯỢC GÌ, VÀ KHÔNG BẮT ĐƯỢC GÌ
---------------------------------
  - ghost TRƯỚC khi kích hoạt → chặn sạch, máy thứ hai nhận `SEAT_TAKEN`.
  - ghost SAU khi kích hoạt   → các bản sao mang cùng `install_id`, cửa kiểm
    KHÔNG phân biệt nổi. Chỉ *phát hiện* được bằng khoá phiên xoay vòng, rồi
    tác giả tự quyết định thu hồi.
Đừng hứa quá hai dòng đó ở bất cứ đâu.

HAI LUẬT KHÔNG ĐƯỢC VI PHẠM
---------------------------
1. **Mất mạng KHÔNG BAO GIỜ chặn khách.** Chỉ chặn khi cửa kiểm trả lời dứt
   khoát: HTTP 200 kèm `{"ok": false}`. Mọi thứ khác — 403 của một proxy, 502,
   hết giờ chờ, JSON rác — đều là KHÔNG BIẾT, và không biết thì cho chạy. Rủi ro
   lớn nhất của cả tầng này là chặn nhầm khách thật; mất vì chặn nhầm đắt hơn
   mất vì bị chia sẻ.
2. **Không gọi mạng trong `gate.check()`.** Hàm đó chạy trong `draw()` của
   panel, tức mỗi lần Blender vẽ lại. Một lần gọi mạng ở đó là treo giao diện.
   `check()` chỉ đọc trạng thái đã lưu trên đĩa; việc gọi mạng nằm ở
   `claim()` (lúc dán mã) và `ping_if_due()` (gọi từ operator/timer).

KHÔNG PHẢI NHỊP TIM
-------------------
`ping_if_due()` chỉ chạy khi đã quá `PING_MOI` ngày, và không gọi được thì bỏ
qua trong im lặng — không đếm ngược, không hết hạn vì lâu không online. Kích
hoạt trực tuyến đúng một lần, sau đó chạy ngoại tuyến vĩnh viễn.

GỬI LÊN NHỮNG GÌ
----------------
`kid` (băm của mã, 16 ký tự), `install_id` (chuỗi ngẫu nhiên của bản cài này),
và chuỗi mã máy — vốn đã là ba chuỗi băm. KHÔNG gửi mã kích hoạt, KHÔNG gửi
email, không có gì đọc ngược ra tên máy hay số hiệu ổ đĩa.
"""
import os
import io
import json
import time
import hashlib
import binascii

# Địa chỉ cửa kiểm. KHÔNG bí mật — nó nằm sẵn trong `catalog.json` công khai ở
# trường `gate`, và `tools/selftest_seat.py` có một phép đo bắt hai chỗ này
# bằng nhau. Hai chỗ lệch nhau là addon gọi vào một địa chỉ không tồn tại, và
# vì luật fail-open ở trên nên nó sẽ hỏng HOÀN TOÀN IM LẶNG.
GATE_URL = 'https://dp-gate.vyd-info.workers.dev'

# Biến môi trường để bài kiểm trỏ sang cửa kiểm giả ở localhost. Không dùng
# trên máy khách.
ENV_GATE = 'DP_GATE_URL'

PING_MOI = 30 * 86400        # giây — thưa thớt, xem khối chú thích ở trên
TIMEOUT = 5                  # giây — ngắn, vì hỏng thì cũng cho chạy

# Trạng thái chỗ ngồi.
OK = 'ok'
TAKEN = 'taken'              # chỗ đã thuộc về một bản cài khác
REVOKED = 'revoked'          # tác giả đã thu hồi
UNKNOWN = 'unknown'          # không hỏi được — CHO CHẠY
NONE = 'none'                # chưa có gì trên đĩa


def gate_url():
    return (os.environ.get(ENV_GATE) or GATE_URL or '').strip().rstrip('/')


def key_id(text):
    """Tên gọi của một mã, để không phải gửi cả mã lên cửa kiểm."""
    raw = (text or '').strip().encode('utf-8')
    return hashlib.sha256(raw).hexdigest()[:16]


# ------------------------------------------------------------------ trên đĩa
def _install_path(store):
    return os.path.join(store, 'install.id')


def _seat_path(store, kid):
    return os.path.join(store, '%s.seat' % kid)


def install_id(store):
    """Chuỗi nhận ra BẢN CÀI này. Sinh một lần rồi giữ nguyên.

    Nằm cạnh mã chứ không nằm trong addon: Blender xoá sạch thư mục addon mỗi
    lần cài đè bản mới, và sinh lại chuỗi này là mất chỗ ngồi — khách cập nhật
    plugin xong bị báo "máy khác đang giữ mã", đúng cái phải tránh nhất.
    """
    p = _install_path(store)
    try:
        with io.open(p, encoding='utf-8') as fh:
            got = fh.read().strip()
        if len(got) == 32 and all(c in '0123456789abcdef' for c in got):
            return got
    except (OSError, ValueError):
        pass
    moi = binascii.hexlify(os.urandom(16)).decode('ascii')
    try:
        os.makedirs(store, exist_ok=True)
        with io.open(p, 'w', encoding='utf-8') as fh:
            fh.write(moi)
    except OSError:
        # Ghi không được thì vẫn trả chuỗi vừa sinh: lần sau sinh chuỗi khác,
        # nên máy này sẽ không giữ nổi chỗ ngồi. Thà thế còn hơn ném lỗi.
        pass
    return moi


def _doc(store, kid):
    try:
        with io.open(_seat_path(store, kid), encoding='utf-8') as fh:
            d = json.load(fh)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def _ghi(store, kid, d):
    try:
        os.makedirs(store, exist_ok=True)
        with io.open(_seat_path(store, kid), 'w', encoding='utf-8') as fh:
            fh.write(json.dumps(d))
        return True
    except OSError:
        return False


def local_state(store, kid):
    """Trạng thái đã lưu. KHÔNG gọi mạng — `gate.check()` gọi hàm này."""
    d = _doc(store, kid)
    if not d:
        return NONE
    st = d.get('state')
    return st if st in (OK, TAKEN, REVOKED) else NONE


def forget(store, kid):
    try:
        os.remove(_seat_path(store, kid))
        return True
    except OSError:
        return False


# -------------------------------------------------------------------- mạng
def _post(url, timeout=TIMEOUT):
    """(dữ_liệu, đã_trả_lời_200). KHÔNG BAO GIỜ ném.

    Hai đường như `dp_hub/catalog.py`: Blender có `requests` trong
    site-packages, nhưng không phải bản nào cũng có, nên lùi về `urllib`.
    """
    try:
        import requests                                     # noqa: PLC0415
        r = requests.post(url, timeout=timeout)
        if r.status_code != 200:
            return None, False
        return r.json(), True
    except ImportError:
        pass
    except Exception:
        return None, False
    try:
        import urllib.request                               # noqa: PLC0415
        req = urllib.request.Request(url, data=b'', method='POST')
        with urllib.request.urlopen(req, timeout=timeout) as fh:
            if fh.getcode() != 200:
                return None, False
            return json.loads(fh.read().decode('utf-8')), True
    except Exception:
        return None, False


def _hoi(duong, kid, install, **thua):
    base = gate_url()
    if not base:
        return None, False
    try:
        import urllib.parse                                 # noqa: PLC0415
        tham = {'k': kid, 'i': install}
        tham.update({k: v for k, v in thua.items() if v})
        url = '%s/%s?%s' % (base, duong, urllib.parse.urlencode(tham))
    except Exception:
        return None, False
    return _post(url)


def _tra_loi(data):
    """Đọc câu trả lời của cửa kiểm thành một trạng thái. Xem luật 1 ở đầu file."""
    if not isinstance(data, dict):
        return UNKNOWN, ''
    if data.get('ok'):
        return OK, str(data.get('nonce') or '')
    ly_do = str(data.get('reason') or '')
    if ly_do == 'SEAT_REVOKED':
        return REVOKED, ''
    if ly_do == 'SEAT_TAKEN':
        return TAKEN, ''
    # `ok:false` với lý do lạ: bản cửa kiểm mới hơn bản addon. KHÔNG chặn —
    # addon cũ không được phép đoán nghĩa một câu nó chưa từng nghe.
    return UNKNOWN, ''


# ------------------------------------------------------------------ đường ra
def claim(store, key_text, machine='', timeout=TIMEOUT):
    """Xin chỗ ngồi cho mã này. Trả (trạng_thái, ngày_máy_đầu_kích_hoạt).

    Gọi lúc khách DÁN MÃ, không gọi lúc vẽ panel.

    `UNKNOWN` nghĩa là cho chạy: hàm này ghi xuống đĩa trạng thái `ok` kèm cờ
    `cho` (còn nợ một lần xin), để `ping_if_due()` xin lại sau.
    """
    kid = key_id(key_text)
    who = install_id(store)
    data, tra_loi = _hoi('activate', kid, who, m=machine)
    if not tra_loi:
        _ghi(store, kid, {'state': OK, 'install': who, 'nonce': '',
                          'at': int(time.time()), 'last': 0, 'cho': 1})
        return UNKNOWN, 0
    st, nonce = _tra_loi(data)
    if st in (TAKEN, REVOKED):
        _ghi(store, kid, {'state': st, 'install': who, 'nonce': '',
                          'at': int(data.get('at') or 0) // 1000,
                          'last': int(time.time()), 'cho': 0})
        return st, int(data.get('at') or 0) // 1000
    _ghi(store, kid, {'state': OK, 'install': who, 'nonce': nonce,
                      'at': int(time.time()), 'last': int(time.time()),
                      'cho': 0 if nonce else 1})
    return OK, 0


def ping_if_due(store, kid, timeout=TIMEOUT):
    """Giữ chỗ, thưa thớt. Trả trạng thái mới, hoặc `UNKNOWN` nếu chưa tới hạn.

    KHÔNG gọi từ `draw()`. Gọi từ operator hoặc timer.
    """
    d = _doc(store, kid)
    if not d:
        return NONE
    if d.get('state') in (TAKEN, REVOKED):
        return d['state']
    tre = int(time.time()) - int(d.get('last') or 0)
    if not d.get('cho') and tre < PING_MOI:
        return UNKNOWN
    who = d.get('install') or install_id(store)

    # Còn nợ một lần xin chỗ (lần dán mã không có mạng) thì xin lại từ đầu,
    # chứ không giữ chỗ — giữ một chỗ chưa bao giờ nhận được là vô nghĩa.
    duong = 'activate' if (d.get('cho') or not d.get('nonce')) else 'seat'
    data, tra_loi = _hoi(duong, kid, who, n=d.get('nonce') or '')
    if not tra_loi:
        return UNKNOWN
    st, nonce = _tra_loi(data)
    if st in (TAKEN, REVOKED):
        d.update({'state': st, 'nonce': '', 'last': int(time.time()), 'cho': 0})
        _ghi(store, kid, d)
        return st
    if st == OK:
        d.update({'state': OK, 'nonce': nonce, 'last': int(time.time()),
                  'cho': 0 if nonce else 1})
        _ghi(store, kid, d)
        return OK
    return UNKNOWN
