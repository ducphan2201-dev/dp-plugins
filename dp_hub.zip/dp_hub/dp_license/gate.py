# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
# -*- coding: utf-8 -*-
"""Cổng kiểm tra mã kích hoạt. Đây là file DUY NHẤT addon cần gọi tới.

CÔNG TẮC DEV / RELEASE
----------------------
`RELEASE_BUILD` dưới đây LUÔN LUÔN là False trong mã nguồn. Script đóng gói
(`tools/build_release.py` của từng addon) ghi True vào BẢN COPY nằm trong file
zip; mã nguồn trên máy tác giả không bị sửa. Nhờ vậy:

  - `deploy_addon.py` chép nguyên source sang Blender -> máy dev nhận False
    -> KHÔNG đọc registry, KHÔNG đọc file, KHÔNG kiểm gì. Sửa và thử nghiệm
    thoải mái, và không tốn một mili-giây nào lúc khởi động.
  - Bản bán ra nhận True -> kiểm mã đầy đủ.

Vì việc bật nằm trong script chứ không phải thao tác tay, không có gì để quên.
Hai chốt tự động canh hai chiều: bản kiểm tra hồi quy báo lỗi nếu SOURCE lỡ
thành True (tránh tự khoá máy mình), còn script đóng gói từ chối tạo zip nếu
bản TRONG ZIP không phải True (tránh bán ra bản không khoá).

VÌ SAO KHÔNG BAO GIỜ NÉM LỖI
----------------------------
Hàm `check()` không được phép làm hỏng lần khởi động của Blender. Mọi hỏng hóc
(thiếu file, mã rách, registry đọc không được) đều trả về một trạng thái CÓ TÊN
để giao diện hiện lời hướng dẫn - chứ không tắt phụt addon. Khách nhìn panel
trống mà không có chữ nào thì sẽ nghĩ addon hỏng, rồi đòi hoàn tiền thay vì đi
gia hạn.
"""
import os
import json
import time
import zlib
import base64

from . import machine_id
from . import rsa_verify

# =============================================================================
# CÔNG TẮC — trong mã nguồn LUÔN là False. Script đóng gói ghi True vào zip.
RELEASE_BUILD = False
# =============================================================================

# Khoá công khai, chép từ tools/keygen.py. Không có gì bí mật: nó chỉ KIỂM được
# chữ ký chứ không KÝ được. Giá trị 0 nghĩa là chưa nhúng khoá.
PUBLIC_N = 20918592401076780572293936118230238104192609911779781253574466418379579598993887426545926979722106258821902849915016518938662725801730961843513168018500144150406029617648821874772680772789228899131398523943980802585067184305776773302378862111366197260733946628687738725832404814334485275782455845061041508673062494720031110730165309781578376714824666437087390233568574602560863815199466743638427798296837025489123666759611005412469040999089884866585628488522545270370329770595479879856659063073137164403447295271358478395542015575718162051602459909796386974796438062684430390211832048885669261775198937518483421144313
PUBLIC_E = 65537

# KHOÁ THỨ HAI — CHỈ KÝ ĐƯỢC MÃ DÙNG THỬ (thêm 13/08/2026)
# ---------------------------------------------------------
# Khoá bí mật của cặp trên NẰM TRÊN MÁY TÁC GIẢ và không bao giờ rời khỏi đó.
# Đó là điều đúng cho mã bán ra, nhưng nó làm bản dùng thử chết: mã thử cũng
# phải chờ đúng cái máy ấy bật lên mới được ký, mà máy ấy tắt phần lớn thời
# gian trong ngày. Khách bấm "Try free" giữa ban ngày thì không có gì xảy ra
# cả — đo được: 18 mã thử đầu tiên đều rơi vào khung 19h–24h.
#
# Nên cửa kiểm tự ký mã thử, bằng MỘT CẶP KHOÁ RIÊNG đặt trên đó. Cặp này bị
# rào chặt ngay tại đây:
#
#   - phải có dấu `t` (mã dùng thử) trong thân mã;
#   - phải CÓ HẠN, và hạn không quá `TRIAL_MAX_DAYS` kể từ lúc ký.
#
# Một mã vĩnh viễn ký bằng khoá thử bị từ chối thẳng ở dòng dưới. Nên kẻ chiếm
# được khoá thử chỉ tự cấp cho nhau được mã ngắn hạn — không chạm được vào một
# đồng doanh thu vĩnh viễn nào, và đổi khoá thử là dập xong, khách đã mua không
# hề hấn vì họ đứng trên khoá kia.
TRIAL_N = 21791408525599385522383045368085710990502239939744531638178500332191808205423363174106986104029420394640834152758390334141794387409552587696752337185640094619061385070831024384500246214750501637142000768947579382467377231257239874563452967910159982093165950561771915496889877532925485309534804535714697275480449630509408703103576121306093459431230598798531208084627899040744755584061332606786960506430473927174762235236704459598971809409163119114505829189255298136947928601747354135103798800351263615559406882143732183630865552175086170800413557301723342437656682341740661941549027126207408608353636031321447227992319
TRIAL_E = 65537
# Rộng hơn hẳn số ngày đang bán (5) là CÓ Ý: một đợt khuyến mãi 14 ngày chỉ
# phải sửa một con số trong sổ đăng ký, không phải phát hành lại addon nào.
# Nhưng vẫn phải có trần — không trần thì `t` là thứ duy nhất chặn, và một dấu
# đơn lẻ thì mỏng quá cho thứ đứng canh cả sản phẩm.
TRIAL_MAX_DAYS = 31

# Trạng thái trả về. Dùng chuỗi có tên thay vì True/False để giao diện nói được
# với khách rằng hỏng ở đâu.
OK = 'ok'
DEV = 'dev'                  # bản dev, không kiểm
NO_KEY = 'no_key'            # chưa kích hoạt bao giờ
BAD_KEY = 'bad_key'          # mã sai định dạng hoặc chữ ký không khớp
WRONG_MACHINE = 'wrong_machine'
EXPIRED = 'expired'
WRONG_PRODUCT = 'wrong_product'
NO_PUBKEY = 'no_pubkey'      # lỗi đóng gói: quên nhúng khoá công khai
SEAT_TAKEN = 'seat_taken'    # mã này đã kích hoạt trên một bản cài khác
SEAT_REVOKED = 'seat_revoked'   # tác giả đã thu hồi chỗ ngồi của mã này

_MESSAGES = {
    OK: 'Activated',
    DEV: 'Developer build - no license check',
    NO_KEY: 'Not activated. Send your machine code to the author.',
    BAD_KEY: 'Invalid key. Check that you copied all of it.',
    WRONG_MACHINE: 'This key was issued for another machine.',
    EXPIRED: 'This activation key has expired.',
    WRONG_PRODUCT: 'This key is not for this product.',
    NO_PUBKEY: 'Packaging error: public key is missing.',
    # KHÔNG nói "mã hỏng": mã không hỏng, nó chỉ đang được dùng ở chỗ khác. Nói
    # sai chỗ hỏng là khách đi đòi mã mới trong khi thứ họ cần là gỡ máy cũ.
    SEAT_TAKEN: ('This key is already activated on another installation. '
                 'One key runs on one machine - contact the author.'),
    SEAT_REVOKED: ('This key was withdrawn by the author. '
                   'Please contact us to sort it out.'),
}


def message(status):
    return _MESSAGES.get(status, status)


# ---------------------------------------------------------------- chỗ lưu mã
def _store_dir():
    """Thư mục lưu mã kích hoạt.

    KHÔNG lưu trong thư mục addon: Blender xoá sạch thư mục đó mỗi lần người
    dùng cài đè bản mới, và khách sẽ mất mã sau mỗi lần cập nhật.
    """
    try:
        import bpy
        p = bpy.utils.user_resource('CONFIG', path='dp_license', create=True)
        if p:
            return p
    except Exception:
        pass    # chạy ngoài Blender (tool kiểm thử) - rơi xuống nhánh dưới
    base = os.environ.get('LOCALAPPDATA') or os.path.expanduser('~')
    p = os.path.join(base, 'DP_License')
    os.makedirs(p, exist_ok=True)
    return p


def key_path(product):
    return os.path.join(_store_dir(), '%s.key' % product)


def save_key(product, text):
    """Ghi mã kích hoạt xuống đĩa. Trả (thành công, lý do).

    ĐÂY LÀ CHỖ DUY NHẤT XIN CHỖ NGỒI, và nó phải nằm ở đây chứ không nằm trong
    DP_Hub: mỗi addon có nút "Paste activation key" riêng (`ui.py`), nên chặn ở
    Hub là dán thẳng trong panel addon đi vòng được.

    Xin chỗ SAU khi chữ ký và máy đã qua — không hỏi cửa kiểm về một chuỗi mà
    chính máy này đã biết là rác.
    """
    text = (text or '').strip()
    st, _ = verify_text(text, product)
    if st != OK:
        return False, st

    # Cửa kiểm nói KHÔNG thì không ghi file mã: ghi rồi mới chặn là khách thấy
    # "đã kích hoạt" ở lần bấm này và "bị từ chối" ở lần mở Blender sau.
    seat_st = _claim_seat(text)
    if seat_st == SEAT_TAKEN:
        return False, SEAT_TAKEN
    if seat_st == SEAT_REVOKED:
        return False, SEAT_REVOKED

    try:
        with open(key_path(product), 'w', encoding='utf-8') as fh:
            fh.write(text)
    except OSError as exc:
        return False, 'khong ghi duoc: %r' % (exc,)
    return True, OK


def load_key(product):
    try:
        with open(key_path(product), encoding='utf-8') as fh:
            return fh.read().strip()
    except OSError:
        return ''


def clear_key(product):
    try:
        os.remove(key_path(product))
        return True
    except OSError:
        return False


# ------------------------------------------------------------------ chỗ ngồi
# Một mã một máy. Tầng này ĐỘC LẬP với `machine_id`: nó bắt được cái mà ba yếu
# tố máy không bắt được — máy ghost từ cùng một image, vốn có ba yếu tố y hệt.
# Toàn bộ phần gọi mạng nằm trong `seat.py` để file này giữ nguyên tính thuần
# khiết: `check()` không chạm mạng, không có gì làm chậm lần vẽ panel.
def _claim_seat(text):
    """Xin chỗ ngồi lúc dán mã. Trả OK / SEAT_TAKEN / SEAT_REVOKED.

    KHÔNG BAO GIỜ NÉM, và không biết thì trả OK — luật fail-open của `seat.py`.
    """
    try:
        from . import seat
        st, _at = seat.claim(_store_dir(), text, machine_id.export())
    except Exception:
        return OK
    if st == seat.TAKEN:
        return SEAT_TAKEN
    if st == seat.REVOKED:
        return SEAT_REVOKED
    return OK


def _seat_state(text):
    """Chỗ ngồi ĐÃ LƯU của mã này. Chỉ đọc đĩa — hàm này chạy trong `draw()`."""
    try:
        from . import seat
        st = seat.local_state(_store_dir(), seat.key_id(text))
    except Exception:
        return OK
    if st == seat.TAKEN:
        return SEAT_TAKEN
    if st == seat.REVOKED:
        return SEAT_REVOKED
    return OK


def ping_seat(product):
    """Giữ chỗ, thưa thớt. GỌI TỪ OPERATOR HOẶC TIMER, không gọi từ `draw()`.

    Trả trạng thái mới nếu vừa đổi, '' nếu không có gì để nói.
    """
    if not RELEASE_BUILD:
        return ''
    text = load_key(product)
    if not text:
        return ''
    try:
        from . import seat
        st = seat.ping_if_due(_store_dir(), seat.key_id(text))
    except Exception:
        return ''
    if st == seat.TAKEN:
        return SEAT_TAKEN
    if st == seat.REVOKED:
        return SEAT_REVOKED
    return ''


# ---------------------------------------------------------------- kiểm mã
def _b64d(s):
    s += '=' * (-len(s) % 4)                       # bù phần đệm đã cắt
    return base64.urlsafe_b64decode(s.encode('ascii'))


def parse(text):
    """Tách mã thành (payload_dict, chữ_ký_bytes, phần_đã_ký_bytes).

    Trả (None, None, None) nếu mã rách. Mọi ngoại lệ đều bị nuốt CÓ CHỦ Ý ở đây:
    đầu vào là chuỗi người dùng dán vào, hỏng kiểu gì cũng phải ra 'mã không
    hợp lệ' chứ không được ném lỗi lên giao diện.
    """
    try:
        body, sig = text.strip().replace('\n', '').replace(' ', '').split('.')
        raw = zlib.decompress(_b64d(body))
        return json.loads(raw.decode('utf-8')), _b64d(sig), body.encode('ascii')
    except Exception:
        return None, None, None


def la_ma_dung_thu(payload):
    """Thân mã này có ĐỦ TƯ CÁCH để được ký bằng khoá thử không.

    Đọc kỹ chiều của câu hỏi: đây KHÔNG phải "mã này có phải mã thử không" —
    thân mã do phía ký soạn, nên nó tự nhận gì cũng được. Đây là hàng rào chặn
    khoá thử ký ra thứ nó không được phép ký. Sai chiều là thành một câu hỏi vô
    nghĩa, và hàng rào biến mất mà không có gì kêu.
    """
    if (payload or {}).get('t') != 1:
        return False
    try:
        ky = int(payload.get('s') or 0)
        han = int(payload.get('x') or 0)
    except (TypeError, ValueError):
        return False
    # `x` = 0 nghĩa là VĨNH VIỄN. Đó đúng là thứ khoá thử không bao giờ được
    # phép ký, nên nó bị chặn ngay ở đây chứ không đợi tới hạn dùng bên dưới.
    if not ky or not han or han <= ky:
        return False
    return han - ky <= TRIAL_MAX_DAYS * 86400


def verify_text(text, product):
    """Kiểm một chuỗi mã BẤT KỲ (chưa cần lưu). Trả (trạng_thái, payload)."""
    if not PUBLIC_N:
        return NO_PUBKEY, None
    if not text:
        return NO_KEY, None
    payload, sig, signed = parse(text)
    if payload is None:
        return BAD_KEY, None
    # 1. Chữ ký trước tiên: chưa tin được một byte nào của payload cho tới khi
    #    biết nó do đúng khoá bí mật ký ra.
    #
    #    HAI KHOÁ, VÀ THỨ TỰ Ở ĐÂY LÀ CÓ Ý: khoá bán hàng trước. Mọi mã khách
    #    trả tiền đều qua ở dòng này và không bao giờ chạm tới nhánh dưới, nên
    #    một ngày nào đó gỡ bản dùng thử đi thì chỉ việc xoá nhánh dưới.
    if not rsa_verify.verify(signed, sig, PUBLIC_N, PUBLIC_E):
        # Khoá thử chỉ được xét khi thân mã đã tự bó mình vào khuôn "dùng thử".
        # Kiểm khuôn TRƯỚC khi kiểm chữ ký để một mã vĩnh viễn giả danh không
        # bao giờ tới được phép so chữ ký với khoá thử.
        if not (TRIAL_N and la_ma_dung_thu(payload)
                and rsa_verify.verify(signed, sig, TRIAL_N, TRIAL_E)):
            return BAD_KEY, None
    # 2. Sản phẩm
    prods = payload.get('p') or []
    if product not in prods:
        return WRONG_PRODUCT, payload
    # 3. Hạn dùng. `x` = 0 nghĩa là vĩnh viễn.
    exp = payload.get('x') or 0
    if exp and time.time() > exp:
        return EXPIRED, payload
    # 4. Máy
    if not machine_id.matches(payload.get('m') or {}):
        return WRONG_MACHINE, payload
    return OK, payload


def check(product):
    """Kiểm mã đã lưu cho `product`. Trả (trạng_thái, payload).

    ĐÂY LÀ HÀM ADDON GỌI. Ở bản dev nó thoát ngay ở dòng đầu, không chạm đĩa
    hay registry.
    """
    if not RELEASE_BUILD:
        return DEV, None
    text = load_key(product)
    st, payload = verify_text(text, product)
    if st != OK:
        return st, payload
    # 5. Chỗ ngồi — CHỈ ĐỌC ĐĨA. Hàm này chạy trong `draw()`, một lần gọi mạng
    #    ở đây là treo giao diện mỗi lần Blender vẽ lại panel.
    seat_st = _seat_state(text)
    if seat_st != OK:
        return seat_st, payload
    return OK, payload


def ok(product):
    """True nếu được phép chạy. Dùng cho chỗ chỉ cần câu trả lời có/không."""
    return check(product)[0] in (OK, DEV)
