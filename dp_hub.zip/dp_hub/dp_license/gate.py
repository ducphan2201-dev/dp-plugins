# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
# -*- coding: utf-8 -*-
"""Cổng kiểm tra mã kích hoạt. Đây là file DUY NHẤT addon cần gọi tới.

CÔNG TẮC DEV / RELEASE
----------------------
`RELEASE_BUILD` dưới đây LUÔN LUÔN là False trong mã nguồn. Script đóng gói
(`tools/build_release.py` của từng addon) ghi True vào BẢN COPY nằm trong file
zip; mã nguồn trên máy tác giả không bị sửa. Nhờ vậy:

  - `deploy_addon.py` chép nguyên source sang Blender -> máy dev nhận False
    -> KHÔNG đọc registry, KHÔNG đọc file, KHÔNG kiểm gì. Sửa và thử nghiệm
    thoải mái, và không tốn một mili-giây nào lúc khởi động.
  - Bản bán ra nhận True -> kiểm mã đầy đủ.

Vì việc bật nằm trong script chứ không phải thao tác tay, không có gì để quên.
Hai chốt tự động canh hai chiều: bản kiểm tra hồi quy báo lỗi nếu SOURCE lỡ
thành True (tránh tự khoá máy mình), còn script đóng gói từ chối tạo zip nếu
bản TRONG ZIP không phải True (tránh bán ra bản không khoá).

VÌ SAO KHÔNG BAO GIỜ NÉM LỖI
----------------------------
Hàm `check()` không được phép làm hỏng lần khởi động của Blender. Mọi hỏng hóc
(thiếu file, mã rách, registry đọc không được) đều trả về một trạng thái CÓ TÊN
để giao diện hiện lời hướng dẫn - chứ không tắt phụt addon. Khách nhìn panel
trống mà không có chữ nào thì sẽ nghĩ addon hỏng, rồi đòi hoàn tiền thay vì đi
gia hạn.
"""
import os
import json
import time
import zlib
import base64

from . import machine_id
from . import rsa_verify

# =============================================================================
# CÔNG TẮC — trong mã nguồn LUÔN là False. Script đóng gói ghi True vào zip.
RELEASE_BUILD = False
# =============================================================================

# Khoá công khai, chép từ tools/keygen.py. Không có gì bí mật: nó chỉ KIỂM được
# chữ ký chứ không KÝ được. Giá trị 0 nghĩa là chưa nhúng khoá.
PUBLIC_N = 20918592401076780572293936118230238104192609911779781253574466418379579598993887426545926979722106258821902849915016518938662725801730961843513168018500144150406029617648821874772680772789228899131398523943980802585067184305776773302378862111366197260733946628687738725832404814334485275782455845061041508673062494720031110730165309781578376714824666437087390233568574602560863815199466743638427798296837025489123666759611005412469040999089884866585628488522545270370329770595479879856659063073137164403447295271358478395542015575718162051602459909796386974796438062684430390211832048885669261775198937518483421144313
PUBLIC_E = 65537

# Trạng thái trả về. Dùng chuỗi có tên thay vì True/False để giao diện nói được
# với khách rằng hỏng ở đâu.
OK = 'ok'
DEV = 'dev'                  # bản dev, không kiểm
NO_KEY = 'no_key'            # chưa kích hoạt bao giờ
BAD_KEY = 'bad_key'          # mã sai định dạng hoặc chữ ký không khớp
WRONG_MACHINE = 'wrong_machine'
EXPIRED = 'expired'
WRONG_PRODUCT = 'wrong_product'
NO_PUBKEY = 'no_pubkey'      # lỗi đóng gói: quên nhúng khoá công khai

_MESSAGES = {
    OK: 'Activated',
    DEV: 'Developer build - no license check',
    NO_KEY: 'Not activated. Send your machine code to the author.',
    BAD_KEY: 'Invalid key. Check that you copied all of it.',
    WRONG_MACHINE: 'This key was issued for another machine.',
    EXPIRED: 'This activation key has expired.',
    WRONG_PRODUCT: 'This key is not for this product.',
    NO_PUBKEY: 'Packaging error: public key is missing.',
}


def message(status):
    return _MESSAGES.get(status, status)


# ---------------------------------------------------------------- chỗ lưu mã
def _store_dir():
    """Thư mục lưu mã kích hoạt.

    KHÔNG lưu trong thư mục addon: Blender xoá sạch thư mục đó mỗi lần người
    dùng cài đè bản mới, và khách sẽ mất mã sau mỗi lần cập nhật.
    """
    try:
        import bpy
        p = bpy.utils.user_resource('CONFIG', path='dp_license', create=True)
        if p:
            return p
    except Exception:
        pass    # chạy ngoài Blender (tool kiểm thử) - rơi xuống nhánh dưới
    base = os.environ.get('LOCALAPPDATA') or os.path.expanduser('~')
    p = os.path.join(base, 'DP_License')
    os.makedirs(p, exist_ok=True)
    return p


def key_path(product):
    return os.path.join(_store_dir(), '%s.key' % product)


def save_key(product, text):
    """Ghi mã kích hoạt xuống đĩa. Trả (thành công, lý do)."""
    text = (text or '').strip()
    st, _ = verify_text(text, product)
    if st != OK:
        return False, st
    try:
        with open(key_path(product), 'w', encoding='utf-8') as fh:
            fh.write(text)
    except OSError as exc:
        return False, 'khong ghi duoc: %r' % (exc,)
    return True, OK


def load_key(product):
    try:
        with open(key_path(product), encoding='utf-8') as fh:
            return fh.read().strip()
    except OSError:
        return ''


def clear_key(product):
    try:
        os.remove(key_path(product))
        return True
    except OSError:
        return False


# ---------------------------------------------------------------- kiểm mã
def _b64d(s):
    s += '=' * (-len(s) % 4)                       # bù phần đệm đã cắt
    return base64.urlsafe_b64decode(s.encode('ascii'))


def parse(text):
    """Tách mã thành (payload_dict, chữ_ký_bytes, phần_đã_ký_bytes).

    Trả (None, None, None) nếu mã rách. Mọi ngoại lệ đều bị nuốt CÓ CHỦ Ý ở đây:
    đầu vào là chuỗi người dùng dán vào, hỏng kiểu gì cũng phải ra 'mã không
    hợp lệ' chứ không được ném lỗi lên giao diện.
    """
    try:
        body, sig = text.strip().replace('\n', '').replace(' ', '').split('.')
        raw = zlib.decompress(_b64d(body))
        return json.loads(raw.decode('utf-8')), _b64d(sig), body.encode('ascii')
    except Exception:
        return None, None, None


def verify_text(text, product):
    """Kiểm một chuỗi mã BẤT KỲ (chưa cần lưu). Trả (trạng_thái, payload)."""
    if not PUBLIC_N:
        return NO_PUBKEY, None
    if not text:
        return NO_KEY, None
    payload, sig, signed = parse(text)
    if payload is None:
        return BAD_KEY, None
    # 1. Chữ ký trước tiên: chưa tin được một byte nào của payload cho tới khi
    #    biết nó do đúng khoá bí mật ký ra.
    if not rsa_verify.verify(signed, sig, PUBLIC_N, PUBLIC_E):
        return BAD_KEY, None
    # 2. Sản phẩm
    prods = payload.get('p') or []
    if product not in prods:
        return WRONG_PRODUCT, payload
    # 3. Hạn dùng. `x` = 0 nghĩa là vĩnh viễn.
    exp = payload.get('x') or 0
    if exp and time.time() > exp:
        return EXPIRED, payload
    # 4. Máy
    if not machine_id.matches(payload.get('m') or {}):
        return WRONG_MACHINE, payload
    return OK, payload


def check(product):
    """Kiểm mã đã lưu cho `product`. Trả (trạng_thái, payload).

    ĐÂY LÀ HÀM ADDON GỌI. Ở bản dev nó thoát ngay ở dòng đầu, không chạm đĩa
    hay registry.
    """
    if not RELEASE_BUILD:
        return DEV, None
    return verify_text(load_key(product), product)


def ok(product):
    """True nếu được phép chạy. Dùng cho chỗ chỉ cần câu trả lời có/không."""
    return check(product)[0] in (OK, DEV)
