# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
# -*- coding: utf-8 -*-
r"""Số định danh máy — dùng để buộc mã kích hoạt vào đúng một máy.

BA YẾU TỐ, VÀ MỖI HỆ ĐIỀU HÀNH LẤY CHÚNG TỪ CHỖ KHÁC NHAU
---------------------------------------------------------
Vai trò của ba yếu tố là như nhau ở mọi nền, chỉ nguồn lấy là khác:

  yếu tố | vai trò                      | Windows        | macOS            | Linux
  -------|------------------------------|----------------|------------------|----------------
  guid   | định danh của BẢN CÀI HĐH    | MachineGuid    | IOPlatformUUID   | /etc/machine-id
  vol    | định danh của Ổ / MÁY        | số hiệu ổ hệ   | serial máy (ioreg)| UUID phân vùng gốc
  host   | tên máy                      | platform.node  | platform.node    | platform.node

Nguồn chính trên Windows: `HKLM\SOFTWARE\Microsoft\Cryptography\MachineGuid` —
Windows sinh ra lúc cài đặt và giữ nguyên suốt vòng đời bản cài. Thay RAM, thay
card đồ hoạ, thêm ổ cứng đều KHÔNG làm nó đổi. Cài lại Windows thì đổi, và đó là
hành vi đúng: coi như máy mới.

MỘT KHÁC BIỆT CỐ Ý GIỮA CÁC NỀN, ĐỪNG "SỬA" NÓ
-----------------------------------------------
Trên macOS, `IOPlatformUUID` gắn với PHẦN CỨNG chứ không gắn với bản cài, nên
khách cài lại macOS thì mã cũ VẪN chạy. Trên Windows thì cài lại là mất. Đây là
ưu ái cho khách chứ không phải lỗ hổng: mã vẫn buộc vào đúng một máy, và máy
khác vẫn bị chặn. Cố ép hai nền giống nhau chỉ làm khách Mac mất mã oan.

VÌ SAO NHÁNH WINDOWS KHÔNG ĐƯỢC ĐỘNG VÀO MỘT KÝ TỰ
---------------------------------------------------
Mọi mã đã cấp cho khách Windows đều mang ba chuỗi băm sinh ra từ đúng đoạn mã
dưới đây. Đổi cách lấy, đổi thứ tự, đổi cả cách viết hoa/thường của giá trị thô
là ba chuỗi băm đổi theo — và MỌI KHÁCH ĐANG DÙNG mất mã cùng lúc, im lặng, chỉ
lộ ra khi họ mở Blender. Phần thêm cho macOS/Linux nằm ở nhánh khác, và bài kiểm
`selftest_machine_id.py` canh đúng chuyện đó.

BA NGUỒN ĐÃ LOẠI, vì chúng chặn nhầm KHÁCH THẬT:
  - Địa chỉ MAC: VPN, Docker, Hyper-V, USB-LAN, Wi-Fi rời đều tạo card mạng ảo.
    Danh sách MAC đổi mỗi lần khách bật VPN -> mã kích hoạt "tự nhiên hỏng".
    Đây là lỗi phổ biến nhất trong các hệ thống bản quyền tự làm.
  - Serial ổ cứng: thay ổ hoặc dựng lại RAID là mất bản quyền.
  - Tên máy: đổi trong năm giây, không chặn được ai.

CHỊU ĐƯỢC NÂNG CẤP PHẦN CỨNG
----------------------------
Lấy ba yếu tố, khớp HAI trên ba là chấp nhận. Nhờ vậy một yếu tố đổi (ví dụ
khách format lại ổ C nhưng giữ bản Windows, hoặc đổi tên máy) thì mã vẫn chạy,
còn máy khác hoàn toàn thì cả ba đều lệch nên vẫn bị chặn.

RIÊNG TƯ
--------
Không gửi đi số thô. Mỗi yếu tố được băm SHA-256 kèm một chuỗi muối cố định,
nên thứ khách gửi cho tác giả không tiết lộ tên máy hay số hiệu ổ đĩa.
"""
import os
import sys
import hashlib
import platform

# Muối cố định: để hai sản phẩm khác nhau không ra cùng một chuỗi băm từ cùng
# một máy, và để chuỗi băm ở đây không trùng với chuỗi băm của hệ thống khác.
_SALT = b'DP_License/2026/machine'


def _sha(value: str) -> str:
    if not value:
        return ''
    return hashlib.sha256(_SALT + value.strip().lower().encode('utf-8')).hexdigest()[:16]


def _chay(cmd) -> str:
    """Chạy một lệnh hệ thống, trả chữ nó in ra. '' nếu hỏng bất cứ kiểu gì.

    KHÔNG BAO GIỜ NÉM. Module này chạy rất sớm — trước khi addon dựng được chỗ
    ghi nhật ký — nên một ngoại lệ ở đây làm addon chết lúc bật, và lời báo lỗi
    đọc lên không liên quan gì tới bản quyền. Yếu tố thiếu chỉ làm giảm số yếu
    tố khớp, không gây lỗi.

    Có hạn giờ: `ioreg`/`diskutil` trên máy đang bận có thể treo, và treo ở đây
    là treo cả lúc mở Blender.
    """
    try:
        import subprocess
        r = subprocess.run(cmd, capture_output=True, timeout=5)
        if r.returncode != 0:
            return ''
        return (r.stdout or b'').decode('utf-8', 'replace')
    except Exception:
        return ''


def _doc_file(path: str) -> str:
    """Nội dung một file văn bản nhỏ. '' nếu không đọc được."""
    try:
        with open(path, 'rb') as fh:
            return fh.read(4096).decode('utf-8', 'replace').strip()
    except Exception:
        return ''


def _ioreg(khoa: str) -> str:
    """Một trường trong bảng phần cứng của macOS. '' nếu không có.

    Một lần gọi `ioreg` trả cả `IOPlatformUUID` lẫn `IOPlatformSerialNumber`,
    nên hai yếu tố của macOS chỉ tốn một lần gọi nếu người gọi biết dùng lại —
    xem `factors()`.
    """
    return _tach_ioreg(_chay(['ioreg', '-rd1', '-c', 'IOPlatformExpertDevice']),
                       khoa)


def _tach_ioreg(chu: str, khoa: str) -> str:
    """Bóc `"<khoa>" = "<gia tri>"` ra khỏi chữ `ioreg` in ra. Tách riêng khỏi
    `_ioreg` để bài kiểm chạy được trên máy Windows, không cần máy Mac."""
    if not chu:
        return ''
    import re
    m = re.search(r'"%s"\s*=\s*"([^"]+)"' % re.escape(khoa), chu)
    return m.group(1) if m else ''


def _uuid_phan_vung_goc() -> str:
    """UUID của phân vùng chứa thư mục gốc trên Linux. '' nếu không tìm ra.

    Đi bằng THUẦN PYTHON, không gọi lệnh ngoài: `/dev/disk/by-uuid/` là một
    thư mục toàn liên kết trỏ tới thiết bị, nên chỉ cần so số hiệu thiết bị của
    `/` với số hiệu thiết bị mà mỗi liên kết trỏ tới. Không cần quyền quản trị,
    không phụ thuộc `blkid`/`lsblk` có được cài hay không.
    """
    try:
        goc = os.stat('/').st_dev
        thu_muc = '/dev/disk/by-uuid'
        for ten in sorted(os.listdir(thu_muc)):
            try:
                if os.stat(os.path.join(thu_muc, ten)).st_rdev == goc:
                    return ten
            except OSError:
                continue
    except Exception:
        return ''
    return ''


def _machine_guid() -> str:
    """Định danh BẢN CÀI hệ điều hành. '' nếu không đọc được.

    Windows: MachineGuid · macOS: IOPlatformUUID · Linux: /etc/machine-id.
    """
    if os.name != 'nt':
        if sys.platform == 'darwin':
            return _ioreg('IOPlatformUUID')
        if sys.platform.startswith('linux'):
            # `/etc/machine-id` là đường chuẩn của systemd; bản không systemd
            # thì thứ tương đương nằm ở chỗ của dbus.
            return (_doc_file('/etc/machine-id')
                    or _doc_file('/var/lib/dbus/machine-id'))
        return ''
    try:
        import winreg
    except ImportError:
        return ''
    try:
        # KEY_WOW64_64KEY: bảo đảm đọc nhánh 64-bit kể cả khi tiến trình là
        # 32-bit. Thiếu cờ này thì trên vài máy sẽ đọc trúng nhánh WOW6432Node
        # và ra một giá trị khác -> mã kích hoạt hết hiệu lực không rõ lý do.
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                            r'SOFTWARE\Microsoft\Cryptography', 0,
                            winreg.KEY_READ | winreg.KEY_WOW64_64KEY) as k:
            return str(winreg.QueryValueEx(k, 'MachineGuid')[0])
    except OSError:
        return ''


def _volume_serial() -> str:
    """Số hiệu ổ chứa hệ điều hành. '' nếu không đọc được.

    Windows: số hiệu ổ hệ · macOS: serial của máy (cùng bảng phần cứng với
    yếu tố trên, nên không tốn thêm một lần gọi nếu đi qua `factors()`) ·
    Linux: UUID phân vùng gốc.
    """
    if os.name != 'nt':
        if sys.platform == 'darwin':
            return _ioreg('IOPlatformSerialNumber')
        if sys.platform.startswith('linux'):
            return _uuid_phan_vung_goc()
        return ''
    try:
        import ctypes
        root = (os.environ.get('SystemDrive') or 'C:') + '\\'
        serial = ctypes.c_ulong(0)
        ok = ctypes.windll.kernel32.GetVolumeInformationW(
            ctypes.c_wchar_p(root), None, 0, ctypes.byref(serial),
            None, None, None, 0)
        return '%08X' % serial.value if ok else ''
    except Exception:
        # Không ghi log ở đây: module này chạy rất sớm, trước khi addon dựng
        # được logger. Yếu tố thiếu chỉ làm giảm số yếu tố khớp, không gây lỗi.
        return ''


def factors() -> dict:
    """Ba yếu tố đã băm. Giá trị '' nghĩa là máy này không đọc được yếu tố đó."""
    if sys.platform == 'darwin':
        # MỘT lần gọi cho cả hai yếu tố. Gọi `ioreg` hai lần thì tốn gấp đôi
        # thời gian ở đúng lúc Blender đang mở, và nhân đôi khả năng vấp hạn
        # giờ trên máy đang bận.
        chu = _chay(['ioreg', '-rd1', '-c', 'IOPlatformExpertDevice'])
        return {
            'guid': _sha(_tach_ioreg(chu, 'IOPlatformUUID')),
            'vol': _sha(_tach_ioreg(chu, 'IOPlatformSerialNumber')),
            'host': _sha(platform.node()),
        }
    return {
        'guid': _sha(_machine_guid()),
        'vol': _sha(_volume_serial()),
        'host': _sha(platform.node()),
    }


def he_dieu_hanh() -> str:
    """Nền của máy này, gọn về ba chữ: 'windows' · 'macos' · 'linux' · 'khac'.

    Dùng chung một chỗ cho: chọn phần máy trong gói cài, và cho bảng DP_Hub nói
    đúng tên nền khi báo cho khách. Hai chỗ đó đoán riêng thì có ngày lệch nhau.
    """
    if os.name == 'nt':
        return 'windows'
    if sys.platform == 'darwin':
        return 'macos'
    if sys.platform.startswith('linux'):
        return 'linux'
    return 'khac'


def thieu_yeu_to() -> int:
    """Số yếu tố máy này KHÔNG đọc được (0 là đủ cả ba).

    Có hàm riêng vì đây là câu hỏi hay bị trả lời sai bằng cách khác: cửa kiểm
    đòi ít nhất hai yếu tố, nên một máy chỉ đọc được một yếu tố sẽ bị từ chối
    với lý do đọc lên giống hệt "trục trặc tạm thời, thử lại lát nữa" — trong
    khi thật ra là điều kiện không bao giờ đạt được. Chỗ nào định in câu "thử
    lại" thì hỏi hàm này trước.
    """
    return sum(1 for v in factors().values() if not v)


def fingerprint() -> str:
    """Chuỗi NGẮN để khách đọc/copy gửi cho tác giả.

    Dạng `AAAA-BBBB-CCCC-DDDD` cho dễ đọc qua điện thoại và dễ nhìn ra khi khách
    gõ thiếu ký tự. Nó là bản rút gọn của ba yếu tố, KHÔNG dùng để so khớp -
    việc so khớp dùng `factors()` đầy đủ trong mã kích hoạt.
    """
    f = factors()
    raw = hashlib.sha256(
        (f['guid'] + '|' + f['vol'] + '|' + f['host']).encode()).hexdigest()
    s = raw[:16].upper()
    return '-'.join(s[i:i + 4] for i in range(0, 16, 4))


def export() -> str:
    """Chuỗi ba yếu tố đã gói, để khách copy một lần gửi cho tác giả.

    Panel hiện chuỗi này kèm nút copy. Nó KHÔNG phải mã kích hoạt và không có
    gì bí mật — chỉ là ba chuỗi băm. Tác giả dán vào `tools/make_key.py --factors`.

    Dùng chuỗi này làm đường CHÍNH thay vì bắt khách đọc `fingerprint()` qua
    điện thoại: chỉ khi có đủ ba yếu tố thì luật "khớp hai trên ba" mới chạy
    được, tức khách nâng cấp máy không bị mất bản quyền.
    """
    import base64 as _b64
    import json as _json
    raw = _json.dumps(factors(), separators=(',', ':'), sort_keys=True).encode()
    return _b64.urlsafe_b64encode(raw).decode('ascii').rstrip('=')


def matches(issued: dict, min_hits: int = 2) -> bool:
    """True nếu máy hiện tại khớp bộ yếu tố `issued` đã cấp.

    Khớp HAI trên ba là đủ -> chịu được một lần nâng cấp/đổi tên máy. Chỉ đếm
    những yếu tố mà CẢ HAI BÊN đều đọc được; yếu tố rỗng không tính là khớp,
    nếu không thì một máy đọc hỏng cả ba sẽ khớp với mọi giấy phép.
    """
    if not isinstance(issued, dict):
        return False
    now = factors()
    hits = sum(1 for k in ('guid', 'vol', 'host')
               if issued.get(k) and now.get(k) and issued[k] == now[k])
    return hits >= min_hits
