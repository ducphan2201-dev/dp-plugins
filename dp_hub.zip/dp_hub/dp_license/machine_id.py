# -*- coding: utf-8 -*-
r"""Số định danh máy — dùng để buộc mã kích hoạt vào đúng một máy.

CHỌN NGUỒN NÀO, VÀ VÌ SAO KHÔNG CHỌN CÁC NGUỒN KHÁC
---------------------------------------------------
Nguồn chính: `HKLM\SOFTWARE\Microsoft\Cryptography\MachineGuid` — Windows sinh
ra lúc cài đặt và giữ nguyên suốt vòng đời bản cài. Thay RAM, thay card đồ hoạ,
thêm ổ cứng đều KHÔNG làm nó đổi. Cài lại Windows thì đổi, và đó là hành vi
đúng: coi như máy mới.

BA NGUỒN ĐÃ LOẠI, vì chúng chặn nhầm KHÁCH THẬT:
  - Địa chỉ MAC: VPN, Docker, Hyper-V, USB-LAN, Wi-Fi rời đều tạo card mạng ảo.
    Danh sách MAC đổi mỗi lần khách bật VPN -> mã kích hoạt "tự nhiên hỏng".
    Đây là lỗi phổ biến nhất trong các hệ thống bản quyền tự làm.
  - Serial ổ cứng: thay ổ hoặc dựng lại RAID là mất bản quyền.
  - Tên máy: đổi trong năm giây, không chặn được ai.

CHỊU ĐƯỢC NÂNG CẤP PHẦN CỨNG
----------------------------
Lấy ba yếu tố, khớp HAI trên ba là chấp nhận. Nhờ vậy một yếu tố đổi (ví dụ
khách format lại ổ C nhưng giữ bản Windows, hoặc đổi tên máy) thì mã vẫn chạy,
còn máy khác hoàn toàn thì cả ba đều lệch nên vẫn bị chặn.

RIÊNG TƯ
--------
Không gửi đi số thô. Mỗi yếu tố được băm SHA-256 kèm một chuỗi muối cố định,
nên thứ khách gửi cho tác giả không tiết lộ tên máy hay số hiệu ổ đĩa.
"""
import os
import hashlib
import platform

# Muối cố định: để hai sản phẩm khác nhau không ra cùng một chuỗi băm từ cùng
# một máy, và để chuỗi băm ở đây không trùng với chuỗi băm của hệ thống khác.
_SALT = b'DP_License/2026/machine'


def _sha(value: str) -> str:
    if not value:
        return ''
    return hashlib.sha256(_SALT + value.strip().lower().encode('utf-8')).hexdigest()[:16]


def _machine_guid() -> str:
    """MachineGuid của Windows. '' nếu không đọc được."""
    if os.name != 'nt':
        return ''
    try:
        import winreg
    except ImportError:
        return ''
    try:
        # KEY_WOW64_64KEY: bảo đảm đọc nhánh 64-bit kể cả khi tiến trình là
        # 32-bit. Thiếu cờ này thì trên vài máy sẽ đọc trúng nhánh WOW6432Node
        # và ra một giá trị khác -> mã kích hoạt hết hiệu lực không rõ lý do.
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                            r'SOFTWARE\Microsoft\Cryptography', 0,
                            winreg.KEY_READ | winreg.KEY_WOW64_64KEY) as k:
            return str(winreg.QueryValueEx(k, 'MachineGuid')[0])
    except OSError:
        return ''


def _volume_serial() -> str:
    """Số hiệu ổ đĩa chứa Windows. '' nếu không đọc được."""
    if os.name != 'nt':
        return ''
    try:
        import ctypes
        root = (os.environ.get('SystemDrive') or 'C:') + '\\'
        serial = ctypes.c_ulong(0)
        ok = ctypes.windll.kernel32.GetVolumeInformationW(
            ctypes.c_wchar_p(root), None, 0, ctypes.byref(serial),
            None, None, None, 0)
        return '%08X' % serial.value if ok else ''
    except Exception:
        # Không ghi log ở đây: module này chạy rất sớm, trước khi addon dựng
        # được logger. Yếu tố thiếu chỉ làm giảm số yếu tố khớp, không gây lỗi.
        return ''


def factors() -> dict:
    """Ba yếu tố đã băm. Giá trị '' nghĩa là máy này không đọc được yếu tố đó."""
    return {
        'guid': _sha(_machine_guid()),
        'vol': _sha(_volume_serial()),
        'host': _sha(platform.node()),
    }


def fingerprint() -> str:
    """Chuỗi NGẮN để khách đọc/copy gửi cho tác giả.

    Dạng `AAAA-BBBB-CCCC-DDDD` cho dễ đọc qua điện thoại và dễ nhìn ra khi khách
    gõ thiếu ký tự. Nó là bản rút gọn của ba yếu tố, KHÔNG dùng để so khớp -
    việc so khớp dùng `factors()` đầy đủ trong mã kích hoạt.
    """
    f = factors()
    raw = hashlib.sha256(
        (f['guid'] + '|' + f['vol'] + '|' + f['host']).encode()).hexdigest()
    s = raw[:16].upper()
    return '-'.join(s[i:i + 4] for i in range(0, 16, 4))


def export() -> str:
    """Chuỗi ba yếu tố đã gói, để khách copy một lần gửi cho tác giả.

    Panel hiện chuỗi này kèm nút copy. Nó KHÔNG phải mã kích hoạt và không có
    gì bí mật — chỉ là ba chuỗi băm. Tác giả dán vào `tools/make_key.py --factors`.

    Dùng chuỗi này làm đường CHÍNH thay vì bắt khách đọc `fingerprint()` qua
    điện thoại: chỉ khi có đủ ba yếu tố thì luật "khớp hai trên ba" mới chạy
    được, tức khách nâng cấp máy không bị mất bản quyền.
    """
    import base64 as _b64
    import json as _json
    raw = _json.dumps(factors(), separators=(',', ':'), sort_keys=True).encode()
    return _b64.urlsafe_b64encode(raw).decode('ascii').rstrip('=')


def matches(issued: dict, min_hits: int = 2) -> bool:
    """True nếu máy hiện tại khớp bộ yếu tố `issued` đã cấp.

    Khớp HAI trên ba là đủ -> chịu được một lần nâng cấp/đổi tên máy. Chỉ đếm
    những yếu tố mà CẢ HAI BÊN đều đọc được; yếu tố rỗng không tính là khớp,
    nếu không thì một máy đọc hỏng cả ba sẽ khớp với mọi giấy phép.
    """
    if not isinstance(issued, dict):
        return False
    now = factors()
    hits = sum(1 for k in ('guid', 'vol', 'host')
               if issued.get(k) and now.get(k) and issued[k] == now[k])
    return hits >= min_hits
