# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
"""Nut bam cua DP_RAMchill.

⛔ TIEN TO `dpramchill.` TREN `bl_idname`, KHONG DUOC RUT NGAN. Hai addon
dat trung mot `bl_idname` thi cai bat sau DE LEN cai truoc trong im lang,
va bo kiem nao goi thang vao ham python se khong bao gio bat duoc. Nha DP
da tra gia chuyen do voi khach that.

BA NUT, VA CA BA DEU KHONG DUNG TOI SCENE:
  * `quet`       — do va bao cao. Khong doi mot pixel nao.
  * `moc_tu_scene` — DO khoang cach that trong scene roi dat bon moc. Do,
                     khong doan. Xem ghi chu trong `props.py`.
  * `tra_lai`    — cai chot tay, cho truong hop Blender chet giua render
                   va map ket lai o co nho.
"""

import bpy
from bpy.types import Operator

from . import chinh_sach
from . import do_canh
from . import doi_co


def _dong_bao_cao(ket_qua, ghi_chu, che_do):
    truoc, sau, doi = chinh_sach.tong_ket(ket_qua)
    d = ["%d/%d maps shrink" % (doi, len(ket_qua)),
         "%s  ->  %s" % (chinh_sach.doc_byte(truoc),
                         chinh_sach.doc_byte(sau))]
    if truoc > 0:
        d.append("saves %s (%.0f%%)" % (
            chinh_sach.doc_byte(truoc - sau),
            100.0 * (truoc - sau) / truoc))

    # ⛔ MOI CHO PHEP DO PHAI BO QUA DEU PHAI NOI RA. Nuot lang la bang doc
    # len thanh "da xet het", trong khi no vua bo qua 40 tam.
    if ghi_chu.get("khong_co_camera"):
        d.append("! no camera - nothing measured")
    for khoa, chu in (("an_viewport_hien_render",
                       "! %d objects hidden in viewport but rendered - "
                       "their maps kept"),
                      ("anh_ngoai_khung",
                       "! %d maps only off-screen - kept (mirrors)"),
                      ("anh_khong_tren_mat",
                       "! %d maps on no surface - kept (world, unused)")):
        if ghi_chu.get(khoa):
            d.append(chu % ghi_chu[khoa])
    if che_do == chinh_sach.CHE_DO_TU_DONG:
        d.append("%d objects / %s tris scanned" % (
            ghi_chu.get("vat_the_da_quet", 0),
            format(ghi_chu.get("tam_giac", 0), ",d")))
    return "\n".join(d)


class DPRAMCHILL_OT_quet(Operator):
    bl_idname = "dpramchill.quet"
    bl_label = "Scan Scene"
    bl_description = ("Measure the scene and report what render would use. "
                      "Changes nothing.\n"
                      "Do scene va bao cao render se dung bao nhieu. Khong "
                      "doi gi ca")
    bl_options = {"REGISTER"}

    def execute(self, context):
        p = context.scene.dp_ramchill
        try:
            ket_qua, ghi_chu = doi_co.lap_ke_hoach(context)
        except Exception as e:                    # noqa: BLE001
            p.bao_cao = "scan failed: %s" % e
            self.report({"ERROR"}, "DP_RAMchill: %s" % e)
            return {"CANCELLED"}
        p.bao_cao = _dong_bao_cao(ket_qua, ghi_chu, p.che_do)
        truoc, sau, doi = chinh_sach.tong_ket(ket_qua)
        self.report({"INFO"}, "DP_RAMchill: %d maps, %s -> %s" % (
            doi, chinh_sach.doc_byte(truoc), chinh_sach.doc_byte(sau)))
        return {"FINISHED"}


class DPRAMCHILL_OT_moc_tu_scene(Operator):
    bl_idname = "dpramchill.moc_tu_scene"
    bl_label = "Fit Rings To Scene"
    bl_description = ("Measure how far the textured surfaces actually are "
                      "and place the four rings on that spread. Works in "
                      "whatever unit the file uses.\n"
                      "Do xem cac mat co map thuc su nam xa bao nhieu roi "
                      "dat bon moc theo do. Dung duoc voi moi don vi")
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        p = context.scene.dp_ramchill
        try:
            anh, ghi_chu = do_canh.quet_scene(context)
        except Exception as e:                    # noqa: BLE001
            self.report({"ERROR"}, "DP_RAMchill: %s" % e)
            return {"CANCELLED"}
        kc = sorted(a["khoang_cach"] for a in anh
                    if a.get("khoang_cach") is not None)
        if len(kc) < 2:
            self.report({"WARNING"},
                        "DP_RAMchill: not enough measured surfaces "
                        "(%d) - rings unchanged" % len(kc))
            return {"CANCELLED"}
        # Bon moc o phan vi 20/40/60/80 cua chinh cac khoang cach do duoc.
        # Khong phai con so "gu": no la phan bo THAT cua scene nay.
        moc = [kc[min(len(kc) - 1, int(len(kc) * q))]
               for q in (0.2, 0.4, 0.6, 0.8)]
        for i in range(1, 4):
            if moc[i] <= moc[i - 1]:
                moc[i] = moc[i - 1] * 1.5 + 1e-4
        p.moc_1, p.moc_2, p.moc_3, p.moc_4 = moc
        self.report({"INFO"}, "DP_RAMchill: rings fitted on %d surfaces "
                              "(%.3f .. %.3f)" % (len(kc), kc[0], kc[-1]))
        return {"FINISHED"}


class DPRAMCHILL_OT_tra_lai(Operator):
    bl_idname = "dpramchill.tra_lai"
    bl_label = "Restore Full Size"
    bl_description = ("Reload every map from disk at full size. Only needed "
                      "if a render was interrupted hard.\n"
                      "Nap lai moi map tu dia o co goc. Chi can toi khi mot "
                      "lan render bi dut giua chung")
    bl_options = {"REGISTER"}

    def execute(self, context):
        doi_co.tra_lai()
        self.report({"INFO"}, "DP_RAMchill: maps restored")
        return {"FINISHED"}


_LOP = (DPRAMCHILL_OT_quet, DPRAMCHILL_OT_moc_tu_scene,
        DPRAMCHILL_OT_tra_lai)


def dang_ky():
    for c in _LOP:
        bpy.utils.register_class(c)


def go():
    for c in reversed(_LOP):
        bpy.utils.unregister_class(c)
