# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
#
# DP_RAMchill — shrink texture maps at render time to save VRAM.
# Copyright (C) 2026  Ducphan
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; version 2 of the License.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
"""DP_RAMchill — ha co map NGAY LUC RENDER de tiet kiem VRAM.

Legacy Add-on (bl_info), KHONG dung blender_manifest.toml — giong ca bay
addon dang ban cua nha DP.

BAN DO CAC LOP, doc theo thu tu nay:

    chinh_sach.py  hai dieu kien -> mot bac -> mot co dich. KHONG import bpy
    do_canh.py     quet scene: khoang cach + dien tich tren khung hinh
    doi_co.py      handler render: ha co truoc, tra lai sau
    props.py       o nhap      ops.py     nut bam      ui_panel.py   bang

LUAT PHAN TANG, DUNG PHA: `chinh_sach.py` KHONG duoc biet Blender ton tai.
Nho vay toan bo phep quyet dinh — nam bac, hai dieu kien, phep khoa chung
— kiem duoc trong MOT GIAY bang python tran, thay vi 20-30 giay moi lan mo
Blender. Co phep do canh dung luat nay (`tools/do_chinh_sach.py`).

⛔ VA LUAT LON NHAT CUA CA ADDON: SCENE KHONG DUOC DOI MOT PIXEL NAO. Map
chi nho di trong khoang thoi gian Cycles dang nap anh len thiet bi, roi
tra lai ngay. File anh tren dia khong bi ghi. `.blend` khong bi ghi. Bam
`Scan Scene` cung khong doi gi — no chi do va bao cao.
"""

__author__ = "Ducphan"
__version__ = "0.1.0"
__date__ = "22 Aug 2026"

bl_info = {
    # Tien to DP_ de addon hien ra khi loc "DP" trong Preferences > Add-ons
    "name": "DP_RAMchill",
    "author": "Ducphan",
    "version": (0, 1, 0),
    "blender": (4, 2, 0),
    "location": "View3D > Sidebar (N) > DP_RAMchill",
    "description": "Shrink texture maps at render time to save VRAM - by "
                   "distance to camera and screen area, or forced to one size",
    "category": "Render",
}

if "bpy" in locals():                    # nap lai khi cai de len ban cu
    import importlib
    for _ten in ("chinh_sach", "do_canh", "doi_co", "props", "ops",
                 "ui_panel"):
        if _ten in locals():
            importlib.reload(locals()[_ten])

import bpy                                                          # noqa: E402

from . import chinh_sach                                            # noqa: E402,F401
from . import do_canh                                               # noqa: E402,F401
from . import doi_co                                                # noqa: E402
from . import ops                                                   # noqa: E402
from . import props                                                 # noqa: E402
from . import ui_panel                                              # noqa: E402


def register():
    props.dang_ky()
    ops.dang_ky()
    ui_panel.dang_ky()
    doi_co.dang_ky()


def unregister():
    doi_co.go()
    ui_panel.go()
    ops.go()
    props.go()
