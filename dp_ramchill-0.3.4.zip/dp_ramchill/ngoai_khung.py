# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
"""BO VAT NGOAI KHUNG HINH KHI RENDER — o `Leave Out Off-screen Objects`.

Ducphan 13/09/2026 (phien DP_MaxImporter): *"fix luon cho ramchill di"*, sau
khi do xong phep ay cho cay proxy cua DP_MaxImporter. Day cung la loi giai cho
viec ton cua addon nay: "345 MB map nam tren vat ngoai khung, dang giu nguyen
co de phong guong" — vat bi bo thi Cycles KHONG DUNG no, va map chi no dung
thi khong duoc nap len card.

SO DO (Cycles 5.2, CPU, Windows): 9 vat 1,31 trieu mat khac nhau, khung thay
1-2 -> phan Cycles giu 1,93 -> 0,34 GB; anh trong khung chi lech hat nhieu.

CACH LAM: hoi bang hinh hoc (8 goc hop bao ngoai mot mat phang khung camera,
co le) roi TAM `hide_render`, tra lai sau render. KHONG dung o "Camera
Culling" cua Cycles: o do chi chay khi BAT Simplify cua ca canh, ma Simplify
keo theo tran chia nho 6 muc - dung toi cai dat cua nguoi dung.

⛔ BONG (0.3.1, Ducphan 13/09/2026: "neu co anh sang gay bong do ma k render
thi sao?"): vat ngoai khung con phai qua phep hoi bong cua `bong_khung` - voi
TUNG nguon sang (den, vat phat sang, Sky Texture, dom sang cua HDRI) khoi "vat
+ bong cua no" phai nam ngoai khung, va vung gan quanh vat (bong mem cua troi,
anh sang doi) khong cham hinh nao thay duoc - khong thi GIU. `bong_khung.py`
la ban GIONG HET ban trong DP_MaxImporter.

⛔ CAI GIA CON LAI, NOI RA TREN BANG: vat bi bo thi PHAN CHIEU cua no mat.
Nen: TAT SAN (khac DP_MaxImporter bat san cho cay proxy — o day la MOI vat, ke
ca tuong sau lung camera trong mot can phong), va vat GAN camera hon `giu_gan`
thi luon giu.

⛔ BAY LOAI VAT KHONG BAO GIO BO, moi loai la mot cach lam hong anh:
  - khong phai hinh hoc (den, camera, empty...)
  - vat PHAT SANG (Emission) - bo di la mat nguon sang
  - den / troi / vat phat sang chuyen dong: bong doi theo khung hinh -> khong
    bo vat nao
  - bat bong / holdout - bo di la doi ca ban tong hop
  - co modifier Geometry Nodes hoac he hat - no co the rai ban ra TRONG khung
    trong khi hop bao cua chinh no nam ngoai
  - la NGUON cua vat khac (Object Info, hat, collection instance)
  - co hoat hoa / rang buoc (ca cha) - vi tri doi theo khung hinh
  - camera chuyen dong: `render_init` chay MOT lan cho ca doan phim -> khong
    bo vat nao ca
"""

import bpy
import numpy as np
from mathutils import Vector

from . import bong_khung as BK

O_DAU = "dpramchill_an"          # dau: addon dang TAM an vat nay khi render
LE_KHUNG = 0.1                   # le khung hinh - cung mac dinh cua Cycles
LOAI_HINH = {"MESH", "CURVE", "SURFACE", "META", "FONT", "CURVES",
             "POINTCLOUD"}

_BAO_CAO = {"an": 0, "xet": 0, "giu_bong": 0, "ly_do": ""}


def bao_cao_lan_cuoi():
    return dict(_BAO_CAO)


def _nguon_instance():
    nguon = set()
    loi = [0]

    def them(v):
        if isinstance(v, bpy.types.Object):
            nguon.add(v.name)
        elif isinstance(v, bpy.types.Collection):
            nguon.update(o.name for o in v.all_objects)

    for ng in bpy.data.node_groups:
        for nd in getattr(ng, "nodes", ()):
            for s in getattr(nd, "inputs", ()):
                if getattr(s, "type", "") in ("OBJECT", "COLLECTION"):
                    them(getattr(s, "default_value", None))
    for ob in bpy.data.objects:
        if ob.instance_type == "COLLECTION":
            them(ob.instance_collection)
        if ob.parent is not None and ob.parent.instance_type in ("VERTS",
                                                                 "FACES"):
            nguon.add(ob.name)
        for ps in getattr(ob, "particle_systems", ()):
            them(getattr(ps.settings, "instance_object", None))
            them(getattr(ps.settings, "instance_collection", None))
        for m in ob.modifiers:
            if m.type != "NODES" or m.node_group is None:
                continue
            for it in m.node_group.interface.items_tree:
                if (getattr(it, "item_type", "") != "SOCKET"
                        or getattr(it, "in_out", "") != "INPUT"
                        or getattr(it, "socket_type", "") not in
                        ("NodeSocketObject", "NodeSocketCollection")):
                    continue
                try:
                    them(m[it.identifier])
                except Exception as e:                   # noqa: BLE001
                    loi[0] += 1
                    if loi[0] == 1:
                        print("[DP_RAMchill] off-screen: cannot read input "
                              "%r of %r on %r: %s" % (it.name, m.name,
                                                      ob.name, e))
    return nguon


def an_truoc_render(scene):
    """Tam an cac vat ngoai khung, xa, va KHONG co bong nao roi vao khung.
    Tra so vat da an."""
    _BAO_CAO.update(an=0, xet=0, giu_bong=0, ly_do="")
    p = getattr(scene, "dp_ramchill", None)
    if p is None or not p.bo_ngoai_khung:
        return 0
    cam = scene.camera
    if cam is None or cam.type != "CAMERA":
        _BAO_CAO["ly_do"] = "no camera"
        return 0
    if BK.dong(cam) or any(m.camera is not None for m in scene.timeline_markers):
        _BAO_CAO["ly_do"] = "camera moves"
        print("[DP_RAMchill] off-screen: the camera moves -> nothing left out")
        return 0
    K = BK.khung_hinh(scene, cam, LE_KHUNG)
    if K is None:
        _BAO_CAO["ly_do"] = "panoramic camera"
        return 0
    sang, dong_sang = BK.nguon_sang(
        scene, log=lambda s: print("[DP_RAMchill] " + s))
    if sang is None:
        _BAO_CAO["ly_do"] = "%s moves" % dong_sang
        print("[DP_RAMchill] off-screen: %s moves -> its shadows change every "
              "frame, nothing left out" % dong_sang)
        return 0
    nguon = _nguon_instance()
    nho_vl = {}
    giu = max(0.0, float(p.giu_gan))
    vi_tri = cam.matrix_world.translation
    xet, hop_ds, kich, bong = [], [], [], []
    for ob in scene.objects:
        if ob.type not in LOAI_HINH or ob.hide_render:
            continue
        if ob.name in nguon or BK.dong(ob):
            continue
        if getattr(ob, "is_shadow_catcher", False) or getattr(ob, "is_holdout",
                                                              False):
            continue
        if any(m.type in ("NODES", "PARTICLE_SYSTEM") for m in ob.modifiers):
            continue
        if BK.vat_phat_sang(ob, nho_vl):
            continue
        _BAO_CAO["xet"] += 1
        mw = ob.matrix_world
        goc = [mw @ Vector(c) for c in ob.bound_box]
        lo = Vector((min(q.x for q in goc), min(q.y for q in goc),
                     min(q.z for q in goc)))
        hi = Vector((max(q.x for q in goc), max(q.y for q in goc),
                     max(q.z for q in goc)))
        gan = Vector((min(max(vi_tri.x, lo.x), hi.x),
                      min(max(vi_tri.y, lo.y), hi.y),
                      min(max(vi_tri.z, lo.z), hi.z)))
        if (gan - vi_tri).length <= giu:
            continue
        xet.append(ob)
        hop_ds.append([(x, y, z) for x in (lo.x, hi.x) for y in (lo.y, hi.y)
                       for z in (lo.z, hi.z)])
        kich.append(max(hi - lo))
        bong.append(bool(getattr(ob, "visible_shadow", True)))
    an = []
    dem = {}
    if xet:
        G = np.array(hop_ds, np.float64)
        ngoai = np.nonzero(BK.ngoai_khung(K, G))[0]
        nhan, canh = BK.vung_nhan(scene, K)
        giu_b, dem = BK.giu_vi_bong(
            K, G[ngoai], np.array(kich, np.float64)[ngoai],
            np.array(bong, bool)[ngoai], sang, np.array(vi_tri),
            cam.data.clip_end, canh, nhan)
        an = [xet[i] for i in ngoai[~giu_b]]
    for ob in an:
        ob[O_DAU] = 1
        ob.hide_render = True
    _BAO_CAO["an"] = len(an)
    _BAO_CAO["giu_bong"] = sum(dem.values())
    if an or dem:
        print("[DP_RAMchill] off-screen: %d of %d objects left out of this "
              "render; %d kept for shadows or nearby light (%s)"
              % (len(an), _BAO_CAO["xet"], _BAO_CAO["giu_bong"],
                 ", ".join("%d by %s" % (n, t) for t, n in sorted(
                     dem.items(), key=lambda kv: -kv[1])[:4]) or "-"))
    return len(an)


def tra_lai():
    """Tra moi vat addon da tam an. Goi nhieu lan vo hai."""
    n = 0
    for ob in bpy.data.objects:
        if ob.get(O_DAU):
            try:
                ob.hide_render = False
                del ob[O_DAU]
                n += 1
            except Exception as e:                       # noqa: BLE001
                print("[DP_RAMchill] could not show %r again: %s"
                      % (ob.name, e))
    return n


@bpy.app.handlers.persistent
def _truoc_render(scene, *a):
    tra_lai()
    try:
        an_truoc_render(scene)
    except Exception as e:                               # noqa: BLE001
        # ⛔ Hong o day KHONG duoc lam hong lan render: tra lai het, render du.
        tra_lai()
        _BAO_CAO["ly_do"] = "%s: %s" % (type(e).__name__, e)
        print("[DP_RAMchill] off-screen skip failed, rendering everything:",
              _BAO_CAO["ly_do"])


@bpy.app.handlers.persistent
def _sau_render(*a):
    tra_lai()


_CAP = (
    ("render_init", _truoc_render),
    ("render_complete", _sau_render),
    ("render_cancel", _sau_render),
    # luu giua luc render / Blender chet giua chung roi mo lai: tra lai
    ("save_pre", _sau_render),
    ("load_post", _sau_render),
)


def dang_ky():
    for ten, ham in _CAP:
        ds = getattr(bpy.app.handlers, ten)
        if ham not in ds:
            ds.append(ham)


def go():
    tra_lai()
    for ten, ham in _CAP:
        ds = getattr(bpy.app.handlers, ten)
        if ham in ds:
            ds.remove(ham)
