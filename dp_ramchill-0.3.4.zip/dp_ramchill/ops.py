# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
"""Nut bam cua DP_RAMchill.

⛔ TIEN TO `dpramchill.` TREN `bl_idname`, KHONG DUOC RUT NGAN. Hai addon
dat trung mot `bl_idname` thi cai bat sau DE LEN cai truoc trong im lang,
va bo kiem nao goi thang vao ham python se khong bao gio bat duoc. Nha DP
da tra gia chuyen do voi khach that.

BA NUT, VA CA BA DEU KHONG DUNG TOI SCENE:
  * `quet`       — do va bao cao. Khong doi mot pixel nao.
  * `moc_tu_scene` — DO khoang cach that trong scene roi dat bon moc. Do,
                     khong doan. Xem ghi chu trong `props.py`.
  * `tra_lai`    — cai chot tay, cho truong hop Blender chet giua render
                   va map ket lai o co nho.
"""

import bpy
from bpy.types import Operator

from . import chinh_sach
from . import do_canh
from . import doi_co
from . import nuong_map


def _dong_bao_cao(ket_qua, ghi_chu, che_do):
    truoc, sau, doi = chinh_sach.tong_ket(ket_qua)
    d = ["%d/%d maps shrink" % (doi, len(ket_qua)),
         "%s  ->  %s" % (chinh_sach.doc_byte(truoc),
                         chinh_sach.doc_byte(sau))]
    if truoc > 0:
        d.append("saves %s (%.0f%%)" % (
            chinh_sach.doc_byte(truoc - sau),
            100.0 * (truoc - sau) / truoc))

    # ⛔ MOI CHO PHEP DO PHAI BO QUA DEU PHAI NOI RA. Nuot lang la bang doc
    # len thanh "da xet het", trong khi no vua bo qua 40 tam.
    if ghi_chu.get("khong_co_camera"):
        d.append("! no camera - nothing measured")
    for khoa, chu in (("an_viewport_hien_render",
                       "! %d hidden-but-rendered kept"),
                      ("anh_ngoai_khung",
                       "! %d off-screen maps kept"),
                      ("anh_khong_tren_mat",
                       "! %d maps on no surface kept")):
        if ghi_chu.get(khoa):
            d.append(chu % ghi_chu[khoa])
    # Bo dem anh dang bat: noi ra bao nhieu tam de cho no, khong thi dong
    # "0/40 maps shrink" doc len nhu addon hong.
    tx = sum(1 for k in ket_qua if k.get("ly_do") == chinh_sach.LY_DO_TX)
    if tx:
        d.append("%d maps on texture cache" % tx)
    # UDIM / anh tu tao chua pack / anh dang sua: khong co cho nao tra lai
    # nen luon giu nguyen — noi ra, dung de "0/40 maps shrink" doc thanh hong.
    ks = sum(1 for k in ket_qua
             if k.get("ly_do") == chinh_sach.LY_DO_KHONG_SUA)
    if ks:
        d.append("! %d UDIM/generated kept" % ks)
    if che_do == chinh_sach.CHE_DO_TU_DONG:
        d.append("%d objects, %s tris" % (
            ghi_chu.get("vat_the_da_quet", 0),
            format(ghi_chu.get("tam_giac", 0), ",d")))
    return "\n".join(d)


# ⛔ BE RONG THANH BEN LA 420 px, va Blender CAT CUT GIUA CHUNG mot dong
# chu dai hon o do — khong xuong dong, khong bao gi. Anh chup 22/08/2026
# lo ra hai dong bi cat: "! 24 maps onl... kept (mirrors)" va "85 objects /
# 2,415,297 tris scan...". Ca 88 phep do luc do deu xanh: ban ve gia doc
# duoc NOI DUNG mot dong chu chu khong do duoc BE RONG cua no.
#
# So do dem tu chinh anh chup: dong KHONG co icon cat o khoang 34 ky tu,
# dong CO icon (bat dau bang "!") mat them cho nen chi con ~30.
DAI_TOI_DA = 34
DAI_TOI_DA_CO_ICON = 30


def do_dai_dong(dong):
    """Dong bao cao nay co vua be rong bang khong?"""
    han = DAI_TOI_DA_CO_ICON if dong.startswith("!") else DAI_TOI_DA
    return len(dong) <= han


def _ghi_moc_da_do(p, ghi_chu):
    """GHI BON MOC VUA DO NGUOC LAI VAO BON O — moi nut co lap ke hoach.

    ⛔ Khi `moc_tu_dong` bat, bon o do bi lam mo va van hien SO MAC DINH
    (5 / 15 / 30 / 60 m). Trong mot can phong 8 met, bon con so do doc len
    la addon dang tinh sai — Ducphan da bao dung cau do 22/08/2026 khi nhin
    bang. Chung khong tham gia phep tinh nao o che do tu dong, nen ghi de len
    la an toan; va `_dau_van` da co y bo qua chung o che do nay nen viec ghi
    KHONG lam ke hoach vua lap bi vut di.
    ⛔ BAKE CUNG PHAI GHI (14/09/2026): anh chup so tay sau khi bam Bake tren
    PN4 hien 5000 / 15000 / 30000 / 60000 mm trong khi Scan cung canh do ra
    310 / 464 / 619 / 735 mm — chi Scan ghi, Bake thi khong.
    """
    m = ghi_chu.get("moc_da_do")
    if m:
        p.moc_1, p.moc_2, p.moc_3, p.moc_4 = m


class DPRAMCHILL_OT_quet(Operator):
    bl_idname = "dpramchill.quet"
    bl_label = "Scan Scene"
    bl_description = ("Measure the scene and report what render would use. "
                      "Changes nothing.\n"
                      "Do scene va bao cao render se dung bao nhieu. Khong "
                      "doi gi ca")
    bl_options = {"REGISTER"}

    def execute(self, context):
        p = context.scene.dp_ramchill
        try:
            ket_qua, ghi_chu = doi_co.lap_ke_hoach(context)
        except Exception as e:                    # noqa: BLE001
            p.bao_cao = "scan failed: %s" % e
            self.report({"ERROR"}, "DP_RAMchill: %s" % e)
            return {"CANCELLED"}
        _ghi_moc_da_do(p, ghi_chu)
        p.bao_cao = _dong_bao_cao(ket_qua, ghi_chu, p.che_do)
        truoc, sau, doi = chinh_sach.tong_ket(ket_qua)
        self.report({"INFO"}, "DP_RAMchill: %d maps, %s -> %s" % (
            doi, chinh_sach.doc_byte(truoc), chinh_sach.doc_byte(sau)))
        return {"FINISHED"}


class DPRAMCHILL_OT_moc_tu_scene(Operator):
    bl_idname = "dpramchill.moc_tu_scene"
    bl_label = "Fit Rings To Scene"
    bl_description = ("Measure how far the textured surfaces actually are "
                      "and place the four rings on that spread. Works in "
                      "whatever unit the file uses.\n"
                      "Do xem cac mat co map thuc su nam xa bao nhieu roi "
                      "dat bon moc theo do. Dung duoc voi moi don vi")
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        p = context.scene.dp_ramchill
        try:
            anh, ghi_chu = do_canh.quet_scene(context)
        except Exception as e:                    # noqa: BLE001
            self.report({"ERROR"}, "DP_RAMchill: %s" % e)
            return {"CANCELLED"}
        kc = sorted(a["khoang_cach"] for a in anh
                    if a.get("khoang_cach") is not None)
        if len(kc) < 2:
            self.report({"WARNING"},
                        "DP_RAMchill: not enough measured surfaces "
                        "(%d) - rings unchanged" % len(kc))
            return {"CANCELLED"}
        # Bon moc o phan vi 20/40/60/80 cua chinh cac khoang cach do duoc.
        # Khong phai con so "gu": no la phan bo THAT cua scene nay.
        moc = [kc[min(len(kc) - 1, int(len(kc) * q))]
               for q in (0.2, 0.4, 0.6, 0.8)]
        for i in range(1, 4):
            if moc[i] <= moc[i - 1]:
                moc[i] = moc[i - 1] * 1.5 + 1e-4
        p.moc_1, p.moc_2, p.moc_3, p.moc_4 = moc
        self.report({"INFO"}, "DP_RAMchill: rings fitted on %d surfaces "
                              "(%.3f .. %.3f)" % (len(kc), kc[0], kc[-1]))
        return {"FINISHED"}


class DPRAMCHILL_OT_tra_lai(Operator):
    bl_idname = "dpramchill.tra_lai"
    bl_label = "Restore Full Size"
    bl_description = ("Reload every map at full size, from disk or from "
                      "the packed block. Only needed "
                      "if a render was interrupted hard.\n"
                      "Nap lai moi map o co goc, tu dia hoac tu goi "
                      "packed. Chi can toi khi mot "
                      "lan render bi dut giua chung")
    bl_options = {"REGISTER"}

    def execute(self, context):
        doi_co.tra_lai()
        self.report({"INFO"}, "DP_RAMchill: maps restored")
        return {"FINISHED"}


class DPRAMCHILL_OT_nuong(Operator):
    """⛔ NUT DUY NHAT CUA ADDON DUOC PHEP GHI RA DIA — va chi ghi FILE MOI.

    Ducphan 12/09/2026: bo nhap .max giu nguyen co anh goc, con viec lam
    nhe thi dat vao day. Xem luat trong `nuong_map.py`.
    """
    bl_idname = "dpramchill.nuong"
    bl_label = "Bake Smaller Maps"
    bl_description = ("Write the plan of the current mode (Auto or Force) "
                      "to NEW smaller image files and point the maps at "
                      "them. Viewport, RAM and render all get lighter. The "
                      "original files are never touched - Restore Original "
                      "Maps brings them back.\n"
                      "Ghi ke hoach cua che do dang chon ra FILE ANH MOI nho "
                      "hon roi tro map sang do. Viewport, RAM va render deu "
                      "nhe di. File goc khong bi dong toi - bam Restore "
                      "Original Maps de tra lai")
    bl_options = {"REGISTER"}

    def execute(self, context):
        p = context.scene.dp_ramchill
        if p.che_do == chinh_sach.CHE_DO_TAT:
            self.report({"WARNING"},
                        "DP_RAMchill: pick Auto or Force first")
            return {"CANCELLED"}
        if nuong_map.thu_muc_that(p.thu_muc_nuong) is None:
            self.report({"ERROR"}, "DP_RAMchill: save the .blend first, "
                                   "or pick an absolute folder")
            return {"CANCELLED"}
        # Map dang bi thu nho boi mot lan render dut giua chung thi tra ve
        # co goc truoc — bake phai doc tu file, khong tu bo dem da ha.
        doi_co.tra_lai()
        try:
            ket_qua, ghi_chu = doi_co.lap_ke_hoach(context, cho_tx=False)
        except Exception as e:                    # noqa: BLE001
            self.report({"ERROR"}, "DP_RAMchill: %s" % e)
            return {"CANCELLED"}
        _ghi_moc_da_do(p, ghi_chu)
        wm = context.window_manager
        viec = sum(1 for k in ket_qua if k.get("doi"))
        wm.progress_begin(0, max(1, viec))
        try:
            dem = nuong_map.nuong_ke_hoach(
                ket_qua, p.thu_muc_nuong,
                bao_tien_do=lambda i, n: wm.progress_update(i))
        except Exception as e:                    # noqa: BLE001
            self.report({"ERROR"}, "DP_RAMchill: bake failed: %s" % e)
            return {"CANCELLED"}
        finally:
            wm.progress_end()
        p.bao_cao = nuong_map.dong_bao_cao(dem)
        self.report({"INFO"}, "DP_RAMchill: baked %d maps into %s" % (
            dem["da_bake"], dem["thu_muc"]))
        return {"FINISHED"}


class DPRAMCHILL_OT_bo_nuong(Operator):
    bl_idname = "dpramchill.bo_nuong"
    bl_label = "Restore Original Maps"
    bl_description = ("Point every baked map back at its original file, at "
                      "full size. The baked files stay on disk.\n"
                      "Tro moi map da bake ve file goc, o co goc. File bake "
                      "van nam tren dia")
    bl_options = {"REGISTER"}

    def execute(self, context):
        doi_co.tra_lai()
        so, hong = nuong_map.tra_ve_goc()
        bc = "restored %d maps" % so
        if hong:
            bc += "\n! %d originals missing, kept" % hong
        context.scene.dp_ramchill.bao_cao = bc
        self.report({"WARNING"} if hong else {"INFO"},
                    "DP_RAMchill: %d maps back to the originals%s" % (
                        so, (", %d could not be restored" % hong)
                        if hong else ""))
        return {"FINISHED"}


_LOP = (DPRAMCHILL_OT_quet, DPRAMCHILL_OT_moc_tu_scene,
        DPRAMCHILL_OT_tra_lai, DPRAMCHILL_OT_nuong, DPRAMCHILL_OT_bo_nuong)


def dang_ky():
    for c in _LOP:
        bpy.utils.register_class(c)


def go():
    for c in reversed(_LOP):
        bpy.utils.unregister_class(c)
