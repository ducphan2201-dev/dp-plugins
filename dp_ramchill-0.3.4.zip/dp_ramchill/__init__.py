# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
#
# DP_RAMchill — shrink texture maps at render time to save VRAM.
# Copyright (C) 2026  Ducphan
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; version 2 of the License.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
"""DP_RAMchill — ha co map NGAY LUC RENDER de tiet kiem VRAM.

Legacy Add-on (bl_info), KHONG dung blender_manifest.toml — giong ca bay
addon dang ban cua nha DP.

BAN DO CAC LOP, doc theo thu tu nay:

    chinh_sach.py  hai dieu kien -> mot bac -> mot co dich. KHONG import bpy
    do_canh.py     quet scene: khoang cach + dien tich tren khung hinh
    doi_co.py      handler render: ha co truoc, tra lai sau
    props.py       o nhap      ops.py     nut bam      ui_panel.py   bang

LUAT PHAN TANG, DUNG PHA: `chinh_sach.py` KHONG duoc biet Blender ton tai.
Nho vay toan bo phep quyet dinh — nam bac, hai dieu kien, phep khoa chung
— kiem duoc trong MOT GIAY bang python tran, thay vi 20-30 giay moi lan mo
Blender. Co phep do canh dung luat nay (`tools/do_chinh_sach.py`).

⛔ VA LUAT LON NHAT CUA CA ADDON: SCENE KHONG DUOC DOI MOT PIXEL NAO. Map
chi nho di trong khoang thoi gian Cycles dang nap anh len thiet bi, roi
tra lai ngay. File anh tren dia khong bi ghi. `.blend` khong bi ghi. Bam
`Scan Scene` cung khong doi gi — no chi do va bao cao.

NGOAI LE DUY NHAT, Ducphan dat 12/09/2026: nut `Bake Smaller Maps`
(`nuong_map.py`) GHI FILE MOI ra mot thu muc rieng va tro map sang do —
chi khi nguoi dung bam, khong bao gio ghi de file goc, moi file doc lai so
tung pixel truoc khi dung, va `Restore Original Maps` tra lai nguyen chuoi
duong dan cu.

THEM 13/09/2026 (Ducphan, 0.3.0) — bang con `Cycles Memory`:
    ngoai_khung.py  TAM an vat ngoai khung camera VA xa khi render (TAT san;
                    vat bi bo mat bong/phan chieu - noi ra tren bang)
    bo dem anh      ve thang hai o Texture Cache / Auto Generate cua Blender
                    5.2 + thu muc dem. Ca hai o bat thi anh FILE thuong thoi
                    ha (bo dem nap theo nhu cau, it hon), anh PACKED van ha -
                    xem `chinh_sach.quyet_dinh(de_cho_tx=...)`.

BO 13/09/2026 (0.3.2, Ducphan: "chuc nang nao gay vot ram va ton ram thi bo"):
    khoi Texture Cache tren bang. Do: lan ve dau RAM may 1,6 -> 6,8 GB. Xem
    ghi chu `ui_panel.DPRAMCHILL_PT_cycles`. Luat nhuong anh FILE cho bo dem
    khi KHACH tu bat bo dem cua Blender thi van giu.

THEM 13/09/2026 (0.3.1, Ducphan: "neu co anh sang gay bong do ma k render thi
sao?"):
    bong_khung.py   vat ngoai khung con phai qua phep hoi BONG - tung nguon
                    sang (den, vat phat sang, Sky Texture, dom sang HDRI) -
                    bong co the roi vao khung thi GIU. Ban GIONG HET trong
                    DP_MaxImporter; sua mot ben thi chep sang ben kia.

THEM 14/09/2026 (0.3.3, Ducphan: "toi uu tiep viec auto resize map theo cam"):
    nhin_thay.py    BAN DO NHIN THAY cho dieu kien 2 cua Auto: pixel THAT ma
                    moi map chiem (cat theo khung, co che khuat) va texel tren
                    chinh cac pixel do. Luat chon bac KHONG doi. Phong khach
                    that: Auto 0 -> 4 tam ha (card 1078 -> 845 MB), anh lech
                    0,021%.

SUA 14/09/2026 (0.3.4): nut Bake cung ghi bon vanh vua do vao bon o, nhu
    Scan (truoc day sau Bake bon o hien so mac dinh 5..60 m). O `Bake folder`
    het to do: khai co `PATH_SUPPORTS_BLEND_RELATIVE` (props._co_tuong_doi).
    Nhom More: nhan "Keep at full size" mot hang rieng (truoc bi cat "Keep
    a..."). DAU VAN CANH om trang thai tung vat (vi tri, an/hien, vat lieu,
    modifier) va anh + Mapping cua vat lieu: truoc day doi cho / an mot vat
    ma so vat khong doi thi lan render sau dung LAI ke hoach cu (doi_co.
    _van_vat). PN4: 11 ms moi lan.
"""

__author__ = "Ducphan"
__version__ = "0.3.4"
__date__ = "14 Sep 2026"

bl_info = {
    # Tien to DP_ de addon hien ra khi loc "DP" trong Preferences > Add-ons
    "name": "DP_RAMchill",
    "author": "Ducphan",
    "version": (0, 3, 4),
    "blender": (4, 2, 0),
    "location": "View3D > Sidebar (N) > DP_RAMchill",
    "description": "Shrink texture maps at render time to save VRAM - by "
                   "distance to camera and screen area, or forced to one size"
                   " - or bake them to smaller files. Also: leave out "
                   "off-screen objects at render time",
    "category": "Render",
}

if "bpy" in locals():                    # nap lai khi cai de len ban cu
    import importlib
    for _ten in ("chinh_sach", "nhin_thay", "do_canh", "doi_co", "nuong_map",
                 "bong_khung", "ngoai_khung", "props", "ops", "ui_panel"):
        if _ten in locals():
            importlib.reload(locals()[_ten])

import bpy                                                          # noqa: E402

from . import chinh_sach                                            # noqa: E402,F401
from . import nhin_thay                                             # noqa: E402,F401
from . import do_canh                                               # noqa: E402,F401
from . import doi_co                                                # noqa: E402
from . import nuong_map                                             # noqa: E402,F401
from . import bong_khung                                            # noqa: E402,F401
from . import ngoai_khung                                           # noqa: E402
from . import ops                                                   # noqa: E402
from . import props                                                 # noqa: E402
from . import ui_panel                                              # noqa: E402


def register():
    props.dang_ky()
    ops.dang_ky()
    ui_panel.dang_ky()
    doi_co.dang_ky()
    ngoai_khung.dang_ky()


def unregister():
    ngoai_khung.go()
    doi_co.go()
    ui_panel.go()
    ops.go()
    props.go()
