# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
"""BAKE MAP — ghi ban da thu nho ra FILE MOI roi tro anh sang do.

=========================================================================
VI SAO CO LOP NAY — va no KHAC hoan toan voi lop render (`doi_co.py`)
=========================================================================
Ducphan 12/09/2026: *"phai de nguyen px anh map nhu file goc chu, them
chuc nang bake map vao dp-ramchill la dc r"*. Bo nhap .max giu nguyen co
anh cua file goc; muon nhe thi nguoi dung BAM NUT o day.

`doi_co` chi ha co trong luc render roi tra lai — viewport va RAM luc dung
van giu ca map goc. Bake la duong con lai: ke hoach cua che do dang chon
(Auto hoac Force) duoc GHI RA FILE, va tam anh tro sang file nho. Viewport,
RAM, VRAM deu nhe di, khong can quet lai luc render.

⛔ BON LUAT, deu la cho de hong im lang:

  1. KHONG BAO GIO GHI DE FILE GOC. Ban nho nam trong mot thu muc rieng
     (mac dinh `//DP_RAMchill_maps`), ten mang dau vet cua duong dan goc
     nen hai tam `wood.jpg` o hai thu muc khong the de len nhau. Duong dan
     goc duoc cat vao chinh tam anh (`KHOA_GOC`), va `Restore Original Maps`
     tra no ve nguyen chuoi.

  2. MOI FILE VUA GHI PHAI DOC LAI VA SO TUNG PIXEL truoc khi tam anh duoc
     tro sang no. Do duoc 12/09/2026 tren Blender 5.2: PNG/TIFF 16 bit CO
     KENH ALPHA bi Blender ghi SAI MAU — lech toi 0,50 tren thang 0..1,
     ngay ca khi chi luu lai ma khong thu nho. PNG 8 bit, PNG 16 bit khong
     alpha va EXR thi dung tung pixel. Khong co cua doc lai thi tam anh bi
     doi mau, va nguoi dung khong bao gio doan ra la do nut Bake.

  3. ANH NAO KHONG LAM DUOC THI GIU NGUYEN VA DEM RA BANG — anh lien ket
     tu file khac, file goc mat, file ghi ra khong khop.

  4. ANH PACKED (map nam trong .blend — PN4.blend cua Ducphan co ca 73 tam
     deu packed): goi goc duoc GHI RA DIA dung tung byte truoc khi thay
     ruot, de Restore con cho lay lai. Xem `_nguon_packed`.

MOT TAM MOT LUC: nap ban tam o co goc, thu nho, ghi, doc lai, tha. RAM di
xuong theo tung tam chu khong vot len.
"""

import hashlib
import os

import bpy
import numpy as np

from . import chinh_sach

KHOA_GOC = "dp_ramchill_goc"          # duong dan goc, NGUYEN CHUOI tho
KHOA_CO_GOC = "dp_ramchill_co_goc"    # [w, h] truoc khi bake
KHOA_GOI_GOC = "dp_ramchill_goi_goc"  # anh PACKED: goi goc giu lai tren dia
KHOA_GOI_SHA = "dp_ramchill_goi_sha"  # ... va sha256 cua no
THU_MUC_MAC_DINH = "//DP_RAMchill_maps"

# Cua doc lai: mot buoc cua thang 8 bit. Moi duong dung do duoc 12/09/2026
# lech <= 0,0003 (PNG 16 bit / EXR) hoac 0 (PNG 8 bit); duong hong lech
# 0,29 .. 0,60. Mot buoc 8 bit la muc mat nguoi khong phan biet duoc tren
# man hinh 8 bit — khong phai so chinh theo mau.
DUNG_SAI = 1.0 / 255.0


def da_nuong(img):
    return KHOA_GOC in img.keys()


def dem_da_nuong():
    return sum(1 for i in bpy.data.images if KHOA_GOC in i.keys())


def _dinh_dang(tam):
    """Dinh dang KHONG MAT DU LIEU cho ban nho: (file_format, duoi).

    Hoi tren ban NAP TAM chu khong hoi tam anh dang song: hoi `is_float`
    cua tam anh dang song la nap ca tam anh goc vao RAM.

    JPG goc cung ra PNG: nen JPG them mot doi la mat them chi tiet, trong
    khi RAM cua tam anh (bo dem 8 bit) y het nhau. Anh float (EXR / HDR /
    PNG 16 bit / TIFF 16 bit): EXR giu EXR, con lai ra PNG — Blender tu
    ghi PNG 16 bit tu bo dem float.
    """
    if tam.is_float and tam.file_format in ("OPEN_EXR", "OPEN_EXR_MULTILAYER",
                                            "HDR"):
        return "OPEN_EXR", ".exr"
    return "PNG", ".png"


def _sach(ten):
    ten = "".join(c if (c.isalnum() or c in "-_.") else "_" for c in ten)
    return ten[:60] or "map"


def _sha(b):
    return hashlib.sha256(b).hexdigest()


def _ten_file(img, vet_nguon, stem, w, h, duoi):
    # Dau vet om CA mau lan che do alpha: cung mot file goc nhung khai hai
    # colorspace khac nhau thi ra hai bo dem khac nhau.
    vet = hashlib.sha1(("%s|%s|%s" % (vet_nguon,
                                      img.colorspace_settings.name,
                                      img.alpha_mode)).encode("utf-8")
                       ).hexdigest()[:8]
    return "%s_%dx%d_%s%s" % (_sach(stem), w, h, vet, duoi)


def _doc_px(img):
    w, h = img.size
    a = np.empty(w * h * img.channels, dtype=np.float32)
    img.pixels.foreach_get(a)
    return a


def _khop(a, b):
    if a.shape != b.shape:
        return False, float("inf")
    # Anh float co the vuot 1.0 (HDR): so theo ti le khi gia tri lon.
    lech = np.abs(a - b) / np.maximum(1.0, np.abs(a))
    m = float(lech.max()) if lech.size else 0.0
    return m <= DUNG_SAI, m


def thu_muc_that(thu_muc):
    """Duong dan tuyet doi cua thu muc bake, hoac None neu chua xac dinh
    duoc (duong dan `//` ma file .blend chua luu)."""
    thu_muc = (thu_muc or THU_MUC_MAC_DINH).strip()
    if thu_muc.startswith("//") and not bpy.data.filepath:
        return None
    return os.path.normpath(bpy.path.abspath(thu_muc))


def _duong(duong, tuong_doi):
    return bpy.path.relpath(duong) if tuong_doi else duong


def _ghi(tam, dich, dinh_dang):
    """Ghi bo dem cua `tam` ra `dich`. Tach rieng de phep do chot nghich
    thay duoc bang mot ham ghi hong."""
    tam.file_format = dinh_dang
    tam.save(filepath=dich, save_copy=True)


def _nguon_packed(img, thu_muc_abs, tuong_doi):
    """Tam PACKED: GIU LAI goi goc ra dia, dung tung byte, de Restore.

    Sau khi bake, goi packed trong .blend la ban NHO — luu .blend la goi
    goc mat khoi file. Nen truoc khi dung toi, ghi goi goc ra thu muc bake
    (`..._original.<duoi>`) va cat sha256 cua no vao tam anh. Tam da bake
    roi thi goi goc da nam san o do.

    Tra ve (file_goc_tren_dia, (duong_luu, sha) hoac None, vua_tao).
    (None, None, False) neu goi goc khong con nguyen ven. `vua_tao` de
    lan bake bi tu choi don dung file CHINH NO vua ghi — file da co san co
    the dang la goi goc cua mot tam khac mang cung ruot.
    """
    if KHOA_GOI_GOC in img.keys():
        f = bpy.path.abspath(img[KHOA_GOI_GOC])
        if not os.path.isfile(f) or _sha(open(f, "rb").read()) != img.get(
                KHOA_GOI_SHA):
            return None, None, False
        return f, None, False
    B = bytes(img.packed_file.data)
    sha = _sha(B)
    duoi = os.path.splitext(img.filepath)[1] or ".img"
    stem = os.path.splitext(os.path.basename(img.filepath))[0] or img.name
    f = os.path.join(thu_muc_abs, "%s_%s_original%s" % (_sach(stem), sha[:8],
                                                        _sach(duoi)))
    vua_tao = False
    if not (os.path.isfile(f) and _sha(open(f, "rb").read()) == sha):
        with open(f, "wb") as fh:
            fh.write(B)
        vua_tao = True
        if _sha(open(f, "rb").read()) != sha:
            return None, None, False
    return f, (_duong(f, tuong_doi), sha), vua_tao


def _don(f):
    if f is None:
        return
    try:
        os.remove(f)
    except OSError as e:
        print("[DP_RAMchill] khong xoa duoc file:", f, e)


def nuong_mot(img, moi_w, moi_h, thu_muc_abs, tuong_doi):
    """Bake mot tam. Tra ve (True, duong_dan) hoac (False, ly_do).

    Tam DA bake roi ma ke hoach doi co (vi du Force 1024 -> 512) thi bake
    lai TU BAN GOC chu khong tu ban nho: thu nho hai lan la lay mau hai
    lan, va dau `KHOA_GOC` phai luon chi ve ban goc that de Restore tra
    dung cho.

    ⛔ TAM PACKED DI DUONG RIENG, do 12/09/2026:
      * thay ruot bang `img.pack(data=...)` — duong dan giu nguyen chuoi,
        goi doi thanh ban nho, `file_format` tu doi theo ruot;
      * TUYET DOI KHONG `reload()`: reload tren anh packed doc `filepath`
        roi PACK LAI tu dia (LESSONS §11) — file goc con tren dia la ban
        nho bi thay nguoc bang ban goc, im lang. Dung `buffers_free()`.
    """
    packed = img.packed_file is not None
    raw_goc = img[KHOA_GOC] if KHOA_GOC in img.keys() else img.filepath
    goi_moi, vua_tao = None, False
    if packed:
        nguon, goi_moi, vua_tao = _nguon_packed(img, thu_muc_abs, tuong_doi)
        if nguon is None:
            return False, "mat_file"
        vet_nguon = os.path.basename(nguon)
        stem = os.path.splitext(os.path.basename(img.filepath))[0] or img.name
    else:
        nguon = bpy.path.abspath(raw_goc, library=img.library)
        if not os.path.isfile(nguon):
            return False, "mat_file"
        vet_nguon = os.path.normcase(nguon)
        stem = os.path.splitext(os.path.basename(nguon))[0]
    cs = img.colorspace_settings.name
    am = img.alpha_mode
    tam = bpy.data.images.load(nguon, check_existing=False)
    try:
        tam.colorspace_settings.name = cs
        tam.alpha_mode = am
        w0, h0 = tam.size
        dinh_dang, duoi = _dinh_dang(tam)
        dich = os.path.join(thu_muc_abs,
                            _ten_file(img, vet_nguon, stem, moi_w, moi_h,
                                      duoi))
        if os.path.normcase(os.path.abspath(dich)) == os.path.normcase(
                os.path.abspath(nguon)):
            _don(nguon if vua_tao else None)
            return False, "trung_goc"         # luat 1 — day la cho gay hai
        tam.scale(moi_w, moi_h)
        mau = _doc_px(tam)
        _ghi(tam, dich, dinh_dang)
    finally:
        bpy.data.images.remove(tam)
    if not os.path.isfile(dich):
        _don(nguon if vua_tao else None)
        return False, "khong_ghi_duoc"

    # Luat 2 — doc lai file vua ghi, CUNG colorspace va alpha, so tung pixel
    kt = bpy.data.images.load(dich, check_existing=False)
    try:
        kt.colorspace_settings.name = cs
        kt.alpha_mode = am
        ok, lech = _khop(mau, _doc_px(kt)) if tuple(kt.size) == (
            moi_w, moi_h) else (False, float("inf"))
    finally:
        bpy.data.images.remove(kt)
    del mau
    if not ok:
        _don(dich)
        _don(nguon if vua_tao else None)
        print("[DP_RAMchill] bake bi tu choi (doc lai lech %.4f): %s"
              % (lech, img.name))
        return False, "doc_lai_lech"

    if KHOA_GOC not in img.keys():
        img[KHOA_GOC] = raw_goc
        img[KHOA_CO_GOC] = [int(w0), int(h0)]
        if goi_moi is not None:
            img[KHOA_GOI_GOC], img[KHOA_GOI_SHA] = goi_moi
    if packed:
        du_lieu = open(dich, "rb").read()
        img.pack(data=du_lieu, data_len=len(du_lieu))
        img.colorspace_settings.name = cs
        img.alpha_mode = am
        img.buffers_free()
    else:
        img.filepath = _duong(dich, tuong_doi)
        # Doi filepath co the lam Blender doan lai colorspace theo file moi
        # (vi du EXR). Tra ve dung cai nguoi dung da khai.
        img.colorspace_settings.name = cs
        img.alpha_mode = am
        img.reload()
    return True, dich


def nuong_ke_hoach(ket_qua, thu_muc, bao_tien_do=None):
    """Bake moi tam ma ke hoach bao `doi`. Tra ve dict dem."""
    thu_muc_abs = thu_muc_that(thu_muc)
    if thu_muc_abs is None:
        raise ValueError("save the .blend first, or pick an absolute folder")
    tuong_doi = (thu_muc or THU_MUC_MAC_DINH).strip().startswith("//")
    os.makedirs(thu_muc_abs, exist_ok=True)
    dem = {"da_bake": 0, "byte_truoc": 0, "byte_sau": 0, "packed": 0,
           "lien_ket": 0, "bake_lai": 0, "mat_file": 0,
           "doc_lai_lech": 0, "khong_ghi_duoc": 0, "trung_goc": 0,
           "thu_muc": thu_muc_abs}
    viec = [k for k in ket_qua if k.get("doi")]
    for i, k in enumerate(viec):
        if bao_tien_do is not None:
            bao_tien_do(i, len(viec))
        img = bpy.data.images.get(k["ten"])
        if img is None or img.source != "FILE" or img.is_dirty:
            continue
        if img.library is not None:
            dem["lien_ket"] += 1
            continue
        lai = da_nuong(img)
        ok, ly_do = nuong_mot(img, k["moi_w"], k["moi_h"], thu_muc_abs,
                              tuong_doi)
        if ok:
            dem["da_bake"] += 1
            dem["bake_lai"] += int(lai)
            dem["packed"] += int(img.packed_file is not None)
            dem["byte_truoc"] += k["byte_truoc"]
            dem["byte_sau"] += k["byte_sau"]
        else:
            dem[ly_do] = dem.get(ly_do, 0) + 1
    return dem


def tra_ve_goc():
    """Tro moi tam da bake ve ban goc. File bake de lai tren dia.

    Tra ve (so_tra_duoc, so_khong_tra_duoc). Tam packed ma goi goc giu lai
    tren dia da mat hoac bi sua (sha256 khong khop) thi KHONG dung toi va
    dem ra — thay mot goi khong phai goc vao la hong im lang.
    """
    so, hong = 0, 0
    for img in bpy.data.images:
        if KHOA_GOC not in img.keys():
            continue
        cs = img.colorspace_settings.name
        am = img.alpha_mode
        if img.packed_file is not None:
            if KHOA_GOI_GOC in img.keys():
                f = bpy.path.abspath(img[KHOA_GOI_GOC])
            else:
                # tam FILE da bake roi nguoi dung bam Pack Resources: ban
                # goc la file tren dia o duong dan cu
                f = bpy.path.abspath(img[KHOA_GOC], library=img.library)
            B = open(f, "rb").read() if os.path.isfile(f) else None
            if B is None or (KHOA_GOI_SHA in img.keys()
                             and _sha(B) != img[KHOA_GOI_SHA]):
                hong += 1
                print("[DP_RAMchill] khong tra lai duoc (mat goi goc):",
                      img.name, f)
                continue
            if img.filepath != img[KHOA_GOC]:
                img.filepath_raw = img[KHOA_GOC]
            img.pack(data=B, data_len=len(B))
            img.colorspace_settings.name = cs
            img.alpha_mode = am
            img.buffers_free()
        else:
            img.filepath = img[KHOA_GOC]
            img.colorspace_settings.name = cs
            img.alpha_mode = am
            img.reload()
        for k in (KHOA_GOC, KHOA_CO_GOC, KHOA_GOI_GOC, KHOA_GOI_SHA):
            if k in img.keys():
                del img[k]
        so += 1
    return so, hong


def dong_bao_cao(dem):
    """Cac dong cho bang — dong nao cung vua be rong thanh ben."""
    d = ["baked %d maps" % dem["da_bake"]]
    if dem.get("bake_lai"):
        d.append("(%d re-baked from originals)" % dem["bake_lai"])
    if dem.get("packed"):
        d.append("(%d packed: .blend shrinks)" % dem["packed"])
    if dem["da_bake"]:
        d.append("%s  ->  %s" % (chinh_sach.doc_byte(dem["byte_truoc"]),
                                 chinh_sach.doc_byte(dem["byte_sau"])))
    for khoa, chu in (("lien_ket", "! %d linked maps kept"),
                      ("mat_file", "! %d missing files kept"),
                      ("doc_lai_lech", "! %d failed read-back, kept"),
                      ("khong_ghi_duoc", "! %d could not be written"),
                      ("trung_goc", "! %d would overwrite source")):
        if dem.get(khoa):
            d.append(chu % dem[khoa])
    return "\n".join(d)
