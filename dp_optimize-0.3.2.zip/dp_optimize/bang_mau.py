# -*- coding: utf-8 -*-
# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
"""Bang tra mau 3 chieu: nuong phep doi mau cua Blender MOT LAN, roi tra.

⛔ VI SAO CO FILE NAY. `tang_kinh.hien_ra` dua anh qua dung bo mau cua
Blender bang cach ghi ra TIFF roi nap lai — do la duong DUY NHAT de Image
Editor chiu ap View Transform / Look / Exposure / White Balance / Curves cho
mot anh THUONG (do 20/09/2026, bon truong hop). Nhung no dat: do 21/09/2026
tren file that cua Ducphan (2625x3500 = 9,2 trieu diem, sRGB / AgX / Punchy,
Blender CO CUA SO):

    hieu_ung (bon phep chinh, tren card)   0,044 - 0,115 s
    hien_ra  (khau doi mau)                ~0,21 s        <- o day
    ve_lai   tron mot luot                 0,24 - 0,30 s  -> 3-4 luot/giay

Va `save_render` co CHI PHI CO DINH lon: anh 9,2 trieu diem het 0,19 s, ma
mot khoi 262 nghin diem cung het ngan ay. Tuc la khong the toi uu bang cach
thu nho anh — phai bo han cai khau do ra khoi duong keo thanh truot.

CACH LAM. Phep doi mau la mot ham tu mau sang mau, khong phu thuoc diem anh
nam o dau. Nen nuong no MOT LAN vao mot khoi tra N x N x N: dua vao mot khoi
"mau dong nhat" trai deu trong khong gian log, cho CHINH BLENDER doi mau no
(cung mot duong `save_render`), roi doc ket qua ve. Tu do moi lan keo thanh
truot chi con tra bang tren card.

⛔ TRA VE DUNG CAI MA `Image.pixels` CAN. Blender nap file anh vao la da
chuyen ve khong gian tuyen tinh cua canh roi; khung anh khi ve lai se ma hoa
nguoc. Nen thu doc duoc tu `pixels` sau khi nap CHINH LA gia tri phai ghi —
khong phai tu minh ma hoa sRGB.

⛔ KHONG NUONG BANG TIFF 8 BIT. 8 bit chia deu 256 muc, sai so lam tron cua
rieng buoc nuong da la 0,5/255 truoc khi noi suy. Dung 16 bit: file van nho
(mot khoi 33^3 chi 36 nghin diem) nen gia khong dang ke.
"""

import os

import bpy
import numpy as np

TEN = "DP-OptimizeRender"

# Canh khoi. 33 la co chuan cua nganh (.cube), nhung do 21/09/2026 tren file
# that thi 33 con lech 1,70/255 trung binh — chua dat. 64 dua xuong duoi mot
# phan 255 (xem `tools/do_bang_mau.py`). Bang 64^3 nang 4 MB tren card va
# nuong het ~0,15 s MOT LAN, nen cai gia la khong dang ke.
N = 64
# Khoang dau vao, theo log2: 2^-10 = 0,001 den 2^+6 = 64. Hep hon thi moi
# nac bang day hon, ma hai dau thi da den han / trang xoa nen khong mat gi.
# 16 nac chia cho 63 buoc = 0,25 nac mot buoc.
LO, HI = -10.0, 6.0

_BANG = {}          # dau mau -> mang (N, N, N, 4) float32
TEN_ANH = "DP_LUT_nuong"

# Cac o `image_settings` ma DP-Optimize muon tam de ghi file trung gian, THEO
# THU TU TRA LAI: `media_type` doi thi Blender dat lai `file_format`, doi
# `file_format` thi dat lai do sau mau / kieu nen — nen tra cai "to" truoc.
O_ANH = ("media_type", "file_format", "color_depth", "color_mode",
         "tiff_codec", "exr_codec", "color_management")


def cat_cai_dat_anh(ims):
    """Chup DU cac o `image_settings` se bi muon (xem `O_ANH`).

    ⛔ PHAI CAT CA `tiff_codec` / `exr_codec`. Ban cu chi cat bon o +
    `color_management`: `hien_ra` dat `tiff_codec = 'PACKBITS'`, ham nay dat
    'NONE', khong ai tra — khach xuat TIFF LZW thi file ra doi kieu nen am
    tham (ra soat 21/09/2026). Dung chung cho `tang_kinh.hien_ra` va
    `nuong` o day."""
    cu = []
    for ten in O_ANH:
        if hasattr(ims, ten):
            try:
                cu.append((ten, getattr(ims, ten)))
            except Exception:                                # noqa: BLE001
                pass
    return cu


def tra_cai_dat_anh(ims, cu):
    """Tra lai cai `cat_cai_dat_anh` da chup. MOI O MOT `try`: mot o hong
    (kieu nen khong hop dinh dang cu...) khong duoc chan cac o sau."""
    for ten, v in cu:
        try:
            if getattr(ims, ten) != v:
                setattr(ims, ten, v)
        except Exception:                                    # noqa: BLE001
            pass


def dau(scene):
    """Dau nhan cua toan bo cai dat mau. Doi mot thu la phai nuong lai."""
    v, d = scene.view_settings, scene.display_settings
    cu = v.curve_mapping
    return (d.display_device, v.view_transform, v.look,
            round(v.exposure, 5), round(v.gamma, 5),
            bool(v.use_curve_mapping),
            cu.white_level[0] if cu else 0.0,
            cu.black_level[0] if cu else 0.0,
            bool(getattr(v, "use_white_balance", False)),
            round(getattr(v, "white_balance_temperature", 0.0), 3),
            round(getattr(v, "white_balance_tint", 0.0), 3))


def _khoi_vao():
    """Khoi mau dong nhat: gia tri TUYEN TINH, trai deu theo log2."""
    i = np.arange(N, dtype=np.float32) / (N - 1.0)
    lin = np.exp2(LO + (HI - LO) * i)
    # Thu tu phang: b cham nhat, roi g, roi r nhanh nhat — dung thu tu ma
    # texture 3 chieu cua card doi (rong = r, cao = g, sau = b).
    a = np.ones((N, N, N, 4), np.float32)
    bb, gg, rr = np.meshgrid(lin, lin, lin, indexing='ij')
    a[:, :, :, 0] = rr
    a[:, :, :, 1] = gg
    a[:, :, :, 2] = bb
    return a


def nuong(scene):
    """Nuong bang tra cho cai dat mau hien tai. Tra ve mang hay None."""
    khoi = _khoi_vao()
    W, H = N * N, N
    img = bpy.data.images.get(TEN_ANH)
    if img is not None and (img.size[0] != W or img.size[1] != H):
        bpy.data.images.remove(img)
        img = None
    if img is None:
        img = bpy.data.images.new(TEN_ANH, W, H, alpha=True, float_buffer=True)
    # ⛔ PHAI DAT Y HET `_anh_tu_mang` TRONG `tang_kinh`. Duong cu ghi anh
    # ra TIFF tu mot Image mang `use_view_as_render = True` va
    # `alpha_mode = 'PREMUL'`; thieu hai co do thi `save_render` cho ra MOT
    # PHEP BIEN DOI KHAC, va bang nuong duoc se lech han (do 21/09/2026:
    # lech 29/255 trung binh — mau sai hoan toan).
    img.use_view_as_render = True
    img.alpha_mode = 'PREMUL'
    img.pixels.foreach_set(khoi.reshape(-1))

    duong = os.path.join(bpy.app.tempdir, "dp_lut_%d.tif" % os.getpid())
    ims = scene.render.image_settings
    cu = cat_cai_dat_anh(ims)
    cu_cm = getattr(ims, "color_management", None)
    nap = None
    try:
        ims.media_type = 'IMAGE'
        ims.file_format = 'TIFF'
        try:
            ims.tiff_codec = 'NONE'
        except Exception:                                    # noqa: BLE001
            pass
        ims.color_depth = '16'
        ims.color_mode = 'RGBA'
        if cu_cm is not None:
            ims.color_management = 'FOLLOW_SCENE'
        img.save_render(filepath=duong, scene=scene)
        nap = bpy.data.images.load(duong, check_existing=False)
        # ⛔ DOC THO, KHONG DE BLENDER GIAI MA. File da o khong gian man
        # hinh. Duong cu (`tang_kinh.hien_ra`) cuoi cung doc ra la MA MAN
        # HINH, vi anh cua no la anh 8 BIT — `Image.pixels` cua mot anh byte
        # tra thang gia tri byte chia 255, khong qua bo mau. Ban 16 bit o day
        # lai la anh FLOAT, nen gan the 'sRGB' la Blender GIAI MA THEM MOT
        # LAN va ca bang tut xuong (do 21/09/2026: lech 0,084 tren duong xam,
        # tuong duong 29/255 tren anh — mau sai han). Gan the khong-mau de
        # lay dung con so nam trong file.
        for ten in ('Non-Color', 'Raw', 'Linear Rec.709', 'Linear'):
            try:
                nap.colorspace_settings.name = ten
                break
            except Exception:                                # noqa: BLE001
                continue
        b = np.empty(len(nap.pixels), np.float32)
        nap.pixels.foreach_get(b)
        ra = b.reshape(H, W, 4)
        # Nguoc lai phep phang o tren: (b, g, r).
        ra = ra.reshape(N, N, N, 4).copy()
        return ra
    except Exception as e:                                   # noqa: BLE001
        # ⛔ DUNG NUOT. Hong o day la ca duong nhanh im lang tat, va nguoi
        # dung chi thay "van cham nhu cu" ma khong hieu vi sao.
        print("[%s] VFB: cannot bake the colour table (%s)" % (TEN, e))
        return None
    finally:
        tra_cai_dat_anh(ims, cu)
        if nap is not None:
            try:
                bpy.data.images.remove(nap)
            except Exception:                                # noqa: BLE001
                pass
        try:
            os.remove(duong)
        except Exception:                                    # noqa: BLE001
            pass


def lay(scene):
    """Bang tra cho cai dat mau hien tai (nuong neu chua co). None = khong
    dung duoc, goi phai quay ve duong `save_render`."""
    k = dau(scene)
    if k in _BANG:
        return _BANG[k]
    a = nuong(scene)
    if a is None:
        return None
    # Chi giu mot bang: doi cai dat mau la bang cu khong dung nua.
    _BANG.clear()
    _BANG[k] = a
    return a


def quen():
    _BANG.clear()
    img = bpy.data.images.get(TEN_ANH)
    if img is not None:
        try:
            bpy.data.images.remove(img)
        except Exception:                                    # noqa: BLE001
            pass
