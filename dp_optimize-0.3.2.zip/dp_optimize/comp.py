# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
"""Tach anh thanh tung kenh anh sang, khu nhieu rieng tung kenh, roi ghep lai.

PHEP GHEP DUNG (da do 05/08/2026, lech 0.000000 so voi anh Combined):

    Combined = (DiffDir + DiffInd) * DiffColor
             + (GlossDir + GlossInd) * GlossColor
             + (TransDir + TransInd) * TransColor
             + Emission + Environment + VolumeDir + VolumeInd

Cac pass Direct/Indirect KHONG chua mau vat lieu — mau nam o pass Color.
Bo phep nhan voi pass Color di (kieu "cong 4 kenh roi Mix Add" hay thay tren
mang) thi anh mat sach texture: do that tren cung mot khung hinh, lech max
0.671. Xem `tools/probe_recombine.py`.

VI SAO TACH RA LAI GIU DUOC CHI TIET HON
    Denoise chay tren pass Direct/Indirect la chay tren ANH SANG THUAN, da bo
    van vat lieu ra ngoai. Anh sang thi muot, nen bo khu nhieu khong con phai
    doan xem mot vet dam la nhieu hay la van go. Van go quay lai o buoc nhan
    pass Color, va pass Color gan nhu khong co nhieu.

CAI GIA PHAI TRA
    Nhieu pass hon = nhieu bo nho hon va nhieu lan chay denoise hon. Co scene
    tach ra khong hon gi ca — do tren phong kiem 06/08/2026 no CHAM HON 2,5
    LAN. Nen o day khong chot ho ai: `verify()` kiem phep ghep co dung khong,
    con `verify()` la cho duy nhat kiem dieu do — bang phep so, khong bang
    mot vong do bat khach ngoi cho.

ALPHA. Cac pass anh sang deu co alpha = 1 o moi diem, ke ca noi khong co gi
ca. Cong/nhan chung lai thi ket qua cung alpha = 1 khap noi — NEN TRONG SUOT
BIEN MAT. Do that 06/08/2026 tren `film_transparent`:

    alpha anh Combined  min 0.000  trung binh 0.841
    alpha anh ghep lai  min 1.000  trung binh 1.000   <- nen da dac lai

RGB thi khop den 2e-6, nen `verify()` cu BAO DAT trong khi anh xuat ra da
hong — no doc anh qua `metrics.load`, ma ham do CAT MAT kenh alpha. Nay alpha
duoc lay tu pass Alpha va dat lai o cuoi bang mot node Set Alpha, con
`verify()` doc RGBA day du (`_load_rgba`) va bao RIENG hai con so.

CHU Y node Set Alpha: socket 'Type' mac dinh la 'Apply Mask', kieu do NHAN
RGB voi alpha (vien anh toi di). Phai dat 'Replace Alpha'.

BLENDER 5.2: `scene.node_tree` KHONG CON. Cay compositor la mot node group
gan vao `scene.compositing_node_group`, ket qua di ra qua NodeGroupOutput
theo socket khai bao trong `tree.interface`. `CompositorNodeMath`,
`CompositorNodeMix`, `CompositorNodeComposite` deu da bi xoa — dung
`ShaderNodeMix` (chay duoc trong cay compositor).
"""
import json
import os
import time

import bpy
import numpy as np

from . import metrics, settings

GROUP_NAME = "DP_SplitDenoise"

# PHIEN BAN CAY — ghi vao chinh cay (`tree[TREE_VER_KEY]`). Cay nam trong file
# .blend, cai addon moi khong doi no; so nay cho `cay_loi_thoi` biet cay nao
# phai dung lai luc mo file.
#   (khong co) cay dung truoc 20/09/2026 ~02:00 — dung lai mot lan cho chac
#   2  nhanh kinh dan duong bang Denoising Albedo/Normal
#   3  20/09 ~02:30: them TACH MAU CO KEP cho nhanh kinh — DA GO BO
#   4  20/09 ~19:40: go tach mau, nhanh kinh ve dan duong thuong (xem `build`)
TREE_VER = 5
TREE_VER_KEY = "dpopt_tree_ver"

# Cho cat trang thai pass TRUOC KHI addon bat chung len, de `clear()` tra lai.
# Khoa nam tren Scene chu khong nam trong bien Python: nguoi dung dung cay
# nay, luu file, tat Blender, hom sau mo lai bam Remove — bien Python da mat
# tu doi nao, con thuoc tinh tren Scene thi di theo file .blend.
SAVED_KEY = "dpopt_split_saved_passes"

# Pass phai bat tren view layer. Thieu mot cai la ghep ra sai anh.
#
# LUON CAN — moi scene deu co anh sang khuech tan va phan xa.
CORE_PASSES = (
    'use_pass_diffuse_direct', 'use_pass_diffuse_indirect', 'use_pass_diffuse_color',
    'use_pass_glossy_direct', 'use_pass_glossy_indirect', 'use_pass_glossy_color',
    'use_pass_emit', 'use_pass_environment', 'use_pass_normal',
)
# CHI KHI SCENE CO KINH / NUOC / LA CAY. Bat thua thi ton bo nho va them mot
# lan chay khu nhieu tren mot buc anh DEN THUI.
TRANSMISSION_PASSES = (
    'use_pass_transmission_direct', 'use_pass_transmission_indirect',
    'use_pass_transmission_color',
)
# CHI KHI SCENE CO KHOI / SUONG.
CYCLES_LAYER_PASSES = ('use_pass_volume_direct', 'use_pass_volume_indirect')

# Moi pass ma addon nay co the dong vao — de chup lai va tra lai cho du.
VIEW_LAYER_PASSES = CORE_PASSES + TRANSMISSION_PASSES


def snapshot_passes(view_layer):
    """Trang thai hien tai cua moi pass ma addon nay se dong vao."""
    out = {}
    for p in VIEW_LAYER_PASSES:
        if p in view_layer.bl_rna.properties:
            out[p] = bool(getattr(view_layer, p))
    for p in CYCLES_LAYER_PASSES + ('denoising_store_passes',):
        if p in view_layer.cycles.bl_rna.properties:
            out['cycles.' + p] = bool(getattr(view_layer.cycles, p))
    return out


def restore_passes(view_layer, saved):
    """Tra lai dung nhung pass da chup. Bo qua cai nao khong con ton tai."""
    for key, value in (saved or {}).items():
        try:
            if key.startswith('cycles.'):
                name = key.split('.', 1)[1]
                if name in view_layer.cycles.bl_rna.properties:
                    setattr(view_layer.cycles, name, value)
            elif key in view_layer.bl_rna.properties:
                setattr(view_layer, key, value)
        except Exception:                                  # noqa: BLE001
            pass


def needed(scene):
    """Scene nay CAN nhung nhanh nao. Day la cho quyet dinh toc do.

    Truoc 06/08/2026 cay luon dung du 5 node Denoise — ke ca tren mot phong
    khong co lay mot manh kinh nao va khong co ti khoi nao. Ba trong nam node
    do chay khu nhieu tren nhung buc anh DEN THUI, va khach tra tien bang
    thoi gian render cho ca ba.

    Khong doan bang cach render thu roi nhin: doc thang cay vat lieu va danh
    sach object ra la biet. Xem `settings.has_transmission` / `has_volume`.
    """
    return dict(transmission=settings.has_transmission(scene),
                volume=settings.has_volume(scene))


def denoise_count(scene, want=None, denoise_volume=True):
    """So node Denoise cay se dung. MOI NODE LA MOT LUOT OIDN TREN ANH DAY DU.

    Day la toan bo gia cua buoc compositing — do 16/09/2026 tren PN4.blend
    (4000x2250, co kinh nen 3 node): cay RONG khong node Denoise nao ton
    +0,3s, tuc la ban than compositor gan nhu KHONG ton gi. Thoi gian di het
    vao may node Denoise nay.
    """
    want = want if want is not None else needed(scene)
    n = 3                                        # diffuse + glossy + emission
    if want.get('transmission'):
        n += 1                                    # kinh: them nhanh khuc xa
    if want.get('volume') and denoise_volume:
        n += 2
    return n


def auto_prefilter(scene):
    """Prefilter nen dung, THEO CHO COMPOSITOR SE CHAY.

    'Accurate' bat OIDN chay BA luot cho MOI node Denoise (khu nhieu albedo,
    khu nhieu phap tuyen, roi moi khu anh). Canh co kinh la 3 node, tuc 9
    luot khu nhieu tren anh DAY DU. Do 16/09/2026 tren PN4.blend 4000x2250,
    3 node, HAI luot do lech nhau duoi 1,2s, them vao mot lan render 19,9s:

        compositor tren CARD   Accurate +5,3s   Fast +2,3s   None +2,7s
        compositor tren CPU    Accurate +30,9s  Fast +7,0s   None +14,3s

    Tren bo xu ly, 'Accurate' mot minh an het 31 giay — hon mot lan render
    day du. Do chinh la cai khach bao "render 1 phut, compositing 2 phut"
    tren may Linux: may render khong co card, hoac khong mo duoc nen do hoa,
    nen compositor rot ve bo xu ly, va o do o 'Accurate' la o dat nhat bang.

    ⚠ 'Accurate' KHONG phai la do thua. Do chat luong cung ngay, anh chuan
    4096 mau (`tools/probe_prefilter.py`), so voi anh chuan:

        Cycles denoise, khong Split   texture 0,3390   blotch 0,00126
        Split + Accurate              texture 0,4242   blotch 0,00142
        Split + None                  texture 0,4564   blotch 0,00156
        Split + Fast                  texture 0,4015   blotch 0,00147

    'Accurate' giu van TOT HON 'Fast' that (0,4242 so voi 0,4015) va sach
    hon mot chut. Nen day la mot CUOC DOI, khong phai mot lan sua loi:

        tren bo xu ly, ha xuong 'Fast' cat 79% thoi gian compositing
        va tra bang 5% van vat lieu.

    ⛔ VA DUCPHAN DA CHOT: *"ket qua split nhu truoc khi sua la rat on"*
    (16/09/2026). Tuc la muc 'Accurate' LA CAI MOC, khong duoc ha xuong de
    doi lay thoi gian. Nen ham nay tra ve 'Accurate' o MOI truong hop.

    Da co mot ban truoc tu ha xuong 'Fast' khi compositor chay tren bo xu ly.
    BO ROI, va dung dat lai: no cat 79% thoi gian cho that, nhung tra bang
    5% van vat lieu — ma van vat lieu chinh la thu duy nhat ca addon nay
    sinh ra de giu. Doi mot thu nhu the la viec cua chu du an, khong phai
    cua mot ham chon ngam.

    Duong di dung cho may cham: DUA COMPOSITOR LEN CARD. Tren card
    'Accurate' chi ton +5,3s — khong mat mot chut chat luong nao va con
    nhanh hon ca 'Fast' tren bo xu ly (+7,0s). Xem `card_dung_duoc()` va
    `tools/kiem_compositing.py`: neu may khong mo duoc nen do hoa thi cho
    Blender mot man hinh (`xvfb-run`, EGL) la xong.

    Ai that su muon doi thi bang Advanced van co du bon lua chon.
    """
    return 'Accurate'


_CARD = {}


def card_dung_duoc():
    """Phien Blender NAY co mo duoc nen do hoa khong.

    VI SAO PHAI HOI. `render.compositor_device` nam TRONG FILE .blend, nen no
    di theo file sang may khac. File dung tren may Windows co card ghi 'GPU';
    mang sang may render Linux khong mo duoc nen do hoa thi Blender LANG LE
    rot compositor ve bo xu ly — o chinh van ghi 'GPU', ma cai chay that la
    CPU, va do la o dat nhat bang (+30,9s so voi +5,3s, do 16/09/2026).

    Co cua so thi khoi hoi: da ve duoc giao dien la da co nen do hoa.
    Chay nen (`blender -b`) thi phai thu that — `gpu.init()` chinh la cai
    Blender tu goi khi no can chay compositor tren card, nen goi no o day
    khong them rui ro nao: may nao lam Blender chet o day thi cung chet o
    duong cua Blender.

    Do MOT LAN roi nho: cai nay khong doi giua chung mot phien.
    `DP_OPT_BO_QUA_DO_CARD=1` de bo han phep do nay neu no gay chuyen.
    """
    if 'kq' in _CARD:
        return _CARD['kq']
    if os.environ.get('DP_OPT_BO_QUA_DO_CARD'):
        _CARD['kq'], _CARD['vi'] = True, "bo qua theo DP_OPT_BO_QUA_DO_CARD"
        return True
    if not bpy.app.background:
        _CARD['kq'], _CARD['vi'] = True, "co cua so"
        return True
    try:
        import gpu
        try:
            nen = gpu.platform.backend_type_get()
        except Exception:                                  # noqa: BLE001
            # Chua khoi dong module gpu — day la trang thai BINH THUONG khi
            # chay nen, khong phai loi. Thu khoi dong.
            gpu.init()
            nen = gpu.platform.backend_type_get()
        ok = bool(nen) and str(nen).upper() != 'NONE'
        _CARD['kq'] = ok
        _CARD['vi'] = "nen do hoa = %s" % nen
        if ok:
            try:
                _CARD['vi'] += " (%s)" % gpu.platform.renderer_get()
            except Exception:                              # noqa: BLE001
                pass
    except Exception as e:                                 # noqa: BLE001
        # Khong mo duoc nen do hoa: day CHINH LA ca ma ham nay di tim.
        _CARD['kq'] = False
        _CARD['vi'] = "khong mo duoc nen do hoa: %s" % e
    return _CARD['kq']


def vi_sao_card():
    """Cau giai thich cua lan do gan nhat, de in ra nhat ky / bang."""
    if 'vi' not in _CARD:
        card_dung_duoc()
    return _CARD.get('vi', '')


def _compositor_tren_card(scene):
    """Compositor cua scene nay se THUC SU chay tren card hay khong.

    Hai dieu kien, va phai du CA HAI:
      1. o chinh trong file bao 'GPU';
      2. may NAY mo duoc nen do hoa — xem `card_dung_duoc`.

    Thieu dieu 2 ma van tin dieu 1 thi dung la cai bay da lam nen chuyen:
    file bao GPU, may chay CPU, addon chon muc loc dat nhat cho mot thiet bi
    khong he duoc dung.
    """
    r = scene.render
    if 'compositor_device' in r.bl_rna.properties:
        if r.compositor_device != 'GPU':
            return False
    elif settings.compositor_device_for(scene) != 'GPU':
        return False
    return card_dung_duoc()


def enable_passes(view_layer, scene=None, want=None):
    """Bat dung nhung pass can. TRA VE trang thai truoc do de con tra lai.

    LUAT 2 CUA ADDON: khong de lai dau vet trong file cua khach. Do that
    06/08/2026 truoc khi sua: mot lan bam Verify bat len 13 pass tren view
    layer cua khach va KHONG BAO GIO tat lai. Khach khong nhin vao bang
    Passes thi khong ai biet, chi thay tu do moi lan render deu ton them bo
    nho va thoi gian — mot cong cu toi uu render lam render nang them.

    `denoising_store_passes` CHI BAT KHI CANH CO KINH/NUOC. Voi nhanh
    Diffuse/Glossy thi khong can: pass Color cua chinh nhanh do da la albedo
    sat hon, con `use_pass_normal` re hon. Nhung nhanh Transmission thi phai
    co — xem khoi chu thich "HUONG DAN" trong `build`. Canh khong co kinh
    khong ton them mot byte nao.
    """
    scene = scene or bpy.context.scene
    want = want if want is not None else needed(scene)

    saved = snapshot_passes(view_layer)
    on = list(CORE_PASSES)
    if want.get('transmission'):
        on += list(TRANSMISSION_PASSES)
        # HAI PASS HUONG DAN CHO NHANH TRANSMISSION — sua 19/09/2026.
        # Cycles ghi 'Denoising Albedo' / 'Denoising Normal' bang cach di
        # XUYEN QUA kinh: chung ta cai vat NAM SAU kinh, dung cai ma nhanh
        # Transmission dang khu nhieu. Thieu chung thi bo khu nhieu chi nhin
        # thay mat kinh phang li va no boi sach do trong tu — xem khoi
        # "HUONG DAN" trong `build`.
        #
        # VA CHUNG THAY LUON `use_pass_normal`, nen chi phi that CHI BANG
        # MOT NUA. Do 19/09/2026, 1920x1080, 64 mau, canh co kinh
        # (`tools/probe_sau_kinh_bu.py`, nhieu cua phep do 0,06s):
        #
        #     truoc sua                      5,469 s
        #     them 2 pass, VAN giu Normal    5,848 s   +6,9%
        #     them 2 pass, BO Normal         5,666 s   +3,6%   <- dang dung
        #
        # Bo `use_pass_normal` KHONG doi chat luong mot chut nao: nhanh
        # Diffuse/Glossy chuyen sang 'Denoising Normal' cho ra dung con so
        # cu (vung de tran texture 1,0174 -> 1,0177, sai so 0,00318 y het).
        # Da kiem ca tren SAN GUONG roughness 0,05 — cho de hong nhat, vi
        # 'Denoising Normal' di xuyen qua mat bong: 0,9594 -> 0,9596, khong
        # doi (`tools/probe_sau_kinh_guong.py`).
        #
        # Canh KHONG co kinh khong dinh gi o day: khong them mot pass nao,
        # khong them mot giay nao.
        if 'denoising_store_passes' in view_layer.cycles.bl_rna.properties:
            view_layer.cycles.denoising_store_passes = True
            if (scene.render.engine == 'CYCLES'
                    and view_layer.cycles.denoising_store_passes
                    and 'use_pass_normal' in on):
                on.remove('use_pass_normal')
    # CHI BAT THEM, KHONG TAT CUA AI. Mot pass dang bat co the la khach tu
    # bat cho viec cua ho; tat no di la lang le lam hong mot thu khac trong
    # file. Cai loi toc do o day den tu viec KHONG bat thua, chu khong phai
    # tu viec tat bot cua nguoi khac.
    for p in on:
        if p in view_layer.bl_rna.properties:
            setattr(view_layer, p, True)
    if want.get('volume'):
        for p in CYCLES_LAYER_PASSES:
            if p in view_layer.cycles.bl_rna.properties:
                setattr(view_layer.cycles, p, True)
    return saved


class _Builder:
    def __init__(self, tree):
        self.tree = tree
        self.x = 0

    def mix(self, blend, a, b):
        n = self.tree.nodes.new('ShaderNodeMix')
        n.data_type = 'RGBA'
        n.blend_type = blend
        n.location = (self.x, 0)
        self.x += 180
        n.inputs['Factor'].default_value = 1.0
        ia = [s for s in n.inputs if s.name == 'A' and s.enabled][0]
        ib = [s for s in n.inputs if s.name == 'B' and s.enabled][0]
        self.tree.links.new(a, ia)
        if isinstance(b, tuple):
            ib.default_value = b          # hang so, vd. san cho phep chia
        else:
            self.tree.links.new(b, ib)
        return [s for s in n.outputs if s.enabled][0]

    def add(self, a, b):
        return self.mix('ADD', a, b)

    def mul(self, a, b):
        return self.mix('MULTIPLY', a, b)


def build(scene, view_layer=None, use_denoise=True, prefilter='Auto',
          quality='Follow Scene', denoise_volume=True):
    """Dung cay compositor tach kenh. Tra ve node group vua tao.

    `prefilter='Auto'` (mac dinh) de `auto_prefilter` chon theo cho compositor
    se chay — xem khoi chu thich cua ham do, day la cho quyet dinh thoi gian
    cho sau khi render xong.
    """
    view_layer = view_layer or bpy.context.view_layer
    want = needed(scene)
    if prefilter in (None, 'Auto'):
        prefilter = auto_prefilter(scene)

    old = scene.compositing_node_group
    was_ours = old is not None and old.name.startswith(GROUP_NAME)

    saved = enable_passes(view_layer, scene, want)
    # CHI GHI LAN DAU. Dung lai cay (doi Prefilter roi bam Build lai) ma ghi
    # de thi thu duoc cat lai la trang thai DA BAT SAN cua chinh addon —
    # luc bam Remove se tra ve dung nhung pass thua ma no vua bat.
    if SAVED_KEY not in scene.keys() or not was_ours:
        scene[SAVED_KEY] = json.dumps({'layer': view_layer.name, 'passes': saved})

    if was_ours:
        scene.compositing_node_group = None
        try:
            bpy.data.node_groups.remove(old)
        except Exception:
            pass

    tree = bpy.data.node_groups.new(GROUP_NAME, "CompositorNodeTree")
    tree[TREE_VER_KEY] = TREE_VER
    scene.compositing_node_group = tree
    tree.interface.new_socket(name="Image", in_out='OUTPUT',
                              socket_type="NodeSocketColor")

    rl = tree.nodes.new('CompositorNodeRLayers')
    rl.scene = scene
    rl.layer = view_layer.name
    rl.location = (-900, 0)
    out = rl.outputs

    b = _Builder(tree)

    # HUONG DAN cho bo khu nhieu — HAI BO KHAC NHAU, VA KHONG DUOC DUNG LAN.
    #
    # Nhanh Diffuse/Glossy khu nhieu anh sang tren CHINH cai mat tia camera
    # vua cham, nen pass Color cua nhanh do la albedo dung. Phap tuyen lay
    # 'Denoising Normal' neu co, khong thi 'Normal' — hai cai cho ra cung
    # mot ket qua, do o duoi va do ca tren san guong.
    #
    # Nhanh Transmission thi khac han: anh cua no nam SAU tam kinh, con
    # 'Transmission Color' va 'Normal' deu ta CHINH TAM KINH — ca hai phang
    # li, mot mau, tren suot mat kinh. Dua chung vao la noi voi OIDN rang
    # "cho nay la mot mat phang tron, mot mau", va no boi sach moi thu nhin
    # thay qua kinh.
    #
    # DO THAT 19/09/2026 - canh nua trai co kinh, nua phai de tran, CUNG mot
    # tam van, cung nguon sang, 16 mau, 800x450 (`tools/probe_sau_kinh.py`).
    # `texture` = van vat lieu con lai so voi anh chuan 512 mau:
    #
    #     huong dan cho nhanh Transmission     sau kinh   de tran
    #     Transmission Color + Normal            0,540     1,129  <- CU, hong
    #     khong huong dan gi                     0,676     1,129
    #     Denoising Albedo + Denoising Normal    0,810     1,129  <- dang dung
    #     (de so: Cycles denoise, khong Split)   0,812     0,995
    #
    # Cot "de tran" khong nhuc nhich o ca ba dong: sua nay khong cham vao
    # nhanh Diffuse/Glossy. Con sau kinh thi tra lai dung cai da mat - ngang
    # voi Cycles tu khu nhieu, trong khi ngoai vung kinh Split van hon
    # Cycles nhu cu.
    #
    # 'Denoising Albedo' / 'Denoising Normal' la hai pass Cycles ghi bang
    # cach DI XUYEN QUA kinh, nen chung ta cai vat SAU kinh - dung cai ma
    # nhanh Transmission dang khu nhieu. `enable_passes` bat chung CHI khi
    # canh co kinh, va bo `use_pass_normal` di de khoi tra tien hai lan.
    #
    # Thieu chung (khong phai Cycles, khach tu tat pass) thi nhanh
    # Transmission chay KHONG HUONG DAN: 0,676 - mo hon mot chut, nhung van
    # hon han 0,540 cua kieu dau day cu.
    dn_albedo = out.get('Denoising Albedo')
    dn_normal = out.get('Denoising Normal')
    normal = dn_normal if dn_normal is not None else out.get('Normal')

    def denoise(sock, guide_albedo=None, guide_normal=None, label=""):
        if not use_denoise:
            return sock
        n = tree.nodes.new('CompositorNodeDenoise')
        n.location = (b.x, 220)
        n.label = label
        b.x += 180
        tree.links.new(sock, n.inputs['Image'])
        if guide_albedo is not None:
            tree.links.new(guide_albedo, n.inputs['Albedo'])
        if guide_normal is not None:
            tree.links.new(guide_normal, n.inputs['Normal'])
        # 5.2: Prefilter/Quality la NodeSocketMenu, nhan CHUOI HIEN THI.
        for name, value in (('Prefilter', prefilter), ('Quality', quality)):
            if name in n.inputs:
                try:
                    n.inputs[name].default_value = value
                except TypeError:
                    pass
        return n.outputs['Image']

    total = None

    def acc(sock):
        nonlocal total
        total = sock if total is None else b.add(total, sock)

    # (Direct + Indirect) khu nhieu tren ANH SANG, roi moi nhan pass mau.
    #
    # DAY LA CHO VAN VAT LIEU DUOC CUU. Bo khu nhieu chi nhin thay anh sang
    # — da bo van go, soi vai ra ngoai — nen no khong con phai doan xem mot
    # vet dam la nhieu hay la van. Van quay lai NGUYEN VEN o buoc nhan pass
    # Color, va pass Color thi gan nhu khong co nhieu.
    #
    # Nhanh Transmission chi dung khi scene co kinh/nuoc/la cay. Dung thua no
    # la bat bo khu nhieu chay tren mot buc anh den thui, tra bang thoi gian
    # render cua khach.
    groups = [('Diffuse Direct', 'Diffuse Indirect', 'Diffuse Color', "Diffuse"),
              ('Glossy Direct', 'Glossy Indirect', 'Glossy Color', "Glossy")]
    if want.get('transmission'):
        groups.append(('Transmission Direct', 'Transmission Indirect',
                       'Transmission Color', "Transmission"))

    for direct, indirect, color, tag in groups:
        if direct not in out or indirect not in out or color not in out:
            continue
        light = b.add(out[direct], out[indirect])
        if tag == "Transmission":
            # NHANH KINH = DAN DUONG THUONG. Khong tach mau, khong kep.
            #
            # TUYET DOI khong lay 'Transmission Color' / 'Normal' lam huong
            # dan — hai cai do ta MAT KINH, khong phai vat sau kinh (do
            # 19/09/2026, `texture` 0,540 so voi 0,810).
            #
            # ⛔ DUNG THU LAI "TACH MAU" (chia cho Denoising Albedo/Transmission
            # Color, khu nhieu, nhan lai) — da lam, da do, da GO BO 20/09/2026.
            # Ducphan render thu ban do: *"vet ghep con rat lo"*. Do tren file
            # that `mrnam khachbep.blend` (vung tu kinh, 874x875 cat ra o 100 %,
            # nen do co du phoi sang +1,0 va can bang trang 4800K nhu file anh),
            # moc = anh chuan 2048 mau DA KHU NHIEU. Thuoc: he so trung khop
            # giua chi tiet tan so cao cua ban do voi chi tiet cua anh chuan
            # (`giong van`), cang cao cang giong VAN THAT:
            #
            #     vung            dan duong thuong   tach mau co kep
            #     van go sau kinh      0,351              0,220
            #     cai binh             0,611              0,471
            #     chai + gio           0,797              0,657
            #     ca o tu tren         0,867              0,748
            #     (o 256 mau)          0,591              0,508
            #
            # Tach mau THUA o CA BON vung va o CA HAI muc mau. Muc hat cua no
            # gap 3 lan anh chuan (0,0136 so 0,0041): cai no them vao la NHIEU
            # cua lop mau, khong phai van. Ly do: phep tach phai NHAN TRO LAI
            # lop mau, ma lop mau sau hai lop kinh tu no da nhieu.
            #
            # Vi sao lop mau nhieu: tam van sau kinh la van BONG (Reflect 0,5,
            # Glossiness lay tu map) nen tia phan chieu tan moi mau mot huong,
            # 'Denoising Albedo' ghi lai cung tan theo. Do o 64 mau, vung van
            # go: Denoising Albedo `giong van` 0,171 (hat 0,0155), anh sang
            # khuc xa 0,055 (hat 0,0730) — O 64 MAU CA HAI DEU KHONG MANG VAN.
            # Khong cay ghep nao lay lai duoc cai khong co trong du lieu; chi
            # tang mau moi co (2048 mau: lop mau len 0,473).
            #
            # Cac cach chinh dan duong deu da do va deu KEM HON cach dang dung
            # (`giong van`, vung van go, 64 mau): bo phap tuyen 0,303 · bo
            # albedo 0,233 · Prefilter None 0,200 · Prefilter Fast 0,288 ·
            # dang dung (Denoising Albedo + Normal, Accurate) 0,351.
            light = denoise(light, guide_albedo=dn_albedo,
                            guide_normal=dn_normal, label=tag)
        else:
            light = denoise(light, guide_albedo=out[color],
                            guide_normal=normal, label=tag)
        acc(b.mul(light, out[color]))

    # EMISSION PHAI QUA KHU NHIEU (sua 21/09/2026).
    #
    # ⛔ CAU CU O DAY NOI: *"Emission va Environment khong phai anh sang
    # dung tia ma ra, chung la gia tri doc thang"*. Cau do SAI voi phan den
    # ma tia PHAI DI TIM. Pass Emission cua Cycles ghi ca dong gop cua mat
    # phat sang bi tia doi vao sau mot lan dap, va phan do CO NHIEU y nhu
    # moi thu khac sinh ra tu tia.
    #
    # Bang chung (21/09/2026, file that `mrnam khachbep.blend`, 64 mau, cac
    # vach kem trong hoc tu — Ducphan: *"cac phan phat sang dang bi lom
    # dom"*): cay Split de lai vet ro hat ro rang tren vach, trong khi bo
    # khu nhieu cua chinh Cycles o CUNG 64 mau cho ra vach MIN HOAN TOAN.
    # Them mot node Denoise vao day la het vet, va anh bang voi Cycles.
    #
    # ⛔ CHO NAY MOI THUOC SO DEU MU — dung tin chung. Da do ba lan bang
    # so (`blotch`, `texture`, va mot thuoc ro hat viet rieng) tren chinh
    # file do: ca ba deu bao "khong doi gi" (0,00142 -> 0,00142), trong khi
    # hai tam anh dat canh nhau thi khac han. Ly do: vet ro hat la tan so
    # CAO nen `texture` dem no vao phan "chi tiet", con `blotch` thi do o
    # vung phang cua CA KHUNG (san da hoa cuong chiem phan lon) chu khong
    # rieng may vach den. CHI ANH LA BANG CHUNG (xem LESSONS).
    #
    # Khong co huong dan nao cho node nay: 'Diffuse Color' ta be mat, khong
    # ta cai dang phat sang. Do lai: khong huong dan van sach.
    if 'Emission' in out:
        acc(denoise(out['Emission'], label="Emission"))

    # Environment (anh nen the gioi) thi GIU NGUYEN. Chua co bang chung nao
    # noi no nhieu, va them mot luot OIDN nua la them thoi gian cho moi lan
    # render. Co bang chung thi hay them.
    if 'Environment' in out:
        acc(out['Environment'])

    if want.get('volume'):
        for name in ('Volume Direct', 'Volume Indirect'):
            if name in out:
                sock = out[name]
                if denoise_volume:
                    # Khoi/suong: chi co phap tuyen lam huong dan, khong co
                    # albedo — y nhu truoc 19/09/2026. Dung dua
                    # 'Denoising Albedo' vao day: no ta be mat RAN sau man
                    # khoi, khong phai ban than man khoi.
                    sock = denoise(sock, guide_normal=normal, label=name)
                acc(sock)

    # ALPHA. Moi pass anh sang co alpha = 1 o khap noi, ke ca cho trong. Cong
    # va nhan chung lai thi ket qua cung alpha = 1 khap noi, va nen trong suot
    # bien mat — do that 06/08/2026, xem chu thich dau file. Nen phai lay
    # alpha THAT tu pass Alpha va dat de len o buoc cuoi.
    if total is not None and 'Alpha' in out:
        sa = tree.nodes.new('CompositorNodeSetAlpha')
        sa.location = (b.x + 40, 0)
        b.x += 180
        tree.links.new(total, sa.inputs['Image'])
        tree.links.new(out['Alpha'], sa.inputs['Alpha'])
        # 'Type' la NodeSocketMenu nhan chuoi hien thi. Phai la thay the han
        # alpha, khong phai nhan them mot lop mask nua.
        if 'Type' in sa.inputs:
            try:
                sa.inputs['Type'].default_value = 'Replace Alpha'
            except TypeError:
                pass
        total = sa.outputs['Image']

    go = tree.nodes.new('NodeGroupOutput')
    go.location = (b.x + 200, 0)
    if total is not None:
        tree.links.new(total, go.inputs[0])
    return tree


def clear(scene):
    """Go cay cua addon ra VA tra lai cac pass no da bat.

    KHONG dung vao cay do khach tu dung. Va go cay khong thoi la chua xong:
    13 pass van con bat tren view layer, moi lan render sau do deu ton them
    bo nho ma khach khong hieu tai sao.
    """
    tree = scene.compositing_node_group
    if tree is None:
        return False
    if not tree.name.startswith(GROUP_NAME):
        return False
    scene.compositing_node_group = None
    try:
        bpy.data.node_groups.remove(tree)
    except Exception:
        pass
    restore_saved_passes(scene)
    return True


def restore_saved_passes(scene):
    """Tra lai cac pass da cat o `SAVED_KEY`, roi xoa cho cat di.

    Khong tim thay cho cat thi khong doi gi ca — tha de thua vai pass con hon
    tat nham mot pass ma khach dang can cho cay compositor cua rieng ho.
    """
    raw = scene.get(SAVED_KEY)
    if not raw:
        return False
    try:
        data = json.loads(raw)
    except (ValueError, TypeError):
        del scene[SAVED_KEY]
        return False
    name = data.get('layer')
    vl = scene.view_layers.get(name) if name else None
    if vl is None:
        vl = bpy.context.view_layer
    restore_passes(vl, data.get('passes') or {})
    try:
        del scene[SAVED_KEY]
    except (KeyError, TypeError):
        pass
    return True


def tree_cost(scene):
    """Cay DANG GAN tra gia bao nhieu: may node Denoise, prefilter nao, o dau.

    Doc tu CHINH CAY chu khong tu o chinh trong bang. Cay di theo file .blend:
    dung o may co card roi gui file sang may render khong co card thi o chinh
    van ghi mot dang, ma cai dang chay lai la cai da dong san trong cay.

    CHI DOC — goi duoc tu `draw`.
    """
    tree = scene.compositing_node_group
    if tree is None or not tree.name.startswith(GROUP_NAME):
        return None
    pfs = []
    n = 0
    for node in tree.nodes:
        if node.bl_idname != 'CompositorNodeDenoise':
            continue
        n += 1
        sock = node.inputs.get('Prefilter')
        if sock is not None:
            pfs.append(str(sock.default_value))
    return dict(nodes=n, prefilters=sorted(set(pfs)),
                on_gpu=_compositor_tren_card(scene),
                dat=bool(n) and not _compositor_tren_card(scene)
                    and 'Accurate' in pfs)


# --------------------------------------------------------------------------
# NOI TRUOC KHI RENDER: lan nay se phai cho bao lau vi cai gi
# --------------------------------------------------------------------------
#
# ⛔ BAN TRUOC O DAY TU HA MUC LOC XUONG 'Fast' luc render, roi tra lai sau.
# DA BO. Ducphan chot 16/09/2026: *"ket qua split nhu truoc khi sua la rat
# on"* — muc 'Accurate' la cai MOC, khong duoc doi lay thoi gian sau lung
# nguoi dung. Dung dat lai: no chay dung, nhung no chua sai de.
#
# Cai con lai o day khong doi MOT BYTE nao trong file cua khach. No chi noi
# ra, truoc khi bat dau cho, rang lan render nay sap ton them bao nhieu va
# vi sao — de nguoi ngoi doi biet duong ma chua CAI DUNG:
#
#     compositor tren card   'Accurate' +5,3s
#     compositor tren CPU    'Accurate' +30,9s
#
# Cung mot chat luong. Chenh nhau 6 lan, va toan bo cho chenh nam o cho
# compositor chay — khong o muc loc.

_DA_NOI = set()
_DEV_CU = {}


def theo_may_dang_chay(scene):
    """Dua compositor ve dung thiet bi cua MAY DANG RENDER, roi tra lai sau.

    `render.compositor_device` nam TRONG file .blend. No duoc dat mot lan,
    luc bam nut, tren may LUC DO — roi di theo file mai mai. May render la
    mot may khac, co thiet bi khac, va khong ai bam nut tren do bao gio.
    Nen o chinh trong file noi mot dang ma may dang chay lai la mot dang.

    Day KHONG phai mot lua chon moi: luat cua addon van la "Cycles chon sao
    thi tool chay vay" (xem `settings.compositor_device_for`). Chi la truoc
    day luat ay duoc ap mot lan roi dong bang vao file; nay no duoc ap tren
    dung may dang lam viec.

    KHONG DOI CHAT LUONG MOT CHUT NAO — cung cay do, cung muc loc do, chi
    khac cho tinh. Va tra lai sau khi render xong, nen file cua khach khong
    bi sua.
    """
    r = scene.render
    if 'compositor_device' not in r.bl_rna.properties:
        return None
    if not is_active(scene):
        return None                     # khong phai cay cua minh thi khong dung
    nen = settings.compositor_device_for(scene)
    if r.compositor_device == nen:
        return None
    _DEV_CU['cu'] = r.compositor_device
    r.compositor_device = nen
    cau = ("[DP-OptimizeRender] o chinh trong file de compositor o %s, nhung "
           "may nay dang render bang %s — chuyen compositor sang %s cho lan "
           "render nay (cung cay, cung chat luong, chi khac cho tinh). O "
           "chinh trong file khong doi."
           % (_DEV_CU['cu'], settings.device_label(scene), nen))
    print(cau)
    return cau


def tra_lai_thiet_bi(scene):
    """Tra `compositor_device` ve dung nhu trong file. Goi lai vo hai."""
    if 'cu' not in _DEV_CU:
        return False
    r = scene.render
    try:
        if 'compositor_device' in r.bl_rna.properties:
            r.compositor_device = _DEV_CU['cu']
    except (TypeError, AttributeError):
        pass
    _DEV_CU.clear()
    return True


def canh_bao_cham(scene):
    """In mot dong neu lan render nay se tra gia dat cho compositing.

    Tra ve cau da in (hoac None). KHONG DOI GI trong file — day la mot cau
    noi, khong phai mot cai sua.

    Chi noi MOT LAN cho moi ly do trong mot phien: render mot doan phim ma
    in 250 dong giong het nhau thi khong ai doc nua.
    """
    tree = scene.compositing_node_group
    if tree is None or not tree.name.startswith(GROUP_NAME):
        return None
    dn = [n for n in tree.nodes if n.bl_idname == 'CompositorNodeDenoise']
    if not dn:
        return None
    if _compositor_tren_card(scene):
        return None

    dat = any('Prefilter' in n.inputs
              and str(n.inputs['Prefilter'].default_value) == 'Accurate'
              for n in dn)
    if not card_dung_duoc():
        # SUA DUOC — va sua thi khong mat chut chat luong nao.
        ly_do = ("may nay khong mo duoc nen do hoa (%s) nen Blender rot "
                 "compositor ve bo xu ly" % vi_sao_card())
        chua = ("cho Blender thay mot man hinh (chay qua `xvfb-run`, hoac ban "
                "Blender co EGL) thi compositor len card: cung chat luong, "
                "nhanh hon khoang 6 lan")
    else:
        ly_do = "compositor dang duoc dat chay tren bo xu ly"
        chua = ("bat mot thiet bi GPU trong Preferences > System cho Cycles, "
                "roi bam lai Protect Texture Detail")
    cau = ("[DP-OptimizeRender] %d node khu nhieu se chay tren BO XU LY sau "
           "khi render xong%s — %s. Cach chua: %s."
           % (len(dn), " o muc 'Accurate' (dat nhat)" if dat else "",
              ly_do, chua))
    _LAN_CUOI_CD['cau'] = cau
    # ⛔ BANG CUA NGUOI DUNG PHAI LA TIENG ANH. Cau tren la cau viet cho
    # NHAT KY (tieng Viet khong dau), va `ui.py` lai dua thang no len bang —
    # cat cut o 58 ky tu vi no khong co dau "|" de tach dong. Nen o day dung
    # mot cau RIENG cho bang, con cau tren giu nguyen cho `print`.
    _LAN_CUOI_CD['ui'] = (
        "%d denoise passes will run on the PROCESSOR after this render%s. | "
        "%s" % (len(dn), " at 'Accurate' (the most expensive)" if dat else "",
                "No graphics backend here, so Blender fell back to the "
                "processor: run through `xvfb-run` or a Blender build with "
                "EGL and the compositor goes back on the GPU"
                if not card_dung_duoc() else
                "The compositor is set to the processor: enable a GPU device "
                "in Preferences > System for Cycles, then press Protect "
                "Texture Detail again"))
    if cau not in _DA_NOI:
        _DA_NOI.add(cau)
        print(cau)
    return cau


_LAN_CUOI_CD = {}


def chan_doan_lan_cuoi():
    """Dong chan doan cua lan render gan nhat, de BANG doc lai.

    Giu trong bien cua module chu KHONG ghi vao Scene: ghi vao Scene la lam
    file cua khach thanh "da sua", va Blender se hoi co luu khong luc thoat
    — chi vi mot cau thong bao. CHI DOC, goi duoc tu `draw`.

    ⛔ TRA VE BAN TIENG ANH (`'ui'`), khong phai `'cau'`. `'cau'` la cau
    viet cho NHAT KY, bang tieng Viet khong dau — dua thang no len bang la
    chu tieng Viet hien ra trong mot giao dien tieng Anh, va vi no khong co
    dau "|" nen `ui.py` con cat cut o 58 ky tu.
    """
    return _LAN_CUOI_CD.get('ui')


def quen_canh_bao():
    """Quen nhung cau da noi (mo file khac thi noi lai tu dau)."""
    _DA_NOI.clear()
    _DEV_CU.clear()
    _LAN_CUOI_CD.clear()


def dong_chan_doan(scene):
    """MOT DONG noi ro lan render nay se chay o dau va ton them bao nhieu.

    VI SAO IN RA MOI LAN. May render co the o noi khac, va nguoi doi no
    khong ngoi canh no. Mot bai kiem "chay lenh nay tren may do" chi dung
    khi co nguoi ngoi o do go duoc. Nen cau tra loi phai TU DEN — nam san
    trong nhat ky cua chinh lan render ma ho dang cho.

    In mot lan cho moi noi dung: 250 khung khong in 250 dong giong het nhau.
    """
    if not is_active(scene):
        return None
    r = scene.render
    dn = denoise_count(scene)
    w = int(r.resolution_x * r.resolution_percentage / 100.0)
    h = int(r.resolution_y * r.resolution_percentage / 100.0)
    tren_card = _compositor_tren_card(scene)
    cau = ("[DP-OptimizeRender] Split dang bat: %d luot khu nhieu tren anh "
           "%dx%d, chay bang %s | o chinh=%s | Cycles=%s | nen do hoa: %s"
           % (dn, w, h, "CARD" if tren_card else "BO XU LY",
              getattr(r, 'compositor_device', '?'),
              settings.device_label(scene), vi_sao_card()))
    if cau not in _DA_NOI:
        _DA_NOI.add(cau)
        print(cau)
    return cau


def is_active(scene):
    tree = scene.compositing_node_group
    return tree is not None and tree.name.startswith(GROUP_NAME)


# --------------------------------------------------------------------------
# CAY DUNG TU TRUOC BAN SUA KINH (19/09/2026)
#
# Cay compositor NAM TRONG FILE .blend. Cai addon moi khong doi mot node nao
# cua cay da luu. Ducphan 20/09/2026: *"tao vua kiem tra, loi mat het chi tiet
# sau kinh van con"* — Blender cua anh da chay ma moi, nhung file
# `mrnam khachbep.blend` van mang cay cu: node Transmission lay
# 'Transmission Color' + 'Normal'. Ban sua chi co tac dung voi cay DUNG MOI.
# --------------------------------------------------------------------------

_DA_DUNG_LAI = {}


def cay_loi_thoi(scene, kiem_thieu_nhanh=False):
    """Cay cua addon tren scene nay co phai dung tu truoc ban sua kinh khong.

    Tra ve cau ly do (tieng Anh, hien tren bang) hoac None.

    `kiem_thieu_nhanh=True` hoi them "canh co kinh ma cay khong co nhanh
    Transmission" — cay dung khi addon con chua thay kinh trong Collection
    Instance / Geometry Nodes. Phep nay goi `needed()`, nen chi dung luc mo
    file, KHONG dung trong `draw()`.
    """
    tree = scene.compositing_node_group
    if tree is None or not tree.name.startswith(GROUP_NAME):
        return None
    co_nhanh = False
    for n in tree.nodes:
        if n.bl_idname == 'CompositorNodeDenoise' and n.label == "Transmission":
            lk = n.inputs['Albedo'].links
            if lk and lk[0].from_socket.name == 'Transmission Color':
                return "Glass channel is denoised by the glass surface"
        if n.bl_idname == 'CompositorNodeRLayers':
            s = n.outputs.get('Transmission Direct')
            if s is not None and s.is_linked:
                co_nhanh = True
    if co_nhanh and int(tree.get(TREE_VER_KEY, 0)) < TREE_VER:
        return "Glass channel from an older version loses detail"
    if kiem_thieu_nhanh and not co_nhanh and needed(scene).get('transmission'):
        return "Scene has glass but the graph has no glass channel"
    return None


def dung_lai(scene):
    """Dung lai cay cua addon bang ma hien tai, GIU cac lua chon cu.

    Doc Prefilter / Quality / co khu nhieu hay khong / co khu nhieu khoi hay
    khong tu CHINH CAY CU, de khach khong mat lua chon ho da dat.
    """
    tree = scene.compositing_node_group
    dn = [n for n in tree.nodes if n.bl_idname == 'CompositorNodeDenoise']
    pf = qa = None
    for n in dn:
        s = n.inputs.get('Prefilter')
        if pf is None and s is not None:
            pf = str(s.default_value)
        s = n.inputs.get('Quality')
        if qa is None and s is not None:
            qa = str(s.default_value)
    rl = [n for n in tree.nodes if n.bl_idname == 'CompositorNodeRLayers']
    vl = scene.view_layers.get(rl[0].layer) if rl else None
    if vl is None:
        vl = scene.view_layers[0]
    want = needed(scene)
    dv = (not want.get('volume')
          or any(n.label.startswith('Volume') for n in dn))
    build(scene, vl, use_denoise=bool(dn), prefilter=pf or 'Auto',
          quality=qa or 'Follow Scene', denoise_volume=dv)


def nang_cap_cay_cu():
    """Luc mo file: moi scene co cay loi thoi thi dung lai, va NOI RA.

    Chay trong `load_post` (luong chinh, file vua mo xong). Khong chay trong
    handler render — HANDOFF 17/09: doi cai dat scene trong handler render la
    sap Blender.
    """
    _DA_DUNG_LAI.clear()
    for sc in bpy.data.scenes:
        try:
            ly_do = cay_loi_thoi(sc, kiem_thieu_nhanh=True)
            if ly_do:
                dung_lai(sc)
                _DA_DUNG_LAI[sc.name] = ly_do
                print("[DP-OptimizeRender] %s: cay Split dung tu ban cu (%s) "
                      "-> da dung lai." % (sc.name, ly_do))
        except Exception as e:                             # noqa: BLE001
            print("[DP-OptimizeRender] %s: khong dung lai duoc cay Split: %s"
                  % (sc.name, e))


def da_dung_lai(scene):
    """Cau ly do neu cay cua scene nay vua duoc dung lai luc mo file."""
    return _DA_DUNG_LAI.get(scene.name)


# --------------------------------------------------------------------------
# Kiem chung: ghep lai co dung bang anh Combined khong?
# --------------------------------------------------------------------------

def _load_rgba(path):
    """Doc EXR ra RGBA DAY DU.

    `metrics.load` cat mat alpha, va chinh cho cat do da giau mot loi that:
    ngay 06/08/2026 `verify()` bao dat trong khi anh ghep lai da mat sach nen
    trong suot. Muon bat lai loi ay thi phai doc ca kenh thu tu.
    """
    img = bpy.data.images.load(path, check_existing=False)
    try:
        w, h = img.size
        buf = np.empty(w * h * 4, dtype=np.float32)
        img.pixels.foreach_get(buf)
    finally:
        bpy.data.images.remove(img)
    return buf.reshape(h, w, 4)


def verify(scene, region_size=40.0, samples=32, view_layer=None):
    """Render hai lan roi doi chieu. TAT denoise de doi chieu TOAN HOC.

    Tra ve dict: max_diff, mean_diff, alpha_max_diff, alpha_mean_diff, secs.
    `max_diff` phai o muc sai so dau cham dong (~1e-6). Lech lon nghia la
    thieu mot pass, khong phai "gan dung".

    KHONG DE LAI DAU VET. Ke ca cac pass tren view layer — cai nay tung bi bo
    sot va bat len 13 pass vinh vien tren file cua khach.
    """
    r = scene.render
    cy = scene.cycles
    ims = r.image_settings
    vl = view_layer or bpy.context.view_layer
    saved_passes = snapshot_passes(vl)
    had_key = SAVED_KEY in scene.keys()
    saved_key = scene.get(SAVED_KEY) if had_key else None
    saved = dict(
        use_border=r.use_border, bx0=r.border_min_x, bx1=r.border_max_x,
        by0=r.border_min_y, by1=r.border_max_y, crop=r.use_crop_to_border,
        comp=r.use_compositing, path=r.filepath, ff=ims.file_format,
        cd=ims.color_depth, cm=ims.color_mode, den=cy.use_denoising,
        smp=cy.samples, adapt=cy.use_adaptive_sampling, seed=cy.seed,
        aseed=cy.use_animated_seed, group=scene.compositing_node_group,
        prec=getattr(r, 'compositor_precision', None))
    out = {}
    made = None
    try:
        # THAO cay dang gan ra TRUOC, dung de `build()` gap no. `build()` xoa
        # han cay cu neu do la cay cua addon — nghia la bam Verify trong luc
        # Split dang bat se XOA cay cua khach, roi `finally` gan lai mot con
        # tro da chet. Thao ra truoc thi `build()` khong thay gi de xoa.
        scene.compositing_node_group = None

        half = max(0.02, min(0.5, region_size / 200.0))
        r.use_border = True
        r.use_crop_to_border = True
        r.border_min_x, r.border_max_x = 0.5 - half, 0.5 + half
        r.border_min_y, r.border_max_y = 0.5 - half, 0.5 + half
        ims.file_format, ims.color_depth, ims.color_mode = 'OPEN_EXR', '32', 'RGBA'
        cy.use_denoising = False
        cy.use_adaptive_sampling = False
        cy.samples = samples
        cy.use_animated_seed = False
        cy.seed = 7

        t0 = time.perf_counter()

        # ⛔ DO NHIEU CUA CHINH PHEP DO TRUOC, ROI MOI PHAN.
        #
        # Ban truoc render hai lan — mot lan anh Combined, mot lan qua cay —
        # roi doi chung khop den sai so dau cham dong. Tien de ay SAI: no gia
        # dinh render hai lan ra CUNG MOT buc anh.
        #
        # Do 16/09/2026 tren PN4.blend (may bat ca 2 card lan CPU cho Cycles):
        #
        #     hai lan render Y HET NHAU            lech lon nhat 0,832
        #     Combined vs ghep lai                 lech lon nhat 0,484
        #
        # Sai so cua phep do (0,832) con LON HON cai no dinh do (0,484). Nen
        # phep kiem bao "Rebuild does NOT match" trong khi cay ghep hoan toan
        # dung — va mot phep kiem bao sai ve mot thu dang chay tot thi te hon
        # la khong co phep kiem nao.
        #
        # Nay: render anh Combined HAI LAN de biet ban than no dao dong bao
        # nhieu, roi so cai lech cua phep ghep VOI con so do. Cach nay dung
        # ca khi render lap lai duoc (nhieu = 0, doi hoi nghiem nhu cu) lan
        # khi khong (nhieu lon, va lech nho hon nhieu thi khong ket toi duoc).
        # ⛔ EP DO CHINH XAC DAY. Mac dinh `compositor_precision` la 'AUTO',
        # va AUTO nghia la compositor chay bang so thuc NUA (float16) tren
        # card. Day la mot phep kiem TOAN HOC — hoi xem cong tru nhan co ra
        # dung khong — nen no khong duoc phep tinh o nua do chinh xac.
        #
        # Do 16/09/2026 tren PN4.blend, cung mot cay, chi doi moi o nay:
        #
        #     AUTO (float16)  lech trung binh 0,000057
        #     FULL (float32)  lech trung binh 0,00000001
        #
        # Tuc la toan bo cai "sai" ma phep kiem tung to cao cay Split chinh
        # la sai so lam tron cua so thuc nua. Cay ghep DUNG.
        if 'compositor_precision' in r.bl_rna.properties:
            r.compositor_precision = 'FULL'

        made = build(scene, vl, use_denoise=False)

        r.use_compositing = False
        beauty = _render(scene, "verify_beauty")
        beauty2 = _render(scene, "verify_beauty2")

        r.use_compositing = True
        recomb = _render(scene, "verify_recomb")

        a = _load_rgba(beauty)
        a2 = _load_rgba(beauty2)
        c = _load_rgba(recomb)
        for p in (beauty, beauty2, recomb):
            try:
                os.unlink(p)
            except OSError:
                pass

        if a.shape != c.shape:
            out = dict(ok=False, reason="kich thuoc khac nhau")
        else:
            # RGB va ALPHA do RIENG. Gop lai thi mot cai nen trong suot bi
            # dac lai chi keo trung binh chung len mot chut va lot qua het.
            d = np.abs(a[:, :, :3] - c[:, :, :3])
            da = np.abs(a[:, :, 3] - c[:, :, 3])
            # NHIEU CUA PHEP DO: hai lan render y het nhau lech nhau bao
            # nhieu. Cai gi nho hon con so nay thi phep do khong noi duoc.
            nhieu = np.abs(a[:, :, :3] - a2[:, :, :3])
            out = dict(ok=True, max_diff=float(d.max()),
                       mean_diff=float(d.mean()),
                       alpha_max_diff=float(da.max()),
                       alpha_mean_diff=float(da.mean()),
                       noise_max=float(nhieu.max()),
                       noise_mean=float(nhieu.mean()),
                       transparent=bool(r.film_transparent),
                       secs=time.perf_counter() - t0)
    finally:
        if made is not None:
            scene.compositing_node_group = None
            try:
                bpy.data.node_groups.remove(made)
            except Exception:
                pass
        r.use_border = saved['use_border']
        r.border_min_x, r.border_max_x = saved['bx0'], saved['bx1']
        r.border_min_y, r.border_max_y = saved['by0'], saved['by1']
        r.use_crop_to_border = saved['crop']
        r.use_compositing = saved['comp']
        r.filepath = saved['path']
        ims.file_format, ims.color_depth, ims.color_mode = (
            saved['ff'], saved['cd'], saved['cm'])
        cy.use_denoising = saved['den']
        cy.samples = saved['smp']
        cy.use_adaptive_sampling = saved['adapt']
        cy.seed = saved['seed']
        cy.use_animated_seed = saved['aseed']
        scene.compositing_node_group = saved['group']
        if saved.get('prec') is not None:
            try:
                r.compositor_precision = saved['prec']
            except (TypeError, AttributeError):
                pass
        # `build()` o tren da bat 13 pass va ghi cho cat cua no. Tra lai het,
        # roi tra lai luon cai cho cat — neu khach dang co cay Split cua addon
        # song san thi cho cat do la CUA HO, khong duoc de phep kiem nay lam
        # mat: mat no la lan bam Remove sau nay khong biet duong ma tra lai.
        restore_passes(vl, saved_passes)
        if had_key:
            scene[SAVED_KEY] = saved_key
        elif SAVED_KEY in scene.keys():
            del scene[SAVED_KEY]
    return out


def _render(scene, name):
    path = os.path.join(bpy.app.tempdir, "dpopt_%s" % name)
    scene.render.filepath = path
    bpy.ops.render.render(write_still=True)
    return path if os.path.isfile(path) else path + '.exr'
