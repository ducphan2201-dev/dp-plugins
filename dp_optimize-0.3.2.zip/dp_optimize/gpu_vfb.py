# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
"""Cac phep chinh nhanh cua DP VFB, chay tren CARD DO HOA.

VI SAO CO FILE NAY. Ducphan 20/09/2026: *"cac thao tac quick adjusment cho
chay GPU cho nhanh"*. Do tren anh 4000x2250, ban chay tren bo xu ly: lam net
0,12 s, bloom 0,21 s, bloom + glare 0,34 s moi lan keo thanh truot. Do rieng
hai khau bat buoc cua duong GPU tren may nay (RTX 3060): day anh len card
0,027 s, lay anh ve 0,039 s, mot luot ve gan nhu 0 s — nen chuyen duoc thi
lai han.

⛔ PHAI CO DUONG LUI. Chay nen (`--background`), may khong co card, trinh
dieu khien tu choi bien dich shader — deu co that, va deu phai ve CPU chu
khong duoc hien anh den. Moi ham o day tra ve None khi khong lam duoc, ben
goi tu quay ve `tang_kinh.hieu_ung`.

⛔ MOI THU O DAY LA TUYEN TINH. Khong dinh gi toi color management: viec doi
mau de hien len man hinh do chinh Blender lam, o `tang_kinh.hien_ra`.

CONG THUC — VIET LAI 20/09/2026 THEO CHUAN NGANH
================================================
Ban cu tu nghi ra: bright pass thu nho 4 lan, ba tam bo loc hop tron tay,
tia sang cong ban sao dich di, lam net bang unsharp mask. Bon cai deu "gan
dung" va deu co tat: quang sang vuong o ria, co duong vien ro tai muc nguong,
tia sang rang cua, lam net sinh vien den quanh vat sang vi anh HDR ra ngoai
[0,1]. Nay thay bang dung bon thuat toan dang duoc dung that:

  1. EXPOSURE  color *= exp2(EV), gop luon vao luot shader dau tien.

  2. BLOOM     Jimenez / Call of Duty: Advanced Warfare — chuoi mip thu nho
               bang bo loc 13 mau, phong to nguoc lai bang bo loc leu 9 mau
               va cong don. Karis average CHI o luot thu nho dau de mot diem
               "dom lua" khong no ra ca quang. Nguong co men mem kieu Unity
               (quadratic knee) nen khong con duong vien tai muc nguong.
               Tron cuoi bang NOI SUY chu khong cong thang -> keo het thanh
               cung khong chay anh.
               Nguon: learnopengl.com/Guest-Articles/2022/Phys.-Based-Bloom
               va compositor_glare_bloom_downsample.glsl cua Blender.

  3. GLARE     Kawase, dung y cai Blender lam cho nut Glare: moi huong tia
               chay 4 luot noi tiep, luot thu n nhay xa pow(4,n) diem, moi
               luot doc 3 mau roi chia doi. Co tan sac mau nhu quang sai.
               So tia lay theo SO CANH KHAU DO: chan thi bay nhieu tia, le
               thi gap doi — dung luat vat ly cua khau do that.
               Nguon: compositor_glare_streaks_filter.glsl cua Blender +
               node_composite_glare.cc (fade 0,9; color modulation 0,25;
               magnitude pow(4,n); attenuation 1/(5 + 1 - so_luot)).

  4. SHARPEN   AMD FidelityFX CAS. Chay SAU CUNG.
               ⛔ CAS gia dinh tin hieu nam trong [0,1]. Anh cua ta la HDR
               tuyen tinh (gia tri len hang nghin) nen chay thang LA SAI va
               sinh vien den quanh vat sang. Phai nen dai sang x/(1+x) truoc
               roi tra lai x'/(1-x') sau. Va lam net theo DO CHOI, khong theo
               tung kenh: re hon ba lan va khong ra vien mau.
               Nguon: github.com/GPUOpen-Effects/FidelityFX-CAS

THU TU: exposure -> (glare va bloom cung lay nguon tu anh DA nhan exposure)
-> tron vao -> sharpen sau cung.
"""
import time

import numpy as np

TEN = "DP-OptimizeRender"

_CO = None           # dung duoc GPU khong (None = chua thu)
_THU_LAI = 0.0       # moc gio duoc thu lai card sau mot lan hong
_SHADER = {}
_BATCH = {}          # bo hinh chu nhat phu man, giu theo shader
_FB = {}             # khung ve, giu theo texture dich
_KHO = {}            # bo nho dem: texture nguon + cac lop trung gian

# --- Cac con so cua cong thuc, de mot cho cho de doi ---
SO_TANG_MIP = 6         # so tang thu nho toi da cua chuoi bloom
CANH_MIN_MIP = 16       # dung thu nho khi canh ngan hon con so nay
MEN_MEM = 0.5           # soft knee cua nguong (Unity)
SUC_BLOOM = 0.25        # thanh 0..2 -> he so noi suy 0..0,5
SUC_TIA = 0.25          # thanh 0..2 -> he so noi suy 0..0,5
SO_LUOT_TIA = 4         # so luot ping-pong moi tia
SO_LUOT_TIA_MAX = 5     # MAX_GLARE_ITERATIONS cua Blender
TAT_DAN_TIA = 0.9       # fade
DIEU_MAU_TIA = 0.25     # color modulation
SO_CANH = 6             # so canh khau do mac dinh -> 6 tia
BK_TO = 0.0             # >0: ban kinh bo loc leu theo uv; 0: theo 1 diem ra
TRAN_HDR = 65504.0      # tran cua so thuc nua do chinh xac


def _gpu():
    import gpu
    return gpu


VS = "void main() { vuv = uv; gl_Position = vec4(pos, 0.0, 1.0); }"

# Moi shader: (ten mau, cac o hang so, cac anh dau vao).
# ⛔ Blender 5.2 KHONG cho `gpu.types.GPUShader(ma_dinh, ma_manh)` nua —
# no nem "cannot create 'GPUShader' instances". Phai khai bao qua
# `GPUShaderCreateInfo`, va khi do MA SHADER KHONG DUOC tu khai `in`, `out`
# hay `uniform`: khai hai lan la loi bien dich.
_KHAI = {
    'mip0': ((('VEC2', "buoc"), ('FLOAT', "phoi"), ('FLOAT', "nguong")),
             ("anh",)),
    'nho': ((('VEC2', "buoc"),), ("anh",)),
    'to': ((('VEC2', "buoc"),), ("anh",)),
    'tia': ((('VEC2', "vec_tia"), ('VEC2', "co"), ('VEC3', "tat_dan"),
             ('FLOAT', "dieu_mau")), ("anh",)),
    'gop': ((('FLOAT', "he_so"),), ("anh",)),
    'ghep': ((('FLOAT', "phoi"), ('FLOAT', "suc_bloom"),
              ('FLOAT', "suc_tia")), ("anh", "bloom", "tia")),
    'net': ((('VEC2', "buoc"), ('FLOAT', "phoi"), ('FLOAT', "sac")),
            ("anh",)),
    # Tra bang mau: `bang` la texture BA CHIEU (xem `bang_mau.py`).
    'mau': ((('FLOAT', "lo"), ('FLOAT', "nghich"), ('FLOAT', "canh")),
            ("anh", ("bang", 'FLOAT_3D'))),
}

# ⛔ NaN KHONG PHAI CHUYEN HIEM. Cycles sinh NaN o nhung diem mau khong hoi
# tu; mot diem NaN khong chan se lan ra CA quang sang (NaN cong voi gi cung
# ra NaN, ma bloom thi cong mot vung rong). `clamp` KHONG diet duoc NaN —
# ket qua cua clamp(NaN,...) la khong xac dinh — nen phai so sanh x == x.
FS_CHUNG = """
float _sach(float x) {
    return (x == x) ? clamp(x, 0.0, 65504.0) : 0.0;
}
vec3 _sach3(vec3 c) {
    return vec3(_sach(c.r), _sach(c.g), _sach(c.b));
}
"""

# 13 diem lay mau cua bo loc thu nho (Call of Duty: AW, slide 153).
#   a b c        a,c,g,i : goc ngoai, cach tam 2 diem
#   d e f        b,d,f,h : canh ngoai, cach tam 2 diem
#   g h i        e       : tam
#    j k         j,k,l,m : bon diem trong, cach tam 1 diem
#    l m
_MAU13 = """
    vec3 a = _lay(vec2(-2.0,  2.0));
    vec3 b = _lay(vec2( 0.0,  2.0));
    vec3 c = _lay(vec2( 2.0,  2.0));
    vec3 d = _lay(vec2(-2.0,  0.0));
    vec3 e = _lay(vec2( 0.0,  0.0));
    vec3 f = _lay(vec2( 2.0,  0.0));
    vec3 g = _lay(vec2(-2.0, -2.0));
    vec3 h = _lay(vec2( 0.0, -2.0));
    vec3 i = _lay(vec2( 2.0, -2.0));
    vec3 j = _lay(vec2(-1.0,  1.0));
    vec3 k = _lay(vec2( 1.0,  1.0));
    vec3 l = _lay(vec2(-1.0, -1.0));
    vec3 m = _lay(vec2( 1.0, -1.0));
"""

# Luot thu nho DAU TIEN: nhan exposure, don NaN, Karis average, roi ap nguong
# co men mem. Ca ba viec chi lam DUNG MOT LAN o day.
FS_MIP0 = FS_CHUNG + """
vec3 _lay(vec2 o) {
    return _sach3(texture(anh, vuv + o * buoc).rgb * phoi);
}

/* Karis average: mot diem qua choi (dom lua) duoc keo xuong theo do choi cua
   chinh no, nen no khong no thanh ca mot quang sang. CHI LAM O LUOT DAU —
   qua luot sau thi dom lua da bi tron mat roi, lam tiep chi lam mo quang.
   Ap len 5 NHOM 2x2 chu khong len tung diem: ap tung diem thi mat ca phan
   sang that cua vat the. */
float _karis(vec3 col) {
    vec3 s = pow(max(col, vec3(0.0)), vec3(1.0 / 2.2));
    float lum = dot(s, vec3(0.299, 0.587, 0.114)) * 0.25;
    return 1.0 / (1.0 + lum);
}

void main() {
""" + _MAU13 + """
    vec3 n0 = (a + b + d + e) * (0.125 / 4.0);
    vec3 n1 = (b + c + e + f) * (0.125 / 4.0);
    vec3 n2 = (d + e + g + h) * (0.125 / 4.0);
    vec3 n3 = (e + f + h + i) * (0.125 / 4.0);
    vec3 n4 = (j + k + l + m) * (0.500 / 4.0);
    vec3 t = n0 * _karis(n0) + n1 * _karis(n1) + n2 * _karis(n2)
             + n3 * _karis(n3) + n4 * _karis(n4);
    t = max(t, vec3(0.0001));

    /* NGUONG CO MEN MEM (Unity quadratic knee). Cat thang `max(x - n, 0)` de
       lai mot duong vien CUNG dung tai muc nguong: tren mot mang tuong chuyen
       sac muot, quang sang bat dau dot ngot thanh mot duong ranh gioi nhin ra
       ngay. Men mem cho phan tu (nguong - knee) den (nguong + knee) di len
       theo duong bac hai, nen khong con duong nao ca. */
    float br = max(max(t.r, t.g), t.b);
    float knee = nguong * MEN_MEM_GLSL + 1e-5;
    float rq = clamp(br - (nguong - knee), 0.0, 2.0 * knee);
    float mem = (0.25 / knee) * rq * rq;
    t *= max(mem, br - nguong) / max(br, 1e-5);
    fragColor = vec4(max(t, vec3(0.0)), 1.0);
}
"""

# Cac luot thu nho sau: van 13 mau, nhung khong Karis va khong nguong nua.
FS_NHO = FS_CHUNG + """
vec3 _lay(vec2 o) {
    return texture(anh, vuv + o * buoc).rgb;
}
void main() {
""" + _MAU13 + """
    vec3 t = e * 0.125
             + (a + c + g + i) * 0.03125
             + (b + d + f + h) * 0.0625
             + (j + k + l + m) * 0.125;
    fragColor = vec4(t, 1.0);
}
"""

# Phong to bang bo loc LEU 9 mau, roi CONG DON vao tang tren (blend cong).
# Cong don qua nhieu tang la cach duy nhat cho ra mot quang sang vua rong
# vua muot ma khong phai mo mot lan voi ban kinh khong lo.
FS_TO = """
void main() {
    vec3 t = texture(anh, vuv).rgb * (4.0 / 16.0);
    t += texture(anh, vuv + vec2(-buoc.x, 0.0)).rgb * (2.0 / 16.0);
    t += texture(anh, vuv + vec2( buoc.x, 0.0)).rgb * (2.0 / 16.0);
    t += texture(anh, vuv + vec2(0.0, -buoc.y)).rgb * (2.0 / 16.0);
    t += texture(anh, vuv + vec2(0.0,  buoc.y)).rgb * (2.0 / 16.0);
    t += texture(anh, vuv + vec2(-buoc.x, -buoc.y)).rgb * (1.0 / 16.0);
    t += texture(anh, vuv + vec2(-buoc.x,  buoc.y)).rgb * (1.0 / 16.0);
    t += texture(anh, vuv + vec2( buoc.x, -buoc.y)).rgb * (1.0 / 16.0);
    t += texture(anh, vuv + vec2( buoc.x,  buoc.y)).rgb * (1.0 / 16.0);
    fragColor = vec4(t, 1.0);
}
"""

# Mot luot cua bo loc tia (Kawase). Chay noi tiep 4 luot, moi luot nhay xa
# gap 4 lan luot truoc, nen 4 luot keo duoc vet dai 3 * 64 = 192 diem.
#
# ⛔ PHAI DUNG `texture()` CHU KHONG `texelFetch`. Vec_tia = huong * do_xa la
# so LE, nen diem can lay nam giua hai diem anh; lay diem gan nhat thi tia
# hien ra thanh bac thang. `vuv` o day da la (diem + 0,5) / kich_thuoc san
# roi, vi tam manh nam giua o.
FS_TIA = """
void main() {
    vec2 v = vec_tia / co;
    vec4 n0 = texture(anh, vuv + v);
    vec4 n1 = texture(anh, vuv + v * 2.0);
    vec4 n2 = texture(anh, vuv + v * 3.0);
    /* Tan sac mau: moi mau bot di hai kenh khac nhau, ra dung kieu quang sai
       cua thau kinh that — cang xa nguon cang nga mau. */
    n0.gb *= dieu_mau;
    n1.rg *= dieu_mau;
    n2.rb *= dieu_mau;
    vec4 tong = tat_dan.x * n0 + tat_dan.y * n1 + tat_dan.z * n2;
    vec4 tam = texture(anh, vuv);
    fragColor = (tam + tong) * 0.5;
}
"""

# Cong mot tia vao cho gom (dung blend cong o ben ngoai).
FS_GOP = """
void main() {
    fragColor = vec4(texture(anh, vuv).rgb * he_so, 1.0);
}
"""

# Ghep cuoi: phoi sang roi NOI SUY voi bloom va voi tia.
#
# ⛔ NOI SUY CHU KHONG CONG THANG. Cong thang thi keo thanh truot len het la
# anh chay trang. Noi suy thi ket qua luon nam GIUA anh goc va lop quang sang,
# khong the vuot qua ca hai — keo het co cung chi la "nhieu quang" chu khong
# bao gio la "mat anh".
#
# ⛔ NOI SUY VE `max(anh, lop)` CHU KHONG VE THANG `lop`. Lop quang sang da
# qua NGUONG nen o cho khong co gi sang no bang 0, va o giua o cua so sang no
# chi bang (do_sang - nguong). Noi suy thang ve no thi keo thanh truot len la
# CA ANH TOI DI: do 20/09/2026 tren anh thu, glare o muc 1,0 lam do sang
# trung binh tut 11,2%, va giua o cua so 6,0 tut con 5,75. Noi suy ve
# `max(anh, lop)` thi phep tron chi co the LAM SANG LEN hoac giu nguyen,
# van khong bao gio vuot qua ca hai — giu duoc ca hai tinh chat.
FS_GHEP = FS_CHUNG + """
void main() {
    vec4 g = texture(anh, vuv);
    vec3 c = _sach3(g.rgb * phoi);
    c = mix(c, max(c, texture(bloom, vuv).rgb), suc_bloom);
    c = mix(c, max(c, texture(tia, vuv).rgb), suc_tia);
    fragColor = vec4(max(c, vec3(0.0)), g.a);
}
"""

# Lam net CAS cua AMD, chay tren DO CHOI da nen dai sang.
FS_NET = FS_CHUNG + """
vec3 _mau(vec2 o) {
    return max(_sach3(texture(anh, vuv + o).rgb * phoi), vec3(0.0));
}
float _choi(vec3 c) {
    return dot(c, vec3(0.2126, 0.7152, 0.0722));
}
/* ⛔ NEN DAI SANG TRUOC. CAS gia dinh tin hieu trong [0,1]: phep
   `min(mn, 2 - mx)` chi co nghia khi 2 la tran. Anh HDR tuyen tinh len toi
   hang nghin, `2 - mx` am ngay, bien do bi cat ve 0 o cho sang va am o cho
   ria — ra dung mot vien den quanh moi vat sang. x/(1+x) dua moi gia tri ve
   [0,1), x'/(1-x') tra lai nguyen ven. */
float _nen(float x) { return x / (1.0 + x); }

void main() {
    vec4 g = texture(anh, vuv);
    vec3 c = max(_sach3(g.rgb * phoi), vec3(0.0));
    float a = _nen(_choi(_mau(vec2(-buoc.x,  buoc.y))));
    float b = _nen(_choi(_mau(vec2(    0.0,  buoc.y))));
    float cc = _nen(_choi(_mau(vec2(buoc.x,  buoc.y))));
    float d = _nen(_choi(_mau(vec2(-buoc.x,     0.0))));
    float e = _nen(_choi(c));
    float f = _nen(_choi(_mau(vec2( buoc.x,     0.0))));
    float gg = _nen(_choi(_mau(vec2(-buoc.x, -buoc.y))));
    float h = _nen(_choi(_mau(vec2(    0.0, -buoc.y))));
    float ii = _nen(_choi(_mau(vec2( buoc.x, -buoc.y))));

    float mn = min(min(min(d, e), f), min(b, h));
    float mn2 = min(min(min(mn, a), cc), min(gg, ii));
    mn = mn + mn2;
    float mx = max(max(max(d, e), f), max(b, h));
    float mx2 = max(max(max(mx, a), cc), max(gg, ii));
    mx = mx + mx2;

    float bien = sqrt(clamp(min(mn, 2.0 - mx) / max(mx, 1e-5), 0.0, 1.0));
    float dinh = -1.0 / mix(8.0, 5.0, clamp(sac, 0.0, 1.0));
    float w = bien * dinh;
    float lm = clamp((b * w + d * w + f * w + h * w + e) / (1.0 + 4.0 * w),
                     0.0, 0.9999);
    lm = lm / (1.0 - lm);                       /* tra lai dai sang */

    /* ⛔ LAM NET THEO DO CHOI, khong theo tung kenh. Tung kenh thi moi ria
       mau ra mot vien mau khac (do o mot ben, lam o ben kia) va ton gap ba
       lan phep tinh. Nhan lai ty le do choi thi mau giu nguyen. */
    float cu = _choi(c);
    float ty = (cu > 1e-5) ? clamp(lm / cu, 0.0, 16.0) : 0.0;
    fragColor = vec4(c * ty, g.a);
}
"""


# TRA BANG MAU 3 CHIEU.
#
# \u26d4 NOI SUY TAM TUYEN TINH LAM BANG TAY, lay dung TAM texel. Sampler ma
# Blender gan cho texture tu Python co the la nearest hay linear tuy ban —
# lay dung tam texel thi hai kieu cho cung mot so, nen cach nay dung ca hai
# duong. Tam texel thu i la (i + 0.5) / canh.
#
# \u26d4 Dau vao la anh TUYEN TINH, co the vuot xa 1.0. Dua ve toa do bang
# bang log2 (cung phep ma `bang_mau._khoi_vao` dung de trai khoi), roi kep
# vao [0,1]: tren nguong thi da trang xoa, duoi nguong thi da den.
FS_MAU = FS_CHUNG + """
vec3 _tra(vec3 t) {
    vec3 p = t * (canh - 1.0);
    vec3 i0 = floor(p);
    vec3 f = p - i0;
    vec3 ra = vec3(0.0);
    for (int k = 0; k < 8; k++) {
        vec3 d = vec3(float(k & 1), float((k >> 1) & 1), float((k >> 2) & 1));
        vec3 q = (min(i0 + d, vec3(canh - 1.0)) + 0.5) / canh;
        vec3 w3 = mix(1.0 - f, f, d);
        ra += texture(bang, q).rgb * (w3.x * w3.y * w3.z);
    }
    return ra;
}
void main() {
    vec4 c = texture(anh, vuv);
    vec3 s = _sach3(c.rgb);
    vec3 t = clamp((log2(max(s, vec3(1e-7))) - lo) * nghich, 0.0, 1.0);
    fragColor = vec4(_tra(t), _sach(c.a));
}
"""


_MA = {
    'mip0': FS_MIP0, 'nho': FS_NHO, 'to': FS_TO, 'tia': FS_TIA,
    'gop': FS_GOP, 'ghep': FS_GHEP, 'net': FS_NET, 'mau': FS_MAU,
}


def _sh(ten):
    sh = _SHADER.get(ten)
    if sh is not None:
        return sh
    gpu = _gpu()
    hang, anh = _KHAI[ten]
    ma = _MA[ten].replace("MEN_MEM_GLSL", "%.6f" % MEN_MEM)
    ifc = gpu.types.GPUStageInterfaceInfo("dpopt_%s" % ten)
    ifc.smooth('VEC2', "vuv")
    info = gpu.types.GPUShaderCreateInfo()
    info.vertex_in(0, 'VEC2', "pos")
    info.vertex_in(1, 'VEC2', "uv")
    info.vertex_out(ifc)
    info.fragment_out(0, 'VEC4', "fragColor")
    for kieu, ten_o in hang:
        info.push_constant(kieu, ten_o)
    for i, ten_a in enumerate(anh):
        # Moi muc la mot cai ten, hoac (ten, kieu sampler). Mac dinh la anh
        # hai chieu; bang tra mau thi la 'FLOAT_3D'.
        kieu_s = 'FLOAT_2D'
        if isinstance(ten_a, tuple):
            ten_a, kieu_s = ten_a
        info.sampler(i, kieu_s, ten_a)
    info.vertex_source(VS)
    info.fragment_source(ma)
    sh = gpu.shader.create_from_info(info)
    _SHADER[ten] = sh
    return sh


def co_the():
    """Card dung duoc khong. Nho ket qua, nhung co cho thu lai."""
    global _CO, _THU_LAI
    if _CO is False and _THU_LAI and time.time() > _THU_LAI:
        _CO, _THU_LAI = None, 0.0          # den gio thu lai
    if _CO is not None:
        return _CO
    _CO = False
    try:
        import bpy
        if bpy.app.background:
            return _CO                       # chay nen thi khong co card
        gpu = _gpu()
        _sh('mip0')
        _ = gpu.types.GPUTexture((4, 4), format='RGBA32F')
        _CO = True
    except Exception as e:                                   # noqa: BLE001
        print("[%s] VFB: the graphics card cannot be used (%s)" % (TEN, e))
        _CO = False
    return _CO


def _tam(ten, W, H):
    """Mot texture nhap, giu lai theo (ten, kich thuoc).

    ⛔ MOI CHO NHAP PHAI MOT TEN RIENG. Doc va ghi cung MOT texture trong mot
    luot ve la ket qua khong xac dinh — moi may mot kieu.
    """
    khoa = (ten, W, H)
    t = _KHO.get(khoa)
    if t is None:
        t = _gpu().types.GPUTexture((W, H), format='RGBA32F')
        _KHO[khoa] = t
    return t


def _trong():
    """Mot texture 4x4 toan so khong, de nhet vao o anh khong dung toi.

    ⛔ Texture moi tao KHONG duoc xoa san — doc no ra rac cua lan truoc.
    """
    t = _KHO.get('trong')
    if t is None:
        gpu = _gpu()
        b = gpu.types.Buffer('FLOAT', 4 * 4 * 4, np.zeros(64, np.float32))
        t = gpu.types.GPUTexture((4, 4), format='RGBA32F', data=b)
        _KHO['trong'] = t
    return t


def _khung(ra):
    fb = _FB.get(ra)
    if fb is None:
        fb = _gpu().types.GPUFrameBuffer(color_slots={"texture": ra})
        _FB[ra] = fb
    return fb


def _bo(sh):
    ba = _BATCH.get(sh)
    if ba is None:
        from gpu_extras.batch import batch_for_shader
        ba = batch_for_shader(sh, 'TRI_FAN', {
            "pos": ((-1, -1), (1, -1), (1, 1), (-1, 1)),
            "uv": ((0, 0), (1, 0), (1, 1), (0, 1))})
        _BATCH[sh] = ba
    return ba


def _xoa(ra):
    """Dat texture ve 0 — bat buoc truoc khi cong don vao no."""
    with _khung(ra).bind():
        _gpu().state.blend_set('NONE')
        _khung(ra).clear(color=(0.0, 0.0, 0.0, 0.0))


def _ve(ten, ra, dat, cong=False):
    """Chay mot luot shader, ghi vao texture `ra`.

    `cong=True` thi CONG vao cai dang co thay vi de len. Phai lam bang trang
    thai tron cua card: doc va ghi cung mot texture trong mot luot ve la ket
    qua khong xac dinh.
    """
    gpu = _gpu()
    sh = _sh(ten)
    fb = _khung(ra)
    with fb.bind():
        # ⛔ 'ADDITIVE' cua Blender la (src * srcAlpha + dst) — nhan ca alpha
        # vao. Cai can o day la (src + dst), tuc 'ADDITIVE_PREMULT'.
        gpu.state.blend_set('ADDITIVE_PREMULT' if cong else 'NONE')
        sh.bind()
        for k, v in dat.items():
            if isinstance(v, gpu.types.GPUTexture):
                sh.uniform_sampler(k, v)
            elif isinstance(v, bool):
                sh.uniform_int(k, int(v))
            elif isinstance(v, int):
                sh.uniform_int(k, v)
            else:
                sh.uniform_float(k, v)
        _bo(sh).draw(sh)
        gpu.state.blend_set('NONE')


def dat_nguon(rgba):
    """Day anh goc len card. Goi moi khi co anh MOI, khong goi moi lan keo."""
    if not co_the():
        return False
    gpu = _gpu()
    try:
        H, W = rgba.shape[:2]
        b = gpu.types.Buffer('FLOAT', W * H * 4,
                             np.ascontiguousarray(rgba, np.float32).ravel())
        _KHO.clear()
        _FB.clear()
        _KHO['nguon'] = gpu.types.GPUTexture((W, H), format='RGBA32F', data=b)
        _KHO['co'] = (W, H)
    except Exception as e:                                   # noqa: BLE001
        print("[%s] VFB: cannot upload the image to the card (%s)" % (TEN, e))
        _KHO.clear()
        _FB.clear()
        return False
    return True


def co_nguon():
    return 'nguon' in _KHO


def dat_bang(bang):
    """Day bang tra mau (mang N x N x N x 4) len card. Goi khi bang doi."""
    if not co_the():
        return False
    if bang is None:
        _KHO.pop('bang', None)
        _KHO.pop('bang_canh', None)
        return False
    gpu = _gpu()
    try:
        n = bang.shape[0]
        d = np.ascontiguousarray(bang, np.float32).ravel()
        buf = gpu.types.Buffer('FLOAT', d.size, d)
        # Thu tu cua card la (rong, cao, sau) = (r, g, b); mang cua
        # `bang_mau` phang theo [b][g][r] nen r chay nhanh nhat — khop.
        _KHO['bang'] = gpu.types.GPUTexture((n, n, n), format='RGBA32F',
                                            data=buf)
        _KHO['bang_canh'] = n
    except Exception as e:                                   # noqa: BLE001
        print("[%s] VFB: cannot upload the colour table (%s)" % (TEN, e))
        _KHO.pop('bang', None)
        _KHO.pop('bang_canh', None)
        return False
    return True


def co_bang():
    return 'bang' in _KHO


def chuoi_mip(W, H, toi_da=SO_TANG_MIP):
    """Kich thuoc cac tang thu nho. Dung khi canh ngan duoi CANH_MIN_MIP."""
    ds = []
    w, h = W, H
    for _ in range(toi_da):
        w, h = w // 2, h // 2
        if min(w, h) < CANH_MIN_MIP:
            break
        ds.append((w, h))
    return ds


def so_tia(st):
    """So tia sao, suy tu SO CANH KHAU DO.

    Luat vat ly cua khau do that: anh sang nhieu xa o MEP moi canh, moi canh
    cho mot cap tia doi xung. So canh CHAN thi hai canh doi dien nam tren
    cung mot duong nen cac cap trung nhau — ra dung bay nhieu tia. So canh LE
    thi khong canh nao doi dien canh nao, moi canh mot cap rieng — ra GAP DOI.
    Vi the ong kinh 6 canh cho 6 tia, con 7 canh cho 14 tia.
    """
    canh = SO_CANH
    for ten in ("vfb_glare_blades", "vfb_so_canh", "vfb_blades"):
        v = getattr(st, ten, None)
        if v:
            canh = int(v)
            break
    canh = max(3, min(12, canh))
    return canh if canh % 2 == 0 else canh * 2


def _chuoi(nguon, W, H, phoi, nguong, toi_da):
    """Dung chuoi mip: tang 0 co Karis + nguong men mem, cac tang sau thuan
    tuy thu nho. Tra ve (danh sach texture, danh sach kich thuoc)."""
    ds = chuoi_mip(W, H, toi_da)
    mip = []
    vao, cvao = nguon, (W, H)
    for i, (w, h) in enumerate(ds):
        t = _tam('mip%d' % i, w, h)
        dat = {"anh": vao, "buoc": (1.0 / cvao[0], 1.0 / cvao[1])}
        if i == 0:
            dat["phoi"] = phoi
            dat["nguong"] = nguong
        _ve('mip0' if i == 0 else 'nho', t, dat)
        mip.append(t)
        vao, cvao = t, (w, h)
    return mip, ds


def _phong_to(mip, ds):
    """Phong to nguoc bang bo loc leu, cong don tu tang nho nhat len tang 0.

    ⛔ BAN KINH LAY MAU LA MOT DIEM CUA ANH RA (tuc nua diem cua anh vao),
    khong phai mot con so uv co dinh. learnopengl de san 0,005 uv cho moi
    tang; o anh 4000 diem thi 0,005 uv la 10 diem, nen chin mau cua bo loc
    leu nam cach nhau 10 diem va ho ra chin cuc rieng le — quang sang hien
    thanh hinh chu thap chu khong tron. Bo loc leu chi la bo loc leu khi ba
    mau lien nhau CHAM vao nhau.
    """
    for i in range(len(mip) - 1, 0, -1):
        w, h = ds[i - 1]
        buoc = (BK_TO, BK_TO) if BK_TO > 0.0 else (1.0 / w, 1.0 / h)
        _ve('to', mip[i - 1], {"anh": mip[i], "buoc": buoc}, cong=True)
    return mip[0]


def _lop_tia(nguon, w, h, n_tia, goc_dau):
    """Tia sao Kawase: moi huong 4 luot noi tiep, roi cong tat ca lai."""
    gom = _tam('tia_gom', w, h)
    _xoa(gom)
    a = _tam('tia_a', w, h)
    b = _tam('tia_b', w, h)
    # Bu do sang: it luot thi tia ngan va nhat, nen phai nhan len. Khi so luot
    # bang toi da thi mau so bang 1, khong bu gi ca (dung Blender).
    bu = 1.0 / float(SO_LUOT_TIA_MAX + 1 - SO_LUOT_TIA)
    # ⛔ CHIA DEU CHO SO TIA. Ducphan 20/09/2026: *"k tang cuong do sang"* —
    # doi so canh khau do la doi HINH cua ngoi sao, khong duoc doi do sang.
    # Cong thang thi 12 tia sang gap doi 6 tia o cung mot muc thanh truot
    # (Blender cu the, nhung o day khong lay). Chuan theo moc 6 tia de muc
    # thanh truot quen thuoc giu nguyen cam giac.
    bu *= SO_CANH / float(max(1, n_tia))
    for k in range(n_tia):
        goc = goc_dau + (float(k) / n_tia) * 2.0 * np.pi
        hx, hy = float(np.cos(goc)), float(np.sin(goc))
        vao = nguon
        ra = a
        for n in range(SO_LUOT_TIA):
            do_xa = 4.0 ** n
            td = TAT_DAN_TIA ** do_xa
            _ve('tia', ra, {
                "anh": vao,
                "vec_tia": (hx * do_xa, hy * do_xa),
                "co": (float(w), float(h)),
                "tat_dan": (td, td * td, td * td * td),
                "dieu_mau": 1.0 - DIEU_MAU_TIA ** (n + 1)})
            vao = ra
            ra = b if ra is a else a
        _ve('gop', gom, {"anh": vao, "he_so": bu}, cong=True)
    return gom


def hieu_ung(st, doi_mau=False, lo=0.0, nghich=1.0):
    """Ap cac phep chinh nhanh tren card. Tra ve mang HxWx4, hay None.

    `doi_mau=True` thi chay THEM mot luot tra bang mau o cuoi, va mang tra
    ve nam trong khong gian ma `Image.pixels` can — ghi thang vao anh la
    xong, khong phai vong qua file nua. Chi dung duoc khi `co_bang()`.
    """
    if not co_the() or 'nguon' not in _KHO:
        return None
    gpu = _gpu()
    # ⛔ KHUNG VE (framebuffer) KHONG DUNG CHUNG GIUA CAC CUA SO. Texture thi
    # dung chung, nhung framebuffer thuoc ve DUNG ngu canh do hoa luc tao ra —
    # moi cua so Blender mot ngu canh. Do 21/09/2026 (batch DP Cam, Blender co
    # cua so): mo cua so VFB xong, keo Quick adjustments bao "Framebuffer is
    # not bound", card bi tat mot phut, bo xu ly lam thay: DUNG HINH 9 s.
    # Tao lai khung ve moi luot — re, vai phan nghin giay.
    _FB.clear()
    try:
        W, H = _KHO['co']
        ph = float(getattr(st, "vfb_exposure", 0.0))
        sac = float(getattr(st, "vfb_sharpen", 0.0))
        bl = float(getattr(st, "vfb_bloom", 0.0))
        gl = float(getattr(st, "vfb_glare", 0.0))
        ng = float(getattr(st, "vfb_bloom_threshold", 1.0))
        goc = float(getattr(st, "vfb_glare_angle", 0.0))
        k = float(2.0 ** ph) if abs(ph) > 1e-6 else 1.0
        nguon = _KHO['nguon']
        trong = _trong()

        can_bloom = bl > 1e-6
        can_tia = gl > 1e-6
        bloom = tia = trong
        s_bloom = s_tia = 0.0

        if can_bloom or can_tia:
            # Chi glare thi khong can ca chuoi: hai tang la du (tia chay o
            # mot phan tu). Co bloom thi moi dung ca sau tang.
            mip, ds = _chuoi(nguon, W, H, k, max(ng, 0.0),
                             SO_TANG_MIP if can_bloom else 2)
            if mip:
                # ⛔ LAY NGUON CUA TIA TRUOC KHI PHONG TO. Luot phong to CONG
                # DON de len chinh cac tang mip, nen sau no mip[1] khong con
                # la anh da qua nguong nua.
                if can_tia:
                    j = 1 if len(mip) > 1 else 0
                    tia = _lop_tia(mip[j], ds[j][0], ds[j][1],
                                   so_tia(st), goc)
                    s_tia = min(gl, 2.0) * SUC_TIA
                if can_bloom:
                    bloom = _phong_to(mip, ds)
                    s_bloom = min(bl, 2.0) * SUC_BLOOM

        # --- ghep: phoi sang + bloom + tia ---
        if sac > 1e-6:
            hop = _tam('hop', W, H)
            _ve('ghep', hop, {"anh": nguon, "bloom": bloom, "tia": tia,
                              "phoi": k, "suc_bloom": s_bloom,
                              "suc_tia": s_tia})
            # --- lam net SAU CUNG ---
            ra = _tam('ra', W, H)
            _ve('net', ra, {"anh": hop, "buoc": (1.0 / W, 1.0 / H),
                            "phoi": 1.0, "sac": min(sac * 0.5, 1.0)})
        else:
            ra = _tam('ra', W, H)
            _ve('ghep', ra, {"anh": nguon, "bloom": bloom, "tia": tia,
                             "phoi": k, "suc_bloom": s_bloom,
                             "suc_tia": s_tia})

        if doi_mau and 'bang' in _KHO:
            # \u26d4 PHAI VE SANG MOT TEXTURE KHAC. Doc va ghi cung mot
            # texture trong mot luot ve la ket qua khong xac dinh.
            ra2 = _tam('ra_mau', W, H)
            _ve('mau', ra2, {"anh": ra, "bang": _KHO['bang'], "lo": lo,
                             "nghich": nghich,
                             "canh": float(_KHO.get('bang_canh', 33))})
            ra = ra2

        fb = _khung(ra)
        with fb.bind():
            b = fb.read_color(0, 0, W, H, 4, 0, 'FLOAT')
        b.dimensions = W * H * 4
        return np.asarray(b, np.float32).reshape(H, W, 4)
    except Exception as e:                                   # noqa: BLE001
        # ⛔ MOT LAN HONG KHONG PHAI LA HONG HAN. Card co the ban vi Cycles
        # dang render tren chinh no, hay trinh dieu khien vua khoi dong lai.
        # Tat vinh vien thi ca phien con lai chay cham gap may lan ma khong
        # ai biet duong bat lai. Cho thu lai sau mot phut.
        global _CO, _THU_LAI
        try:
            gpu.state.blend_set('NONE')
        except Exception:                                    # noqa: BLE001
            pass
        print("[%s] VFB: the card could not do it (%s) — using the processor, "
              "will try the card again in a minute" % (TEN, e))
        _CO = False
        _THU_LAI = time.time() + 60.0
        _KHO.clear()
        _FB.clear()
        return None


def quen():
    """Bo het texture dang giu tren card (ke ca bang tra mau)."""
    _KHO.clear()
    _FB.clear()
    _BATCH.clear()
    _SHADER.clear()
