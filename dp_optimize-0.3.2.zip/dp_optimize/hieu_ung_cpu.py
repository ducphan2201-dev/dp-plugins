# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
"""Cac phep chinh nhanh cua DP VFB, chay tren BO XU LY.

Ban sao tung chu cua `gpu_vfb.py` bang numpy, cho may khong co card, cho luc
chay nen (`--background`), va cho luc trinh dieu khien tu choi bien dich
shader. Cham hon nhieu lan, nhung PHAI RA DUNG MOT ANH.

⛔ CUNG MOT THANH TRUOT PHAI CHO CUNG MOT ANH. Anh luu ra file va anh dang
nhin phai la mot; hai may cua cung mot khach phai giong nhau. Vi the file nay
KHONG tu nghi ra cong thuc nao: no nhap thang cac con so tu `gpu_vfb.py`
(`MEN_MEM`, `SUC_BLOOM`, `TAT_DAN_TIA`, ...) va di dung tung buoc cua shader.
Sua cong thuc thi sua o `gpu_vfb.py`, o day chi sua phep tinh.

BA CHO DE SAI, va cach lam o day:
  1. LAY MAU. Card lay mau bang NOI SUY hai chieu voi ria KEO DAI. Lay diem
     gan nhat thi bloom ra o vuong va tia ra bac thang. `_mau` o duoi lam
     dung phep noi suy do.
  2. TOA DO. Card danh so theo uv: tam diem anh thu `i` nam o `(i+0,5)/W`.
     Doi ra chi so diem anh la `(i+0,5)*W_vao/W_ra - 0,5`. Sai nua diem la
     anh lech nua diem so voi card.
  3. RIA. `np.roll` CUON VONG — tia sang cua mot den o mep trai se hien lai
     o mep phai. Ria phai KEO DAI, dung nhu clamp-to-edge cua card.
"""
import numpy as np

try:
    from . import gpu_vfb as _card          # khi nam trong addon
except ImportError:                          # khi chay roi de thu
    import gpu_vfb as _card

TEN = "DP-OptimizeRender"

TRAN_HDR = _card.TRAN_HDR
MEN_MEM = _card.MEN_MEM
SUC_BLOOM = _card.SUC_BLOOM
SUC_TIA = _card.SUC_TIA
SO_TANG_MIP = _card.SO_TANG_MIP
SO_LUOT_TIA = _card.SO_LUOT_TIA
SO_LUOT_TIA_MAX = _card.SO_LUOT_TIA_MAX
TAT_DAN_TIA = _card.TAT_DAN_TIA
DIEU_MAU_TIA = _card.DIEU_MAU_TIA
BK_TO = _card.BK_TO

_CHOI = np.array([0.2126, 0.7152, 0.0722], np.float32)
_SRGB = np.array([0.299, 0.587, 0.114], np.float32)


def _sach(a):
    """NaN ve 0 roi chan tran — dung y ham `_sach3` cua shader."""
    return np.clip(np.where(a == a, a, 0.0), 0.0, TRAN_HDR).astype(np.float32)


def _mau(a, gx, gy):
    """Lay mau bang noi suy hai chieu, ria KEO DAI.

    `gx` dai W_ra, `gy` dai H_ra, tinh theo CHI SO diem anh (so thuc).
    """
    h, w = a.shape[:2]
    gx = np.clip(np.asarray(gx, np.float64), 0.0, w - 1.0)
    gy = np.clip(np.asarray(gy, np.float64), 0.0, h - 1.0)
    x0 = np.floor(gx).astype(np.intp)
    y0 = np.floor(gy).astype(np.intp)
    x1 = np.minimum(x0 + 1, w - 1)
    y1 = np.minimum(y0 + 1, h - 1)
    tx = (gx - x0).astype(np.float32)[None, :, None]
    ty = (gy - y0).astype(np.float32)[:, None, None]
    t0, t1 = a[y0], a[y1]
    c0 = t0[:, x0] * (1.0 - tx) + t0[:, x1] * tx
    c1 = t1[:, x0] * (1.0 - tx) + t1[:, x1] * tx
    return (c0 * (1.0 - ty) + c1 * ty).astype(np.float32)


def _goc(w_vao, h_vao, w_ra, h_ra):
    """Chi so diem anh cua tam moi diem dau ra, o he toa do dau vao."""
    bx = (np.arange(w_ra, dtype=np.float64) + 0.5) * w_vao / w_ra - 0.5
    by = (np.arange(h_ra, dtype=np.float64) + 0.5) * h_vao / h_ra - 0.5
    return bx, by


def _muoi_ba(a, w_ra, h_ra, don=None):
    """13 mau cua bo loc thu nho (Call of Duty: AW).

    `don` la ham don moi mau (nhan exposure va don NaN) o luot dau.
    """
    h, w = a.shape[:2]
    bx, by = _goc(w, h, w_ra, h_ra)

    def q(dx, dy):
        m = _mau(a, bx + dx, by + dy)
        return don(m) if don is not None else m

    return (q(-2.0, 2.0), q(0.0, 2.0), q(2.0, 2.0),
            q(-2.0, 0.0), q(0.0, 0.0), q(2.0, 0.0),
            q(-2.0, -2.0), q(0.0, -2.0), q(2.0, -2.0),
            q(-1.0, 1.0), q(1.0, 1.0), q(-1.0, -1.0), q(1.0, -1.0))


def _karis(col):
    """1/(1+do_choi) — keo mot diem qua choi xuong de no khong no ra quang."""
    s = np.power(np.maximum(col, 0.0), 1.0 / 2.2)
    lum = (s * _SRGB).sum(axis=2, keepdims=True) * 0.25
    return 1.0 / (1.0 + lum)


def _mip0(a, w_ra, h_ra, phoi, nguong):
    """Luot thu nho DAU: exposure + Karis average + nguong co men mem."""
    a, b, c, d, e, f, g, h, i, j, k, l, m = _muoi_ba(
        a, w_ra, h_ra, don=lambda x: _sach(x * phoi))
    n0 = (a + b + d + e) * (0.125 / 4.0)
    n1 = (b + c + e + f) * (0.125 / 4.0)
    n2 = (d + e + g + h) * (0.125 / 4.0)
    n3 = (e + f + h + i) * (0.125 / 4.0)
    n4 = (j + k + l + m) * (0.500 / 4.0)
    t = (n0 * _karis(n0) + n1 * _karis(n1) + n2 * _karis(n2)
         + n3 * _karis(n3) + n4 * _karis(n4))
    t = np.maximum(t, 0.0001)

    br = t.max(axis=2, keepdims=True)
    knee = nguong * MEN_MEM + 1e-5
    rq = np.clip(br - (nguong - knee), 0.0, 2.0 * knee)
    mem = (0.25 / knee) * rq * rq
    t = t * (np.maximum(mem, br - nguong) / np.maximum(br, 1e-5))
    return np.maximum(t, 0.0).astype(np.float32)


def _nho(a, w_ra, h_ra):
    """Cac luot thu nho sau: 13 mau, khong Karis va khong nguong."""
    a, b, c, d, e, f, g, h, i, j, k, l, m = _muoi_ba(a, w_ra, h_ra)
    return (e * 0.125
            + (a + c + g + i) * 0.03125
            + (b + d + f + h) * 0.0625
            + (j + k + l + m) * 0.125).astype(np.float32)


def _to(a, w_ra, h_ra):
    """Phong to bang bo loc LEU 9 mau. Ban kinh = mot diem anh RA."""
    h, w = a.shape[:2]
    bx, by = _goc(w, h, w_ra, h_ra)
    if BK_TO > 0.0:
        ox, oy = BK_TO * w, BK_TO * h
    else:
        ox, oy = float(w) / w_ra, float(h) / h_ra

    def q(dx, dy):
        return _mau(a, bx + dx, by + dy)

    return (q(0.0, 0.0) * (4.0 / 16.0)
            + (q(-ox, 0.0) + q(ox, 0.0) + q(0.0, -oy) + q(0.0, oy))
            * (2.0 / 16.0)
            + (q(-ox, -oy) + q(-ox, oy) + q(ox, -oy) + q(ox, oy))
            * (1.0 / 16.0)).astype(np.float32)


def _luot_tia(a, vx, vy, tat_dan, dieu_mau):
    """Mot luot bo loc tia (Kawase): ba mau xuoi theo huong, roi chia doi."""
    h, w = a.shape[:2]
    ix = np.arange(w, dtype=np.float64)
    iy = np.arange(h, dtype=np.float64)
    n = [_mau(a, ix + vx * t, iy + vy * t) for t in (1.0, 2.0, 3.0)]
    # Tan sac mau: moi mau bot di hai kenh khac nhau.
    n[0] = n[0] * np.array([1.0, dieu_mau, dieu_mau], np.float32)
    n[1] = n[1] * np.array([dieu_mau, dieu_mau, 1.0], np.float32)
    n[2] = n[2] * np.array([dieu_mau, 1.0, dieu_mau], np.float32)
    tong = tat_dan[0] * n[0] + tat_dan[1] * n[1] + tat_dan[2] * n[2]
    return ((a + tong) * 0.5).astype(np.float32)


def _lop_tia(nguon, n_tia, goc_dau):
    """Tia sao: moi huong 4 luot noi tiep, roi cong tat ca lai."""
    gom = np.zeros_like(nguon)
    bu = 1.0 / float(SO_LUOT_TIA_MAX + 1 - SO_LUOT_TIA)
    # Chia deu cho so tia — xem chu thich cung cho o `gpu_vfb._lop_tia`.
    # Hai ban PHAI giong nhau tung con so.
    bu *= _card.SO_CANH / float(max(1, n_tia))
    for kk in range(n_tia):
        goc = goc_dau + (float(kk) / n_tia) * 2.0 * np.pi
        hx, hy = float(np.cos(goc)), float(np.sin(goc))
        v = nguon
        for n in range(SO_LUOT_TIA):
            do_xa = 4.0 ** n
            td = TAT_DAN_TIA ** do_xa
            v = _luot_tia(v, hx * do_xa, hy * do_xa,
                          (td, td * td, td * td * td),
                          1.0 - DIEU_MAU_TIA ** (n + 1))
        gom += v * bu
    return gom


def _dich(a, dx, dy):
    """Doi anh di nguyen diem, ria KEO DAI.

    ⛔ Khong dung `np.roll`: no CUON VONG, nen ria phai cua anh lai lay mau
    tu ria trai — khac han clamp-to-edge cua card.
    """
    h, w = a.shape[:2]
    b = np.pad(a, ((1, 1), (1, 1)), mode='edge')
    return b[1 + dy:1 + dy + h, 1 + dx:1 + dx + w]


def _lam_net(c, sac):
    """AMD FidelityFX CAS tren DO CHOI da nen dai sang."""
    lum = (c * _CHOI).sum(axis=2)
    nen = lum / (1.0 + lum)                    # dua ve [0,1)
    e = nen
    a = _dich(nen, -1, 1)
    b = _dich(nen, 0, 1)
    cc = _dich(nen, 1, 1)
    d = _dich(nen, -1, 0)
    f = _dich(nen, 1, 0)
    g = _dich(nen, -1, -1)
    h = _dich(nen, 0, -1)
    i = _dich(nen, 1, -1)

    mn = np.minimum(np.minimum(np.minimum(d, e), f), np.minimum(b, h))
    mn = mn + np.minimum(np.minimum(np.minimum(mn, a), cc), np.minimum(g, i))
    mx = np.maximum(np.maximum(np.maximum(d, e), f), np.maximum(b, h))
    mx = mx + np.maximum(np.maximum(np.maximum(mx, a), cc), np.maximum(g, i))

    bien = np.sqrt(np.clip(np.minimum(mn, 2.0 - mx) / np.maximum(mx, 1e-5),
                           0.0, 1.0))
    s = min(max(sac, 0.0), 1.0)
    dinh = -1.0 / (8.0 + (5.0 - 8.0) * s)
    w = bien * dinh
    lm = np.clip((b * w + d * w + f * w + h * w + e) / (1.0 + 4.0 * w),
                 0.0, 0.9999)
    lm = lm / (1.0 - lm)                       # tra lai dai sang
    ty = np.where(lum > 1e-5, np.clip(lm / np.maximum(lum, 1e-5), 0.0, 16.0),
                  0.0)
    return (c * ty[:, :, None]).astype(np.float32)


def _len_co(a, W, H):
    """Lay mot lop nho len dung co anh that, bang noi suy — y luot ghep."""
    h, w = a.shape[:2]
    if (h, w) == (H, W):
        return a
    bx, by = _goc(w, h, W, H)
    return _mau(a, bx, by)


def hieu_ung(st, rgb, alp):
    """Ap exposure / bloom / glare / sharpen len anh goc. Tra ve HxWx4.

    `rgb` la (H,W,3) tuyen tinh, `alp` la (H,W,1). Thu tu va cong thuc y het
    `gpu_vfb.hieu_ung`.
    """
    rgb = np.ascontiguousarray(np.asarray(rgb, np.float32))
    H, W = rgb.shape[:2]
    if alp is None:
        alp = np.ones((H, W, 1), np.float32)
    alp = np.asarray(alp, np.float32).reshape(H, W, 1)

    ph = float(getattr(st, "vfb_exposure", 0.0))
    sac = float(getattr(st, "vfb_sharpen", 0.0))
    bl = float(getattr(st, "vfb_bloom", 0.0))
    gl = float(getattr(st, "vfb_glare", 0.0))
    ng = max(float(getattr(st, "vfb_bloom_threshold", 1.0)), 0.0)
    goc = float(getattr(st, "vfb_glare_angle", 0.0))
    k = float(2.0 ** ph) if abs(ph) > 1e-6 else 1.0

    can_bloom = bl > 1e-6
    can_tia = gl > 1e-6
    bloom = tia = None
    s_bloom = s_tia = 0.0

    if can_bloom or can_tia:
        ds = _card.chuoi_mip(W, H, SO_TANG_MIP if can_bloom else 2)
        mip = []
        vao = rgb
        for idx, (w, h) in enumerate(ds):
            vao = (_mip0(vao, w, h, k, ng) if idx == 0 else _nho(vao, w, h))
            mip.append(vao)
        if mip:
            # ⛔ LAY NGUON CUA TIA TRUOC KHI PHONG TO — luot phong to cong don
            # de len chinh cac tang mip.
            if can_tia:
                j = 1 if len(mip) > 1 else 0
                tia = _lop_tia(mip[j], _card.so_tia(st), goc)
                s_tia = min(gl, 2.0) * SUC_TIA
            if can_bloom:
                for idx in range(len(mip) - 1, 0, -1):
                    w, h = ds[idx - 1]
                    mip[idx - 1] = mip[idx - 1] + _to(mip[idx], w, h)
                bloom = mip[0]
                s_bloom = min(bl, 2.0) * SUC_BLOOM

    c = _sach(rgb * k)
    if s_bloom > 0.0 and bloom is not None:
        c = c + (np.maximum(c, _len_co(bloom, W, H)) - c) * s_bloom
    if s_tia > 0.0 and tia is not None:
        c = c + (np.maximum(c, _len_co(tia, W, H)) - c) * s_tia
    c = np.maximum(c, 0.0).astype(np.float32)

    if sac > 1e-6:
        c = _lam_net(c, min(sac * 0.5, 1.0))

    return np.concatenate((c, alp), axis=2)
