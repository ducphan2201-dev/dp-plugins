# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
"""Bang dieu khien trong Properties > Render.

CHU TREN GIAO DIEN LA TIENG ANH — addon nay ban ra.
"""
import bpy
from bpy.types import Panel

from . import comp, ops, props, settings, tang_kinh


def _estimate(scene, st):
    """So lan render se chay. Phai tinh ca so lan lap, neu khong thi con so
    hien ra be bang mot nua thuc te."""
    timed = 1 + 1 + 1               # current, current-repeat, combined
    opts = 0
    for axis, ok in settings.available_axes(scene):
        if not ok:
            continue
        row = next((a for a in st.axes if a.key == axis['key']), None)
        if row is not None and row.enabled:
            opts += len(axis['options'])
    timed += opts
    timed += opts // max(2, st.rebase_every)   # cac lan do lai diem xuat phat
    # Warm-up chay den khi may on dinh nen chi biet duoc khoang: it nhat 3.
    return (3 + 1 + timed * max(1, st.repeats),
            max(1, st.warmup_max) + 1 + timed * max(1, st.repeats))


class _Base:
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = "render"


class _CyclesOnly(_Base):
    """Bang con chi co nghia khi dang dung Cycles."""

    @classmethod
    def poll(cls, context):
        return context.engine == 'CYCLES'


class DPOPT_PT_main(_Base, Panel):
    bl_label = "DP Optimize"
    bl_idname = "DPOPT_PT_main"

    # KHONG loc theo engine o day. Bang cha ma tu an di thi nguoi dung bat
    # addon xong khong thay gi ca va tuong la deploy hong — dung cai bay ma
    # Path Guiding cua Blender dang mac. Thay vi bien mat, no phai NOI RA
    # ly do va dua san nut de sua.

    def draw(self, context):
        scene = context.scene
        layout = self.layout

        if context.engine != 'CYCLES':
            box = layout.box()
            box.label(text="This add-on measures Cycles renders.", icon='INFO')
            box.label(text="The current engine is %s."
                           % scene.render.engine.replace('BLENDER_', '')
                             .replace('_', ' ').title())
            box.operator("dpopt.use_cycles", icon='SHADING_RENDERED')
            return

        # CHI DUOC DOC TRONG `draw`, KHONG DUOC GHI.
        # Blender cam ghi vao du lieu ID (Scene) trong luc ve giao dien. Goi
        # `ensure_axes()` o day — no them dong vao CollectionProperty cua
        # Scene — la Blender nem loi ngay tai dong do, va ket qua la khung
        # bang HIEN RA NHUNG RONG RUOT, chi con may bang con. Nhin vao tuong
        # addon hong. Danh sach truc duoc dung san boi handler khi mo file va
        # boi cac operator, xem `props.ensure_axes`.
        st = scene.dpopt

        if st.running:
            box = layout.box()
            box.label(text="Working… %s" % st.progress, icon='TIME')
            box.label(text="Press Esc to stop. Your settings are kept safe.")
            return

        # NUT CHINH BAM PHAT XONG, KHONG RENDER LAN NAO.
        # Truoc day nut chinh la vong do 17 lan render full — mot cong cu
        # tang toc ma bat cho ca buoi thi khong con la tang toc. Nhung thu
        # trong day khong phu thuoc scene nen khong can do; xem
        # `ops._instant_wins`.
        todo = ops._instant_wins(scene)
        col = layout.column()
        col.scale_y = 2.0
        col.enabled = bool(todo)
        col.operator("dpopt.speedup", icon='CHECKMARK')
        # CUA SO RENDER RIENG CUA DP nam o bang con "DP VFB" ngay duoi day —
        # khong nhet vao bang chinh nua. Ducphan 20/09/2026: *"ua sao dp vfb
        # lai o detail behind glass, sap xep lai giao dien addon"*.

        if todo:
            # GAP LAI (Ducphan 21/09/2026): danh sach dai toi 15 dong.
            box = layout.box()
            hang = box.row(align=True)
            hang.prop(st, "show_todo", text="",
                      icon='DISCLOSURE_TRI_DOWN' if st.show_todo
                      else 'DISCLOSURE_TRI_RIGHT', emboss=False)
            hang.label(text="Ready to switch on, no rendering needed: %d"
                       % len(todo), icon='INFO')
            if st.show_todo:
                for _p, _v, msg in todo:
                    box.label(text="    %s" % msg)
        else:
            layout.label(text="Nothing left to switch on for free.",
                         icon='CHECKMARK')

        # CYCLES CHON SAO THI TOOL CHAY VAY.
        # Addon KHONG dat lai thiet bi tinh toan. Nguoi dung da chon CPU /
        # GPU / ca hai trong Cycles roi, va lua chon do la cua ho — mot cong
        # cu toi uu ma tu doi thiet bi render la lam hong cai ho vua can.
        # Dong nay chi DOC ra de ho thay tool dang di theo cai gi.
        dev = settings.device_label(scene)
        if dev:
            layout.label(text="Following Cycles: rendering on %s." % dev,
                         icon='MEMORY')

        # TU NHA RAM SAU RENDER DA CHUYEN SANG DP_RAMchill (Ducphan 18/09/2026:
        # *"go khoi dp-optimize di vi cai nay o ram chill hop hon"*). Chi MOT addon
        # lam viec nay de khong xung dot khi cai chung. Ban cu cua module con trong
        # backup/dp_optimize_20260918_2034.zip.
        # Mot dong chi duong, de khach quen cho cu khong tuong tinh nang mat.
        layout.label(text="Memory hand-back: now in DP_RAMchill.",
                     icon='INFO')

        if scene.camera is None:
            layout.label(text="This scene has no camera.", icon='ERROR')

        if st.last_summary:
            box = layout.box()
            box.label(text=st.last_summary, icon='INFO')


class DPOPT_PT_advanced(_CyclesOnly, Panel):
    """Cho cat moi thu ma nguoi dung binh thuong khong can biet."""
    bl_label = "Advanced"
    bl_idname = "DPOPT_PT_advanced"
    bl_parent_id = "DPOPT_PT_main"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        scene = context.scene
        st = scene.dpopt          # chi doc, xem chu thich o DPOPT_PT_main
        layout = self.layout

        if st.running:
            layout.label(text="Working… %s" % st.progress, icon='TIME')
            return

        layout.label(text="These are chosen for you when you press Optimize.")

        col = layout.column(align=True)
        col.prop(st, "region_mode")
        col.prop(st, "region_size")

        col = layout.column(align=True)
        col.prop(st, "ref_samples")
        col.prop(st, "ref_threshold")
        col.prop(st, "repeats")
        col.prop(st, "rebase_every")
        col.prop(st, "warmup_max")
        col.prop(st, "warmup_tolerance")
        col.prop(st, "seed")

        if st.repeats < 2:
            box = layout.box()
            box.alert = True
            box.label(text="With one run per setting, a change that costs",
                      icon='ERROR')
            box.label(text="time can still measure as free, and get accepted.")

        lo, hi = _estimate(scene, st)
        layout.label(text="%d to %d test renders with these" % (lo, hi),
                     icon='RENDER_STILL')

        # VONG DO DAY DU — o day chu khong o ngoai. No ton bang chung ay lan
        # render that, nen no la mot viec nguoi dung CHU DONG chon lam luc
        # ranh may, khong phai thao tac hang ngay.
        box = layout.box()
        box.label(text="Full measurement", icon='SEQ_HISTOGRAM')
        box.label(text="Renders this scene about %d times at full size."
                       % props.AUTO_RENDERS)
        box.label(text="Small test renders were measured to rank settings")
        box.label(text="wrongly, so there is no fast shortcut. Esc stops it.")
        box.operator("dpopt.benchmark", text="Measure and Apply",
                     icon='PLAY').auto = True
        op = box.operator("dpopt.benchmark", text="Measure Only, Apply Nothing",
                          icon='SEQ_HISTOGRAM')
        op.auto = False

        # NOI RUOT CUA "Protect Texture Detail". Bang chinh chi co mot nut va
        # addon tu quyet dinh het; ai muon soi hay chinh thi vao day.
        box = layout.box()
        box.label(text="Split denoise internals", icon='NODETREE')
        col = box.column(align=True)
        col.prop(st, "split_prefilter")
        col.prop(st, "split_quality")
        col.prop(st, "split_denoise_volume")
        col = box.column(align=True)
        col.label(text="Check the rebuild is exact — a correct graph differs")
        col.label(text="from an ordinary render only by rounding error.")
        col.prop(st, "split_verify_samples")
        col.operator("dpopt.split_verify", icon='CHECKMARK')

        if st.ref_noise > st.ref_noise_warn:
            box = layout.box()
            box.alert = True
            box.label(text="Reference image is still noisy (%.4f)."
                           % st.ref_noise, icon='ERROR')
            box.label(text="Its own leftover grain counts as texture, so")
            box.label(text="every result is scored against a moving target.")
            box.label(text="Raise Reference Samples or lower its threshold.")


class DPOPT_PT_axes(_CyclesOnly, Panel):
    bl_label = "What To Measure"
    bl_parent_id = "DPOPT_PT_advanced"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        scene = context.scene
        st = scene.dpopt          # chi doc, xem chu thich o DPOPT_PT_main
        layout = self.layout

        if st.running:
            layout.label(text="Working… %s" % st.progress, icon='TIME')
            return

        row = layout.row(align=True)
        row.operator("dpopt.axes_set", text="All").mode = 'ALL'
        row.operator("dpopt.axes_set", text="Default").mode = 'DEFAULT'
        row.operator("dpopt.axes_set", text="None").mode = 'NONE'

        # MOT lan moi luot ve: do 21/09/2026 tren file khach bep moi lan goi
        # ~5 ms, ban cu goi 1 + so nhom lan (~30 ms moi luot ve bang).
        truc = settings.available_axes(scene)
        groups = []
        for axis, _ok in truc:
            if axis['group'] not in groups:
                groups.append(axis['group'])

        for group in groups:
            box = layout.box()
            box.label(text=group)
            for axis, ok in truc:
                if axis['group'] != group:
                    continue
                r = next((a for a in st.axes if a.key == axis['key']), None)
                if r is None:
                    continue
                line = box.row(align=True)
                line.enabled = ok
                line.prop(r, "enabled", text="")
                label = axis['label']
                if not ok:
                    label += "  (not available in this scene)"
                line.label(text=label)


class DPOPT_PT_results(_CyclesOnly, Panel):
    bl_label = "What Was Measured"
    bl_parent_id = "DPOPT_PT_main"
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return (context.engine == 'CYCLES'
                and len(context.scene.dpopt.results) > 0)

    def draw(self, context):
        st = context.scene.dpopt
        layout = self.layout

        if st.running:
            layout.label(text="Working… %s" % st.progress, icon='TIME')
            return
        if not len(st.results):
            layout.label(text="Nothing measured yet.")
            return

        head = layout.row(align=True)
        head.label(text="Setting")
        sub = head.row(align=True)
        sub.alignment = 'RIGHT'
        sub.label(text="Time")
        sub.label(text="Texture")
        sub.label(text="Detail")
        sub.label(text="Diff")

        base = next((r for r in st.results if r.kind == 'BASE'), None)

        for i, r in enumerate(st.results):
            box = layout.box() if r.kind in ('BASE', 'COMBO') else layout
            line = box.row(align=True)

            if r.kind == 'COMBO':
                icon = 'SOLO_ON'
            elif r.kind == 'BASE':
                icon = 'DOT'
            elif r.winner:
                icon = 'CHECKMARK'
            elif r.passed:
                icon = 'BLANK1'
            else:
                icon = 'X'
            line.label(text=r.label, icon=icon)

            sub = line.row(align=True)
            sub.alignment = 'RIGHT'
            # Phan tram lay tu `ratio` — da chuan hoa theo diem xuat phat do
            # duoc gan no nhat ve thoi gian, khong phai chia cho giay tho.
            if r.kind == 'BASE':
                sub.label(text="%.1fs" % r.secs)
            else:
                sub.label(text="%.1fs (%+.0f%%)"
                               % (r.secs, (r.ratio - 1.0) * 100.0))
            sub.label(text="%.3f" % r.texture)
            sub.label(text="%.2f" % r.detail)
            sub.label(text="%.4f" % r.diff)

            if r.kind != 'BASE':
                op = sub.operator("dpopt.apply", text="", icon='IMPORT')
                op.index = i

        if any(r.kind == 'COMBO' for r in st.results):
            layout.operator("dpopt.apply_combined", icon='CHECKMARK')

        col = layout.column(align=True)
        col.label(text="Texture is fine material detail — wood grain, weave.")
        col.label(text="It is what the denoiser blurs away first, so it is what")
        col.label(text="a setting has to keep in order to be accepted.")
        if st.timing_noise:
            col.label(text="Timing spread on this machine: %.0f%%"
                           % (st.timing_noise * 100.0),
                      icon='TIME')
        if st.warmup_used:
            col.label(text="Warm-up: %d renders discarded." % st.warmup_used,
                      icon='TIME')
        if not st.warmup_ok:
            col.label(text="The machine never settled within the warm-up limit.",
                      icon='ERROR')
            col.label(text="Treat these times as rough. Raise Warm-up Limit.")
        if st.drift > 0.15:
            col.label(text="This machine changed speed by %.0f%% during the run;"
                           % (st.drift * 100.0), icon='INFO')
            col.label(text="times are corrected against nearby baselines.")


class DPOPT_PT_thresholds(_CyclesOnly, Panel):
    bl_label = "Accept / Reject"
    bl_parent_id = "DPOPT_PT_advanced"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        st = context.scene.dpopt
        # Bang CON van duoc ve khi bang CHA da dung o "Working…" — Blender
        # khong dung ve con vi cha da dung. Khong chan thi giua lan do, khach
        # sua duoc nguong ngay trong luc dang do.
        if st.running:
            self.layout.label(text="Working… %s" % st.progress, icon='TIME')
            return
        col = self.layout.column(align=True)
        col.prop(st, "detail_floor")
        col.prop(st, "diff_ceiling")
        col.prop(st, "min_gain")
        col.prop(st, "blotch_slack")
        col = self.layout.column(align=True)
        col.prop(st, "edge_percentile")
        col.prop(st, "flat_percentile")
        col.prop(st, "ref_noise_warn")


class DPOPT_PT_split(_CyclesOnly, Panel):
    bl_label = "Split Light Channels"
    bl_parent_id = "DPOPT_PT_main"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        scene = context.scene
        st = scene.dpopt
        layout = self.layout

        # Bang cha ve chu "Working…" roi `return`, nhung bang CON van duoc ve
        # tiep — Blender khong dung ve con vi cha da dung. Khong chan o day
        # thi giua lan do, khach van thay day du nut Build/Measure/Verify va
        # bam duoc chong len lan do dang chay.
        if st.running:
            layout.label(text="Working… %s" % st.progress, icon='TIME')
            return

        if comp.is_active(scene):
            box = layout.box()
            box.label(text="Texture is protected.", icon='CHECKMARK')
            box.label(text="The denoiser only ever sees smooth light;")
            box.label(text="material colour is multiplied back afterwards.")
            # CAY DUNG TU TRUOC BAN SUA KINH nam san trong file (20/09/2026:
            # Ducphan cai ma moi ma file cu van mat chi tiet sau kinh). Mo file
            # thi addon tu dung lai — NOI RA cho khach biet. Con file dang mo
            # san luc cai addon thi dua nut.
            moi = comp.da_dung_lai(scene)
            if moi:
                box.label(text="Graph rebuilt on open for the glass fix.",
                          icon='INFO')
            elif comp.cay_loi_thoi(scene):
                box.label(text="Built before the glass fix: detail behind",
                          icon='ERROR')
                box.label(text="glass is blurred away.")
                box.operator("dpopt.split_rebuild", icon='FILE_REFRESH')
            # CAI GIA, DOC TU CHINH CAY. Moi node Denoise la mot luot khu
            # nhieu tren anh day du, chay SAU khi render xong — day la thanh
            # "Compositing" ma nguoi dung phai ngoi cho.
            cost = comp.tree_cost(scene)
            if cost:
                box.label(text="After each render: %d denoise passes on the %s."
                               % (cost['nodes'],
                                  "GPU" if cost['on_gpu'] else "processor"),
                          icon='TIME')
                cd = comp.chan_doan_lan_cuoi()
                if cd:
                    # Nguoi render tren may khac khong mo terminal. Dua cau
                    # chan doan cua lan render gan nhat len BANG, de no tu
                    # den voi nguoi doi thay vi nam trong mot cua so ho
                    # khong nhin.
                    for doan in cd.replace("[DP-OptimizeRender] ", "").split(" | "):
                        box.label(text=doan[:58], icon='DOT')
                if cost['dat']:
                    # Do 16/09/2026, 4000x2250, 3 node: tren bo xu ly
                    # 'Accurate' ton +31s, 'Fast' +7,6s. File dung o may co
                    # card roi mang sang may render khong card roi vao dung
                    # o nay.
                    box.label(text="Accurate guides on the processor cost more",
                              icon='ERROR')
                    box.label(text="than the render. Remove and press")
                    box.label(text="Protect Texture Detail again to retune.")
            box.operator("dpopt.split_clear", icon='X')
            return

        col = layout.column(align=True)
        col.label(text="Stops the denoiser blurring wood grain, fabric")
        col.label(text="weave and fine grain: light is denoised on its own,")
        col.label(text="then the material colour is multiplied back in.")

        # MOT NUT, KHONG O CHINH. Cai gi suy ra duoc tu scene thi addon tu
        # suy — xem `comp.needed`. Bay cho khach ba o de chinh la bat ho tra
        # loi ba cau hoi ma chinh ho khong co cach nao tra loi.
        want = comp.needed(scene)
        chans = ["diffuse", "glossy"]
        if want.get('transmission'):
            chans.append("transmission")
        if want.get('volume'):
            chans.append("volume")
        col = layout.column()
        col.scale_y = 2.0
        col.operator("dpopt.split_build", icon='NODETREE')
        layout.label(text="This scene needs %d channels: %s."
                          % (len(chans), ", ".join(chans)), icon='INFO')
        # Noi truoc cai gia, dung de no hien ra o thanh "Compositing" sau lan
        # render dau tien.
        n = comp.denoise_count(scene, want, st.split_denoise_volume)
        layout.label(text="Each render then denoises %d times on the %s."
                          % (n, "GPU" if comp._compositor_tren_card(scene)
                             else "processor"), icon='TIME')


class DPOPT_PT_vfb_render(_Base, Panel):
    """Cua so render rieng cua DP, va thu no lam duoc ma cua so cua Blender
    khong lam duoc.

    ⛔ KHONG LOC THEO ENGINE O DAY. Bang nay tung nam sau `_CyclesOnly`,
    va hau qua la tren EEVEE KHONG CO DUONG NAO CHAM TOI O TICK — bang bien
    mat ca. Trong khi chinh DP VFB thi chay voi moi engine:
    `tang_kinh._do_anh_vua_render` viet ra de do anh vua render vao cua so
    "cho nhung lan render KHONG chay bu kinh: canh khong co kinh, ENGINE
    KHONG PHAI CYCLES...". Cai doi Cycles chi la hop "Detail behind glass"
    ben trong, va hop do da tu noi "Not available: Cycles only".

    ⛔ DUNG NHET CAI NAY LAM O CON CUA "Split Light Channels" NUA. Da tung
    de o do va Ducphan hoi thang (20/09/2026): *"ua sao dp vfb lai o detail
    behind glass, sap xep lai giao dien addon sao cho hop ly di"*. DP VFB la
    CUA SO RENDER — no ngang hang voi viec render, khong phai mot tuy chon
    cua bo loc khu nhieu. Con "detail behind glass" la MOT viec ma cua so do
    lam, nen no nam BEN TRONG day.
    """
    bl_label = "DP VFB"
    bl_idname = "DPOPT_PT_vfb_render"
    bl_parent_id = "DPOPT_PT_main"

    def draw_header(self, context):
        # Cong tac bat/tat nam ngay tren thanh tieu de, kieu cua Blender.
        self.layout.prop(context.scene.dpopt, "vfb_bat", text="")

    def draw(self, context):
        scene = context.scene
        st = scene.dpopt          # chi doc, xem chu thich o DPOPT_PT_main
        layout = self.layout

        if st.running:
            layout.label(text="Working… %s" % st.progress, icon='TIME')
            return

        col = layout.column(align=True)
        if st.vfb_bat:
            col.label(text="F12 finishes in the DP window.", icon='CHECKMARK')
            col.label(text="Blender's own render window stays shut.")
        else:
            col.label(text="Off: F12 renders exactly as Blender always did.",
                      icon='INFO')
        layout.operator("dpopt.render_window", icon='WINDOW')

        _ve_glass_boost(layout, scene, st)


CLASSES = (DPOPT_PT_main, DPOPT_PT_vfb_render, DPOPT_PT_results,
           DPOPT_PT_split, DPOPT_PT_advanced, DPOPT_PT_axes,
           DPOPT_PT_thresholds)


def _ve_glass_boost(layout, scene, st):
    """O Glass Boost — viec rieng cua DP VFB, khong phai cua bo khu nhieu.

    Bat DP VFB thi F12 tu chay het. Nut o day la duong di tay cho ai muon
    lam mot khung rieng ma khong bat cong tac.
    """
    box = layout.box()
    box.label(text="Detail behind glass", icon='SHADERFX')
    ly_do = tang_kinh.vi_sao_khong(scene)
    if ly_do:
        box.label(text="Not available: %s." % ly_do, icon='INFO')
        return
    box.label(text="Denoising cannot bring back what is behind")
    box.label(text="glass. This renders those areas again with")
    box.label(text="more samples, then blends them in.")
    box.prop(st, "glass_boost_samples")
    col = box.column()
    col.scale_y = 1.4
    col.operator("dpopt.render_glass_boost", icon='RENDER_STILL')
    if not st.vfb_bat:
        box.label(text="Or tick DP VFB above and just press F12.",
                  icon='INFO')
