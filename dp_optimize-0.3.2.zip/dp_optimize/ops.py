# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
"""Cac nut bam.

Docstring cua moi lop Operator LA TOOLTIP tren giao dien — nen chung phai la
tieng Anh, khong phai tieng Viet. Day la cho rat de quen.
"""
import json
import time

import bpy
from bpy.props import IntProperty, StringProperty

from . import bench, comp, metrics, props, settings


def _redraw():
    for win in bpy.context.window_manager.windows:
        for area in win.screen.areas:
            if area.type == 'PROPERTIES':
                area.tag_redraw()


def _store(st, runner):
    """Do ket qua tu Runner vao CollectionProperty de giao dien ve."""
    st.results.clear()
    winners = runner.winners()
    win_ids = {id(r) for r in winners.values()}
    base_row = runner.base()
    base_m = base_row['m'] if base_row else None
    for r in runner.results:
        row = st.results.add()
        row.kind = r['kind']
        row.label = r['label']
        row.group = r['group']
        row.key = r['key']
        row.option = r['option']
        row.secs = r['secs']
        row.ratio = runner.ratio(r)
        m = r['m']
        row.diff = float(m.get('diff', 0.0))
        row.detail = float(m.get('detail', 0.0))
        row.texture = float(m.get('texture', 0.0))
        row.blotch = float(m.get('blotch', 0.0))
        row.passed = metrics.passes(m, base_m, st.detail_floor, st.diff_ceiling)
        row.winner = id(r) in win_ids
        row.overrides = json.dumps(r['overrides'] or {})

    st.ref_noise = float(getattr(runner, 'ref_noise', 0.0))
    st.ref_secs = float(getattr(runner, 'ref_secs', 0.0))
    st.timing_noise = float(runner.timing_noise)
    st.drift = float(runner.drift)
    st.warmup_used = int(runner.warmup_count)
    st.warmup_ok = bool(runner.warm_stable())

    base = base_row
    combo = runner.combo()
    if base and combo:
        st.last_summary = ("Combined: %+.0f%% material texture kept, "
                           "%+.0f%% render time"
                           % (runner.texture_gain(combo) * 100.0,
                              (runner.ratio(combo) - 1.0) * 100.0))
        # CHOT CHAN CUOI. Neu gop het cac phuong an "thang" lai ma anh khong
        # con dep hon, hoac gop lai thi hoa ra cham di, thi chung khong thang
        # that. Phai noi thang ra, vi nguoi dung sap bam nut Apply.
        if winners and not runner.is_win(combo):
            st.last_summary += (" — these did not hold up when measured "
                                "together, so nothing here is worth applying")
    elif base:
        st.last_summary = ("Nothing kept more material texture without costing "
                           "render time or leaving more noise. Your settings "
                           "are already the best of what was measured.")
    else:
        st.last_summary = ""


def _auto_setup(scene, st):
    """Tu chon thong so do. Nguoi dung KHONG phai biet gi ve phep do.

    Moi con so o day deu suy ra tu chinh scene, khong phai gu cua ai. Ai
    muon can thiep thi mo bang Advanced — con mac dinh la mot nut bam.
    """
    # KHUNG DAY. Khong co duong tat nao ca — xem `bench.Runner._set_region`.
    # Do tren anh nho nhanh that, nhung xep hang sai, va ap ket qua sai vao
    # file cua khach thi render CHAM DI. Tha lau con hon sai.
    st.region_mode = 'FULL'

    cy = scene.cycles
    # Anh chuan phai sach hon han anh thuong, neu khong thi chinh no lam
    # moi ket qua bi cham diem oan. Nhung no cung la lan render dat nhat,
    # nen chan tren 384 chu khong 1024.
    st.ref_samples = int(max(192, min(384, max(1, cy.samples) * 2)))
    st.ref_threshold = max(0.0005, (cy.adaptive_threshold or 0.01) / 4.0)

    # MOI PHEP DO CHAY MOT LAN. Chong nhieu bang cach khac, re hon nhieu:
    # xen ke do lai diem xuat phat de chua troi toc do, roi bat buoc bo gop
    # cuoi cung phai do LAI 3 LAN moi duoc ap dung. Cai gi lot qua vong dau
    # do nhieu thi chet o vong xac nhan.
    st.repeats = 1
    st.combo_repeats = 2
    # Moi lan render bay gio la MOT KHUNG DAY DU, dat bang dung mot lan
    # render that cua khach. Bo di 4 lan de "lam nong may" la doi cua ho 4
    # lan render khong de lam gi.
    st.warmup_max = 1

    keys = _auto_axes(scene)
    for row in st.axes:
        row.enabled = row.available and row.key in keys


def _auto_axes(scene):
    """Truc nao dang do tren scene NAY.

    Nhom khu nhieu chi hien ra khi dang dung OpenImageDenoise. Ai de OptiX
    thi ba trong do khong ton tai, va mot che do mot nut khong con truc nao
    de do thi chi la mot nut bam cho vui — nen luc do do nhom phan bo mau.
    """
    if settings.is_oidn(scene):
        return props.AUTO_AXES_DENOISE
    return props.AUTO_AXES_SAMPLING


class DPOPT_OT_benchmark(bpy.types.Operator):
    """Measure this scene and keep whatever holds on to the most material texture.

    Everything is chosen for you. Nothing is changed unless it keeps more
    fine texture without costing render time or leaving more noise
    """
    bl_idname = "dpopt.benchmark"
    # Ten goc = chu tren panel. "Optimize This Scene" nay la ten nut
    # dpopt.speedup (Ducphan 14/09/2026) - de trung thi o tim F3 / lich su
    # Undo hien hai dong giong het.
    bl_label = "Measure and Apply"
    bl_options = {'REGISTER', 'UNDO'}

    auto: bpy.props.BoolProperty(
        default=True,
        description="Pick the measurement settings automatically and apply the "
                    "result when it holds up")

    _timer = None
    _t0 = 0.0
    runner = None

    @classmethod
    def poll(cls, context):
        return (context.scene is not None
                and context.scene.render.engine == 'CYCLES'
                and context.scene.camera is not None)

    def _begin(self, context):
        scene = context.scene
        settings.refresh_devices()      # ngoai `draw` moi duoc lam viec nay
        st = props.ensure_axes(scene)
        if self.auto:
            _auto_setup(scene, st)
        st.results.clear()
        st.last_summary = ""
        self.runner = bench.Runner(scene, st)
        total = self.runner.build_jobs()
        self.runner.start()
        self._t0 = time.perf_counter()
        st.running = True
        st.progress = "0 / %d" % total
        return total

    def _tick(self, context):
        st = context.scene.dpopt
        alive = self.runner.step()
        done = min(self.runner.index, len(self.runner.jobs))
        total = len(self.runner.jobs)
        # Bao con bao lau nua. Mot thanh dem "12 / 31" khong noi len dieu gi;
        # nguoi dung can biet co nen di pha ca phe hay khong.
        left = ""
        if self._t0 and done > 0:
            per = (time.perf_counter() - self._t0) / done
            secs = per * max(0, total - done)
            left = ("  ~%d min left" % round(secs / 60.0) if secs >= 90
                    else "  ~%d s left" % round(secs))
        st.progress = "%d / %d%s" % (done, total, left)
        _redraw()
        return alive

    def _end(self, context, cancelled=False):
        st = context.scene.dpopt
        try:
            _store(st, self.runner)
        finally:
            self.runner.finish()
        st.running = False
        st.progress = ""

        if self.runner.error:
            self.report({'ERROR'}, self.runner.error)
        elif cancelled:
            self.report({'WARNING'}, "Cancelled — your settings are unchanged")
        elif self.auto:
            self._auto_apply(context, st)
        else:
            self.report({'INFO'}, st.last_summary or "Measurement finished")
        _redraw()

    def _auto_apply(self, context, st):
        """Tu ap dung — nhung CHI KHI ket qua tru duoc khi do chung.

        Neu gop cac phuong an thang lai ma anh khong con dep hon, hoac gop
        lai thi hoa ra cham di, thi chung khong thang that. Luc do KHONG
        duoc doi gi cua khach het.
        """
        combo = self.runner.combo()
        if combo and self.runner.is_win(combo):
            ov = combo['overrides'] or {}
            settings.apply(context.scene, ov)
            pct = self.runner.texture_gain(combo) * 100.0
            secs = (self.runner.ratio(combo) - 1.0) * 100.0
            st.last_summary = ("Keeps %.0f%% more material texture at %+.0f%% "
                               "render time. Changed %d settings. Press "
                               "Ctrl+Z to undo." % (pct, secs, len(ov)))
            self.report({'INFO'}, st.last_summary)
        else:
            st.last_summary = ("Nothing kept more material texture without "
                               "costing render time. Nothing changed.")
            self.report({'INFO'}, st.last_summary)

    # --- chay dong bo: dung cho --background va cho ban khong co cua so ---
    def execute(self, context):
        self._begin(context)
        try:
            while self._tick(context):
                pass
        finally:
            self._end(context)
        return {'CANCELLED'} if self.runner.error else {'FINISHED'}

    def invoke(self, context, event):
        if bpy.app.background:
            return self.execute(context)
        self._begin(context)
        wm = context.window_manager
        self._timer = wm.event_timer_add(0.05, window=context.window)
        wm.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type in {'ESC'}:
            self._cleanup(context)
            self._end(context, cancelled=True)
            return {'CANCELLED'}
        if event.type == 'TIMER':
            if not self._tick(context):
                self._cleanup(context)
                self._end(context)
                return {'FINISHED'}
        return {'PASS_THROUGH'}

    def _cleanup(self, context):
        if self._timer is not None:
            context.window_manager.event_timer_remove(self._timer)
            self._timer = None

    def cancel(self, context):
        """Blender HUY lenh tu ben ngoai (mo file .blend khac, dong cua so,
        doi khong gian lam viec) — luc do no khong goi `modal` nua.

        ⛔ QUEN HAM NAY thi bo dem gio o lai chay tiep, va co `running` ket
        True: bang ghi "Working…" mai mai va nut Measure khong bam duoc nua.
        Blender khong goi `cancel` khi `modal` tu tra {'CANCELLED'}, va o do
        `_timer` da ve None, nen khong don hai lan.
        """
        if self._timer is None:
            return
        self._cleanup(context)
        try:
            self._end(context, cancelled=True)
        except Exception as e:                               # noqa: BLE001
            print("[DP-OptimizeRender] benchmark cancel: %s" % e)


class DPOPT_OT_apply(bpy.types.Operator):
    """Apply this measured setting to the scene"""
    bl_idname = "dpopt.apply"
    bl_label = "Apply"
    bl_options = {'REGISTER', 'UNDO'}

    index: IntProperty(default=-1)

    def execute(self, context):
        st = context.scene.dpopt
        if not (0 <= self.index < len(st.results)):
            self.report({'ERROR'}, "No such result")
            return {'CANCELLED'}
        row = st.results[self.index]
        try:
            ov = json.loads(row.overrides or "{}")
        except ValueError:
            self.report({'ERROR'}, "Result data is unreadable")
            return {'CANCELLED'}
        if not ov:
            self.report({'INFO'}, "Nothing to change — this is your current setting")
            return {'FINISHED'}
        settings.apply(context.scene, ov)
        self.report({'INFO'}, "Applied: %s" % settings.describe(context.scene, ov))
        return {'FINISHED'}


class DPOPT_OT_apply_combined(bpy.types.Operator):
    """Apply every winning setting from the last measurement at once"""
    bl_idname = "dpopt.apply_combined"
    bl_label = "Apply Combined Winners"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        st = context.scene.dpopt
        for row in st.results:
            if row.kind == 'COMBO':
                try:
                    ov = json.loads(row.overrides or "{}")
                except ValueError:
                    ov = {}
                if ov:
                    settings.apply(context.scene, ov)
                    self.report({'INFO'}, "Applied %d settings" % len(ov))
                    return {'FINISHED'}
        self.report({'WARNING'}, "No combined result to apply")
        return {'CANCELLED'}


class DPOPT_OT_axes_set(bpy.types.Operator):
    """Turn every measurable setting on or off"""
    bl_idname = "dpopt.axes_set"
    bl_label = "Set Axes"
    bl_options = {'REGISTER', 'UNDO'}

    mode: StringProperty(default='ALL')

    def execute(self, context):
        st = props.ensure_axes(context.scene)
        for row in st.axes:
            if self.mode == 'ALL':
                row.enabled = row.available
            elif self.mode == 'NONE':
                row.enabled = False
            else:
                row.enabled = row.available and row.key in props.DEFAULT_ON
        return {'FINISHED'}


def _instant_wins(scene):
    """Nhung thay doi nhanh hon MA KHONG CAN DO tren tung scene.

    Trong day chi duoc chua thu nao nhanh hon vi LY DO CAU TRUC, khong phai
    vi may man voi mot scene cu the. Do o khung day 1920x1080 ngay
    05/08/2026, kem cham chat luong so voi ban hoi tu:

        nguyen trang        9.05s          detail 0.776   diff 0.0015
        bat khu nhieu GPU   3.55s  -61%    detail 0.777   diff 0.0015

    Khu nhieu chay bang CPU trong khi may co GPU khong phai la mot lua chon
    ve chat luong — no chi la dung sai phan cung. Nen no la mot NUT BAM,
    khong phai mot vong do 17 lan render.

    Da THU va DA LOAI: `scrambling Auto` chi -2%, nam trong sai so. Cai gi
    khong chac thi khong duoc tu bat cho khach.

    TU 14/09/2026 (nut doi ten "Optimize This Scene"): them nhom BO NHO do chu
    du an chot - tran anh 2048 (render + khung nhin), o 1024, tat Persistent
    Data. Tran anh LA doi anh; xem khoi chu thich trong than ham.
    """
    todo = []
    cy = scene.cycles
    # CHI KHI CYCLES DANG DUNG CARD. Nguoi dung de scene o CPU thi ho co ly
    # do — dang dung card cho viec khac, driver do chung, VRAM khong du. Bat
    # khu nhieu chay card luc do la tu y keo card vao mot cong viec ma ho da
    # chon khong dung no. Cycles chon sao thi tool chay vay.
    if (settings.is_oidn(scene) and settings.uses_gpu(scene)
            and settings.has_oidn_gpu(scene) and not cy.denoising_use_gpu):
        todo.append(('cycles.denoising_use_gpu', True,
                     "Denoising moved to the GPU, alongside the render"))
    # ===== KHU NHIEU KHUNG NHIN + SO MAU - DUCPHAN CHOT 21/09/2026 =====
    # "dong y de denoise viewport ve optix / sample viewport va render chuyen
    # ve 64". CHI khung nhin ve OptiX: o khung nhin toc do la chinh. O Render
    # GIU NGUYEN - compositor (cay Split) chi co OpenImageDenoise (node
    # Denoise 5.2 chi co Prefilter/Quality/HDR, do 21/09/2026), va OIDN giu
    # chi tiet hon OptiX. May khong co card NVIDIA thi bo qua phan OptiX.
    if settings.has_optix(scene):
        if not cy.use_preview_denoising:
            todo.append(('cycles.use_preview_denoising', True,
                         "Viewport denoising on"))
        if cy.preview_denoiser != 'OPTIX':
            todo.append(('cycles.preview_denoiser', 'OPTIX',
                         "Viewport denoiser set to OptiX (faster while you "
                         "move around)"))
    for path, nhan in (('cycles.samples', "Render"),
                       ('cycles.preview_samples', "Viewport")):
        if settings.get(scene, path) != SO_MAU:
            todo.append((path, SO_MAU, "%s samples set to %d" % (nhan, SO_MAU)))
    # "nut optimize tat ca noise Threshold" (Ducphan 21/09/2026): tat lay mau
    # thich ung o CA Render lan Viewport - moi diem anh chay du SO_MAU.
    for path, nhan in (('cycles.use_adaptive_sampling', "Render"),
                       ('cycles.use_preview_adaptive_sampling', "Viewport")):
        if settings.exists(scene, path) and settings.get(scene, path):
            todo.append((path, False, "%s Noise Threshold off" % nhan))
    # ===== BO NHO (VRAM/RAM) - DUCPHAN CHOT 14/09/2026 =====
    # "cho tat ca nhung toi uu o simplify (2048), tile (1024), viewport texture
    # (2048), tat persistent data vao trong nut". Nguyen do: `bantest_v20` (377
    # anh = 6,43 GB co goc, 16 trieu tam giac, card 16 GB) - Blender giu 8,8 GB
    # VRAM o khung nhin Solid/Texture, card RO'I mot lan khi render.
    # ⚠ TRAN ANH 2048 LA DOI ANH (anh > 2048 px mo di khi nhin gan) - nguoc
    # voi luat cu "cai gi doi anh thi khong tu bat". Chu du an da chot doi luat
    # cho nut nay; dung "sua lai" ve luat cu.
    # Chi HA, khong bao gio NANG: nguoi dung da dat tran thap hon (1024...) thi
    # giu nguyen. Tinh theo co anh (w*h*kenh): bantest 6,43 -> 2,49 GB.
    if not scene.render.use_simplify:
        todo.append(('render.use_simplify', True,
                     "Simplify on (it carries the texture size limit)"))
    # "max subdivision o simplify ve 2" (Ducphan 21/09/2026). Chi HA nhu tran
    # anh: nguoi dung da de thap hon (0, 1) thi giu nguyen.
    for path, nhan in (('render.simplify_subdivision', "Viewport"),
                       ('render.simplify_subdivision_render', "Render")):
        if settings.exists(scene, path) and settings.get(scene, path) > MAX_SUBDIV:
            todo.append((path, MAX_SUBDIV, "%s Max Subdivision set to %d"
                         % (nhan, MAX_SUBDIV)))
    for path, nhan in (('cycles.texture_limit_render', "Render"),
                       ('cycles.texture_limit', "Viewport render")):
        if settings.exists(scene, path) and _tran_qua(settings.get(scene, path)):
            todo.append((path, str(TRAN_ANH),
                         "%s textures capped at %d px (less video memory; "
                         "textures above that lose close-up detail)" % (nhan, TRAN_ANH)))
    # O 1024: bo dem anh (film) tren card chi lon bang mot o, khong bang ca
    # khung - khung 4000x2250 cua bantest_v20 la 9 trieu diem anh.
    if settings.exists(scene, 'cycles.use_auto_tile') and not cy.use_auto_tile:
        todo.append(('cycles.use_auto_tile', True, "Tiled rendering on"))
    if settings.exists(scene, 'cycles.tile_size') and cy.tile_size > TILE:
        todo.append(('cycles.tile_size', TILE,
                     "Render in %d px tiles (smaller image buffers on the card)" % TILE))
    # PERSISTENT DATA: TAT, khong bat. Truoc 14/09/2026 nut nay BAT no khi
    # `frame_end > frame_start` - moi scene mac dinh la khung 1..250 nen anh
    # tinh cung bi bat. Do (tools/probe_vram_sau_render.py, VRAM rieng tien
    # trinh): tat -> render xong con 0 MB; bat -> giu 1.108 MB tren canh nho.
    if scene.render.use_persistent_data:
        todo.append(('render.use_persistent_data', False,
                     "Persistent Data off (video memory is handed back after "
                     "each render)"))
    # TRAN ANH KHUNG NHIN: Preferences, khong nam trong file. Khung nhin Solid
    # (Color: Texture) / Material Preview day anh len card DUNG CO GOC khi
    # Preferences de 'CLAMP_OFF' (mac dinh) - Cycles texture limit KHONG ap
    # cho khung nhin.
    gl = getattr(bpy.context.preferences.system, 'gl_texture_limit', None)
    if gl is not None and _tran_qua(gl):
        todo.append(('sys.gl_texture_limit', 'CLAMP_%d' % TRAN_ANH,
                     "Viewport textures capped at %d px (a Preferences "
                     "setting: every file, not undone by Ctrl+Z)" % TRAN_ANH))
    return todo


TRAN_ANH = 2048
TILE = 1024
SO_MAU = 64
MAX_SUBDIV = 2


def _tran_qua(gt):
    """Tran anh hien tai (enum Cycles '2048' / 'OFF' hoac Preferences
    'CLAMP_2048' / 'CLAMP_OFF') CAO HON TRAN_ANH hay khong gioi han."""
    s = str(gt).replace('CLAMP_', '')
    if s.upper() == 'OFF':
        return True
    try:
        return int(s) > TRAN_ANH
    except ValueError:
        return False


class DPOPT_OT_speedup(bpy.types.Operator):
    """Apply the speed and memory settings that need no test render: GPU
    denoising, OptiX viewport denoising, 64 samples and Noise Threshold off
    (render and viewport), Simplify Max Subdivision 2, textures capped at 2048 px (render and viewport), 1024 px tiles,
    Persistent Data off. Textures above 2048 px lose close-up
    detail. Handing memory back after a render is done by DP_RAMchill
    """
    # bl_idname GIU NGUYEN (dpopt.speedup) - chi doi TEN nut (Ducphan
    # 14/09/2026: "doi nut thanh OPTIMIZE THIS SCENE").
    bl_idname = "dpopt.speedup"
    bl_label = "Optimize This Scene"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        scene = context.scene
        return scene is not None and scene.render.engine == 'CYCLES'

    def execute(self, context):
        scene = context.scene
        settings.refresh_devices()
        todo = _instant_wins(scene)
        # Nha RAM sau render da chuyen sang DP_RAMchill (18/09/2026). Tat
        # Persistent Data van nam trong `todo`. Do 16/09/2026 tren PN4.blend:
        # bat -> render xong giu 12.479 MB RAM + 5.913 MB VRAM; tat -> 7.378
        # MB + 3.564 MB.
        if not todo:
            xong = "Already set. Nothing here needed changing."
            self.report({'INFO'}, "Already set — nothing left to switch on")
            scene.dpopt.last_summary = xong
            return {'FINISHED'}
        for path, value, _msg in todo:
            settings.put(scene, path, value)
        bits = [m for _p, _v, m in todo]
        msg = "; ".join(bits)
        # Ctrl+Z chi hoan tac phan nam trong FILE; tran anh khung nhin la
        # Preferences - noi ro, dung de nguoi dung tuong da hoan tac het.
        if any(p.startswith('sys.') for p, _v, _m in todo):
            scene.dpopt.last_summary = (msg + ". Press Ctrl+Z to undo the scene "
                                        "settings; the viewport texture limit "
                                        "is in Preferences > Viewport.")
        else:
            scene.dpopt.last_summary = msg + ". Press Ctrl+Z to undo."
        self.report({'INFO'}, msg)
        return {'FINISHED'}


class DPOPT_OT_use_cycles(bpy.types.Operator):
    """Switch this scene to the Cycles render engine"""
    bl_idname = "dpopt.use_cycles"
    bl_label = "Switch to Cycles"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.scene and context.scene.render.engine != 'CYCLES'

    def execute(self, context):
        context.scene.render.engine = 'CYCLES'
        self.report({'INFO'}, "Render engine set to Cycles")
        return {'FINISHED'}


class DPOPT_OT_denoise_gpu(bpy.types.Operator):
    """Turn on GPU denoising for OpenImageDenoise.

    Enabling OptiX in Preferences does not do this: it is a separate switch
    and it is off by default
    """
    bl_idname = "dpopt.denoise_gpu"
    bl_label = "Enable GPU Denoising"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        scene = context.scene
        return (scene and scene.render.engine == 'CYCLES'
                and settings.is_oidn(scene) and settings.has_oidn_gpu(scene)
                and not scene.cycles.denoising_use_gpu)

    def execute(self, context):
        context.scene.cycles.denoising_use_gpu = True
        self.report({'INFO'}, "GPU denoising enabled")
        return {'FINISHED'}


class DPOPT_OT_split_build(bpy.types.Operator):
    """Protect material texture from the denoiser.

    Diffuse, glossy and transmission light are denoised on their own, before
    their colour pass is multiplied back in — so wood grain, fabric weave and
    fine grain are never something the denoiser has to guess at. Set up for
    you: only the channels this scene actually uses are built
    """
    bl_idname = "dpopt.split_build"
    bl_label = "Protect Texture Detail"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.scene and context.scene.render.engine == 'CYCLES'

    def execute(self, context):
        scene = context.scene
        st = scene.dpopt
        want = comp.needed(scene)

        # THIET BI TRUOC, CAY SAU. Prefilter tu chon doc `compositor_device`
        # de biet may node Denoise se chay o dau (xem `comp.auto_prefilter`),
        # nen cho dat thiet bi phai dung TRUOC luc dung cay. Dat sau la cay
        # duoc dung theo thiet bi CU — dung loi da co trong ban truoc.
        #
        # COMPOSITOR DI THEO CYCLES, khong tu chon.
        # Cycles dang render bang bo xu ly ma bat compositor chay tren card
        # la tu y dung mot thiet bi ma nguoi dung da chon KHONG dung. Con
        # dang render bang card thi compositor cung nen o do: anh vua render
        # xong da nam san trong bo nho card.
        moved = None
        want_dev = settings.compositor_device_for(scene)
        if ('compositor_device' in scene.render.bl_rna.properties
                and scene.render.compositor_device != want_dev):
            scene.render.compositor_device = want_dev
            moved = want_dev

        prefilter = st.split_prefilter
        if prefilter == 'Auto':
            prefilter = comp.auto_prefilter(scene)
        comp.build(scene, context.view_layer, use_denoise=True,
                   prefilter=prefilter, quality=st.split_quality,
                   denoise_volume=st.split_denoise_volume)

        # Denoise trong Cycles va denoise trong compositor cung luc la khu
        # nhieu HAI LAN — cham hon va bet hon. Tat cai trong Cycles di.
        was = scene.cycles.use_denoising
        scene.cycles.use_denoising = False
        scene.render.use_compositing = True

        bits = ["Texture protected"]
        chans = ["diffuse", "glossy"]
        if want.get('transmission'):
            chans.append("transmission")
        if want.get('volume'):
            chans.append("volume")
        bits.append("%s denoised separately" % ", ".join(chans))
        if was:
            bits.append("scene denoising turned off")
        if moved:
            bits.append("compositor follows Cycles onto the %s"
                        % ("GPU" if moved == 'GPU' else "CPU"))
        # NOI RA CAI GIA. Moi node Denoise la mot luot khu nhieu tren ANH DAY
        # DU, sau khi render xong — nguoi dung ngoi nhin thanh "Compositing"
        # chay ma khong biet no den tu dau. Tren bo xu ly no ton hon ca mot
        # lan render, do that 16/09/2026; xem `comp.auto_prefilter`.
        n = comp.denoise_count(scene, want, st.split_denoise_volume)
        bits.append("compositing runs %d denoise passes on the %s (%s guides)"
                    % (n, "GPU" if comp._compositor_tren_card(scene) else "CPU",
                       prefilter.lower()))
        msg = "; ".join(bits)
        st.last_summary = msg + ". Press Ctrl+Z to undo."
        self.report({'INFO'}, msg)
        return {'FINISHED'}


class DPOPT_OT_split_clear(bpy.types.Operator):
    """Remove the split denoise graph and turn scene denoising back on"""
    bl_idname = "dpopt.split_clear"
    bl_label = "Remove Split Denoise"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.scene and comp.is_active(context.scene)

    def execute(self, context):
        scene = context.scene
        comp.clear(scene)
        scene.cycles.use_denoising = True
        self.report({'INFO'}, "Split denoise removed")
        return {'FINISHED'}


class DPOPT_OT_split_rebuild(bpy.types.Operator):
    """Rebuild the split denoise graph with this version of the add-on,
    keeping its prefilter and quality. Needed for graphs built before the
    glass fix: they blur everything seen through glass"""
    bl_idname = "dpopt.split_rebuild"
    bl_label = "Rebuild for Glass"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.scene and comp.is_active(context.scene)

    def execute(self, context):
        comp.dung_lai(context.scene)
        self.report({'INFO'}, "Split graph rebuilt: glass now keeps the detail "
                              "behind it")
        return {'FINISHED'}


class DPOPT_OT_split_verify(bpy.types.Operator):
    """Render twice with denoising off and check the split graph rebuilds the
    image exactly.

    A correct rebuild differs from the ordinary render only by floating point
    error. A large difference means a pass is missing, not that it is close
    enough
    """
    bl_idname = "dpopt.split_verify"
    bl_label = "Verify Split Denoise"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return (context.scene and context.scene.render.engine == 'CYCLES'
                and context.scene.camera is not None)

    def execute(self, context):
        scene = context.scene
        st = scene.dpopt
        out = comp.verify(scene, region_size=st.region_size,
                          samples=st.split_verify_samples,
                          view_layer=context.view_layer)
        if not out.get('ok'):
            self.report({'ERROR'}, "Verification failed: %s"
                        % out.get('reason', 'unknown'))
            return {'CANCELLED'}
        md = out['max_diff']
        # ALPHA DUOC BAO RIENG. Gop chung vao mot con so thi mot cai nen trong
        # suot bi dac lai chi keo trung binh len chut xiu roi lot qua — dung
        # cai bay da xay ra that ngay 06/08/2026.
        amd = out.get('alpha_max_diff', 0.0)
        # NGUONG DI THEO NHIEU CUA CHINH PHEP DO. Tren may chay Cycles bang
        # nhieu thiet bi, hai lan render y het nhau da lech nhau toi 0,83
        # (do 16/09/2026, PN4.blend) — doi phep ghep khop den 1e-3 o do la
        # doi mot thu ma phep do khong nhin thay noi. Xem `comp.verify`.
        # ⛔ PHAN XET BANG TRUNG BINH, KHONG BANG LON NHAT. "Lon nhat" la
        # gia tri cua MOT diem anh trong 1,4 trieu diem: no nhay theo tung
        # dom sang lac va khong lap lai duoc. Trung binh thi on dinh.
        nhieu_max = out.get('noise_max')
        nhieu_tb = out.get('noise_mean')
        mean_d = out['mean_diff']
        if nhieu_tb is None:
            ok_rgb = md < 1e-3                 # ban cu: doi khop tuyet doi
            nguong_tb = 1e-3
        else:
            # Phep ghep dung khi cai lech cua no khong phan biet duoc voi
            # chenh lech giua hai lan render y het nhau.
            nguong_tb = max(1e-5, nhieu_tb * 2.0)
            ok_rgb = mean_d <= nguong_tb
        msg = ("Rebuild matches: max difference %.7f, mean %.7f, alpha %.7f "
               "(%.1fs)" % (md, mean_d, amd, out['secs']))
        if nhieu_tb is not None:
            msg += ("; two identical renders of this scene already differ by "
                    "%.7f mean / %.7f max, so the rebuild is within the noise "
                    "of the measurement itself" % (nhieu_tb, nhieu_max or 0.0))
        ok_alpha = amd < 1e-3
        if ok_rgb and ok_alpha:
            self.report({'INFO'}, msg)
        elif ok_rgb:
            msg = ("Colour matches but ALPHA does not (%.5f). A transparent "
                   "background would come out solid. %s" % (amd, msg))
            self.report({'WARNING'}, msg)
        else:
            msg = "Rebuild does NOT match — %s" % msg
            self.report({'WARNING'}, msg)
        st.last_summary = msg
        return {'FINISHED'}


CLASSES = (DPOPT_OT_benchmark, DPOPT_OT_apply, DPOPT_OT_apply_combined,
           DPOPT_OT_axes_set, DPOPT_OT_speedup, DPOPT_OT_use_cycles,
           DPOPT_OT_denoise_gpu, DPOPT_OT_split_build, DPOPT_OT_split_clear,
           DPOPT_OT_split_rebuild, DPOPT_OT_split_verify)
