# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
bl_info = {
    "name": "DP-OptimizeRender",
    "author": "Ducphan",
    "version": (0, 3, 2),
    "blender": (5, 2, 0),
    "location": "Properties > Render > DP Optimize",
    "description": "Stop the denoiser blurring material texture. Builds a "
                   "compositor graph that denoises light on its own, then "
                   "multiplies wood grain and fabric weave back in.",
    "warning": "",
    "category": "Render",
}

# ===========================================================================
# DU AN MOI, 05/08/2026
# ---------------------------------------------------------------------------
# LY DO ADDON NAY TON TAI
#   Moi bai huong dan "toi uu Cycles" tren mang deu la mot bo so co dinh, do
#   tren scene cua NGUOI KHAC. Da do tren Blender 5.2 ngay 05/08/2026, hon
#   nua so bo so pho bien la VO NGHIA hoac SAI:
#
#     - "Tick OptiX thi OIDN tu chay GPU"  -> SAI. `denoising_use_gpu` la mot
#       cong tac RIENG, mac dinh False.
#     - "Chuyen Automatic sang Blue Noise" -> 5.2 AUTOMATIC DA la blue-noise.
#     - "Clamp Indirect xuong 10"          -> mac dinh 5.2 DA la 10.0.
#     - "Noise Threshold 0.02-0.01"        -> mac dinh DA la 0.01.
#     - "Input passes Albedo + Normal"     -> mac dinh DA la RGB_ALBEDO_NORMAL.
#     - "Prefilter Accurate"               -> mac dinh DA la ACCURATE.
#     - "Bat Path Guiding"                 -> CPU-only. Bang UI co
#       `poll = use_cpu(context)`. Render GPU thi no khong hien ra.
#     - "Denoise 4 kenh roi Mix Add"       -> SAI PHEP TOAN. Do that ngay
#       05/08/2026: bo pass Color di thi lech max 0.67. Phep dung phai la
#       (Dir + Ind) * Color cho tung nhom, cong Emission + Environment +
#       Volume. Do lai bang `comp.verify()` -> lech 0.000000.
#
#   Nen addon nay KHONG ban so. No DO tren scene dang mo roi bao so.
#
# ===========================================================================
# LUAT CUA DU AN — Ducphan chot 06/08/2026
#
#   Nang cap ve mat CHAT LUONG TEXTURE va ANH SANG, bang COMPOSITION,
#   TU DONG HOA, CHAT LUONG CAO NHAT, THOI GIAN PHAT SINH IT NHAT.
#
# Doc tung ve, vi moi ve deu da co mot lan lam sai:
#
#   CHAT LUONG TEXTURE, ANH SANG — muc tieu la giu chi tiet nho ma bo khu
#     nhieu hay ca mo: van go, soi vai, hat son. KHONG phai lam render nhanh
#     hon. Ten du an la "Optimize render" nen rat de truot ve toc do.
#
#   BANG COMPOSITION — don bay chinh la cay compositor tach kenh: khu nhieu
#     tren anh sang thuan roi nhan pass Color tro lai, nen bo khu nhieu khong
#     bao gio nhin thay van vat lieu. Xem `comp.build`.
#
#   TU DONG HOA — addon tu doc scene ma quyet dinh, KHONG DO DAC. Quet cay
#     vat lieu de biet co kinh/khoi (`comp.needed`), dung render thu roi nhin.
#     Va DUNG THEM NUT: gia tri phai nam trong duong tu dong.
#
#   CHAT LUONG CAO NHAT — khong danh doi hinh anh lay toc do. Cai gi LAM DOI
#     anh (bot bounces, Fast GI, ha clamp) thi khong duoc tu bat cho khach.
#
#   THOI GIAN PHAT SINH IT NHAT — chi dung nhanh nao scene that su dung.
#     Nguong chap nhan duoc: cham hon 2-3 giay thi van OK (do 1920x1080 tren
#     RTX 3090: 1,85s -> 2,65s).
#
# VA: CYCLES CHON SAO THI TOOL CHAY VAY. Khong dat lai thiet bi tinh toan cua
# nguoi dung — xem `settings.compositor_device_for`.
# ===========================================================================
#
# LUAT KY THUAT
#   1. KHONG CO HANG SO GU. Moi nguong deu la nut cua nguoi dung. Bo so
#      mac dinh chi la diem xuat phat cua phep do, khong phai ket luan.
#   2. DO XONG PHAI TRA LAI NGUYEN TRANG. Phep do khong duoc de lai dau vet
#      trong file cua khach. Xem `settings.Snapshot`.
#   3. CHU TREN GIAO DIEN LA TIENG ANH.
#
# ADDON NAY MIEN PHI, CHIA SE RONG RAI (Ducphan chot 06/08/2026).
# TUYET DOI KHONG gan `dp_license`: khong co ma kich hoat nao duoc cap cho no,
# nen mot cua khoa o day se chan vinh vien chinh nguoi duoc tang.
#
# CAP NHAT 07/08/2026 — Ducphan chot dua no LEN DP_Hub nhu do tang. Cau tren
# ("KHONG dang ky vao projects.json, KHONG day len kho") DA HET HIEU LUC. Nay
# no CO trong so dang ky voi khoa `"free": true`, va khoa do doi ca ba viec:
# dong goi khong cam khoa · gia phai bang 0 · goi cai len kho CONG KHAI chu
# khong vao kho zip rieng tu sau cua kiem ma.
#
# VAN LA NGOAI LE, chi la mot ngoai le CO TEN: `rollout.py --audit` doc file
# nay bang `ast` va bao do neu no goi toi cua khoa, con `run_accept.py` do
# rang KHONG co ma nao ma addon van chay. Xem `note_tang` trong projects.json.
# ===========================================================================

import bpy
from bpy.app.handlers import persistent

from . import (bench, comp, luong_chinh, metrics, ops, props, settings,
               tang_kinh, ui)


class DPOPT_Preferences(bpy.types.AddonPreferences):
    bl_idname = __name__

    def draw(self, context):
        col = self.layout.column()
        col.label(text="DP-OptimizeRender measures on the open scene.",
                  icon='INFO')
        col.label(text="No preset numbers are applied without a measurement.")


CLASSES = (DPOPT_Preferences,) + props.CLASSES + ops.CLASSES + ui.CLASSES


SO_NHIP_CHUAN_BI = 25     # 25 nhip x 0,2 s = 5 giay thu lai
_NHIP_CON = [0]


def _prepare(_dummy=None):
    """Dung san danh sach truc cho MOI scene. Tra ve True neu da lam xong.

    Phai lam o day chu khong lam trong `draw`: Blender cam ghi vao du lieu
    Scene trong luc ve giao dien, va neu ghi thi bang chi hien ra cai khung
    rong. Chay luc bat addon va moi lan mo file .blend.

    LUC BLENDER DANG KHOI DONG THI `bpy.data` CHUA MO. No la mot doi tuong
    `_RestrictData` khong co `.scenes`, va cham vao la:

        '_RestrictData' object has no attribute 'scenes'

    Chay tay giua phien thi khong sao, nhung addon duoc bat san trong
    Preferences se chay `register()` NGAY LUC KHOI DONG — va chet o day.
    Gap luc do thi tra ve False va lui lai: handler `load_post` va bo dem gio
    `_nhip_chuan_bi` se lam not khi du lieu da mo.
    """
    try:
        scenes = list(bpy.data.scenes)
    except AttributeError:
        return False

    settings.refresh_devices()
    for scene in scenes:
        try:
            st = props.ensure_axes(scene)
            # Lan do truoc bi cat ngang (tat Blender giua chung) se de lai co
            # `running` bat — bang se ket o chu "Working..." mai mai.
            st.running = False
            st.progress = ""
        except Exception as e:                             # noqa: BLE001
            # ⛔ DUNG NUOT. `ensure_axes` la CHO DUY NHAT dung danh sach truc
            # (`draw` bi cam goi no). Hong ma im lang thi bang "What To
            # Measure" hien ra RONG, hoac co `running` ket True va bang treo
            # o "Working…" — ma khong mot dong log nao de lan ra.
            print("[DP-OptimizeRender] cannot prepare scene '%s' (%s)"
                  % (getattr(scene, "name", "?"), e))
    # Viec theo Scene cua DP VFB (tra lai cai dat bi muon do dang, ap lai o
    # tick) nam o DAY chu khong o `tang_kinh.dang_ky`: ham nay la cho duy
    # nhat biet chac `bpy.data` da mo, va da co san duong lui + bo dem gio.
    try:
        tang_kinh.chuan_bi_canh(scenes)
    except Exception as e:                                 # noqa: BLE001
        print("[DP-OptimizeRender] cannot prepare the DP VFB state (%s)" % e)
    return True


def _nhip_chuan_bi():
    """Bo dem gio: thu lai `_prepare` cho den khi `bpy.data` mo xong.

    ⛔ TRA VE None LA BO DEM GIO TU GO. Ban truoc dat thang `_prepare` lam
    bo dem gio, ma `_prepare` tra None ca khi du lieu CHUA mo — nen no chi
    thu DUNG MOT NHIP roi thoi, trai han voi cau "se lam not" viet o tren.
    Chua lo ra vi `load_post` ganh giup: mo mot file .blend la `_prepare`
    chay lai. Nhung ai bat Blender len roi lam viec ngay tren file khoi dong
    (khong mo file .blend nao) thi khong co lan nao ganh. Nen o day phai thu
    LAI, va phai co tran de khong quay mai neu that su hong.
    """
    if _prepare():
        return None
    _NHIP_CON[0] -= 1
    if _NHIP_CON[0] <= 0:
        print("[DP-OptimizeRender] Blender data is still not open after "
              "%.0f s — giving up on the deferred setup"
              % (SO_NHIP_CHUAN_BI * 0.2))
        return None
    return 0.2


@persistent
def _on_load(_dummy):
    # Mo file khac thi nhung cau da noi cho file TRUOC khong con dung nua.
    try:
        comp.quen_canh_bao()
    except Exception:                                      # noqa: BLE001
        pass
    # Cay Split dung tu truoc ban sua kinh (19/09/2026) nam san trong file:
    # dung lai ngay luc mo, khong thi ban sua khong bao gio toi file cu.
    try:
        comp.nang_cap_cay_cu()
    except Exception:                                      # noqa: BLE001
        pass
    # `_prepare` lam ca viec theo Scene cua DP VFB: tra lai cai dat bi muon
    # do dang, va ap lai tac dung cua o tick (`update=` cua property KHONG
    # chay lai khi mo file).
    _prepare()
    # Mo file khac thi anh va kho EXR cua file truoc khong con nghia gi —
    # bo di ngay, dung de vai GB nam lai trong thu muc tam.
    try:
        tang_kinh.don_tam()
    except Exception:                                      # noqa: BLE001
        pass


@persistent
def _khung_moi(scene=None, _dummy=None):
    tang_kinh.khung_moi(scene)


@persistent
def _truoc_render(scene=None, _dummy=None):
    # Dat lai bo dem khung NGAY TREN LUONG RENDER: chi gan mot so nguyen.
    tang_kinh.bat_dau(scene)
    # Luong render -> nho luong chinh lam va cho (xem `luong_chinh.py`).
    luong_chinh.chay(_lam_truoc_render, scene)


def _lam_truoc_render(scene=None):
    """Truoc khi bat dau render: noi ra neu lan nay sap cho lau vi compositor
    phai chay tren bo xu ly. KHONG SUA GI trong file — xem `comp.canh_bao_cham`.

    `render_init` no MOT lan cho ca cong viec render (khac `render_pre`, no
    moi khung hinh) — doan phim 250 khung thi thao lap 250 lan la vo ich va
    la them 250 co hoi de hong.
    """
    scene = scene or bpy.context.scene
    # DP VFB: hen mo cua so + hien anh dang render (o luong chinh).
    try:
        tang_kinh.hen_mo_vfb()
    except Exception:                                      # noqa: BLE001
        pass
    # 1) Dua compositor ve thiet bi cua MAY DANG RENDER (khong doi chat luong).
    # 2) In mot dong chan doan — cau tra loi phai TU DEN voi nguoi doi, chu
    #    khong bat ho chay mot lenh tren mot may ho khong ngoi canh.
    # 3) Keu len neu lan nay se phai cho lau, kem cach chua.
    for ham in (comp.theo_may_dang_chay, comp.dong_chan_doan,
                comp.canh_bao_cham):
        try:
            ham(scene)
        except Exception:                                  # noqa: BLE001
            pass


# TU NHA RAM SAU RENDER DA CHUYEN SANG DP_RAMchill (Ducphan 18/09/2026:
# *"go khoi dp-optimize di vi cai nay o ram chill hop hon"*). Chi MOT addon
# lam viec nay de khong xung dot khi cai chung. Ban cu cua module con trong
# backup/dp_optimize_20260918_2034.zip.
#
# ⛔ TEN CHOT DA DOI `_sau_render` -> `_tra_thiet_bi_sau_render`: DP_RAMchill
# nhan ra ban DP_Optimize CU (con tu nha RAM) bang dung ten `dp_optimize.
# _sau_render` va NHUONG. Giu ten cu thi RAMchill nhuong mai, khong ai nha RAM.
@persistent
def _tra_thiet_bi_sau_render(_scene=None, _dummy=None):
    luong_chinh.chay(_lam_sau_render)


def _lam_sau_render():
    """Render xong thi tra thiet bi compositor ve nhu cu.

    PHAI LA `@persistent`: chot khong persistent bi go sach moi lan mo file
    khac, va luc do addon im lang khong lam gi nua ma khong ai biet.

    `render_complete` / `render_cancel` no MOT lan cho ca cong viec render
    (khac `render_post`, no moi khung hinh). Render mot doan phim 250 khung
    ma don 250 lan la lam cham chinh cong viec do.

    KHONG DUOC NEM LOI RA NGOAI. Day la viec don dep chay sau lung mot lan
    render da xong — no khong co quyen lam hong lan render ay.
    """
    # Tra lai la viec bat buoc phai xong (file cua khach khong duoc mang dau
    # vet cua may nay).
    try:
        comp.tra_lai_thiet_bi(bpy.context.scene)
    except Exception as e:                                 # noqa: BLE001
        # ⛔ DUNG NUOT: chu thich ngay tren noi day la viec BAT BUOC phai
        # xong. Hong ma im lang thi thiet bi compositor cua khach o lai dung
        # cai addon dat vao, va khong ai biet tu dau ra.
        print("[DP-OptimizeRender] cannot put the compositor device back "
              "(%s)" % e)
    # DP VFB: F12 xong thi CHI HEN mot bo dem gio — khong bao gio goi mot lan
    # render moi tu trong chot render.
    try:
        tang_kinh.hen(bpy.context.scene)
    except Exception:                                      # noqa: BLE001
        pass


@persistent
def _truoc_khi_thoat(*_a):
    """Blender sap thoat: don file nang cua phien nay va tra file khoa.

    ⛔ DAY LA DUONG CHINH DE DON RAC, dung go no di. Tu 20/09/2026 file nang
    (EXR ca khung hinh, 108 MB mot cai o anh 4K) khong con nam trong thu muc
    tam cua Blender — cho ma chinh Blender don khi thoat — ma nam trong thu
    muc cache cua nguoi dung, la cho KHONG AI DON HO. `exit_pre` chay ca khi
    thoat binh thuong lan khi bam nut dong cua so, nen don o day la sach gan
    het truong hop. Bi tat ngang (sap may, kill) thi con `tang_kinh.
    don_rac_cu()` luc bat addon cua phien sau lo — no chi don phan cua nhung
    so hieu tien trinh DA CHET.

    KHONG DUOC NEM LOI RA NGOAI: day la viec don dep luc dong cua.
    """
    # ⛔ `tra_lai_cua_so_render` PHAI CO O DAY. DP VFB dat
    # `preferences.view.render_display_type = 'NONE'`, ma do la
    # PREFERENCES chu khong phai file. Blender bat san "Auto-Save
    # Preferences", nen thoat ma khong tra lai la 'NONE' duoc GHI VAO
    # `userpref.blend`: phien sau bam F12 khong thay gi ca, ke ca khi da go
    # addon. Tra lai o day thi khong sao — phien sau bat addon len,
    # `chuan_bi_canh` tu dat lai 'NONE' neu tick con bat.
    for ham in (tang_kinh.tra_lai_cua_so_render,
                tang_kinh.don_tam, tang_kinh._dong_khoa):
        try:
            ham()
        except Exception:                                  # noqa: BLE001
            pass


@persistent
def _truoc_khi_luu(*_a):
    """Anh xem cua DP VFB khong duoc vao file khach (xem `tang_kinh`)."""
    try:
        tang_kinh.go_anh_truoc_khi_luu()
    except Exception as e:                                 # noqa: BLE001
        print("[DP-OptimizeRender] save: cannot keep the DP VFB images out "
              "(%s)" % e)


@persistent
def _sau_khi_luu(*_a):
    try:
        tang_kinh.dung_lai_sau_khi_luu()
    except Exception as e:                                 # noqa: BLE001
        print("[DP-OptimizeRender] save: cannot put the DP VFB image back "
              "(%s)" % e)


@persistent
def _vua_render_xong(scene=None, _dummy=None):
    """Chi `render_complete` (khong phai huy): cat anh vua render cho DP VFB
    NGAY, truoc khi batch cua DP Cam kip bam camera ke."""
    luong_chinh.chay(_lam_vua_render_xong, scene)


def _lam_vua_render_xong(scene=None):
    try:
        tang_kinh.bat_anh_vua_render(scene or bpy.context.scene)
    except Exception as e:                                 # noqa: BLE001
        print("[DP-OptimizeRender] VFB: cannot keep this render (%s)" % e)


_CHOT = (
    ("render_complete", _vua_render_xong),
    ("save_pre", _truoc_khi_luu),
    ("save_post", _sau_khi_luu),
    ("render_init", _truoc_render),
    ("render_post", _khung_moi),
    ("render_complete", _tra_thiet_bi_sau_render),
    ("render_cancel", _tra_thiet_bi_sau_render),
    ("exit_pre", _truoc_khi_thoat),
)


def _register_class(cls):
    """Dang ky mot lop, don sach ban cu neu no con ket lai.

    Tat roi bat lai addon thi Blender NAP LAI module: moi lop tro thanh mot
    doi tuong Python MOI, trong khi lop cu van con dang ky duoi cung mot ten.
    Luc do `register_class` bao:

        already registered as a subclass 'DPOPT_Axis'

    va addon chet ngay tu buoc bat. Chuyen nay xay ra vi vong go dang ky
    truoc day nuot loi bang `except: pass` — no giau su co thay vi bao, roi
    lan bat sau moi vo ra. Nen o day phai chu dong don truoc khi dang ky.
    """
    old = getattr(bpy.types, cls.__name__, None)
    if old is not None and old is not cls:
        try:
            bpy.utils.unregister_class(old)
        except Exception:
            pass
    bpy.utils.register_class(cls)


def register():
    for cls in CLASSES:
        _register_class(cls)
    props.register()
    luong_chinh.dang_ky()
    tang_kinh.dang_ky()
    if _on_load not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_on_load)
    for ten, ham in _CHOT:
        ds = getattr(bpy.app.handlers, ten, None)
        if ds is not None and ham not in ds:
            ds.append(ham)

    # Thu ngay; neu dang khoi dong thi `_prepare` tu lui lai va bo dem gio
    # duoi day thu LAI cho den khi Blender mo xong du lieu.
    if not _prepare():
        _NHIP_CON[0] = SO_NHIP_CHUAN_BI
        try:
            if not bpy.app.timers.is_registered(_nhip_chuan_bi):
                bpy.app.timers.register(_nhip_chuan_bi, first_interval=0.2)
        except Exception:
            pass


def unregister():
    if _on_load in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_on_load)
    for ten, ham in _CHOT:
        ds = getattr(bpy.app.handlers, ten, None)
        if ds is not None and ham in ds:
            ds.remove(ham)
    tang_kinh.go_hen()
    tang_kinh.go()
    luong_chinh.go()
    try:
        if bpy.app.timers.is_registered(_nhip_chuan_bi):
            bpy.app.timers.unregister(_nhip_chuan_bi)
    except Exception:
        pass
    props.unregister()

    # Go nguoc thu tu: lop chua PointerProperty/CollectionProperty phai di
    # truoc lop ma no tro toi, neu khong Blender tu choi go.
    failed = []
    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except Exception as exc:                       # noqa: BLE001
            failed.append("%s: %s" % (cls.__name__, exc))
    if failed:
        # KHONG im lang. Go khong sach ma khong ai biet thi lan bat sau se
        # bao "already registered" va nguoi dung khong hieu tu dau ra.
        print("[DP-OptimizeRender] go dang ky khong sach: %s" % "; ".join(failed))


if __name__ == "__main__":
    register()
