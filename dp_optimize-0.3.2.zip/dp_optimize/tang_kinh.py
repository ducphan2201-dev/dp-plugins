# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
"""BOM THEM MAU CHI CHO VUNG NHIN QUA KINH — "Glass Boost", CHAY TU DONG.

VI SAO CO. Anh nhin QUA KINH la cho path tracing kho nhat: do 20/09/2026 tren
`mrnam khachbep.blend` (Ducphan), cung mot mang van go sau canh tu kinh, so ban
64 mau voi ban 2048 mau cua chinh no (he so trung khop chi tiet tan so cao):

    co kinh   0,348          an tam kinh di   0,968

Tu duoc chieu sang XUYEN QUA kinh (thay kinh dac vao thi trong tu toi con
0,0013 do sang), nen duong sang do vua hiem vua nhieu. O 64 mau ca anh sang
lan lop mau dan duong deu KHONG mang van (0,055 va 0,171) — khong bo khu nhieu
nao lay lai duoc cai khong co trong du lieu. Chi con duong THEM MAU.

Cycles khong cho dat so mau rieng cho tung vung (bo tu 3.0), nen lam HAI LUOT:
luot 1 la chinh lan render cua khach; luot 2 chi render may hinh chu nhat bao
quanh kinh voi nhieu mau hon, roi dan vao, lam mem mep.

GIA VA LOI — do tren file that, ca khung 2625x3500, `giong van` = do trung khop
voi anh chuan 2048 mau da khu nhieu:

    cach                        giay      van go   cai binh   ca o tu
    64 mau (nhu cu)             74,3       0,347     0,590     0,866
    GLASS BOOST 256 mau        107,6       0,633     0,720     0,909   +45 %
    128 mau ca khung           132,2       0,524     0,678     0,887   +78 %
    256 mau ca khung          ~162         0,594     0,723     0,907  +118 %

Boost BANG HOAC HON ban 256 mau ca khung ma chi ton mot phan ba so tien do,
vi kinh chi chiem 3,6 % diem anh (hinh bao 6,5 % khung).

VET DAN KHONG LO. Do doc ngang bon bien dan: khac biet giua ban boost va ban
thuong tang dan deu tu 0,0010 ngoai bien len 0,005-0,012 trong long vung,
KHONG co buoc nhay. Nhin anh phong 3 lan o bien cung khong thay vet.

TIM VUNG KINH bang mot luot render RAT NHO (1 mau, 1/8 do phan giai, chi lay
pass Transmission Color) — pass do khac 0 dung o diem tia camera cham
kinh/nuoc. Khong doan theo ten vat lieu: file nhap tu Max thi vat lieu nao
cung la nhom Max_Material. Luot nho ton ~5,5 s (gan het la nap canh).

DAN KHONG LECH MOT DIEM ANH. Blender doi vien (border) ra diem anh bang phep
lam tron; dat vien o (x + 0,25) / W thi lam tron xuong hay lam tron gan deu ra
x. Anh luot 2 tra ve phai dung kich thuoc da tinh, sai la bao loi — dan lech
mot diem anh la canh vat bi nhoe doi.

KHONG DUNG VAO FILE CUA KHACH: moi thiet lap doi tam thoi (vien, so mau, duong
dan, dinh dang anh, cay compositor cua luot nho) deu tra lai trong `finally`.

⛔ KHONG chay boost tu trong chot render. Chot render chay tren LUONG RENDER
(xem `luong_chinh.py`); goi mot lan render nua tu do la treo may. Chot chi HEN
mot bo dem gio, bo dem cho `bpy.app.is_job_running('RENDER')` tat han roi moi
lam.
"""
import hashlib
import io
import json
import os
import sys
import tempfile
import time

import bpy
import numpy as np
from bpy.app.handlers import persistent

from . import bang_mau, gpu_vfb, hieu_ung_cpu, settings

TEN_ANH = "DP Glass Boost"
# Cum kinh nho hon ti le nay cua khung thi bo: mot luot render them ton
# ~6 s nap canh, khong dang cho vai diem anh. 0,1 % -> 0,3 % (Ducphan chon
# 21/09/2026: *"nhung dien tich kinh qua nho cung co the bo"* — tren file bep
# bo ly ban an, coc tren ke, 2 o cua tu nho).
NGUONG_CUM = 0.003
DAC_TOI_THIEU = 0.6  # kinh phai lap tu muc nay hinh bao cua cum (xem `_doc_mask`)
LE = 32          # diem anh noi rong quanh vung kinh: >= MEM (24, dai hoa mep nam NGOAI kinh) + 8 (sai so mat na 1/8)
MEM = 24         # diem anh lam mem mep khi dan
TOI_DA_VUNG = 8  # tran; duoi tran `_gop` tu lua theo gia (`_nguong_gop`) — Ducphan: "nhieu nhat 8 khoang, tu lua"
# ⛔ DA THU VA BO (21/09/2026, Ducphan: *"can toi uu glassboost chi render khu
# vuc co kinh"* ... *"thu xem, ko dc thi bo"*). Do THAT file bep co goc
# 2625x3500, 3 camera, RTX 3060 (moi luot nap canh ~2,9 s, 1 % khung o 256 mau
# ~3,1 s — mo hinh nay khop 6 luot do, lech 1-5 s):
#   - hinh bao tung cum, ep <= 3 (CACH NAY)          : 391,9 s
#   - luoi o 128 px + gop theo gia                     : 439,4 s (+12 %)
#   - hinh bao tung cum + gop THEO GIA (bo tran 3)     : 394,3 s (ngang)
#   - luoi + thu sat ve mat na (uoc tren mat na that)  : ~ngang
# Kinh chi chiem 2-8 % khung; phan thua la le LE, khong phai hinh bao qua
# rong — khong con gi de vat tren file nay.
#   - GHEP THEO MAT NA (thay vi ca hinh chu nhat): khong nhanh hon giay nao,
#     ma vat XUYEN SANG MOT PHAN (binh thuy tinh toi mau) bi mat na bat cho co
#     cho khong -> TRON 256 va 64 mau TRONG CUNG MOT VAT. Bo.
#   - LE 48 -> 24 px: 387,4 s so 391,9 s (-1 %, trong nhieu do) — bo.
#   - NHO MAT NA THEO CAMERA (bo luot do kinh khi render lai cung camera):
#     lan 2 VAN do lai — DP_RAMchill tra map sau moi render lam vat lieu "doi",
#     khong phan biet duoc voi khach sua vat lieu kinh (doan sai = render THIEU
#     kinh). Loi toi da 5 s/camera — bo.
#   - "Kenh kinh" tu luot render day du: nut Viewer KHONG cap nhat trong luot
#     render cuoi (Blender 5.2); nut File Output ghi duoc (phai tao muc truoc,
#     roi `format.media_type = 'IMAGE'` moi chon duoc PNG). Nhung Glass Boost
#     chay kinh TRUOC anh day du nen lan dau van phai do — chi loi khi camera
#     da render bang F12 thuong truoc do. Khong lam.
# Con so "54 % khung" cua phien 18:40 KHONG lap lai voi ma hien tai (do lai
# Camera 13 %).


# CHI CUU VAT TRONG SUOT THAT (Ducphan 21/09/2026: *"nhung vat the xuyen sang
# nhoe thi can gi phai cuu chi tiet, chi vat the trong suot nhin thay ben trong
# tren 90% moi can cuu"*). Luot do kinh bat moi thu co Transmission Color, ke ca
# rem voan (tulle: Refract 0,4, Glossiness 0,5) — tren file bep Camera.001 rem
# chiem 5,2 trong 8,4 % "kinh", va vung chua rem an 45 s trong 70 s cua cac
# luot vung. Vat lieu nhu vay danh dau tam `pass_index` trong luot do kinh roi
# loai khoi mat na. Doc khong ra so (map, node la) thi GIU — cuu thua con hon.
TRONG_TOI_THIEU = 0.9    # Transmission >= muc nay moi goi la trong suot
NHAM_TOI_DA = 0.2        # Roughness tu muc nay tro len la nhin xuyen bi nhoe
_PHEP = {'ADD': lambda a, b: a + b, 'SUBTRACT': lambda a, b: a - b,
         'MULTIPLY': lambda a, b: a * b,
         'DIVIDE': lambda a, b: a / b if b else 0.0,
         'POWER': lambda a, b: a ** b if a >= 0 else 0.0,
         'MINIMUM': min, 'MAXIMUM': max,
         'SQRT': lambda a, b: max(a, 0.0) ** 0.5,
         'ABSOLUTE': lambda a, b: abs(a)}


def _so_cua(sock, ngoai):
    """Gia tri HANG SO cua mot o node, hoac None neu khong doc duoc."""
    if not sock.is_linked:
        v = getattr(sock, 'default_value', None)
        try:
            return float(v)
        except TypeError:
            try:
                return float(sum(v[:3]) / 3.0)
            except Exception:                                # noqa: BLE001
                return None
    lk = sock.links[0]
    n = lk.from_node
    if n.bl_idname == 'NodeReroute':
        return _so_cua(n.inputs[0], ngoai)
    if n.bl_idname == 'NodeGroupInput':
        if not ngoai:
            return None
        s = ngoai[-1].inputs.get(lk.from_socket.name)
        return _so_cua(s, ngoai[:-1]) if s is not None else None
    if n.bl_idname == 'ShaderNodeValue':
        return float(n.outputs[0].default_value)
    if n.bl_idname == 'ShaderNodeMath':
        f = _PHEP.get(n.operation)
        if f is None:
            return None
        a, b = _so_cua(n.inputs[0], ngoai), _so_cua(n.inputs[1], ngoai)
        if a is None or b is None:
            return None
        v = f(a, b)
        return min(max(v, 0.0), 1.0) if n.use_clamp else v
    return None


def _xuyen_mo(cay, ngoai=(), sau=0):
    """(co BSDF xuyen sang, MOI BSDF xuyen sang deu mo/nhoe chac chan)."""
    co, mo = False, True
    if sau > 8:
        return True, False
    for n in cay.nodes:
        if n.mute:
            continue
        if n.bl_idname == 'ShaderNodeGroup' and n.node_tree is not None:
            c, m = _xuyen_mo(n.node_tree, ngoai + (n,), sau + 1)
            co, mo = co or c, mo and (m or not c)
            continue
        if n.bl_idname == 'ShaderNodeBsdfPrincipled':
            t = _so_cua(n.inputs['Transmission Weight'], ngoai)
            if t is not None and t <= 0.0:
                continue
            r = _so_cua(n.inputs['Roughness'], ngoai)
        elif n.bl_idname in ('ShaderNodeBsdfGlass', 'ShaderNodeBsdfRefraction'):
            t, r = 1.0, _so_cua(n.inputs['Roughness'], ngoai)
        elif n.bl_idname == 'ShaderNodeBsdfTranslucent':
            t, r = 1.0, 1.0
        else:
            continue
        co = True
        ro = ((t is not None and t < TRONG_TOI_THIEU)
              or (r is not None and r >= NHAM_TOI_DA))
        mo = mo and ro
    return co, mo


def vat_lieu_mo(mat):
    """Vat lieu cho sang xuyen qua nhung KHONG nhin ro vao trong duoc."""
    cay = getattr(mat, 'node_tree', None)
    if cay is None:
        return False
    try:
        co, mo = _xuyen_mo(cay)
    except Exception:                                        # noqa: BLE001
        return False
    return co and mo


def _doc_exr(path):
    img = bpy.data.images.load(path, check_existing=False)
    try:
        w, h = img.size
        a = np.empty(w * h * 4, np.float32)
        img.pixels.foreach_get(a)
    finally:
        bpy.data.images.remove(img)
    return a.reshape(h, w, 4)            # hang 0 = DUOI cung (kieu Blender)


# ⛔ DA BO `_render()`. No dat `scene.render.filepath` roi KHONG TRA LAI, va
# goi `bpy.ops.render.render()` DONG BO — hai thu deu bi cam o day: lenh bu
# kinh chay bang modal nen render dong bo la treo giao dien, con ghi de duong
# xuat file cua khach la mat cho luu cua ca mot loat batch. Anh render duoc
# lay qua `_luu_render_result`.


def _cum(mask):
    """Cac cum True lien nhau (4 huong) -> list (so diem, y0, y1, x0, x1)."""
    h, w = mask.shape
    nhan = np.zeros(mask.shape, np.int32)
    ra = []
    for y0 in range(h):
        hang = np.nonzero(mask[y0] & (nhan[y0] == 0))[0]
        for x0 in hang:
            if nhan[y0, x0]:
                continue
            k = len(ra) + 1
            ngan = [(y0, x0)]
            nhan[y0, x0] = k
            n, ya, yb, xa, xb = 0, y0, y0, x0, x0
            while ngan:
                y, x = ngan.pop()
                n += 1
                ya, yb, xa, xb = min(ya, y), max(yb, y), min(xa, x), max(xb, x)
                for yy, xx in ((y - 1, x), (y + 1, x), (y, x - 1), (y, x + 1)):
                    if 0 <= yy < h and 0 <= xx < w and mask[yy, xx] \
                            and not nhan[yy, xx]:
                        nhan[yy, xx] = k
                        ngan.append((yy, xx))
            ra.append((n, ya, yb + 1, xa, xb + 1))
    return ra


def _gop(vung, W, H, nguong=0.01):
    """Gop cac hinh chu nhat cho con toi da TOI_DA_VUNG, uu tien gop cap ton
    them it dien tich nhat. Duoi tran thi CHI gop khi phan dien tich them vao
    re hon mot lan nap canh (`nguong` = ti le khung, xem `_nguong_gop`)."""
    vung = [list(v) for v in vung]

    def them(a, b):
        u = (min(a[0], b[0]), max(a[1], b[1]), min(a[2], b[2]), max(a[3], b[3]))
        dt = lambda r: (r[1] - r[0]) * (r[3] - r[2])
        return u, dt(u) - dt(a) - dt(b)

    while True:
        tot = None
        for i in range(len(vung)):
            for j in range(i + 1, len(vung)):
                u, d = them(vung[i], vung[j])
                if tot is None or d < tot[0]:
                    tot = (d, i, j, u)
        if tot is None:
            break
        # gop khi con qua nhieu vung, hoac khi gop re hon mot lan nap canh
        if len(vung) <= TOI_DA_VUNG and tot[0] > nguong * W * H:
            break
        d, i, j, u = tot
        vung = [v for k, v in enumerate(vung) if k not in (i, j)] + [list(u)]
    return [tuple(v) for v in vung]


def _nguong_gop(mau):
    """Dien tich (ti le khung) re bang MOT lan nap canh o `mau` mau.

    Do 21/09/2026 file bep 4000x3000, RTX 3060: nap canh ~3 s moi luot, 1 %
    khung o 256 mau ~3,8 s -> 0,8 % khung. It mau hon thi dien tich re hon,
    gop rong tay hon."""
    return 0.008 * 256.0 / max(16, int(mau))


# ⛔ DA BO `tim_vung_kinh()`: no goi `_render()` da bo o tren. Viec do vung
# kinh nay nam trong lenh bu kinh, o `_dat_mask` + `_luu_render_result`.
def _trong_so(hc, wc, y0, y1, x0, x1, H, W):
    """1 o giua, giam dan ve 0 trong MEM diem anh sat mep vung — tru mep trung
    mep khung (o do khong co gi de hoa vao)."""
    wy = np.ones(hc, np.float32)
    wx = np.ones(wc, np.float32)
    ram = (np.arange(MEM, dtype=np.float32) + 0.5) / MEM
    if y0 > 0:
        wy[:MEM] = np.minimum(wy[:MEM], ram)
    if y1 < H:
        wy[-MEM:] = np.minimum(wy[-MEM:], ram[::-1])
    if x0 > 0:
        wx[:MEM] = np.minimum(wx[:MEM], ram)
    if x1 < W:
        wx[-MEM:] = np.minimum(wx[-MEM:], ram[::-1])
    return (wy[:, None] * wx[None, :])[:, :, None]


# ======================================================== LENH RENDER RIENG
#
# ⛔ THU TU LA TAT CA. Blender chi co MOT `Render Result` va no thuoc ve LUOT
# RENDER CUOI CUNG. Ban truoc (20/09 ~20:30) render vung kinh SAU anh chinh:
# nguoi dung bam F12 xong thi cua so Render hien MAU KINH, khong phai anh cua
# ho (Ducphan: *"render result thi ra dung cai doan kinh"*). Python KHONG ghi
# nguoc vao `Render Result` duoc — da thu hai cach, hong ca hai.
#
# Nen day dao thu tu: do vung kinh -> render TUNG VUNG truoc -> ANH DAY DU
# render SAU CUNG, va cho compositor tron may vung do vao ngay trong luot cuoi.
# Luot cuoi chinh la anh hoan chinh, nen `Render Result` tu no dung.
#
# ⛔ VA PHAI LA MODAL. Goi `bpy.ops.render.render()` thang trong mot lenh hay
# mot bo dem gio thi giao dien Blender DUNG HINH suot ca luot (Ducphan:
# *"chay glassboost no treo me luon blender"*). Modal thi moi luot render la
# mot cong viec binh thuong cua Blender: co thanh tien trinh, bam ESC duoc.

TEN = "DP-OptimizeRender"
_XONG = False
_HUY = False         # luot vua roi bi HUY (Esc trong cua so render...)
_TU_BATCH = [False]  # True CHI trong `bat_dau_render_batch` (batch DP Cam goi)


class _KhongKhoiDong(RuntimeError):
    """`render.render` tra CANCELLED — Blender khong khoi dong luot nay."""


def _trang_thai_batch_dp_cam():
    """Dict `batch_render_state` cua DP Cam, hoac None neu khong co.

    ⛔ BAN BAN GIAU BIEN NAY TRONG `dp_camera.core`. Dong goi (liclib) cat
    `__init__.py` cua DP Cam con dung mot dong `from .core import register,
    ...`, nen `sys.modules["dp_camera"].batch_render_state` KHONG ton tai o
    may khach — doc sai cho la im lang tra False, DP VFB mu truoc batch.
    Bat duoc 24/09/2026 bang goi dung kieu ban ban (moi bai test deu nap DP
    Cam tu nguon nen khong thay). Tim `.core` truoc, roi toi goc (ban dev).
    Doc qua `sys.modules` — DP-Optimize KHONG phu thuoc DP Cam."""
    for ten in ("dp_camera.core", "dp_camera"):
        m = sys.modules.get(ten)
        st = getattr(m, "batch_render_state", None) if m is not None else None
        if isinstance(st, dict):
            return st
    return None


def _batch_dp_cam_dang_chay():
    """Batch cua DP Cam (du an Blender-Camerasetting) co dang chay khong."""
    try:
        st = _trang_thai_batch_dp_cam()
        return bool(st and st.get('is_rendering'))
    except Exception:                                        # noqa: BLE001
        return False


def vi_sao_ban():
    """Ly do KHONG duoc bat dau Glass Boost / F12 cua DP VFB luc nay vi dang
    co viec render khac. Chuoi rong = duoc.

    ⛔ CHAN KHI CO JOB RENDER HAY BATCH DP CAM DANG CHAY. Ban cu chi chan
    `dang_chay` cua chinh no: bam Glass Boost giua batch (giua hai camera
    `is_job_running` tat 0,1 s) thi no cat cai dat cua camera batch lam
    "goc", va batch doc `Render Result` / resolution cua no (ra soat
    21/09/2026). Ngoai le DUY NHAT: batch goi qua `bat_dau_render_batch`
    (co `_TU_BATCH`).
    """
    try:
        if bpy.app.is_job_running('RENDER'):
            return "a render is already running"
    except Exception:                                        # noqa: BLE001
        pass
    if not _TU_BATCH[0] and _batch_dp_cam_dang_chay():
        return "the DP Camera batch render is running"
    return ""


@persistent
def _chot_render_xong(*_a):
    global _XONG
    _XONG = True


@persistent
def _chot_render_huy(*_a):
    """⛔ HUY PHAI KHAC XONG. Ban cu gan cung mot ham cho ca `render_cancel`:
    Esc giua luot MASK/VUNG thi Glass Boost tuong luot do xong, doc `Render
    Result` do dang ra ghep vao anh roi chay tiep (ra soat 21/09/2026)."""
    global _XONG, _HUY
    _XONG = True
    _HUY = True


def _gan_chot():
    for ds, fn in ((bpy.app.handlers.render_complete, _chot_render_xong),
                   (bpy.app.handlers.render_cancel, _chot_render_huy)):
        if fn not in ds:
            ds.append(fn)


def _go_chot():
    for ds in (bpy.app.handlers.render_complete, bpy.app.handlers.render_cancel):
        for fn in (_chot_render_xong, _chot_render_huy):
            while fn in ds:
                ds.remove(fn)


_SO_KHUNG = 0        # so khung hinh cua lan render vua roi (1 = anh tinh)
_DA_HEN = False


def hien_anh_dang_render():
    """Cho cua so VFB tro vao `Render Result` de nguoi dung NHIN THAY anh
    hien dan ra trong luc render. Tra ve True neu da tro duoc.

    ⛔ DAY LA CAI MA CUA SO RENDER CUA BLENDER LAM MA VFB TUNG KHONG LAM.
    Truoc 21/09/2026, VFB chi duoc do anh vao SAU KHI render xong, nen suot
    lan render no la mot o ca-ro trong tron — Ducphan hoi dung cau do:
    *"sao trong luc render cua so khong hien gi nhu cua so render mac dinh
    cua blender"*. Mot Image Editor dang tro vao `Render Result` thi chinh
    Blender ve lai tung o khi render xong tung o, khong ton them gi.

    Xong render thi `_do_anh_vua_render` goi `doi_khung_render_result` de
    doi nguoc lai sang anh DA QUA BO MAU cua DP — duong doi nguoc do co san
    tu truoc, khong phai them.

    ⛔ CHI DOI CUA SO MANG DAU `DAU_VFB`. Cua so anh khac cua nguoi dung
    dang mo cai gi thi de nguyen cai do.
    """
    rr = bpy.data.images.get('Render Result')
    if rr is None:
        # Blender chua dung `Render Result` — bo dem gio se hoi lai.
        return False
    n = 0
    for w in getattr(bpy.context.window_manager, "windows", ()):
        try:
            if DAU_VFB not in w.screen.keys():
                continue
        except Exception:                                    # noqa: BLE001
            continue
        for area in getattr(w.screen, "areas", ()):
            if area.type != 'IMAGE_EDITOR':
                continue
            sp = area.spaces.active
            cu = getattr(sp, "image", None)
            # ⛔ KHONG DUNG `is` DE SO DU LIEU BLENDER — luon sai. Hoi kieu.
            if cu is None or cu.type != 'RENDER_RESULT':
                sp.image = rr
            n += 1
    return n > 0


_NHIP_MO = [0]       # so nhip `_nhip_mo_vfb` da thu (0 = chua chay lan nao)
SO_NHIP_CHO_ANH = 25  # tran: 25 x 0,2 s = 5 s cho `Render Result` hien ra


def _nhip_mo_vfb():
    """Mo cua so VFB tren LUONG CHINH (hen tu chot render), roi tro no vao
    anh dang render.

    ⛔ CHI GOI `mo_cua_so` O NHIP DAU. `mo_cua_so` keo theo `_mo_tab`, ma
    `_mo_tab` lai dang ky mot bo dem gio nua — goi moi nhip la de ra mot
    chuoi bo dem gio.
    """
    try:
        scene = bpy.context.scene
        st = getattr(scene, "dpopt", None)
        if st is None or not getattr(st, "vfb_bat", False):
            _NHIP_MO[0] = 0
            return None
        if _NHIP_MO[0] == 0:
            img = anh_ket_qua()
            if img is None:
                r = scene.render
                img = _anh_tu_mang(TEN_ANH_KQ,
                                   np.zeros((max(1, r.resolution_y // 8),
                                             max(1, r.resolution_x // 8), 4),
                                            np.float32))
            mo_cua_so(bpy.context, img)
        _NHIP_MO[0] += 1
        if hien_anh_dang_render():
            _NHIP_MO[0] = 0
            return None
        if _NHIP_MO[0] >= SO_NHIP_CHO_ANH:
            # Khong thay `Render Result` sau 5 s thi thoi — cua so van mo,
            # va anh cuoi van duoc do vao luc render xong. ⛔ PHAI CO TRAN:
            # mot bo dem gio quay mai la mot bo dem gio khong ai go.
            _NHIP_MO[0] = 0
            return None
        return 0.2
    except Exception as e:                                   # noqa: BLE001
        _NHIP_MO[0] = 0
        print("[%s] cannot open the DP window (%s)" % (TEN, e))
    return None


def bat_dau(_scene=None, _dummy=None):
    """`render_init` — CHAY TREN LUONG RENDER. Chi gan so nguyen va hen gio.

    ⛔ BAT F12 LA PHAI THAY CAI GI DO NGAY. Bat DP VFB thi cua so Render cua
    Blender bi tat (`render_display_type = 'NONE'`); neu cua so DP chi mo
    luc bu kinh XONG thi suot lan render nguoi dung nhin vao khoang khong, va
    canh khong co kinh thi khong bao gio thay gi ca (Ducphan 20/09/2026:
    *"luc tat het cua so render bam F12 thi deo co VFB nao hien ra ca"*).
    Nen: render vua bat dau la hen mo cua so ngay.
    """
    global _SO_KHUNG
    if not TRANG_THAI['dang_chay']:
        _SO_KHUNG = 0
        _NHIP_MO[0] = 0          # chi gan mot so nguyen: an toan o luong render


def hen_mo_vfb():
    """Hen mo cua so VFB. Goi tren LUONG CHINH (`__init__._lam_truoc_render`,
    qua `luong_chinh`).

    ⛔ KHONG DANG KY BO DEM GIO TU LUONG RENDER. Ban truoc goi ngay trong
    `bat_dau` (luong render) — dung loai thao tac `luong_chinh.py` sinh ra de
    ne (bai ra soat 21/09/2026). `bpy.app.timers` khong co khoa giua cac luong.
    """
    if TRANG_THAI['dang_chay']:
        return
    try:
        if not bpy.app.timers.is_registered(_nhip_mo_vfb):
            bpy.app.timers.register(_nhip_mo_vfb, first_interval=0.1)
    except Exception:                                        # noqa: BLE001
        pass


def khung_moi(_scene=None, _dummy=None):
    """`render_post` — LUONG RENDER. Chi cong mot so nguyen."""
    global _SO_KHUNG
    if not TRANG_THAI['dang_chay']:
        _SO_KHUNG += 1


def vi_sao_khong_tu_dong(scene):
    """Ly do F12 KHONG keo theo Glass Boost. Chuoi rong = co chay."""
    st = getattr(scene, "dpopt", None)
    if st is None or not getattr(st, "vfb_bat", False):
        return "DP VFB is off"
    if TRANG_THAI['dang_chay']:
        return "already running"
    if _SO_KHUNG > 1:
        return "still images only (%d frames)" % _SO_KHUNG
    if bpy.app.background:
        return "needs the interface (not -b)"
    return vi_sao_khong(scene)


_VUA = [None]        # (ten camera, mang anh) bat ngay luc render xong


def _render_thu_ngoai():
    """Lan render nay la render THU chan (dong bo) cua addon khac, khong phai
    anh cua khach.

    ⛔ BO QUA, DUNG CAT VAO KHO VFB. Bang bao cao Optimize Meshes cua
    DP_RAMchill (`so_sanh_luoi.render_thu`) render thu 50 %, 64 mau: ban cu cat
    anh do vao kho DP VFB DUOI TEN CAMERA THAT, de len anh that cua camera
    (ra soat 21/09/2026). Render chan chay tren luong chinh nen `render_complete`
    chay NGAY trong luc co con bat. Khong dua vao `is_job_running`: chay nen
    moi lan render deu dong bo, khong phan biet duoc.
    """
    m = sys.modules.get("dp_ramchill.so_sanh_luoi")
    try:
        return bool(m is not None and getattr(m, "DANG_RENDER_THU", False))
    except Exception:                                        # noqa: BLE001
        return False


def bat_anh_vua_render(scene):
    """`render_complete` (qua `luong_chinh`, LUONG CHINH): cat ngay anh vua
    render vao kho THEO CAMERA.

    ⛔ PHAI BAT NGAY TAI DAY, KHONG DOI BO DEM GIO. Do doc ma 21/09/2026:
    batch cua DP Cam bam camera ke chi 0,1 s sau `render_complete`, con
    `_nhip_hen` hen 0,3 s — toi luc do `Render Result` da la camera KE. Batch
    3 camera thi VFB chi con anh camera cuoi va danh sach camera trong. O day
    luot render van chua xong han (`is_job_running` con True) nen batch chua
    the bam camera ke, `Render Result` chac chan la cua camera nay.
    """
    st = getattr(scene, "dpopt", None)
    if st is None or not getattr(st, "vfb_bat", False):
        return False
    # Glass Boost tu lo anh cua no; doan phim thi khong cat tung khung.
    if TRANG_THAI['dang_chay'] or _SO_KHUNG > 1:
        return False
    if _render_thu_ngoai():
        return False
    if bpy.data.images.get('Render Result') is None:
        return False
    ten = scene.camera.name if scene.camera else ""
    tam = os.path.join(thu_muc_kho(), "dpopt_vfb_xem_%d.exr" % os.getpid())
    try:
        a = _luu_render_result(scene, tam)
    except Exception as e:                                   # noqa: BLE001
        print("[%s] VFB: cannot read the render (%s)" % (TEN, e))
        return False
    finally:
        # EXR 32 bit ca khung (150-190 MB) chi de doc `Render Result` ra —
        # doc xong la bo, ban giu lai nam trong kho (`cat_vao_kho`).
        try:
            os.remove(tam)
        except Exception:                                    # noqa: BLE001
            pass
    TRANG_THAI.update(
        camera=ten, rong=a.shape[1], cao=a.shape[0],
        mau=int(getattr(scene.cycles, "samples", 0)) if hasattr(scene, "cycles") else 0,
        mau_kinh=0, so_vung=0, dien_tich=0.0, giay_mask=0.0, giay_vung=0.0,
        giay_cuoi=0.0)
    if ten:
        cat_vao_kho(ten, a, thu_muc_kho())
    _VUA[0] = (ten, a)
    return True


def _do_anh_vua_render(scene):
    """Dua anh vua render vao cua so VFB.

    Dung cho moi lan render KHONG qua Glass Boost: canh khong co kinh, engine
    khong phai Cycles, batch cua DP Cam, menu Render > Render Image... DP VFB
    van phai hien ra dung cai vua render, vi cua so Render cua Blender da tat.
    Anh lay tu `bat_anh_vua_render` (bat dung luc xong); khong co thi moi doc
    `Render Result`.
    """
    st = getattr(scene, "dpopt", None)
    if st is None or not getattr(st, "vfb_bat", False):
        return False
    vua, _VUA[0] = _VUA[0], None
    if vua is None:
        if not bat_anh_vua_render(scene):
            return False
        vua, _VUA[0] = _VUA[0], None
    ten, a = vua
    if ten and ten in _KHO:
        TRANG_THAI.update(_KHO[ten]['tk'])
    dat_anh_goc(a)
    if not ve_lai(scene):
        anh_ket_qua(a)
    try:
        img = anh_ket_qua()
        mo_cua_so(bpy.context, img)
        doi_khung_render_result(img)
    except Exception as e:                                   # noqa: BLE001
        print("[%s] VFB: cannot show the render (%s)" % (TEN, e))
    try:
        ve_lai_giao_dien()
    except Exception:                                        # noqa: BLE001
        pass
    return True


def _nhip_hen():
    """Cho lan render thuong tat han roi do anh vua render vao DP VFB."""
    global _DA_HEN
    # Dang chay chuoi Glass Boost (giua hai luot `is_job_running` tat mot
    # nhip) thi doi — do anh cu vao luc nay la de len anh dang ghep.
    if bpy.app.is_job_running('RENDER') or TRANG_THAI['dang_chay']:
        return 0.25
    _DA_HEN = False
    # ⛔ KHONG CON TU CHAY GLASS BOOST SAU MOT LAN RENDER THUONG. Ducphan
    # 21/09/2026: *"tao bao la glassboost truoc co ma"*. Chay sau thi thu tu
    # la anh day du TRUOC, kinh SAU — dung cai anh cam. F12 khi bat DP VFB nay
    # la `dpopt.render_f12` (kinh truoc); toi duoc day la mot lan render KHONG
    # qua lenh do (menu Render > Render Image, lenh cua addon khac, canh
    # khong co kinh) — chi do anh vua render vao VFB.
    # ⛔ Khong co dong nay thi bam render xong la mot cua so trang tron: cua
    # so Render cua Blender da tat, ma cua so DP thi khong ai do anh vao.
    try:
        _do_anh_vua_render(bpy.context.scene)
    except Exception as e:                                   # noqa: BLE001
        print("[%s] VFB: cannot show the render (%s)" % (TEN, e))
    return None


def hen(scene):
    """Goi tu chot sau render. CHI dang ky bo dem gio.

    ⛔ Khong bao gio goi mot lan render moi tu trong chot render: cho do van
    nam trong cong viec render cu, goi vao la treo may.
    """
    global _DA_HEN
    st = getattr(scene, "dpopt", None)
    if _DA_HEN or st is None or not getattr(st, "vfb_bat", False):
        return False
    # ⛔ DANG CHAY GLASS BOOST THI DUNG HEN. Moi luot render phu cua no
    # cung no `render_complete`, va `_nhip_hen` khi thay "already running"
    # se do `Render Result` — luc do la MAN KINH vua render — de len anh
    # dang ghep trong cua so VFB. Luot chay tu lo phan hien anh cua no.
    if TRANG_THAI['dang_chay']:
        return False
    # Render THU cua addon khac (khong phai anh cua khach): khong hen, khong
    # thi `_nhip_hen` doc lai `Render Result` cua anh thu (xem `_render_thu_ngoai`).
    if _render_thu_ngoai():
        return False
    # ⛔ HEN KE CA KHI KHONG BU KINH DUOC. Truoc day cho nay chan bang
    # `vi_sao_khong_tu_dong`, nen canh KHONG CO KINH thi khong hen gi ca —
    # ma cua so Render cua Blender lai dang bi tat, thanh ra bam F12 xong
    # khong thay gi het. Cu hen; `_nhip_hen` se tu quyet dinh la bu kinh hay
    # chi do anh vua render vao cua so.
    _DA_HEN = True
    bpy.app.timers.register(_nhip_hen, first_interval=0.3)
    return True


_XEM_CU = None       # kieu hien anh render cua Blender truoc khi bat VFB


def _nhip_bat_vfb():
    """Lam that viec bat VFB, o NHIP SAU."""
    try:
        _bat_vfb_ngay(bpy.context.scene)
    except Exception as e:                                   # noqa: BLE001
        print("[%s] cannot open the DP window (%s)" % (TEN, e))
    return None


def bat_tat_vfb(scene):
    """Goi tu `update` cua o tick DP VFB.

    ⛔ TRONG `update` KHONG DUOC MO CUA SO hay GO/DANG KY LOP. Blender goi
    callback nay ngay giua luc no dang ghi gia tri property; mo cua so moi
    (`wm.window_new`) va `unregister_class` o do la loai thao tac sinh ra sap
    khong co ngan xep Python. Hoan mot nhip la an toan.
    """
    st = getattr(scene, "dpopt", None)
    bat = bool(st and getattr(st, "vfb_bat", False))
    if not bat:
        _bat_vfb_ngay(scene)             # tat thi chi tra lai mot gia tri
        return
    if not bpy.app.timers.is_registered(_nhip_bat_vfb):
        bpy.app.timers.register(_nhip_bat_vfb, first_interval=0.05)


def _bat_vfb_ngay(scene):
    """Bat/tat DP VFB.

    Bat len thi Blender KHONG mo cua so Render cua no nua (Ducphan
    20/09/2026: *"khi kich hoat roi thi khong hien cua so render cua blender
    nua ma dung dp vfb luon"*) — cai do la `render_display_type = 'NONE'`.
    Tat di thi tra lai y nhu cu.
    """
    global _XEM_CU
    st = getattr(scene, "dpopt", None)
    bat = bool(st and getattr(st, "vfb_bat", False))
    try:
        xem = bpy.context.preferences.view
    except Exception:                                        # noqa: BLE001
        return
    if bat:
        if _XEM_CU is None:
            _XEM_CU = xem.render_display_type
        xem.render_display_type = 'NONE'
        try:
            img = anh_ket_qua()
            if img is None:
                r = scene.render
                img = _anh_tu_mang(TEN_ANH_KQ,
                                   np.zeros((max(1, r.resolution_y // 8),
                                             max(1, r.resolution_x // 8), 4),
                                            np.float32))
            mo_cua_so(bpy.context, img)
        except Exception as e:                               # noqa: BLE001
            print("[%s] cannot open the DP window (%s)" % (TEN, e))
    else:
        if _XEM_CU is not None:
            xem.render_display_type = _XEM_CU
            _XEM_CU = None


def dong_bo_tick(scene):
    """Ap lai tac dung cua o tick DP VFB.

    ⛔ `update=` CUA MOT PROPERTY KHONG CHAY LAI KHI MO FILE. O tick nam
    trong Scene nen no duoc luu vao file; mo file ra thi tick VAN HIEN LA
    BAT, nhung cai viec di kem — tat cua so Render cua Blender — thi chua
    bao gio duoc goi. Ket qua dung nhu Ducphan gap 20/09/2026: *"bat vfb len
    roi ma luc render van ra cua so render mac dinh"*. Phai goi tay luc mo
    file va luc bat addon.
    """
    st = getattr(scene, "dpopt", None)
    if st is None or not getattr(st, "vfb_bat", False):
        return False
    global _XEM_CU
    try:
        xem = bpy.context.preferences.view
    except Exception:                                        # noqa: BLE001
        return False
    if xem.render_display_type != 'NONE':
        if _XEM_CU is None:
            _XEM_CU = xem.render_display_type
        xem.render_display_type = 'NONE'
    return True


def tra_lai_cua_so_render():
    """Tra lai kieu hien anh render cua Blender (goi luc tat addon)."""
    global _XEM_CU
    if _XEM_CU is None:
        return
    try:
        bpy.context.preferences.view.render_display_type = _XEM_CU
    except Exception:                                        # noqa: BLE001
        pass
    _XEM_CU = None


def go_hen():
    global _DA_HEN
    _DA_HEN = False
    if bpy.app.timers.is_registered(_nhip_hen):
        bpy.app.timers.unregister(_nhip_hen)


def vi_sao_khong(scene):
    """Ly do KHONG chay duoc. Chuoi rong = chay duoc."""
    if scene is None:
        return "no scene"
    if scene.render.engine != 'CYCLES':
        return "Cycles only"
    if scene.camera is None:
        return "no camera"
    r = scene.render
    if r.use_border and not (r.border_min_x <= 0.001 and r.border_max_x >= 0.999
                             and r.border_min_y <= 0.001
                             and r.border_max_y >= 0.999):
        return "Render Region is on"
    if not settings.has_transmission(scene):
        return "no glass, water or leaves in this scene"
    return ""


KHOA_CUU = "dpopt_vfb_dang_muon"


def _cat_de_tra(scene, cu):
    """Ghi cai dat DANG MUON len chinh Scene.

    ⛔ VI SAO KHONG CHI GIU TRONG BIEN PYTHON. Lenh nay muon tam cua khach
    rat nhieu thu: so mau, do phan giai, vien render, cay compositor. Neu no
    chet giua chung (hay Blender sap, hay khach tat cua so) thi bien Python
    mat, con FILE CUA KHACH thi o lai voi cay do kinh va 1 mau — render ra
    sai mau va chay sang, ma khong ai biet vi sao. Ghi len Scene thi lan sau
    mo addon van tra lai duoc.
    """
    try:
        scene[KHOA_CUU] = json.dumps({
            'pct': cu['pct'], 'smp': cu['smp'], 'den': cu['den'],
            'ad': cu['ad'], 'b': cu['b'], 'crop': cu['crop'],
            'bx': list(cu['bx']), 'comp': cu['comp'], 'tc': cu['tc'],
            'mi': cu.get('mi', False), 'pidx': cu.get('pidx') or {},
            'grp': cu['grp'].name if cu['grp'] is not None else None,
            'vl': getattr(bpy.context.view_layer, "name", ""),
            'xem': cu.get('xem'),
        })
    except Exception as e:                                   # noqa: BLE001
        print("[%s] cannot record the borrowed settings (%s)" % (TEN, e))


def _tra_pidx(vl, cu):
    """Tra `pass_index` cua vat lieu va pass Material Index da muon luc do
    kinh. Goi lai vo hai: tra xong thi xoa so ghi."""
    for ten, so in list((cu.get('pidx') or {}).items()):
        m = bpy.data.materials.get(ten)
        if m is not None:
            m.pass_index = int(so)
    cu['pidx'] = {}
    if 'mi' in cu:
        vl.use_pass_material_index = bool(cu['mi'])


def _da_tra(scene):
    if KHOA_CUU in scene.keys():
        del scene[KHOA_CUU]


def con_dang_muon(scene):
    """Con cai dat nao cua khach dang bi muon dang do khong."""
    return KHOA_CUU in scene.keys()


def tra_lai_cai_dat(scene):
    """Tra lai cai dat bi bo quen sau mot lan chay do dang. Tra ve True neu
    co gi de tra."""
    if KHOA_CUU not in scene.keys():
        return False
    try:
        c = json.loads(scene[KHOA_CUU])
    except Exception:                                        # noqa: BLE001
        _da_tra(scene)
        return False
    r, cy = scene.render, scene.cycles
    # Tra dung VIEW LAYER da muon, khong phai cai dang mo. `_on_load` duyet
    # het cac scene, nen scene dang mo co the khac scene bi muon do dang.
    vl = scene.view_layers.get(c.get('vl') or "")         or scene.view_layers[0] if len(scene.view_layers) else None
    if vl is None:
        vl = bpy.context.view_layer
    # ⛔ MOI MUC MOT `try` RIENG. Ban cu bao ca muoi phep tra lai trong MOT
    # `try`: hong o muc thu hai la tam muc sau khong ai tra, ma dong
    # `_da_tra(scene)` ngay duoi VAN chay — tuc la xoa luon cai khoa cuu ho
    # ghi tren Scene. Lan mo file sau khong con gi de tra: file cua khach o
    # lai voi 1 mau va 1/8 do phan giai VINH VIEN, dung cai ma `_cat_de_tra`
    # sinh ra de tranh. Nen tach tung muc, va con sot muc nao thi GIU KHOA
    # LAI de lan mo file sau tra tiep.
    def _bien(bx):
        (r.border_min_x, r.border_max_x,
         r.border_min_y, r.border_max_y) = bx

    viec = (
        ("resolution_percentage",
         lambda: setattr(r, "resolution_percentage", c['pct'])),
        ("cycles.samples", lambda: setattr(cy, "samples", c['smp'])),
        ("use_denoising", lambda: setattr(cy, "use_denoising", c['den'])),
        ("use_adaptive_sampling",
         lambda: setattr(cy, "use_adaptive_sampling", c['ad'])),
        ("use_border", lambda: setattr(r, "use_border", c['b'])),
        ("use_crop_to_border",
         lambda: setattr(r, "use_crop_to_border", c['crop'])),
        ("border_*", lambda: _bien(c['bx'])),
        ("use_compositing", lambda: setattr(r, "use_compositing", c['comp'])),
        ("compositing_node_group",
         lambda: setattr(scene, "compositing_node_group",
                         bpy.data.node_groups.get(c['grp'])
                         if c['grp'] else None)),
        ("use_pass_transmission_color",
         lambda: setattr(vl, "use_pass_transmission_color", c['tc'])),
        ("pass_index / use_pass_material_index", lambda: _tra_pidx(vl, c)),
    )
    # ⛔ KHONG TRA `render_display_type` O DAY. No la Preferences cua
    # Blender, khong phai cua file. Lan chay do dang xay ra luc DP VFB
    # dang bat thi gia tri cat lai la 'NONE'; mo lai file la ep ca Blender
    # thanh 'NONE' du phien moi chua bat VFB — ai bat "Auto-Save
    # Preferences" thi dinh vinh vien, F12 khong con mo cua so Render va
    # khong hieu vi sao. Trong mot phien thi `_XEM_CU` da lo viec do roi.
    hong = []
    for ten_muc, ham in viec:
        try:
            ham()
        except Exception as e:                               # noqa: BLE001
            hong.append("%s (%s)" % (ten_muc, e))
    for ten in ("DP_GlassMask",):
        g = bpy.data.node_groups.get(ten)
        if g is not None:
            try:
                bpy.data.node_groups.remove(g)
            except Exception:                                # noqa: BLE001
                pass
    if hong:
        # Giu khoa lai: lan mo file sau con mot lan tra nua. Dong nay se in
        # lai moi lan mo file neu that su khong tra duoc — do la co y, tha
        # lam phien con hon de file cua khach hong ma khong ai biet.
        print("[%s] Glass Boost: could not put these back: %s — the note is "
              "kept on the scene so the next file open can try again"
              % (TEN, "; ".join(hong)))
        return True
    _da_tra(scene)
    print("[%s] Glass Boost: render settings put back after an interrupted run"
          % TEN)
    return True


def _luu_render_result(scene, duong):
    """Luu `Render Result` ra EXR 32 bit roi tra ve numpy (HxWx4, hang 0 o DUOI)."""
    im = bpy.data.images.get("Render Result")
    if im is None:
        raise RuntimeError("no Render Result")
    ims = scene.render.image_settings
    cu = bang_mau.cat_cai_dat_anh(ims)      # du o (xem `bang_mau.O_ANH`)
    # ⛔ MAU PHAI DI THEO SCENE. `save_render` dung `image_settings`; file nao
    # dat `color_management = 'OVERRIDE'` (rat hay gap o file di thue render)
    # thi EXR ghi ra mang mot phep bien doi KHAC, va anh ghep cuoi cung ra sai
    # mau / chay sang ma khong hieu vi sao. EXR 32 bit phai la tuyen tinh
    # thuan, khong bien doi gi.
    cu_cm = getattr(ims, "color_management", None)
    try:
        ims.media_type = 'IMAGE'
        ims.file_format = 'OPEN_EXR'
        ims.color_depth = '32'
        ims.color_mode = 'RGBA'
        if cu_cm is not None:
            ims.color_management = 'FOLLOW_SCENE'
        im.save_render(filepath=duong, scene=scene)
    finally:
        bang_mau.tra_cai_dat_anh(ims, cu)
    if not os.path.isfile(duong):
        raise RuntimeError("cannot save the render result")
    return _doc_exr(duong)


def ve_lai_giao_dien():
    """Bao Blender ve lai moi khung anh (thanh dau + thanh ben cua VFB).

    ⛔ KHONG CO HAM NAY THI THANH DAU NOI DOI. Thanh dau va thanh ben doc
    `TRANG_THAI`, nhung Blender chi ve lai mot vung khi co gi do bao no —
    doi mot bien Python thi khong. Ducphan 21/09/2026 gui anh: render xong roi
    ma VFB van ghi *"Glass area 2 of 2 at 256 samples… Esc to stop"*, cho
    toi khi re chuot qua.
    """
    for w in getattr(bpy.context.window_manager, "windows", ()):
        for area in getattr(w.screen, "areas", ()):
            if area.type in ('IMAGE_EDITOR', 'PROPERTIES'):
                area.tag_redraw()


def _anh_tu_mang(ten, a):
    """Dua mot mang numpy HxWx4 vao mot Image datablock (tao moi neu can)."""
    H, W = a.shape[:2]
    img = bpy.data.images.get(ten)
    cho_xem = []
    if img is not None and (tuple(img.size) != (W, H) or not img.is_float):
        # ⛔ NHO KHUNG DANG XEM TRUOC KHI XOA (cung benh da chua o `hien_ra`).
        # Anh xem cua VFB la anh FILE 8 bit (qua bo mau), nen luot ve NHANH
        # dau tien khi keo Quick adjustments luon xoa no de tao anh float —
        # va cua so VFB BONG TRONG TRON giua luc keo (do 21/09/2026).
        cho_xem = _cac_khung_dang_xem(img)
        bpy.data.images.remove(img)
        img = None
    if img is None:
        img = bpy.data.images.new(ten, W, H, alpha=True, float_buffer=True)
        for sp in cho_xem:
            try:
                sp.image = img
            except Exception:                                # noqa: BLE001
                pass
    # ⛔ HAI CO NAY QUYET DINH ANH HIEN RA CO GIONG BAN RENDER KHONG.
    # Ducphan 20/09/2026: *"anh hien thi 1 dang, vfb hien thi 1 neo, nghi ngo
    # la do k dong bo color management"* — dung, nhung khong phai do cai dat
    # scene: `Render Result` bat san `use_view_as_render`, con mot Image
    # thuong thi KHONG. Khong bat thi Blender chi doi anh tu khong gian mau
    # cua no sang man hinh, BO QUA View Transform / Look / Exposure / Gamma
    # cua scene — anh AgX + Punchy hien ra nhat thech va sai han. Va anh
    # render la PREMUL, de STRAIGHT thi Blender chia nguoc cho alpha, sai
    # mau ngay khi Film > Transparent.
    img.use_view_as_render = True
    img.alpha_mode = 'PREMUL'
    img.pixels.foreach_set(np.ascontiguousarray(a, np.float32).ravel())
    img.update()
    return img


class DPOPT_OT_render_glass_boost(bpy.types.Operator):
    """Render this frame, spending extra samples only where the camera looks
    through glass.

    Detail behind glass is the one thing denoising cannot bring back. This
    renders the glass areas first with more samples, then renders the full
    frame and blends them in, so the Render window ends up with the finished
    image. Press Esc to cancel
    """
    bl_idname = "dpopt.render_glass_boost"
    bl_label = "Render with Glass Boost"
    bl_options = {'REGISTER'}
    # `tu_dong`: F12 vua render xong roi, DUNG render lai anh day du — lay
    # thang `Render Result` lam anh nen. Do la ca mot luot render 67 giay.
    tu_dong: bpy.props.BoolProperty(default=False, options={'HIDDEN'})

    @classmethod
    def poll(cls, context):
        # ⛔ PHAI CHAN KHI DANG CHAY. Giua luot boost, cai dat cua khach dang
        # bi muon (1 mau, 1/8 do phan giai, cay DP_GlassMask). Bam lan hai thi
        # lenh thu hai doc DUNG DONG RAC do lam "cai dat goc" va ghi de ban
        # luu tren Scene — xong viec la file cua khach o lai voi 1 mau, va ca
        # duong cuu ho `tra_lai_cai_dat` cung da bi dau doc.
        if TRANG_THAI['dang_chay']:
            return False
        if vi_sao_ban():
            return False
        return context.scene is not None and not vi_sao_khong(context.scene)

    # ---------------------------------------------------------------- tien ich
    def _bat_dau_luot(self):
        global _XONG, _HUY
        _XONG = False
        _HUY = False
        TRANG_THAI['luot'] = self.buoc
        self.t_luot = time.perf_counter()
        kq = bpy.ops.render.render('INVOKE_DEFAULT', write_still=False)
        # ⛔ BLENDER TU CHOI LUOT NAY THI DUNG NGAY. Ban cu bo qua ket qua:
        # modal cho 20 s roi moi thoi, va neu trong luc do co lan render cua
        # nguoi khac xong thi `_chot_render_xong` bat nham `_XONG` — doc
        # `Render Result` cua nguoi ta lam anh cua luot nay (ra soat
        # 21/09/2026).
        if 'CANCELLED' in kq:
            raise _KhongKhoiDong("Blender did not start the render")
        # ⛔ CHO NGUOI DUNG NHIN THAY LUOT DANG CHAY, nhu cua so Render cua
        # Blender (Ducphan 21/09/2026: *"khong chay kieu render giong cua so
        # cua blend"*). Truoc day suot ca lenh VFB chi hien mot anh den giu
        # cho. Tro khung VFB vao `Render Result` cho luot VUNG KINH va luot
        # ANH DAY DU; `_xong` doi nguoc sang anh da ghep. Bo luot do kinh (1
        # mau, 1/8 do phan giai — nhin vao chi thay mau kinh) va luot vung
        # cua duong tu dong sau F12 (luc do VFB dang hien anh da ghep dan).
        if self.buoc == 'DAY_DU' or (self.buoc == 'VUNG' and not self.tu_f12):
            try:
                hien_anh_dang_render()
            except Exception:                                # noqa: BLE001
                pass
        try:
            ve_lai_giao_dien()           # thanh dau vua doi dong "Glass area…"
        except Exception:                                    # noqa: BLE001
            pass

    def _tra_lai(self):
        r, cy = self.sc.render, self.sc.cycles
        c = self.cu
        r.resolution_percentage = c['pct']
        cy.samples = c['smp']
        cy.use_denoising = c['den']
        cy.use_adaptive_sampling = c['ad']
        r.use_border, r.use_crop_to_border = c['b'], c['crop']
        (r.border_min_x, r.border_max_x,
         r.border_min_y, r.border_max_y) = c['bx']
        r.use_compositing = c['comp']
        self.sc.compositing_node_group = c['grp']
        self.vl.use_pass_transmission_color = c['tc']
        _tra_pidx(self.vl, c)
        _da_tra(self.sc)
        if c.get('xem'):
            try:
                bpy.context.preferences.view.render_display_type = c['xem']
            except Exception:                                # noqa: BLE001
                pass
        for ten in ("DP_GlassMask", "DP_GlassBoost_tron"):
            g = bpy.data.node_groups.get(ten)
            if g is not None and g is not c['grp']:
                try:
                    bpy.data.node_groups.remove(g)
                except Exception:                            # noqa: BLE001
                    pass

    def _dat_mask(self):
        """Luot do vung kinh: 1 mau, 1/8 do phan giai, chi lay Transmission Color."""
        r, cy = self.sc.render, self.sc.cycles
        self.vl.use_pass_transmission_color = True
        # Kenh do = co xuyen sang; kenh xanh = vat lieu MO (pass_index 1 tam
        # thoi, tra lai ngay sau luot nay — `_tra_pidx`).
        self.vl.use_pass_material_index = True
        pidx = {}
        for m in bpy.data.materials:
            muon = 1 if vat_lieu_mo(m) else 0
            if (m.pass_index == 1) != bool(muon):
                pidx[m.name] = m.pass_index
                m.pass_index = muon
        self.cu['pidx'] = pidx
        _cat_de_tra(self.sc, self.cu)
        g = bpy.data.node_groups.new("DP_GlassMask", "CompositorNodeTree")
        g.interface.new_socket(name="Image", in_out='OUTPUT',
                               socket_type="NodeSocketColor")
        rl = g.nodes.new('CompositorNodeRLayers')
        rl.scene = self.sc
        rl.layer = self.vl.name
        tach = g.nodes.new('CompositorNodeSeparateColor')
        g.links.new(rl.outputs['Transmission Color'], tach.inputs[0])
        lon = g.nodes.new('ShaderNodeMath')
        lon.operation = 'MAXIMUM'
        g.links.new(tach.outputs[0], lon.inputs[0])
        g.links.new(tach.outputs[1], lon.inputs[1])
        lon2 = g.nodes.new('ShaderNodeMath')
        lon2.operation = 'MAXIMUM'
        g.links.new(lon.outputs[0], lon2.inputs[0])
        g.links.new(tach.outputs[2], lon2.inputs[1])
        ghep = g.nodes.new('CompositorNodeCombineColor')
        g.links.new(lon2.outputs[0], ghep.inputs[0])
        g.links.new(rl.outputs['Material Index'], ghep.inputs[1])
        ra = g.nodes.new('NodeGroupOutput')
        g.links.new(ghep.outputs[0], ra.inputs[0])
        self.sc.compositing_node_group = g
        r.use_compositing = True
        r.use_border = False
        r.resolution_percentage = max(1, int(round(self.cu['pct'] / 8)))
        cy.samples, cy.use_denoising, cy.use_adaptive_sampling = 1, False, False

    def _doc_mask(self, a):
        mask = (a[:, :, 0] > 0.01) & (a[:, :, 1] < 0.5)
        h, w = mask.shape
        self.ti_le = float(mask.mean())
        sx, sy = self.W / float(w), self.H / float(h)
        # Cac mang kinh SAT NHAU tinh chung mot cum truoc khi xet nguong: tu
        # kinh hai canh bi khung cua chia doi, moi canh 0,24-0,26 % khung, lot
        # duoi NGUONG_CUM ma thuc te van phai cuu (Ducphan 21/09/2026). Noi
        # rong mat na NOI 2 diem anh (1/8 do phan giai ~ 16 px that) roi dem
        # diem kinh THAT trong hinh bao.
        noi = mask.copy()
        for _ in range(2):
            n2 = noi.copy()
            n2[1:] |= noi[:-1]
            n2[:-1] |= noi[1:]
            n2[:, 1:] |= noi[:, :-1]
            n2[:, :-1] |= noi[:, 1:]
            noi = n2
        vung = []
        for _n, y0, y1, x0, x1 in _cum(noi):
            y0, y1 = min(y0 + 2, y1 - 1), max(y1 - 2, y0 + 1)
            x0, x1 = min(x0 + 2, x1 - 1), max(x1 - 2, x0 + 1)
            n = int(mask[y0:y1, x0:x1].sum())
            if n < NGUONG_CUM * w * h:
                continue
            # DO DAC: tam kinh phang (canh tu) lap 87-100 % hinh bao; ly, coc
            # decor lua thua chi 30-55 % — Ducphan: *"canh tu thi duoc nhung
            # may cai decor nho nho thi bo"*.
            if n < DAC_TOI_THIEU * (y1 - y0) * (x1 - x0):
                continue
            vung.append((max(0, int(y0 * sy) - LE),
                         min(self.H, int(np.ceil(y1 * sy)) + LE),
                         max(0, int(x0 * sx) - LE),
                         min(self.W, int(np.ceil(x1 * sx)) + LE)))
        return _gop(vung, self.W, self.H,
                    _nguong_gop(max(int(self.mau), self.cu['smp'])))

    def _dat_vung(self, k):
        """Luot render mot vung kinh: dung cay compositor CUA KHACH, nhieu mau hon."""
        r, cy = self.sc.render, self.sc.cycles
        y0, y1, x0, x1 = self.vung[k]
        self.sc.compositing_node_group = self.cu['grp']
        r.use_compositing = self.cu['comp']
        r.resolution_percentage = self.cu['pct']
        self.vl.use_pass_transmission_color = self.cu['tc']
        cy.use_denoising, cy.use_adaptive_sampling = self.cu['den'], self.cu['ad']
        cy.samples = max(int(self.mau), self.cu['smp'])
        r.use_border = r.use_crop_to_border = True
        # +0,25 diem anh: Blender doi vien ra diem anh bang phep lam tron, dat
        # o giua thi lam tron kieu nao cung ra dung o do — dan lech mot diem
        # anh la canh vat nhoe doi.
        r.border_min_x, r.border_max_x = (x0 + 0.25) / self.W, (x1 + 0.25) / self.W
        r.border_min_y, r.border_max_y = (y0 + 0.25) / self.H, (y1 + 0.25) / self.H

    def _dat_day_du(self):
        """Luot ANH DAY DU: dung nguyen cai dat va cay compositor cua khach."""
        self._tra_lai()
        self.sc.render.use_border = False

    def _chay_day_du(self, context):
        """Bat dau luot ANH DAY DU — luot render CUOI CUNG cua ca lenh."""
        self.buoc = 'DAY_DU'
        self._dat_day_du()
        TRANG_THAI['buoc'] = "Full frame at %d samples…" % self.cu['smp']
        context.workspace.status_text_set(
            "Glass Boost: full frame at %d samples…" % self.cu['smp'])
        self._bat_dau_luot()
        return {'PASS_THROUGH'}

    # ---------------------------------------------------------------- modal
    def invoke(self, context, event):
        ly_do = vi_sao_ban() or vi_sao_khong(context.scene)
        if ly_do:
            self.report({'ERROR'}, "Glass Boost: %s." % ly_do)
            return {'CANCELLED'}
        self.sc = context.scene
        self.vl = context.view_layer
        r, cy = self.sc.render, self.sc.cycles
        self.cu = dict(pct=r.resolution_percentage, smp=cy.samples,
                       den=cy.use_denoising, ad=cy.use_adaptive_sampling,
                       b=r.use_border, crop=r.use_crop_to_border,
                       bx=(r.border_min_x, r.border_max_x,
                           r.border_min_y, r.border_max_y),
                       comp=r.use_compositing, grp=self.sc.compositing_node_group,
                       tc=self.vl.use_pass_transmission_color,
                       mi=self.vl.use_pass_material_index, pidx={})
        _cat_de_tra(self.sc, self.cu)
        self.W = int(r.resolution_x * r.resolution_percentage / 100)
        self.H = int(r.resolution_y * r.resolution_percentage / 100)
        self.mau = int(getattr(self.sc.dpopt, "glass_boost_samples", 256))
        self.thu_muc = thu_muc_kho()
        self.vung = []
        self.k = 0
        self.ti_le = 0.0
        self.t0 = time.perf_counter()
        self.t_moc = self.t0     # moc de do RIENG tung buoc (khong tru chuoi)
        self.moc = {'mask': 0.0, 'day_du': 0.0, 'vung': 0.0}
        # Vung kinh da render nhung CHUA ghep duoc, vi anh day du chay sau
        # cung. Moi phan tu: ((y0, y1, x0, x1), mang anh).
        self.cat_vung = []
        self.nhat_ky = []        # [buoc, giay cho render, giay chan luong chinh]
        self.anh_vung = None
        self.anh_trong_so = None
        self.anh_ghep = None
        self.buoc = 'MASK'
        self.tu_f12 = bool(self.tu_dong)
        self.cho_tu = 0.0        # luc bat dau cho mot luot render khoi dong
        # ⛔ TAT cua so Render cua Blender trong luot nay. Khong tat thi moi
        # luot render phu lai bat len mot cua so, va nguoi dung ngoi nhin mot
        # cua so hien MAU KINH trong khi anh that dang duoc dung o cua so cua
        # DP. Tra lai trong `_tra_lai`.
        try:
            xem = bpy.context.preferences.view
            self.cu['xem'] = xem.render_display_type
            xem.render_display_type = 'NONE'
        except Exception:                                    # noqa: BLE001
            self.cu['xem'] = None
        _cat_de_tra(self.sc, self.cu)
        # ⛔ CAM BAT Persistent Data o day. No giu ca canh da dong bo trong
        # bo nho giua cac luot — do 20/09/2026 tren file that: Blender len
        # 12,2 GB. Ducphan: *"cam dung presitent data gay nang ram"*.
        # DA THU LAI 21/09/2026 (Ducphan hoi "tinh la 1 lan render de do build
        # lai canh"), file khach bep 2625x3500, Blender co cua so:
        #   khong PD: 99 s, dung hinh 1 lan 0,9 s, RAM dinh 18,9 GB
        #   co PD   : 91 s, dung hinh 4 lan tong 8,2 s (2,3-2,5 s moi lan),
        #             RAM dinh 25,6 GB
        # Nhanh 8 s ma GIAT — Ducphan chon bo. Dung bat lai.
        cy_d = getattr(self.sc.cycles, "device", "")
        TRANG_THAI.update(dang_chay=True, buoc="Finding the glass areas…",
                          camera=self.sc.camera.name, rong=self.W, cao=self.H,
                          mau=self.cu['smp'], mau_kinh=max(self.mau, self.cu['smp']),
                          so_vung=0, dien_tich=0.0, giay=0.0, giay_mask=0.0,
                          giay_vung=0.0, giay_cuoi=0.0,
                          thiet_bi="Cycles on the %s"
                                   % ("GPU" if cy_d == 'GPU' else "processor"))
        _gan_chot()
        try:
            if self.tu_f12:
                # PHAI DOC NGAY BAY GIO: luot do kinh se DE LEN `Render
                # Result`, doc sau la mat anh cua khach.
                self.anh_ghep = _luu_render_result(
                    self.sc, os.path.join(self.thu_muc,
                                          _ten_nang("dpopt_kinh_day_du")))
                dat_anh_goc(self.anh_ghep)
                if not ve_lai(self.sc):
                    anh_ket_qua(self.anh_ghep)
                TRANG_THAI['giay_cuoi'] = 0.0
            self._dat_mask()
            self._bat_dau_luot()
        except Exception as e:                               # noqa: BLE001
            _go_chot()
            self._tra_lai()
            # ⛔ PHAI HA CO O DAY. Quen mot dong nay thi `dang_chay` ket True
            # mai mai: thanh dau VFB ghi "Working…" khong dut, va
            # `vi_sao_khong_tu_dong` luon tra "already running" nen F12 KHONG
            # bao gio keo Glass Boost nua — khong co cach nao go tu giao dien,
            # phai tat Blender.
            TRANG_THAI['dang_chay'] = False
            TRANG_THAI['buoc'] = ""
            self.report({'ERROR'}, "Glass Boost: %s" % e)
            return {'CANCELLED'}
        # Mo VFB NGAY, dung doi den luc xong: nguoi bam render muon nhin thay
        # no dang chay o dau (Ducphan 20/09/2026: *"bam render la kich hoat
        # VFB luon chu"*).
        try:
            mo_cua_so(context, anh_ket_qua() or _anh_tu_mang(
                TEN_ANH_KQ, np.zeros((max(1, self.H // 8),
                                      max(1, self.W // 8), 4), np.float32)))
        except Exception as e:                               # noqa: BLE001
            print("[%s] cannot open the DP window (%s)" % (TEN, e))
        # ⛔ BA DONG NAY PHAI NAM TRONG `try`. Lenh duoc goi tu bo dem gio
        # `_nhip_hen` bang 'INVOKE_DEFAULT', noi `context.window` /
        # `context.workspace` co the la None. Nem ra o day thi `_nhip_hen`
        # nuot bang mot dong `print`, con co `dang_chay` thi KET TRUE MAI
        # MAI: bang dung o "Working…", nut Render mo han, F12 khong bao gio
        # keo Glass Boost nua — va khong co duong nao go tu giao dien.
        try:
            wm = context.window_manager
            self._bo_dem = wm.event_timer_add(0.2, window=context.window)
            wm.modal_handler_add(self)
            context.workspace.status_text_set(
                "Glass Boost: finding the glass areas…")
        except Exception as e:                               # noqa: BLE001
            print("[%s] cannot start the modal loop (%s)" % (TEN, e))
            _go_chot()
            self._tra_lai()
            TRANG_THAI['dang_chay'] = False
            TRANG_THAI['buoc'] = ""
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}

    def _ket(self, context, ly_do, loai='INFO'):
        _go_chot()
        # Don file trung gian o MOI duong ra: xong, huy, hay loi.
        try:
            don_luot(self.thu_muc)
        except Exception:                                    # noqa: BLE001
            pass
        wm = context.window_manager
        if getattr(self, "_bo_dem", None) is not None:
            wm.event_timer_remove(self._bo_dem)
            self._bo_dem = None
        # ⛔ HA CO TRUOC, roi moi dung toi `context.workspace` (co the None khi
        # lenh duoc goi tu bo dem gio): nem loi truoc khi ha co la `dang_chay`
        # ket True mai mai va thanh dau ghi "Glass area…" khong dut.
        TRANG_THAI['dang_chay'] = False
        TRANG_THAI['buoc'] = ""
        TRANG_THAI['luot'] = ""
        if loai != 'INFO':
            TRANG_THAI['ket_qua'] = 'HUY' if loai == 'WARNING' else 'LOI'
        try:
            context.workspace.status_text_set(None)
        except Exception:                                    # noqa: BLE001
            pass
        try:
            ve_lai_giao_dien()
        except Exception:                                    # noqa: BLE001
            pass
        if loai == 'INFO':
            self.report({'INFO'}, ly_do)
            return {'FINISHED'}
        self._tra_lai()
        self.report({loai}, ly_do)
        return {'CANCELLED'}

    def cancel(self, context):
        """Blender HUY lenh tu ben ngoai: mo mot file .blend khac, dong cua
        so, doi khong gian lam viec. Luc do no khong goi `modal` them lan nao
        nua.

        ⛔ QUEN HAM NAY LA HONG NANG. Bo dem gio o lai, `dang_chay` ket True
        (thanh dau VFB ghi "Working…" khong dut va `vi_sao_khong_tu_dong`
        luon tra "already running" nen F12 khong bao gio keo Glass Boost nua),
        va nang nhat: cai dat cua khach O LAI trong tinh trang di muon — 1 mau,
        1/8 do phan giai, cay DP_GlassMask.

        Blender KHONG goi `cancel` khi `modal` tu tra {'CANCELLED'}, nen
        khong so tra lai hai lan; du vay van chan bang co `dang_chay`.
        """
        if not TRANG_THAI['dang_chay']:
            return
        self._ket(context, "Glass Boost cancelled", 'WARNING')

    def modal(self, context, event):
        if event.type == 'ESC' and event.value == 'PRESS':
            return self._ket(context, "Glass Boost cancelled", 'WARNING')
        if event.type != 'TIMER':
            return {'PASS_THROUGH'}
        if not _XONG or bpy.app.is_job_running('RENDER'):
            # ⛔ PHAI CO HAN GIO. Neu `render.render('INVOKE_DEFAULT')` khong
            # khoi dong duoc mot luot nao (dang co lan render khac, het VRAM,
            # job bi tu choi) thi `_XONG` mai False va `is_job_running` cung
            # mai False — modal quay vong VO TAN, thanh dau treo "Working…",
            # va cai dat cua khach o lai trong tinh trang di muon. Khong ai
            # doan duoc la phai bam Esc.
            if not bpy.app.is_job_running('RENDER'):
                if self.cho_tu == 0.0:
                    self.cho_tu = time.perf_counter()
                elif time.perf_counter() - self.cho_tu > 20.0:
                    return self._ket(context,
                                     "Glass Boost: Blender did not start the "
                                     "render — nothing was changed", 'WARNING')
            else:
                self.cho_tu = 0.0
            return {'PASS_THROUGH'}
        self.cho_tu = 0.0
        if _HUY:
            return self._ket(context, "Glass Boost cancelled", 'WARNING')
        # Do RIENG hai thu cho moi luot: cho render (Blender van ve giao dien)
        # va thoi gian `_tiep` CHAN LUONG CHINH (doc EXR, ghep, ve lai) — cai
        # thu hai moi la "treo Blender" nguoi dung thay.
        t = time.perf_counter()
        self.nhat_ky.append([self.buoc, t - getattr(self, 't_luot', t), 0.0])
        try:
            kq = self._tiep(context)
            self.nhat_ky[-1][2] = time.perf_counter() - t
            return kq
        except _KhongKhoiDong as e:
            return self._ket(context, "Glass Boost: %s" % e, 'ERROR')
        except Exception as e:                               # noqa: BLE001
            import traceback
            traceback.print_exc()
            return self._ket(context, "Glass Boost failed: %s" % e, 'ERROR')

    def _tiep(self, context):
        # THU TU (doi 21/09/2026 theo lenh Ducphan): do kinh -> TUNG VUNG
        # KINH -> ANH DAY DU sau cung -> ghep mot the bang numpy.
        #
        # ⛔ ANH DAY DU PHAI LA LUOT RENDER CUOI CUNG. Blender chi co MOT
        # `Render Result`, va no luon thuoc ve luot render CUOI. Ban cu chay
        # may man kinh sau cung, nen cua so Render cua Blender o lai voi mot
        # MAN KINH (Ducphan 20/09/2026: *"render result thi ra dung cai doan
        # kinh"*), va Python thi khong ghi nguoc vao `Render Result` duoc.
        # Dao lai thu tu la het — khong phai chen node, khong phai ghi nguoc.
        # Lam vay con do "lag" han: nguoi dung ngoi cho o PHAN DAU, roi cai
        # cuoi cung ho nhin thay la khung hinh day du hien dan ra binh thuong,
        # thay vi thay anh xong roi may dung hinh them nua phut nua.
        #
        # Tron bang numpy chu KHONG chen node vao cay compositor cua khach:
        # chen node thi Blender khong thay Render Layers o tang ngoai va BO
        # QUA ca luot render (da lam, anh ra den thui, 20/09/2026).
        if self.buoc == 'MASK':
            a = _luu_render_result(
                self.sc,
                os.path.join(self.thu_muc, _ten_nang("dpopt_kinh_mask")))
            self.vung = self._doc_mask(a)
            # Tra pass_index cua khach NGAY, khong doi het lenh.
            _tra_pidx(self.vl, self.cu)
            _cat_de_tra(self.sc, self.cu)
            self.t_moc = time.perf_counter()
            self.moc['mask'] = self.t_moc - self.t0
            TRANG_THAI['giay_mask'] = self.moc['mask']
            TRANG_THAI['so_vung'] = len(self.vung)
            TRANG_THAI['dien_tich'] = (
                sum((y1 - y0) * (x1 - x0) for y0, y1, x0, x1 in self.vung)
                / float(self.W * self.H)) if self.vung else 0.0
            if self.tu_f12:
                # Anh day du la cua F12, khong render lai.
                self.moc['day_du'] = 0.0
                if not self.vung:
                    return self._xong(context)
                self.k = 0
                self.buoc = 'VUNG'
                self._dat_vung(self.k)
                TRANG_THAI['buoc'] = ("Glass area 1 of %d at %d samples…"
                                      % (len(self.vung),
                                         max(self.mau, self.cu['smp'])))
                context.workspace.status_text_set(TRANG_THAI['buoc'])
                self._bat_dau_luot()
                return {'PASS_THROUGH'}
            if not self.vung:
                # Khong co kinh: chi con dung mot luot anh day du.
                return self._chay_day_du(context)
            self.k = 0
            self.buoc = 'VUNG'
            self._dat_vung(self.k)
            TRANG_THAI['buoc'] = ("Glass area 1 of %d at %d samples…"
                                  % (len(self.vung),
                                     max(self.mau, self.cu['smp'])))
            context.workspace.status_text_set(TRANG_THAI['buoc'])
            self._bat_dau_luot()
            return {'PASS_THROUGH'}

        if self.buoc == 'DAY_DU':
            now = time.perf_counter()
            self.anh_ghep = _luu_render_result(
                self.sc,
                os.path.join(self.thu_muc, _ten_nang("dpopt_kinh_day_du")))
            self.moc['day_du'] = now - self.t_moc
            self.t_moc = now
            TRANG_THAI['giay_cuoi'] = self.moc['day_du']
            # Ghep may vung kinh da render tu truoc vao — numpy, tinh xong
            # trong mot cai chop mat, khong co luot render nao nua.
            for (y0, y1, x0, x1), cat in self.cat_vung:
                tr = _trong_so(y1 - y0, x1 - x0, y0, y1, x0, x1, self.H, self.W)
                self.anh_ghep[y0:y1, x0:x1] = (
                    tr * cat + (1.0 - tr) * self.anh_ghep[y0:y1, x0:x1])
            self.cat_vung = []
            dat_anh_goc(self.anh_ghep)
            if not ve_lai(self.sc):
                anh_ket_qua(self.anh_ghep)
            return self._xong(context)

        if self.buoc == 'VUNG':
            y0, y1, x0, x1 = self.vung[self.k]
            cat = _luu_render_result(
                self.sc,
                os.path.join(self.thu_muc,
                             _ten_nang("dpopt_kinh_vung%d" % self.k)))
            if cat.shape[:2] != (y1 - y0, x1 - x0):
                raise RuntimeError("area %d came back %s, expected %s"
                                   % (self.k, cat.shape[:2], (y1 - y0, x1 - x0)))
            if self.anh_ghep is None:
                # Thu tu moi: anh day du chay SAU, nen chua co gi de ghep
                # vao. Giu lai, ghep mot the o buoc 'DAY_DU'.
                self.cat_vung.append(((y0, y1, x0, x1), cat))
            else:
                # Duong cu (goi tu dong sau F12): anh day du da co san, ghep
                # ngay de khach thay no dang tot len tung vung.
                tr = _trong_so(y1 - y0, x1 - x0, y0, y1, x0, x1,
                               self.H, self.W)
                self.anh_ghep[y0:y1, x0:x1] = (
                    tr * cat + (1.0 - tr) * self.anh_ghep[y0:y1, x0:x1])
                dat_anh_goc(self.anh_ghep)
                if not ve_lai(self.sc):
                    anh_ket_qua(self.anh_ghep)
            self.k += 1
            now = time.perf_counter()
            self.moc['vung'] += now - self.t_moc
            self.t_moc = now
            TRANG_THAI['giay_vung'] = self.moc['vung']
            if self.k < len(self.vung):
                self._dat_vung(self.k)
                TRANG_THAI['buoc'] = ("Glass area %d of %d at %d samples…"
                                      % (self.k + 1, len(self.vung),
                                         max(self.mau, self.cu['smp'])))
                context.workspace.status_text_set(TRANG_THAI['buoc'])
                self._bat_dau_luot()
                return {'PASS_THROUGH'}
            if self.anh_ghep is None:
                return self._chay_day_du(context)
            return self._xong(context)
        return {'PASS_THROUGH'}

    def _xong(self, context):
        self._tra_lai()
        giay = time.perf_counter() - self.t0
        TRANG_THAI.update(dang_chay=False, buoc="", giay=giay, ket_qua='XONG')
        try:
            cat_vao_kho(self.sc.camera.name, self.anh_ghep, self.thu_muc)
        except Exception as e:                               # noqa: BLE001
            print("[%s] VFB: cannot keep this camera (%s)" % (TEN, e))
        try:
            img = anh_ket_qua()
            mo_cua_so(context, img)
            doi_khung_render_result(img)
        except Exception as e:                               # noqa: BLE001
            # ⛔ DUNG NUOT. Day la nhanh DUA ANH THAT ra cua so. Hong ma im
            # lang thi `_ket` ngay duoi van bao {'INFO'} "xong", trong khi cai
            # nguoi dung nhin thay la cua so Render CON NGUYEN MOT MANG KINH
            # — ket qua SAI chu khong phai "khong lam gi".
            print("[%s] VFB: the finished image could not be shown (%s)"
                  % (TEN, e))
        loi = ("Glass Boost: %d glass area(s), %.0f%% of the frame at %d "
               "samples, %.0f s total"
               % (len(self.vung), 100 * TRANG_THAI['dien_tich'],
                  max(self.mau, self.cu['smp']), giay))
        print("[%s] %s" % (TEN, loi))
        # Mot dong cho moi luot: bao lau cho render, bao lau Blender dung hinh.
        print("[%s] Glass Boost steps: %s" % (TEN, " | ".join(
            "%s render %.1f s, busy %.1f s" % (b, c, d)
            for b, c, d in self.nhat_ky)))
        return self._ket(context, loi)


# ==================================================== CUA SO RENDER CUA DP
#
# VI SAO CO. Cua so Render cua Blender gan chat voi `Render Result`, ma
# `Render Result` luon thuoc ve LUOT RENDER CUOI CUNG va Python khong ghi vao
# no duoc. Moi thu chay nhieu luot (Glass Boost) deu vap vao do. Nen
# DP-Optimize co cua so RIENG: mot cua so Blender moi, ben trong la mot Image
# Editor tro vao anh cua chinh addon.
#
# Khong bat cua so nay thi F12 cua Blender chay y nhu cu — addon khong dung gi.

TEN_ANH_KQ = "DP Optimize Render"
# Dau danh tren MAN HINH cua cua so VFB, de nhan ra no sau khi mo lai file.
DAU_VFB = "dpopt_cua_so_vfb"

# Trang thai cua lan render gan nhat — thanh dau va thanh ben doc tu day.
TRANG_THAI = {
    'dang_chay': False, 'buoc': "", 'camera': "", 'rong': 0, 'cao': 0,
    'mau': 0, 'mau_kinh': 0, 'so_vung': 0, 'dien_tich': 0.0, 'giay': 0.0,
    'giay_mask': 0.0, 'giay_vung': 0.0, 'giay_cuoi': 0.0, 'thiet_bi': "",
    # Luot dang render cua Glass Boost: 'MASK' / 'VUNG' / 'DAY_DU' / "".
    # DP_RAMchill doc o day de KHONG ha map o luot do kinh.
    'luot': "",
    # Ket cuc lenh gan nhat: 'XONG' / 'HUY' / 'LOI' / "" — DP Camera doc de
    # dung batch khi nguoi dung huy.
    'ket_qua': "",
}

# Kho anh THEO CAMERA, giu tren DIA (EXR trong thu muc tam) chu khong giu
# trong bo nho: mot anh 2625x3500 float la 147 MB, vai camera la vai GB.
_KHO = {}            # ten camera -> {'exr': duong dan, 'tk': ban sao TRANG_THAI}

# ⛔ DOI CAMERA TRONG VFB PHAI NHANH. Do 21/09/2026 (batch DP Cam 3 camera,
# anh 4000x3000): doc lai EXR 32 bit tu dia mat 0,7-1,2 s MOI LAN doi. Giu
# ban NUA DO CHINH XAC cua vai camera gan nhat trong RAM (96 MB mot anh
# 4000x3000) — doi camera con lai phan ve. Co tran: vuot thi bo camera xem
# lau nhat; dia van con nen bo khong mat gi.
def _ram_may():
    """Tong RAM cua may (byte), 0 neu khong doc duoc. Ca ba he."""
    try:
        if sys.platform == "win32":
            import ctypes

            class _MS(ctypes.Structure):
                _fields_ = [("dwLength", ctypes.c_ulong),
                            ("dwMemoryLoad", ctypes.c_ulong),
                            ("ullTotalPhys", ctypes.c_ulonglong),
                            ("ullAvailPhys", ctypes.c_ulonglong),
                            ("ullTotalPageFile", ctypes.c_ulonglong),
                            ("ullAvailPageFile", ctypes.c_ulonglong),
                            ("ullTotalVirtual", ctypes.c_ulonglong),
                            ("ullAvailVirtual", ctypes.c_ulonglong),
                            ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]
            m = _MS()
            m.dwLength = ctypes.sizeof(_MS)
            if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m)):
                return int(m.ullTotalPhys)
            return 0
        return int(os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES"))
    except Exception:                                        # noqa: BLE001
        return 0


# ⛔ TRAN THEO MAY, KHONG CO DINH (21/09/2026). Ducphan render 20-30 anh mot
# file; 1 GB chi giu ~10 anh 4000x3000. Nay: 10 % RAM may, tran 3 GB, san
# 512 MB — may 64 GB giu ~30 anh 4K, may 16 GB giu ~16, khong may nao bi an
# qua 10 % RAM vi viec nay. Qua tran thi doc lai tu dia (cham hon ~0,25 s).
TRAN_RAM_CAM = max(512 * 1024 ** 2, min(3 * 1024 ** 3, _ram_may() // 10))
_RAM_CAM = {}        # ten camera -> mang float16, thu tu = cu -> moi


def _nho_ram(ten, a):
    if not ten or a is None:
        return
    _RAM_CAM.pop(ten, None)
    _RAM_CAM[ten] = np.asarray(a, np.float16)
    tong = sum(v.nbytes for v in _RAM_CAM.values())
    while tong > TRAN_RAM_CAM and len(_RAM_CAM) > 1:
        cu = next(iter(_RAM_CAM))
        tong -= _RAM_CAM.pop(cu).nbytes


TEN_ANH_GOC = "DP Optimize Render (linear)"


def anh_ket_qua(a=None):
    """Anh ket qua cua DP-Optimize (tao/cap nhat neu duoc dua mang vao)."""
    if a is not None:
        return hien_ra(bpy.context.scene, a)
    return bpy.data.images.get(TEN_ANH_KQ)


def anh_goc_tuyen_tinh():
    """Anh TUYEN TINH day du — cai dung de luu ra file, khong phai ban xem."""
    return bpy.data.images.get(TEN_ANH_GOC)


def thu_muc_tam():
    """Cho de file NHO va doi lien tuc (anh xem tren cua so).

    ⛔ Ducphan 20/09/2026: *"cac van de bo nho dem thi sao ??? vi tao dung da
    nen tang os day"*. Ba cai bay:
      1. Moi he dieu hanh mot cho khac nhau, va nguoi dung con doi duoc cho do
         trong Preferences > File Paths > Temporary Files. `bpy.app.tempdir`
         la cho Blender DANG dung that, lai duoc chinh Blender don khi thoat;
         `tempfile.gettempdir()` chi la phuong an cuoi.
      2. Tren Linux `/tmp` la cua CHUNG. Hai ban Blender mo cung luc (hay hai
         nguoi dung chung may) ma ghi cung mot ten file thi de len nhau, anh
         cua ban nay hien o cua so ban kia. Nen ten file phai mang so hieu
         tien trinh.
      3. Dau gach cheo nguoc cua Windows va dau // cua Blender: di qua
         `bpy.path.abspath` het.

    Cho nay CO THE nam trong RAM va nhu the lai tot: no chi giu DUNG MOT file
    anh xem, bi ghi de moi lan ve lai, nen khong phinh ra. Cac file NANG thi
    khong duoc de o day — xem `thu_muc_kho`.
    """
    d = bpy.app.tempdir or tempfile.gettempdir()
    try:
        d = bpy.path.abspath(d)
        if not os.path.isdir(d):
            os.makedirs(d, exist_ok=True)
    except Exception:                                        # noqa: BLE001
        d = tempfile.gettempdir()
    return d


PID = os.getpid()
_KHO_NOI = [None]        # nho lai cho da chon, khoi do lai moi lan


def thu_muc_kho(noi_ra=True):
    """Cho de file NANG (EXR ca khung hinh, 108 MB mot cai o anh 4K).

    ⛔ KHONG CON DO XEM THU MUC TAM CO NAM TRONG RAM HAY KHONG. Ban cu doc
    `/proc/mounts` de doan `/tmp` co phai `tmpfs` khong roi moi chon cho ghi.
    Ducphan 20/09/2026 bat bo cach do: no them MOT CHO CO THE DOAN SAI, va
    ca nhanh do chi chay tren Linux nen tren may dev (Windows) chua ai chay
    that bao gio — mot nhanh chua tung duoc do la mot nhanh khong dam tin.
    Nay LUON ghi vao thu muc cache rieng cua nguoi dung, la cho nam TREN DIA
    o ca ba he dieu hanh. Dung them lai phep do tmpfs.

    Thu muc tam cua Blender (`thu_muc_tam`) van giu nguyen vai tro cu: chi de
    MOT file anh xem, bi ghi de lien tuc, nen nam trong RAM cung khong sao.
    """
    if _KHO_NOI[0] and os.path.isdir(_KHO_NOI[0]):
        return _KHO_NOI[0]
    if os.name == 'nt':
        goc = os.environ.get("LOCALAPPDATA") \
            or os.path.join(os.path.expanduser("~"), "AppData", "Local")
        thu = os.path.join(goc, "dp_optimize", "cache")
    else:
        goc = os.environ.get("XDG_CACHE_HOME") \
            or os.path.join(os.path.expanduser("~"), ".cache")
        thu = os.path.join(goc, "dp_optimize")
    try:
        os.makedirs(thu, exist_ok=True)
    except Exception as e:                                   # noqa: BLE001
        # Home chi doc, hay bi chan quyen: lui ve thu muc tam, nhung PHAI
        # noi ra — de file nang trong thu muc tam la chuyen nguoi dung can
        # biet, nhat la tren may Linux dat /tmp trong RAM.
        thu = thu_muc_tam()
        if noi_ra:
            print("[%s] cannot create the cache folder (%s) — the big "
                  "images have to go in the temporary folder: %s"
                  % (TEN, e, thu))
    _KHO_NOI[0] = thu
    return thu


def _ten_nang(ten, duoi=".exr"):
    """Ten mot file NANG — luon mang so hieu tien trinh.

    ⛔ HAI BAN BLENDER CO THE MO CUNG LUC, va nay file nang nam trong thu
    muc cache DUNG CHUNG chu khong con trong thu muc tam rieng cua tung ban.
    Khong co so hieu tien trinh thi hai ban ghi de len file cua nhau, va
    khau don rac se xoa mat file ban kia dang dung do.
    """
    return "%s_%d%s" % (ten, PID, duoi)


def _cua_minh(ten):
    """File nang nay co phai do CHINH tien trinh Blender nay tao ra khong."""
    if not ten.startswith(("dpopt_kinh_", "dpopt_vfb_")):
        return False
    return os.path.splitext(ten)[0].endswith("_%d" % PID)


# ------------------------------------------------- KHOA CUA TIEN TRINH NAY
#
# ⛔ VI SAO KHONG DON RAC THEO TUOI FILE. Cach de nhat la "file nao qua 24
# gio thi xoa". Cach do SAI khi nguoi dung mo HAI ban Blender cung luc: ban
# moi bat len se xoa mat file ma ban dang chay do dang van con dung. Nen moi
# tien trinh dat mot FILE KHOA mang so hieu cua no, va chi don phan cua
# nhung so hieu da CHET. Tuoi file chi con la duong cuoi, cho truong hop
# khong the biet chu cua no con song hay khong (xem `don_rac_cu`).
_KHOA = [None]           # doi tuong file khoa, PHAI giu mo suot phien
BAY_NGAY = 7 * 24 * 3600


def _mo_khoa():
    """Dat file khoa cua tien trinh nay va GIU NO MO.

    Giu mo la co y: tren Windows mot file dang mo thi tien trinh khac khong
    xoa duoc, nen do la them mot lop chan neu khau kiem tien trinh doan sai.
    """
    if _KHOA[0] is not None:
        return
    try:
        duong = os.path.join(thu_muc_kho(), "dpopt_khoa_%d.lock" % PID)
        f = io.open(duong, "w", encoding="utf-8")
        f.write("%d\n" % PID)
        f.flush()
        _KHOA[0] = f
    except Exception as e:                                   # noqa: BLE001
        print("[%s] cannot create the lock file (%s)" % (TEN, e))


def _dong_khoa():
    f = _KHOA[0]
    _KHOA[0] = None
    if f is None:
        return
    try:
        duong = f.name
        f.close()
        os.remove(duong)
    except Exception:                                        # noqa: BLE001
        pass


def _con_song(pid):
    """Tien trinh `pid` con song khong. True / False / None (khong biet chac)."""
    if pid <= 0:
        return None
    if os.name == 'nt':
        # ⛔ TREN WINDOWS CAM DUNG `os.kill(pid, 0)`. Python tren Windows dich
        # no thanh `TerminateProcess`: tin hieu 0 KHONG phai la cau hoi tham,
        # no GIET tien trinh do that. Phai hoi bang `OpenProcess` voi quyen
        # PROCESS_QUERY_LIMITED_INFORMATION (0x1000).
        try:
            import ctypes
            k = ctypes.windll.kernel32
            h = k.OpenProcess(0x1000, False, int(pid))
            if not h:
                return False
            k.CloseHandle(h)
            return True
        except Exception:                                    # noqa: BLE001
            return None
    try:
        os.kill(pid, 0)          # tin hieu 0: chi hoi tham, khong giet ai
    except ProcessLookupError:
        return False
    except PermissionError:
        return True              # cua nguoi dung khac, nhung CON SONG
    except Exception:                                        # noqa: BLE001
        return None
    if sys.platform.startswith("linux"):
        # So hieu tien trinh duoc dung lai: pid ay co the la mot chuong
        # trinh hoan toan khac. Hoi them ten cho chac.
        try:
            with io.open("/proc/%d/comm" % pid, encoding="utf-8",
                         errors="replace") as f:
                if "blender" not in f.read().lower():
                    return False
        except Exception:                                    # noqa: BLE001
            return None
    return True


def _qua_cu(duong, giay):
    try:
        return (time.time() - os.path.getmtime(duong)) > giay
    except Exception:                                        # noqa: BLE001
        return False


def _xoa_phan_cua(thu, pid, duong_khoa):
    """Xoa moi file nang mang so hieu `pid`, roi xoa chinh file khoa."""
    n = 0
    duoi = "_%d" % pid
    try:
        for ten in os.listdir(thu):
            if not ten.startswith(("dpopt_kinh_", "dpopt_vfb_")):
                continue
            if not os.path.splitext(ten)[0].endswith(duoi):
                continue
            try:
                os.remove(os.path.join(thu, ten))
                n += 1
            except Exception:                                # noqa: BLE001
                pass
    except Exception:                                        # noqa: BLE001
        pass
    try:
        os.remove(duong_khoa)
    except Exception:                                        # noqa: BLE001
        pass
    return n


def don_rac_cu():
    """Don file nang cua nhung ban Blender DA CHET. Tra ve so file da xoa.

    Chay luc bat addon. File nang nay nam ngoai thu muc tam cua Blender nen
    Blender khong don ho nua — ma cung khong duoc don bua: xem ghi chu ⛔ o
    tren `_KHOA`. Luat: chu da chet thi don; khong biet chac thi DE YEN, tru
    khi file khoa da qua bay ngay. Tha de lai rac con hon xoa nham cua
    nguoi dang dung.
    """
    thu = thu_muc_kho(noi_ra=False)
    try:
        ds = sorted(os.listdir(thu))
    except Exception:                                        # noqa: BLE001
        return 0
    n = 0
    for ten in ds:
        if not ten.startswith("dpopt_khoa_") or not ten.endswith(".lock"):
            continue
        duong = os.path.join(thu, ten)
        try:
            pid = int(ten[len("dpopt_khoa_"):-len(".lock")])
        except Exception:                                    # noqa: BLE001
            pid = 0
        if pid == PID:
            continue
        song = _con_song(pid) if pid else None
        if song is False:
            n += _xoa_phan_cua(thu, pid, duong)
        elif song is None and _qua_cu(duong, BAY_NGAY):
            n += _xoa_phan_cua(thu, pid, duong)
    return n


def _duong_hien():
    return os.path.join(thu_muc_tam(), "dpopt_vfb_hien_%d.tif" % os.getpid())


def don_luot(thu_muc):
    """Xoa cac EXR trung gian cua MOT luot bu kinh, ngay khi lam xong.

    ⛔ Chung khong con dung vao viec gi sau khi da tron xong. O anh 4000x2250
    moi file la 108 MB: de lai thi moi lan bam render lai an them tung ay
    dung luong, va tren Linux ma thu muc tam nam trong RAM thi la an them
    tung ay BO NHO.
    """
    try:
        for ten in os.listdir(thu_muc):
            # ⛔ CHI XOA FILE CUA CHINH MINH. Thu muc cache la cho DUNG CHUNG
            # cua moi ban Blender dang mo; quet sach theo tien to la xoa mat
            # file ma ban Blender kia dang bu kinh do dang.
            if ten.startswith("dpopt_kinh_") and _cua_minh(ten):
                try:
                    os.remove(os.path.join(thu_muc, ten))
                except Exception:                            # noqa: BLE001
                    pass
    except Exception:                                        # noqa: BLE001
        pass


# Tran cho kho anh theo camera. Vuot thi bo anh CU NHAT. Mot loat 20 camera o
# anh 4K la hon 2 GB neu khong chan.
TRAN_KHO = 4 * 1024 ** 3     # 30 camera 4000x3000 float16 = 2,8 GB
# ⛔ O DIA DAY THI TU THU LAI (21/09/2026): tran kho la 3 GB NHUNG khong bao
# gio de o chua kho con duoi `CHUA_TRONG` — may render day o la may render
# hong giua chung, dat hon nhieu mot anh xem lai.
CHUA_TRONG = 10 * 1024 ** 3


def _tran_kho(thu, tong_cua_minh):
    """Tran THAT: 3 GB, tru di phan can de o dia con `CHUA_TRONG`."""
    try:
        import shutil
        trong = shutil.disk_usage(thu).free
    except Exception:                                        # noqa: BLE001
        return TRAN_KHO
    return max(0, min(TRAN_KHO, tong_cua_minh + trong - CHUA_TRONG))


def _go_bot_kho():
    """Giu tong dung luong file nang CUA CHINH TIEN TRINH NAY duoi muc tran,
    bo tu cai cu nhat.

    Dem CA THU MUC chu khong chi dem nhung anh con ghi trong `_KHO`: file
    nang nay nam trong cache dung chung, mot lan chay chet giua chung co the
    de lai anh ma `_KHO` khong con nho. Nhung chi XOA anh theo camera
    (`dpopt_vfb_`) — file trung gian `dpopt_kinh_` co the la cua luot dang
    chay ngay luc nay, va `don_luot` da lo don chung roi.
    """
    thu = thu_muc_kho(noi_ra=False)
    tong, bo_duoc = 0, []
    try:
        for ten in os.listdir(thu):
            if not _cua_minh(ten):
                continue
            duong = os.path.join(thu, ten)
            try:
                kich = os.path.getsize(duong)
                moc = os.path.getmtime(duong)
            except Exception:                                # noqa: BLE001
                continue
            tong += kich
            if ten.startswith("dpopt_vfb_"):
                bo_duoc.append((moc, kich, duong))
    except Exception:                                        # noqa: BLE001
        return
    tran = _tran_kho(thu, tong)
    if tong <= tran:
        return
    theo_duong = dict((m['exr'], ten) for ten, m in _KHO.items())
    for _moc, kich, duong in sorted(bo_duoc):
        if tong <= tran:
            break
        ten_cam = theo_duong.get(duong)
        if ten_cam:
            _KHO.pop(ten_cam, None)
            _RAM_CAM.pop(ten_cam, None)
        try:
            os.remove(duong)
        except Exception:                                    # noqa: BLE001
            pass
        tong -= kich
        print("[%s] VFB: dropped the stored image for '%s' to stay under "
              "%.1f GB" % (TEN, ten_cam or os.path.basename(duong),
                           tran / 1024.0 ** 3))


def don_tam():
    """Xoa file xem tam, kho anh theo camera, va cac anh xem cua lan truoc.

    Goi luc TAT ADDON va luc MO FILE KHAC (Ducphan 20/09/2026: *"dung la
    phai tu don bo nho khi thoat"*). Moi camera giu mot EXR 32 bit — anh
    2625x3500 la 147 MB mot cai, vai camera la vai GB nam lai trong thu muc
    tam. Blender co don thu muc tam cua no luc thoat binh thuong, nhung no
    KHONG don khi bi tat ngang, va cung khong don giua hai lan mo file.
    """
    for m in list(_KHO.values()):
        try:
            if os.path.isfile(m['exr']):
                os.remove(m['exr'])
        except Exception:                                    # noqa: BLE001
            pass
    _KHO.clear()
    _RAM_CAM.clear()
    dat_anh_goc(None)
    for ten in (TEN_ANH_KQ, TEN_ANH_GOC, "DP_VFB_tam", "DP_VFB_ghi"):
        img = bpy.data.images.get(ten)
        if img is not None:
            try:
                bpy.data.images.remove(img)
            except Exception:                                # noqa: BLE001
                pass
    # Quet ca thu muc tam: ngoai file xem, con cac EXR cua lan bu kinh
    # (mask, anh day du, tung vung) — anh 2625x3500 la 147 MB MOT CAI.
    for thu in {thu_muc_tam(), thu_muc_kho(noi_ra=False)}:
        try:
            for ten in os.listdir(thu):
                # ⛔ CHI CUA MINH — xem ghi chu o `don_luot`.
                if _cua_minh(ten):
                    try:
                        os.remove(os.path.join(thu, ten))
                    except Exception:                        # noqa: BLE001
                        pass
        except Exception:                                    # noqa: BLE001
            pass


def _cac_khung_dang_xem(img):
    """Moi khung anh dang tro vao datablock nay."""
    ra = []
    for w in getattr(bpy.context.window_manager, "windows", ()):
        for area in getattr(w.screen, "areas", ()):
            if area.type != 'IMAGE_EDITOR':
                continue
            sp = area.spaces.active
            if getattr(sp, "image", None) is img:
                ra.append(sp)
    return ra


def hien_ra(scene, a):
    """Dua mang TUYEN TINH len cua so VFB, qua dung bo mau cua Blender.

    ⛔ TAI SAO PHAI VONG QUA MOT FILE. Do 20/09/2026, bon truong hop (co
    "View as Render" bat/tat x Standard/AgX): mot Image THUONG trong Image
    Editor luon hien ra y het nhau — anh phang 1.0 tuyen tinh ra 255 ca bon
    lan, trong khi AgX phai ra khoang 184. Nghia la khung anh KHONG ap View
    Transform / Look / Exposure / Gamma cua scene cho anh thuong; chi rieng
    `Render Result` moi duoc. Do la ly do Ducphan thay *"anh hien thi 1 dang,
    vfb hien thi 1 neo"*.

    Va cach chua KHONG PHAI la tu nan mau cho vua mat (Ducphan noi thang:
    *"tao bao may dong bo hien thi color cho chuan chu deo bao may di sua
    rieng anh cho dung"*). Cach dung la de CHINH BLENDER lam phep bien doi:
    `save_render` chay dung bo color management cua scene, ke ca Look, White
    Balance va Curves. Ghi ra TIFF 8 bit roi nap lai: do 4000x2250 het 0,30 s
    (PNG 2,45 s, PNG 16 bit 3,61 s — nen khong dung).

    Ban TUYEN TINH van duoc giu nguyen o `TEN_ANH_GOC` de luu ra file.
    """
    if a is None:
        return None
    goc = _anh_tu_mang(TEN_ANH_GOC, a)
    duong = _duong_hien()
    ims = scene.render.image_settings
    cu = bang_mau.cat_cai_dat_anh(ims)      # du o, ca `tiff_codec`
    cu_cm = getattr(ims, "color_management", None)
    try:
        ims.media_type = 'IMAGE'
        ims.file_format = 'TIFF'
        # Kieu nen: do 20/09/2026 o anh 4000x2250, ghi + nap lai —
        # PACKBITS 0,22 s | DEFLATE 0,27 s | NONE 0,28 s | LZW 0,54 s.
        # PNG thi 2,45 s nen khong dung duoc cho viec ve lai lien tuc.
        try:
            ims.tiff_codec = 'PACKBITS'
        except Exception:                                    # noqa: BLE001
            pass
        ims.color_depth = '8'
        ims.color_mode = 'RGBA'
        if cu_cm is not None:
            ims.color_management = 'FOLLOW_SCENE'
        goc.save_render(filepath=duong, scene=scene)
    except Exception as e:                                   # noqa: BLE001
        # Khong ghi duoc file thi van phai co anh de nhin, du mau chua chuan.
        print("[%s] VFB: cannot colour-manage the preview (%s)" % (TEN, e))
        return _anh_tu_mang(TEN_ANH_KQ, a)
    finally:
        bang_mau.tra_cai_dat_anh(ims, cu)

    img = bpy.data.images.get(TEN_ANH_KQ)
    if img is not None and img.source != 'FILE':
        # ⛔ NHO CAC KHUNG DANG XEM ANH NAY TRUOC KHI XOA. Xoa mot datablock
        # anh thi Blender dat `space.image = None` cho moi khung dang tro vao
        # no: cua so VFB dang mo bong trong tron, mat luon tab "DP Optimize"
        # (vi `poll` so theo ten anh), va lan sau `mo_cua_so` khong thay anh
        # dau nen MO THEM mot cua so nua.
        cho_xem = [sp for sp in _cac_khung_dang_xem(img)]
        bpy.data.images.remove(img)
        img = None
    else:
        cho_xem = []
    if img is None:
        img = bpy.data.images.load(duong, check_existing=False)
        img.name = TEN_ANH_KQ
        for sp in cho_xem:
            try:
                sp.image = img
            except Exception:                                # noqa: BLE001
                pass
    else:
        img.filepath = duong
        img.reload()
    # File da o KHONG GIAN MAN HINH roi, nen phai bao dung the — bao sai la
    # Blender bien doi them mot lan nua.
    for ten in (getattr(scene.display_settings, "display_device", ""), 'sRGB'):
        try:
            img.colorspace_settings.name = ten
            break
        except Exception:                                    # noqa: BLE001
            continue
    return img


def _duong_kho(ten_cam, thu_muc):
    """File EXR cua mot camera trong kho."""
    # ⛔ Ten camera phan biet hoa thuong, TEN FILE tren Windows/macOS THI
    # KHONG. "Camera" va "camera" la hai camera khac nhau trong Blender nhung
    # se dung chung mot file — cai sau de len cai truoc. Dan them may chu cua
    # ma bam de hai ten khac nhau chac chan ra hai file khac nhau.
    sach = "".join(c if (c.isalnum() or c in "-_") else "_" for c in ten_cam)
    dau = hashlib.sha1(ten_cam.encode("utf-8")).hexdigest()[:8]
    return os.path.join(thu_muc,
                        _ten_nang("dpopt_vfb_%s_%s" % (sach[:40], dau),
                                  duoi=".npy"))


def cat_vao_kho(ten_cam, a, thu_muc):
    """Cat ket qua cua mot camera ra dia de xem lai sau."""
    if a is None or not ten_cam:
        return
    duong = _duong_kho(ten_cam, thu_muc)
    try:
        # ⛔ GHI THANG MANG NUA DO CHINH XAC, KHONG QUA EXR (21/09/2026).
        # `Image.use_half_precision` + `save()` KHONG ra EXR nua do chinh xac:
        # do anh 2625x3500 ra 140 MB, 4000x3000 ra 183 MB — dung co 32 bit, tran
        # kho 3 GB chi giu 16-20 camera trong khi Ducphan render 20-30 anh mot
        # file. Mang float16 tho: dung 70 / 92 MB, doc lai nhanh hon giai nen
        # EXR. Day chi la ban XEM LAI; ban luu cua batch von lay tu ban float16.
        with open(duong, "wb") as f:
            np.save(f, np.asarray(a, np.float16))
    except Exception as e:                                   # noqa: BLE001
        print("[%s] VFB: cannot keep the image for %s (%s)" % (TEN, ten_cam, e))
        return
    tk = dict(TRANG_THAI)
    try:
        # Bo mau cua camera LUC RENDER: camera bi doi ten / xoa sau do thi
        # VFB van ve dung (`mau_cua_camera`).
        tk['bo_mau_cam'] = mau_cua_camera(bpy.context.scene, ten_cam)
    except Exception:                                        # noqa: BLE001
        pass
    _KHO[ten_cam] = {'exr': duong, 'tk': tk}
    if _BATCH_CHO[0] == ten_cam:
        # Ban 32 bit cua dung luot batch nay — `luu_ket_qua` lay no.
        _MOI_BATCH[ten_cam] = a
    _nho_ram(ten_cam, a)
    _go_bot_kho()


def _doc_kho(duong):
    """Doc mot anh trong kho camera (.npy float16; file cu .exr)."""
    if duong.endswith(".npy"):
        return np.load(duong)
    return _doc_exr(duong)


def lay_tu_kho(ten_cam):
    """Doc lai anh cua mot camera da render."""
    m = _KHO.get(ten_cam)
    if not m:
        return False
    a = _RAM_CAM.get(ten_cam)
    if a is not None:
        _nho_ram(ten_cam, a)             # vua xem -> thanh moi nhat
    elif os.path.isfile(m['exr']):
        a = _doc_kho(m['exr'])
        _nho_ram(ten_cam, a)
    else:
        return False
    dat_anh_goc(a)
    # Chi lay cac khoa CUA TRANG_THAI — `bo_mau_cam` la cua kho, khong tron vao.
    TRANG_THAI.update({k: v for k, v in m['tk'].items() if k in TRANG_THAI})
    TRANG_THAI['dang_chay'] = False
    return True


_NHIP_TAB = [None]      # bo dem gio mo tab, giu lai de con go duoc


def _mo_tab(w):
    """Mo san tab 'DP Optimize' o thanh ben cua VFB.

    ⛔ PHAI TIM LAI VUNG THEO CUA SO, dung giu tham chieu cu: sau
    `screen_full_area()` cua so dung mot MAN HINH TAM khac, vung Image Editor
    la doi tuong MOI (do 20/09/2026: dat len vung cu thi thanh ben mo ra dung
    tab 'Tool').

    ⛔ LAN GOI NGAY LUON HONG, va the la dung. `active_panel_category` chi
    ghi duoc khi vung DA VE mot lan va da co tab that; goi ngay thi Blender
    bao "attribute ... is read-only". Nhip 0,4 giay sau moi la nhip an.
    """
    def dat():
        # ⛔ BOC CA `w.screen`. Cua so bi dong trong 0,4 giay thi `w` la con
        # tro chet va cham vao la ReferenceError — khong ai bat.
        try:
            for area in getattr(w.screen, "areas", ()):
                if area.type != 'IMAGE_EDITOR':
                    continue
                for rg in area.regions:
                    if rg.type == 'UI':
                        rg.active_panel_category = DPOPT_PT_vfb.bl_category
        except Exception:                                    # noqa: BLE001
            pass
        _NHIP_TAB[0] = None
        return None
    # ⛔ GO CAI CU TRUOC KHI CHAY `dat()`. `dat` la mot closure MOI, va
    # dong cuoi cua no dat `_NHIP_TAB[0] = None` — tuc la chay no truoc se
    # xoa mat tham chieu toi closure CU dang con hen, roi `_go_nhip_tab()`
    # nhin thay None nen khong go gi: mot bo dem gio mo coi khong co duong
    # go. Goi `mo_cua_so` hai lan trong 0,4 giay la dinh.
    _go_nhip_tab()
    dat()
    # ⛔ PHAI GIU THAM CHIEU. Ban cu dang ky mot closure vo danh nen KHONG CO
    # DUONG NAO GO: tat addon trong 0,4 giay dau la no van chay, va no cham
    # vao mot lop bang da go dang ky roi.
    _NHIP_TAB[0] = dat
    bpy.app.timers.register(dat, first_interval=0.4)


def _go_nhip_tab():
    """Go bo dem gio mo tab cua lan truoc (neu con)."""
    f = _NHIP_TAB[0]
    _NHIP_TAB[0] = None
    if f is None:
        return
    try:
        if bpy.app.timers.is_registered(f):
            bpy.app.timers.unregister(f)
    except Exception:                                        # noqa: BLE001
        pass


def _go_nhip_phu():
    """Go hai bo dem gio ngan chay mot nhip: mo tab VFB va bat VFB.

    Ca hai tu thao sau mot nhip nen binh thuong khong ai thay. Nhung tat
    addon dung trong khoang 0,05-0,4 giay do thi chung van chay, tren mot
    module da go — nen phai go tay. Chi goi tu `go()`.

    ⛔ `_mo_tab` chi duoc goi `_go_nhip_tab`, KHONG duoc goi ham nay: no co
    the dang chay tu trong chinh `_nhip_bat_vfb`, va go mot bo dem gio dang
    chay la tu cat chan minh.
    """
    _go_nhip_tab()
    # ⛔ `_nhip_mo_vfb` CUNG PHAI O DAY. No duoc dang ky trong `bat_dau`
    # (chot `render_init`), nen tat addon ngay sau khi bam F12 la no van
    # chay tren mot module DA GO.
    for nhip in (_nhip_bat_vfb, _nhip_mo_vfb, _nhip_soi_mau):
        try:
            if bpy.app.timers.is_registered(nhip):
                bpy.app.timers.unregister(nhip)
        except Exception:                                    # noqa: BLE001
            pass


_POLL_CU = {}        # lop bang cua addon khac -> (poll goc, co dang ky lai)
# Tab cua chinh Blender thi giu: chung la mot phan cua khung anh.
_TAB_GIU = {"Tool", "Image", "View", "Scopes", "Annotation", "Node", "Paint",
            "Grease Pencil", "Item", "DP Optimize"}


def _la_cua_so_vfb(context):
    sp = getattr(context, "space_data", None)
    img = getattr(sp, "image", None)
    return img is not None and img.name == TEN_ANH_KQ


def _moi_lop_bang(goc=None):
    goc = goc or bpy.types.Panel
    for c in goc.__subclasses__():
        yield c
        for x in _moi_lop_bang(c):
            yield x


def _dat_poll(cls, poll):
    """Gan lai (hay bo han) `poll` cua mot lop bang."""
    if poll is None:
        if "poll" in cls.__dict__:
            del cls.poll
    else:
        cls.poll = poll


def _boc_poll(cls, cu, ke_thua):
    """Ham `poll` moi: o cua so VFB tra False, moi cho khac giu nguyen.

    ⛔ CAM DUNG THAM SO MAC DINH DE MANG BIEN VAO. Blender DEM so tham so cua
    `poll` luc dang ky va doi DUNG HAI (`cls`, `context`). Mot ham viet kieu
    `def moi(context, _cu=None, _kt=None, _cls=None)` co bon tham so, nen
    `register_class` nem:

        expected Panel, XXX class "poll" function to have 2 args, found 4

    Do that 20/09/2026 tren Blender 5.2: vi loi do ma ca bang cua addon kia
    bi GO DANG KY ROI KHONG BAO GIO DANG KY LAI — tab cua ho BIEN MAT khoi
    Image Editor cua ca cua so chinh, den luc khoi dong lai Blender moi co
    lai. Muon mang bien vao thi dung BIEN DONG (closure) nhu duoi day.
    """
    def moi(_cls, context):
        try:
            if _la_cua_so_vfb(context):
                return False
        except Exception:                                    # noqa: BLE001
            pass
        try:
            if cu is not None:
                return cu.__func__(cls, context)
            if ke_thua is not None:
                return ke_thua(context)
        except Exception:                                    # noqa: BLE001
            # Poll cua ho no thi GIAU bang di, dung bay no ra.
            return False
        return True
    return classmethod(moi)


def _bang_con(cls):
    """Cac bang CON dang dang ky duoi bang nay, theo thu tu dinh nghia."""
    ten = getattr(cls, "bl_idname", "") or cls.__name__
    ra = []
    for c in _moi_lop_bang():
        if getattr(c, "bl_parent_id", "") == ten \
                and getattr(c, "is_registered", False):
            ra.append(c)
    return ra


def _dang_ky_lai(cls, lui_ve):
    """Dang ky lai mot bang de Blender doc lai ham `poll` cua no.

    ⛔ PHAI GO CAC BANG CON TRUOC. Go dang ky mot bang CHA lam Blender cat
    dut lien ket cha-con: bang con o lai voi cha rong nen khong con duoc ve
    o dau ca — chung bien mat, ke ca sau khi bang cha da dang ky lai. Go con
    truoc, dang ky lai cha, roi dang ky lai con theo DUNG THU TU CU thi lien
    ket duoc noi lai va thu tu trong tab khong doi.

    `lui_ve` la `poll` goc: dang ky lai that bai thi tra poll cu roi dang ky
    lai — THA KHONG GIAU DUOC TAB con hon de bang cua ho bien mat.
    """
    con = _bang_con(cls)
    for c in reversed(con):
        bpy.utils.unregister_class(c)
    bpy.utils.unregister_class(cls)
    try:
        bpy.utils.register_class(cls)
    except Exception:
        _dat_poll(cls, lui_ve)
        bpy.utils.register_class(cls)
        raise
    finally:
        for c in con:
            try:
                bpy.utils.register_class(c)
            except Exception:                                # noqa: BLE001
                pass


def che_tab_la():
    """An tab cua ADDON KHAC khi khung anh dang la cua so DP VFB.

    ⛔ Ducphan 20/09/2026: *"ma sao trong dp vfb lai co dp post ?? ngao a"*.
    DP VFB la mot Image Editor that, nen MOI addon co bang ben o Image Editor
    deu hien tab cua no vao day — nhin nhu VFB di muon do cua nguoi khac.
    Khong sua duoc ma cua addon kia (va cung khong duoc phep), nen chi boc
    them mot lop `poll`: o cua so VFB thi tra ve False, moi cho khac giu
    nguyen. Tat addon thi TRA LAI poll cu — xem `_tra_poll_tab`.

    ⛔ CHI DANG KY LAI KHI BAT BUOC, VA DANG KY LAI CA TAB MOT LUOT. Blender
    chot con duong goi `poll` vao luc dang ky lop: lop nao luc dang ky KHONG
    co `poll` thi gan `cls.poll` sau do khong an gi, phai dang ky lai. Ma
    `register_class` chi biet noi THEM VAO CUOI danh sach bang cua vung. Nen:

      - tab ma MOI bang deu da co `poll` (phan lon addon) -> chi gan de,
        KHONG dang ky lai, thu tu giu nguyen tuyet doi;
      - tab co du mot bang thieu `poll` -> dang ky lai CA TAB theo dung thu
        tu cu, de thu tu cac bang BEN TRONG tab khong doi. Dang ky lai le te
        tung bang thi bang bi dang ky lai nhay xuong duoi bang khong bi dang
        ky lai — do dung la kieu "dao thu tu" ma Ducphan thay.

    ⛔ CHO NAY CON MOT VET KHONG CHUA DUOC: tab nao phai dang ky lai thi no
    nhay xuong CUOI thanh tab va o lai the. Blender 5.2 khong co duong nao
    doc hay dat lai thu tu danh sach bang cua mot vung tu Python (do
    20/09/2026: `bpy.types.Region` khong co danh sach bang, con `bl_order`
    chi sap xep trong MOT tab chu khong sap xep cac tab voi nhau). Dung mat
    thoi gian tim lai.
    """
    # Duyet tren mot ban SAO: vong nay go/dang ky lai lop trong luc chay.
    nhom = {}
    for cls in list(_moi_lop_bang()):
        if getattr(cls, "bl_space_type", "") != 'IMAGE_EDITOR' \
                or getattr(cls, "bl_region_type", "") != 'UI':
            continue
        tab = getattr(cls, "bl_category", "")
        if tab in _TAB_GIU:
            continue
        # ⛔ CHI BOC BANG CO TAB RIENG. Bang con (`bl_parent_id`) an theo cha:
        # giau cha la du.
        if not tab or getattr(cls, "bl_parent_id", ""):
            continue
        mod = getattr(cls, "__module__", "") or ""
        if mod.startswith("bl_ui") or mod.startswith(__package__ or "dp_"):
            continue
        if cls in _POLL_CU or not getattr(cls, "is_registered", False):
            continue
        # ⛔ `cls.__dict__` BO SOT poll KE THUA. Rat nhieu addon viet mot lop
        # nen co `poll` roi cho cac bang ke thua; lay theo `__dict__` thi ra
        # None, va wrapper se luon tra True — bang cua ho hien ra ca trong
        # nhung truong hop chinh ho da chan.
        cu = cls.__dict__.get("poll", None)
        ke_thua = getattr(cls, "poll", None) if cu is None else None
        nhom.setdefault(tab, []).append((cls, cu, ke_thua))

    for tab, ds in nhom.items():
        # Luc dang ky lop, Blender chi cai duong goi `poll` neu lop CO `poll`
        # (ke ca ke thua). Ca tab deu co san thi gan de la xong.
        du_poll = all(cu is not None or kt is not None for _c, cu, kt in ds)
        for cls, cu, kt in ds:
            _dat_poll(cls, _boc_poll(cls, cu, kt))
        if du_poll:
            for cls, cu, _kt in ds:
                _POLL_CU[cls] = (cu, False)
            continue
        for cls, cu, _kt in ds:
            try:
                _dang_ky_lai(cls, cu)
            except Exception as e:                           # noqa: BLE001
                _dat_poll(cls, cu)
                print("[%s] cannot hide the '%s' tab (%s)" % (TEN, tab, e))
                continue
            _POLL_CU[cls] = (cu, True)


def _tra_poll_tab():
    """Tra lai `poll` cu. `_POLL_CU` giu dung thu tu da boc, nen dang ky lai
    theo thu tu do la cac bang trong mot tab ve dung cho cu cua chung."""
    for cls, (cu, phai_dang_ky_lai) in list(_POLL_CU.items()):
        try:
            _dat_poll(cls, cu)
            if phai_dang_ky_lai:
                _dang_ky_lai(cls, cu)
        except Exception:                                    # noqa: BLE001
            pass
    _POLL_CU.clear()


def mo_cua_so(context, img=None):
    """Mo cua so VFB (Image Editor tro vao anh cua DP). 0 = da mo san."""
    img = img or anh_ket_qua()
    wm = context.window_manager
    # ⛔ CHI MOT CUA SO VFB, MOT LAN (Ducphan 20/09/2026: *"chi mo 1 DP VFB 1
    # lan thoi"*). Hai cai bay tung lam no mo them:
    #   1. Anh ket qua BI THAY BANG MOT DATABLOCK KHAC moi lan ve lai (ban giu
    #      cho la anh sinh ra, ban that la anh doc tu file da qua bo mau). So
    #      bang `is` thi lan sau khong nhan ra cua so dang mo.
    #   2. Man hinh cua cua so VFB DUOC LUU VAO FILE. Mo lai file la co mot
    #      cua so anh RONG — khong anh, khong bang, khong nut — va Ducphan
    #      nhin dung vao no roi bao khong co chuc nang gi.
    # Nen: danh dau man hinh, va nhan dang theo TEN anh.
    for w in wm.windows:
        try:
            co_dau = DAU_VFB in w.screen.keys()
        except Exception:                                    # noqa: BLE001
            co_dau = False
        vung = list(getattr(w.screen, "areas", ()))
        for area in vung:
            if area.type != 'IMAGE_EDITOR':
                continue
            cu_anh = area.spaces.active.image
            quen = cu_anh is not None and cu_anh.name == TEN_ANH_KQ
            # Cua so VFB cua mot BAN CU (luu truoc khi co dau) hien ra sau
            # khi mo file duoi dang MOT cua so chi co dung mot khung anh va
            # KHONG co anh nao trong do. Do la cai Ducphan goi la *"van co 1
            # cua so render mac dinh hien ra"* — no rong, nen nhin nhu cua so
            # Render chua render gi. Nhan lay no ma dung lai.
            # Cua so Render cua chinh Blender thi luon dang tro vao
            # `Render Result`, nen khong bi nham.
            bo_roi = len(vung) == 1 and cu_anh is None
            if co_dau or quen or bo_roi:
                try:
                    w.screen[DAU_VFB] = 1
                except Exception:                            # noqa: BLE001
                    pass
                if img is not None and cu_anh is not img:
                    area.spaces.active.image = img
                _mo_tab(w)
                return 0
    truoc = set(wm.windows)
    try:
        # `window_new` mo CUA SO CON — khong co thanh workspace, khong co
        # thanh scene/view layer, khong co status bar: gon dung nhu cua so
        # Render cua Blender (Ducphan 20/09/2026: *"tao muon VFB hien thi gon
        # gang nhu cua so render cua blender"*). `window_new_main` thi be
        # nguyen ca cua so chinh sang, rat roi.
        bpy.ops.wm.window_new()
    except Exception as e:                                   # noqa: BLE001
        print("[%s] cannot open the DP render window (%s)" % (TEN, e))
        return 0
    moi = [w for w in wm.windows if w not in truoc]
    if not moi:
        return 0
    w = moi[-1]
    areas = sorted(getattr(w.screen, "areas", ()),
                   key=lambda a: a.width * a.height, reverse=True)
    if not areas:
        return 0
    area = areas[0]
    area.type = 'IMAGE_EDITOR'
    sp = area.spaces.active
    if img is not None:
        sp.image = img
    # Thanh ben BEN TRONG VFB thi CO — do la cho chinh nhanh. Cai Ducphan
    # khong muon la them N-panel o cua so chinh.
    sp.show_region_ui = True
    # Bo thanh cong cu va o hien lenh vua chay: VFB chi can khung anh, thanh
    # dau va thanh ben.
    for o, v in (("show_region_toolbar", False), ("show_region_hud", False)):
        try:
            setattr(sp, o, v)
        except Exception:                                    # noqa: BLE001
            pass
    if len(getattr(w.screen, "areas", ())) > 1:
        try:
            with bpy.context.temp_override(window=w, screen=w.screen,
                                           area=area):
                bpy.ops.screen.screen_full_area()
        except Exception as e:                               # noqa: BLE001
            print("[%s] cannot maximise the DP window (%s)" % (TEN, e))
    try:
        w.screen[DAU_VFB] = 1
    except Exception:                                        # noqa: BLE001
        pass
    che_tab_la()
    _mo_tab(w)
    return 1


def doi_khung_render_result(img):
    """Moi khung anh dang xem 'Render Result' -> chuyen sang anh cua DP.

    ⛔ CHO NAY LA CHO NGUOI DUNG BI LUA. Cac luot render vung kinh DE LEN
    `Render Result`, nen cua so Render cua Blender (neu dang mo) ket thuc bang
    MOT MAU KINH — trong nhu anh bi chay sang va sai mau (Ducphan 20/09/2026:
    *"the deo nao render ra van sai mau voi chay loan len the kia"*, kem anh
    chup cua so Render dang hien dung mot mang tu kinh). Ket qua that thi nam
    o anh cua DP. Nen xong viec la day anh that vao het cac khung do.
    """
    if img is None:
        return 0
    n = 0
    for w in getattr(bpy.context.window_manager, "windows", ()):
        for area in getattr(w.screen, "areas", ()):
            if area.type != 'IMAGE_EDITOR':
                continue
            sp = area.spaces.active
            cu = getattr(sp, "image", None)
            if cu is not None and cu.type == 'RENDER_RESULT':
                sp.image = img
                n += 1
    return n


def _dong_gio(giay):
    giay = float(giay or 0.0)
    if giay < 60:
        return "%.1f s" % giay
    return "%d min %02d s" % (int(giay // 60), int(giay % 60))


def _ve_ten(self, context):
    """Ten cua so, dat o DAU thanh — cho ma Blender ghi 'Image Editor'.

    ⛔ Thanh tieu de cua cua so la cua HE DIEU HANH: Blender dat no mot lan
    luc mo cua so va khong mo cho Python doi (Ducphan 20/09/2026: *"tren cua
    so vfb doi ten Image Editor thanh Dp-VFB render"*). Cho doi duoc, va cung
    la cho mat nhin vao, la day.
    """
    sp = context.space_data
    img = getattr(sp, "image", None)
    if img is None or img.name != TEN_ANH_KQ:
        return
    self.layout.label(text="DP-VFB Render", icon='RENDER_RESULT')


def _ve_dau(self, context):
    """Thanh thong tin tren DAU cua so anh — chi hien khi dang xem anh cua DP.

    ⛔ Thanh nay CHI CO MOT HANG: viet dai la bi cat cut o mep phai, va cai bi
    cat dau tien la cai nam cuoi (do 20/09/2026: nut Render bien mat).
    """
    sp = context.space_data
    img = getattr(sp, "image", None)
    if img is None or img.name != TEN_ANH_KQ:
        return
    t = TRANG_THAI
    lo = self.layout
    lo.separator_spacer()
    if t['dang_chay']:
        lo.label(text=t['buoc'] or "Working…", icon='TIME')
        lo.label(text="Esc to stop")
        return
    lo.operator("dpopt.render_glass_boost", text="Render", icon='RENDER_STILL')
    if not t['camera']:
        lo.label(text="DP Optimize", icon='RENDER_STILL')
        return
    lo.label(text=t['camera'], icon='CAMERA_DATA')
    lo.label(text="%d x %d" % (t['rong'], t['cao']), icon='IMAGE_DATA')
    lo.label(text="%d → %d" % (t['mau'], t['mau_kinh']), icon='SHADERFX')
    if t['so_vung']:
        lo.label(text="%d glass %.0f%%" % (t['so_vung'], 100 * t['dien_tich']),
                 icon='SELECT_SET')
    lo.label(text=_dong_gio(t['giay']), icon='TIME')


class DPOPT_OT_render_window(bpy.types.Operator):
    """Open the DP VFB window without rendering.

    A window of its own, so what DP-Optimize renders is not overwritten by
    Blender's own render result. Shows the last DP render; if there is none
    yet it opens empty and waits for one
    """
    bl_idname = "dpopt.render_window"
    bl_label = "Open DP VFB"
    bl_options = {'REGISTER'}

    def execute(self, context):
        img = anh_ket_qua()
        if img is None:
            r = context.scene.render
            img = _anh_tu_mang(TEN_ANH_KQ,
                               np.zeros((max(1, r.resolution_y // 8),
                                         max(1, r.resolution_x // 8), 4),
                                        np.float32))
        if not mo_cua_so(context, img):
            self.report({'INFO'}, "The DP render window is already open")
        return {'FINISHED'}


# ============================================ CHINH NHANH NGAY TREN ANH (VFB)
#
# ⛔ KHONG chay lai compositor cho may viec nay: compositor chi chay trong mot
# lan render, ma mot lan render lai de len `Render Result`. Tinh thang bang
# numpy tren mang anh GOC giu trong bo nho; anh GOC khong bao gio bi sua.

# ⛔ MOI LAN KEO THANH TRUOT LA MOT LAN TINH LAI CA ANH — VA NO PHAI NHANH.
# Do 20/09/2026 tren anh 4000x2250 o ban dau tien: lam net 0,77 s, bloom
# 0,55 s, bloom + glare 0,91 s MOI LAN. Keo thanh truot thanh ra giat cuc
# (Ducphan: *"toc do xu ly cua cai nay qua cham va lag, ket qua cung khong
# duoc dep"*). Ba cho an het thi gio, va ca ba deu tranh duoc:
#   1. `a[:, :, :3]` la KHUNG NHIN CACH QUANG. numpy cham han khi tinh tren
#      no. Giu ba kenh mau thanh mot mang LIEN TUC rieng, alpha de rieng.
#   2. Tinh lai tu dau nhung thu KHONG DOI theo thanh truot. Anh hieu de lam
#      net va lop quang sang khong phu thuoc DO MANH — tinh mot lan roi nhan
#      voi con so la xong.
#   3. Lam mo / phong to o anh thu nho: lop quang sang giu o kich thuoc nho,
#      chi phong to MOT lan sau khi da tron bloom voi glare.
_RGB = None          # ba kenh mau cua anh dang xem, LIEN TUC (H,W,3)
_ALP = None          # kenh alpha (H,W,1)
_CAN_VE = False
_CM_CU = None        # dau nhan cai dat mau cua lan ve gan nhat


def dat_anh_goc(a):
    global _RGB, _ALP
    if a is None:
        _RGB = _ALP = None
        gpu_vfb.quen()
        return
    b = np.asarray(a, np.float32)
    _RGB = np.ascontiguousarray(b[:, :, :3])
    _ALP = (np.ascontiguousarray(b[:, :, 3:4]) if b.shape[2] > 3
            else np.ones(b.shape[:2] + (1,), np.float32))
    _bat_soi_mau()
    # Day len card MOT LAN cho moi anh moi — keo thanh truot thi khong day
    # lai nua. Khong co card thi thoi, ben duoi tu tinh bang bo xu ly.
    try:
        gpu_vfb.dat_nguon(np.concatenate((_RGB, _ALP), axis=2))
    except Exception:                                        # noqa: BLE001
        pass


def co_anh_goc():
    return _RGB is not None


# ⛔ DA CHUYEN DI. Cac phep lam mo / quang sang / lam net truoc o day nay
# nam o `hieu_ung_cpu.py` (ban chay tren bo xu ly) va `gpu_vfb.py` (ban
# chay tren card). Hai ban do dung CUNG MOT thuat toan va cung hang so
# nen may co card va may khong co card ra cung mot anh; giu them mot ban
# thu ba o day la chac chan co ngay ba ban le nhau.


def hieu_ung(st):
    """Ap exposure / bloom / glare / sharpen len anh goc, tra ve HxWx4.

    Thu CARD truoc, khong duoc thi tinh bang bo xu ly. HAI BEN CHAY CUNG MOT
    THUAT TOAN va cung hang so (do 20/09/2026: lech trung binh 0,000% voi
    exposure / sharpen / bloom, 0,0009% voi glare) — nho vay may co card va
    may khong co card cho ra cung mot anh, va cai luu ra file bang y cai dang
    nhin tren cua so.

    Thu tu: exposure -> (bloom, glare lay nguon tu anh DA nhan exposure) ->
    sharpen sau cung. ⛔ Sharpen PHAI di sau, va phai chay tren dai sang da
    nen lai: mot canh giua 0,2 va 5000 (mep den) ma lam net thang tren so
    tuyen tinh thi sinh hut am khong lo — VIEN DEN quanh vat sang.
    """
    if _RGB is None:
        return None
    if gpu_vfb.co_nguon():
        a = gpu_vfb.hieu_ung(st)
        if a is not None:
            return a
    return hieu_ung_cpu.hieu_ung(st, _RGB, _ALP)

_BANG_DAU = [None]    # dau mau cua bang dang nam tren card


def _hien_nhanh(scene):
    """Ve lai bang BANG TRA MAU tren card. True = da ve xong.

    \u26d4 DAY LA DUONG DE VFB MUOT. Duong thuong phai ghi anh ra TIFF roi
    nap lai — do la cach DUY NHAT bat Image Editor ap View Transform cho mot
    anh thuong (xem `hien_ra`) — va rieng khau do ton ~0,21 s tren anh 9,2
    trieu diem, tuc 3-4 luot ve mot giay. Phep doi mau lai la mot ham tu mau
    sang mau, nen nuong no MOT LAN vao bang 33^3 (`bang_mau.py`) roi tra tren
    card: ca luot ve con ~0,05-0,12 s.

    \u26d4 SAI MOT LI LA SAI MAU CA ANH. Nen: khong nuong duoc, khong day
    duoc len card, card ban — deu tra False de goi quay ve duong cu, thay vi
    ve ra mot buc anh sai mau.
    """
    if not gpu_vfb.co_the() or not gpu_vfb.co_nguon():
        return False
    with _DungMauCamera(scene, _camera_dang_xem(scene)):
        bang = bang_mau.lay(scene)
        k = bang_mau.dau(scene)
    if bang is None:
        return False
    if _BANG_DAU[0] != k or not gpu_vfb.co_bang():
        if not gpu_vfb.dat_bang(bang):
            _BANG_DAU[0] = None
            return False
        _BANG_DAU[0] = k
    a = gpu_vfb.hieu_ung(
        scene.dpopt, doi_mau=True, lo=bang_mau.LO,
        nghich=1.0 / (bang_mau.HI - bang_mau.LO))
    if a is None:
        _BANG_DAU[0] = None
        return False
    # ⛔ KHONG GAN LAI THE MAU O DAY. Da thu (21/09/2026): dat
    # `colorspace_settings.name` tren mot Image FLOAT lam Blender DOI LUON
    # noi dung bo dem, va sai so vot tu 26/255 len 127/255. De nguyen the ma
    # `_anh_tu_mang` dat.
    _anh_tu_mang(TEN_ANH_KQ, a)
    return True


# ================================================ KHONG DE ANH VFB VAO FILE
#
# ⛔ ANH CUA VFB LA ANH TAM, KHONG DUOC NAM TRONG FILE CUA KHACH. Do
# 21/09/2026 file `mrnam khachbep.blend`: bat "Automatically Pack Resources"
# (dan dung archviz hay bat), nen moi lan Ctrl+S Blender DONG GOI ca anh xem
# cua VFB — 35 MB TIFF 2625x3500 — tro vao thu muc tam cua mot phien da tat.
# Mo lai la bao *"Unable to pack file… Keeping packed image"* va file phinh
# them moi lan. Nen: go anh cua addon NGAY TRUOC KHI LUU, dung lai ngay sau.
_SAU_LUU = []        # [co anh DP truoc khi luu, *khung anh dang xem no]


def _ten_anh_tam():
    return (TEN_ANH_KQ, TEN_ANH_GOC, "DP_VFB_tam", "DP_VFB_ghi", TEN_ANH,
            bang_mau.TEN_ANH)


def go_anh_truoc_khi_luu():
    """`save_pre`: go moi anh tam cua addon khoi `bpy.data`."""
    _SAU_LUU.clear()
    if TRANG_THAI['dang_chay']:
        # Glass Boost dang doc/ghi may anh nay — dung gio tay. Hiem gap.
        return 0
    img = bpy.data.images.get(TEN_ANH_KQ)
    if img is not None:
        _SAU_LUU.append(True)
        _SAU_LUU.extend(_cac_khung_dang_xem(img))
    n = 0
    for ten in _ten_anh_tam():
        img = bpy.data.images.get(ten)
        if img is None:
            continue
        try:
            bpy.data.images.remove(img)
            n += 1
        except Exception as e:                               # noqa: BLE001
            print("[%s] cannot keep '%s' out of the saved file (%s)"
                  % (TEN, ten, e))
    return n


def dung_lai_sau_khi_luu():
    """`save_post`: dua anh VFB tro lai nhung khung dang xem no."""
    cho = list(_SAU_LUU[1:])
    co = bool(_SAU_LUU)
    _SAU_LUU.clear()
    if not co or _RGB is None:
        return False
    scene = bpy.context.scene
    if not ve_lai(scene):
        return False
    img = anh_ket_qua()
    for sp in cho:
        try:
            sp.image = img
        except Exception:                                    # noqa: BLE001
            pass
    return True


# ======================================== MAU THEO CAMERA CUA DP CAMERA
#
# ⛔ MOI CAMERA MOT BO MAU (21/09/2026). DP Camera giu Exposure / White
# Balance / Tint RIENG cho tung camera (`my_cam_ev`, `my_cam_wb_temp`...) va
# chi day xuong Scene cho camera DANG CHON. Batch dat bo mau cua tung camera
# truoc khi render, nen FILE luu ra dung mau. Con VFB thi ve lai moi anh
# bang bo mau DANG nam tren Scene — file bep: Camera EV 2 / 5000 K hien ra
# bang bo cua Camera.004 (EV 1 / 4800 K), toi va vang hon. Ducphan: *"anh
# hien thi trong vfb sai mau, con anh tu luu ra trong batch render thi dung
# mau"* + *"white balance va tint cung nhu exposure va gamma phai di theo
# thong so trong cam cua dp cam"*. Gamma: DP Camera khong co gamma rieng
# tung camera — dung gamma cua Scene, dung nhu file luu ra.


def _bo_mau_goc(scene):
    """Exposure / White Balance cua SCENE khi khong camera nao day de len."""
    vs = scene.view_settings
    goc = {'exposure': vs.exposure}
    if hasattr(vs, "use_white_balance"):
        goc.update(use_white_balance=vs.use_white_balance,
                   white_balance_temperature=vs.white_balance_temperature,
                   white_balance_tint=vs.white_balance_tint)
    st = _trang_thai_batch_dp_cam()
    if st and st.get('is_rendering'):
        # Batch dang chay: Scene mang bo mau cua camera DANG render.
        if 'orig_exposure' in st:
            goc['exposure'] = st['orig_exposure']
        if 'use_white_balance' in goc and 'orig_use_wb' in st:
            goc.update(use_white_balance=st['orig_use_wb'],
                       white_balance_temperature=st['orig_wb_temp'],
                       white_balance_tint=st['orig_wb_tint'])
        return goc
    if getattr(scene, "my_cam_fc_applied", False):
        # False Color la cong cu SOI cua DP Camera; batch tat no truoc khi
        # render nen file KHONG mang no. `view_transform` PHAI dung truoc
        # `look`: doi transform la Blender dua look ve None.
        goc = dict(view_transform=scene.my_cam_saved_view_transform
                   or 'Standard', look=scene.my_cam_saved_look or 'None',
                   **goc)
    if getattr(scene, "my_cam_ev_applied", False):
        goc['exposure'] = scene.my_cam_saved_exposure
    if 'use_white_balance' in goc and getattr(scene, "my_cam_wb_applied", False):
        goc.update(use_white_balance=scene.my_cam_saved_use_wb,
                   white_balance_temperature=scene.my_cam_saved_wb_temp,
                   white_balance_tint=scene.my_cam_saved_wb_tint)
    return goc


def mau_cua_camera(scene, ten_cam):
    """Bo mau MA FILE CUA CAMERA NAY DUOC LUU BANG (cung luat voi batch cua
    DP Camera). {} = khong co DP Camera / camera la — dung nguyen Scene."""
    cam = scene.objects.get(ten_cam) if ten_cam else None
    if cam is None or cam.type != 'CAMERA' or not hasattr(cam, "my_cam_use_ev"):
        # Camera da doi ten / bi xoa sau khi render: dung bo mau da cat luc
        # render, khong roi ve mau cua Scene hien tai.
        return dict(_KHO.get(ten_cam, {}).get('tk', {}).get('bo_mau_cam') or {})
    kq = _bo_mau_goc(scene)
    if cam.my_cam_use_ev:
        kq['exposure'] = cam.my_cam_ev
    if 'use_white_balance' in kq and getattr(cam, "my_cam_use_wb", False):
        kq.update(use_white_balance=True,
                  white_balance_temperature=cam.my_cam_wb_temp,
                  white_balance_tint=cam.my_cam_wb_tint)
    return kq


def _camera_dang_xem(scene):
    return TRANG_THAI['camera'] or (scene.camera.name if scene.camera else "")


class _DungMauCamera:
    """`with _DungMauCamera(scene, ten):` — tam dat bo mau cua camera `ten`
    len Scene cho MOT lan `save_render`, roi tra lai y nguyen."""

    def __init__(self, scene, ten_cam):
        self.vs = scene.view_settings
        self.moi = mau_cua_camera(scene, ten_cam)
        self.cu = {}

    def __enter__(self):
        for k, v in self.moi.items():
            cu = getattr(self.vs, k)
            if cu != v:
                self.cu[k] = cu
                setattr(self.vs, k, v)
        return self

    def __exit__(self, *a):
        for k, v in self.cu.items():
            try:
                setattr(self.vs, k, v)
            except Exception:                                # noqa: BLE001
                pass
        return False


def ve_lai(scene):
    """Ve lai anh dang xem tu anh GOC + cac thanh truot."""
    global _CM_CU
    if _RGB is None:
        return False
    # ⛔ `ve_lai` LA BAN CHUAN, khong dung bang tra. Bang tra chi dung cho
    # nhung nhip DANG KEO trong `_nhip_ve`; anh cuoi cung ma nguoi dung nhin
    # va luu ra file phai di dung duong da nghiem thu (lech 0,30/255 so voi
    # Render Result, 20/09/2026).
    a = hieu_ung(scene.dpopt)
    if a is None:
        return False
    with _DungMauCamera(scene, _camera_dang_xem(scene)):
        hien_ra(scene, a)
    _CM_CU = _dau_mau(scene)
    _DAU_XIN[0] = None
    return True


def _dau_mau(scene):
    """Dau nhan cua toan bo cai dat mau — doi mot thu la doi dau."""
    v, d = scene.view_settings, scene.display_settings
    cu = v.curve_mapping
    m = mau_cua_camera(scene, _camera_dang_xem(scene))
    return (d.display_device, m.get('view_transform', v.view_transform),
            m.get('look', v.look),
            round(m.get('exposure', v.exposure), 5), round(v.gamma, 5),
            bool(v.use_curve_mapping), cu.white_level[0] if cu else 0.0,
            bool(m.get('use_white_balance',
                       getattr(v, "use_white_balance", False))),
            round(m.get('white_balance_temperature',
                        getattr(v, "white_balance_temperature", 0.0)), 3),
            round(m.get('white_balance_tint',
                        getattr(v, "white_balance_tint", 0.0)), 3))


_DAU_XIN = [None]    # dau mau da xin ve lai, chua ve xong


def theo_doi_mau(scene):
    """Cai dat mau vua doi thi ve lai — goi tu `draw` cua bang VFB.

    Cac o color management la cua Blender, khong gan `update` vao duoc, nen
    phai TU SOI: bang ve lai lien tuc, so dau nhan la biet.
    """
    if _RGB is None:
        return
    d = _dau_mau(scene)
    # ⛔ CHI XIN MOT LAN CHO MOI THAY DOI. Xin lai moi lan soi (4 lan/giay,
    # hay moi lan bang ve) la dat lai moc `_LAN_DOI` lien tuc: `_nhip_ve`
    # tuong nguoi dung con dang keo, ve MAI ban nhanh, khong bao gio toi
    # ban chuan (do 21/09/2026, `tools/thu_mau_camera.py`).
    if d != _CM_CU and d != _DAU_XIN[0]:
        _DAU_XIN[0] = d
        xin_ve_lai()


SOI_MAU = 0.25   # giay giua hai lan soi bo mau khi VFB co anh


def _nhip_soi_mau():
    """Nhip soi: doi o mau cua CAMERA (DP Camera) hay cua Scene thi VFB ve
    lai — KHONG phu thuoc bang VFB co dang duoc ve hay khong.

    ⛔ Do 21/09/2026 (`tools/thu_mau_camera.py`): chi soi trong `draw` thi
    doi `my_cam_ev` cua camera dang xem, 3 s sau VFB van hien EV cu — thanh
    ben khong ve lai nen `theo_doi_mau` khong chay. Chot
    `depsgraph_update_post` cung KHONG no khi doi thuoc tinh do (da thu,
    cung bai do). Ducphan: *"van phai dong bo cac thong so trong cam va
    thong so tren VFB"*. `_dau_mau` chi doc vai so nen soi 4 lan/giay re.
    Het anh (`_RGB` None) thi tu dung; `dat_anh_goc` bat lai.
    """
    if _RGB is None:
        return None
    try:
        if not TRANG_THAI['dang_chay'] and not bpy.app.is_job_running('RENDER'):
            theo_doi_mau(bpy.context.scene)
    except Exception:                                        # noqa: BLE001
        pass
    return SOI_MAU


def _bat_soi_mau():
    try:
        if not bpy.app.timers.is_registered(_nhip_soi_mau):
            bpy.app.timers.register(_nhip_soi_mau, first_interval=SOI_MAU,
                                    persistent=True)
    except Exception:                                        # noqa: BLE001
        pass


NGHI_TRUOC_KHI_VE = 0.30   # doi thanh truot DUNG HAN bao lau roi moi ve
_LAN_DOI = [0.0]           # luc mot o chinh nhanh doi gia tri lan cuoi


def _nhip_ve():
    global _CAN_VE
    if not _CAN_VE:
        return None
    # ⛔ KHONG VE KHI DANG RENDER. Ve lai la muon `view_settings` (bo mau
    # camera) va `image_settings` (TIFF 8 bit) cua Scene; luong render ghi
    # file dung luc do la ra file sai phoi sang / sai dinh dang.
    if TRANG_THAI['dang_chay'] or bpy.app.is_job_running('RENDER'):
        return 0.25
    # ⛔ VE KHI NGUOI DUNG DA BUONG, KHONG VE GIUA CHUNG. Mot luot `ve_lai`
    # o anh 4K ton 0,2-0,4 s, phan lon la khau `save_render` doi mau — day la
    # duong DUY NHAT de Blender ap dung View Transform (xem `hien_ra`). Ban
    # cu hoan 0,12 s roi ve, tuc la NGAN HON chinh cong viec: keo thanh truot
    # la cac luot ve chong len nhau, luong chinh khong con nhip nao de ve
    # giao dien, va Ducphan doc ra la *"phan quick adjusment qua lag luon"*
    # (21/09/2026). Nay doi cho gia tri dung han roi moi ve MOT lan.
    cho = NGHI_TRUOC_KHI_VE - (time.perf_counter() - _LAN_DOI[0])
    if cho > 0.0:
        # ⛔ DANG KEO: VE BAN NHANH, DUNG VE BAN CHUAN. Ban nhanh tra bang
        # mau tren card (0,09 s) thay cho khau ghi TIFF (0,28 s), nen keo
        # thanh truot van thay anh doi theo tay. Sai so cua bang do 21/09/2026
        # tren anh nhieu gat: 1,8/255 trung binh — khong nhin ra luc dang keo,
        # va KHONG CON O ANH CUOI, vi buong tay ra la ve lai bang duong chuan.
        # Nho vay khong phai danh doi mot ti mau nao de lay do muot.
        try:
            _hien_nhanh(bpy.context.scene)
        except Exception as e:                               # noqa: BLE001
            print("[%s] VFB: quick redraw failed (%s)" % (TEN, e))
        return min(cho, 0.1)
    _CAN_VE = False
    try:
        ve_lai(bpy.context.scene)
    except Exception as e:                                   # noqa: BLE001
        print("[%s] VFB: cannot redraw (%s)" % (TEN, e))
    return None


def xin_ve_lai(self=None, context=None):
    """Goi tu `update` cua cac thanh truot. Hoan mot nhip roi moi ve — keo
    thanh truot ban ra hang chuc lan goi mot giay."""
    global _CAN_VE
    if _RGB is None:
        return
    _CAN_VE = True
    _LAN_DOI[0] = time.perf_counter()
    if not bpy.app.timers.is_registered(_nhip_ve):
        bpy.app.timers.register(_nhip_ve, first_interval=NGHI_TRUOC_KHI_VE)


class DPOPT_OT_vfb_reset(bpy.types.Operator):
    """Put every quick adjustment back to zero"""
    bl_idname = "dpopt.vfb_reset"
    bl_label = "Reset Adjustments"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        st = context.scene.dpopt
        st.vfb_exposure = 0.0
        st.vfb_sharpen = 0.0
        st.vfb_bloom = 0.0
        st.vfb_glare = 0.0
        xin_ve_lai()
        return {'FINISHED'}


def _duoi(scene):
    """Duoi file theo DUNG dinh dang dau ra ma nguoi dung dang dat."""
    try:
        return scene.render.file_extension or ".png"
    except Exception:                                        # noqa: BLE001
        return ".png"


def _luu_mot(scene, a, duong, ten_cam=None):
    """Ghi mot mang tuyen tinh ra file, THEO DINH DANG CUA NGUOI DUNG.

    ⛔ Dung ep PNG hay TIFF o day. Ducphan 20/09/2026: *"tao dang render png
    ma, phai cho nhan du the loai chu"* — PNG, JPEG, EXR, TIFF, ai dat gi thi
    ra cai do, kem ca do sau mau va bo mau cua ho. Chi can `save_render` voi
    `scene`: no dung nguyen `image_settings` cua ho.
    """
    img = _anh_tu_mang("DP_VFB_ghi", a)
    try:
        # ⛔ KHONG HOI `splitext`: ten camera "Camera.001" co ".001" trong
        # ten, `splitext` tuong la duoi file — batch DP Cam ghi ra file KHONG
        # DUOI (do 21/09/2026). Hoi dung duoi cua dinh dang dang dat.
        if not duong.lower().endswith(_duoi(scene).lower()):
            duong += _duoi(scene)
        with _DungMauCamera(scene, ten_cam or _camera_dang_xem(scene)):
            img.save_render(filepath=duong, scene=scene)
    finally:
        try:
            bpy.data.images.remove(img)
        except Exception:                                    # noqa: BLE001
            pass
    return duong


def dang_render():
    """Dang co job render hay chuoi Glass Boost dang chay.

    ⛔ NUT LUU / DOI CAMERA CUA VFB PHAI CHAN LUC NAY. Chung muon
    `view_settings` (mau rieng camera, `_DungMauCamera`) va `image_settings`
    (TIFF 8 bit, `hien_ra`) cua Scene; luong render doc chinh cac o do de ghi
    file / chay compositor — anh cua lan render dang chay ra sai mau (ra soat
    21/09/2026)."""
    if TRANG_THAI['dang_chay']:
        return True
    try:
        return bool(bpy.app.is_job_running('RENDER'))
    except Exception:                                        # noqa: BLE001
        return False


class DPOPT_OT_vfb_save(bpy.types.Operator):
    """Save the image shown here, with the adjustments applied, in the output
    format this scene is set to"""
    bl_idname = "dpopt.vfb_save"
    bl_label = "Save Image"
    bl_options = {'REGISTER'}
    filepath: bpy.props.StringProperty(subtype='FILE_PATH')

    @classmethod
    def poll(cls, context):
        return not dang_render()

    def invoke(self, context, event):
        sc = context.scene
        goc = bpy.path.abspath(sc.render.filepath or "//")
        ten = (TRANG_THAI['camera'] or "render")
        self.filepath = os.path.join(goc, ten + _duoi(sc)) \
            if goc.endswith(("/", "\\")) else goc + _duoi(sc)
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        # Hop chon file la modal: render co the bat dau trong luc do.
        if dang_render():
            self.report({'WARNING'}, "Wait for the render to finish")
            return {'CANCELLED'}
        a = hieu_ung(context.scene.dpopt)
        if a is None:
            self.report({'ERROR'}, "Nothing rendered yet")
            return {'CANCELLED'}
        try:
            d = _luu_mot(context.scene, a, self.filepath)
        except Exception as e:                               # noqa: BLE001
            self.report({'ERROR'}, "Cannot save: %s" % e)
            return {'CANCELLED'}
        self.report({'INFO'}, "Saved %s" % d)
        return {'FINISHED'}


class DPOPT_OT_vfb_save_all(bpy.types.Operator):
    """Save every camera rendered in this session into one folder, in the
    output format this scene is set to"""
    bl_idname = "dpopt.vfb_save_all"
    bl_label = "Save All Images"
    bl_options = {'REGISTER'}
    directory: bpy.props.StringProperty(subtype='DIR_PATH')

    @classmethod
    def poll(cls, context):
        return bool(_KHO) and not dang_render()

    def invoke(self, context, event):
        self.directory = bpy.path.abspath(context.scene.render.filepath
                                          or "//")
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        if dang_render():
            self.report({'WARNING'}, "Wait for the render to finish")
            return {'CANCELLED'}
        sc = context.scene
        thu = bpy.path.abspath(self.directory)
        try:
            os.makedirs(thu, exist_ok=True)
        except Exception as e:                               # noqa: BLE001
            self.report({'ERROR'}, "Cannot use that folder: %s" % e)
            return {'CANCELLED'}
        # Nho anh DANG xem de tra lai — luu ca loat khong duoc lam doi cai
        # nguoi dung dang nhin.
        dang_xem = TRANG_THAI['camera']
        giu = None if _RGB is None else np.concatenate((_RGB, _ALP), axis=2)
        xong, hong = 0, []
        for ten in sorted(_KHO):
            m = _KHO[ten]
            if not os.path.isfile(m['exr']):
                hong.append(ten)
                continue
            try:
                dat_anh_goc(_doc_kho(m['exr']))
                a = hieu_ung(sc.dpopt)
                sach = "".join(c if (c.isalnum() or c in "-_") else "_"
                               for c in ten)
                _luu_mot(sc, a, os.path.join(thu, sach + _duoi(sc)), ten)
                xong += 1
            except Exception as e:                           # noqa: BLE001
                print("[%s] VFB: cannot save %s (%s)" % (TEN, ten, e))
                hong.append(ten)
        if dang_xem and dang_xem in _KHO:
            lay_tu_kho(dang_xem)
            ve_lai(sc)
        elif giu is not None:
            # Anh dang xem khong nam trong kho (lan cat vao kho that bai) —
            # tra lai tu ban da giu, khong de anh nhay sang camera khac o lan
            # keo thanh truot ke tiep.
            dat_anh_goc(giu)
            TRANG_THAI['camera'] = dang_xem
            ve_lai(sc)
        if hong:
            self.report({'WARNING'}, "Saved %d, could not save: %s"
                        % (xong, ", ".join(hong)))
        else:
            self.report({'INFO'}, "Saved %d image(s) to %s" % (xong, thu))
        return {'FINISHED'}


class DPOPT_OT_vfb_camera(bpy.types.Operator):
    """Show the image already rendered from this camera"""
    bl_idname = "dpopt.vfb_camera"
    bl_label = "Show Camera"
    bl_options = {'REGISTER'}
    camera: bpy.props.StringProperty()

    @classmethod
    def poll(cls, context):
        # Dang chay ma doi anh thi `lay_tu_kho` ep `dang_chay = False`, va
        # luot render cuoi ket thuc se hen Glass Boost chay LAI tu dau.
        # Job render thuong: xem `dang_render`.
        return not dang_render()

    def execute(self, context):
        if not lay_tu_kho(self.camera):
            self.report({'WARNING'}, "That image is no longer on disk")
            return {'CANCELLED'}
        # ⛔ DOI CAMERA VE BAN NHANH TRUOC (nhu luc keo thanh truot). Do
        # 21/09/2026 o anh 4000x3000: ve ban chuan ngay ton ~0,5 s moi lan bam.
        # Ban nhanh (bang tra mau tren card) hien anh ngay; dung tay
        # `NGHI_TRUOC_KHI_VE` thi `_nhip_ve` ve lai bang duong chuan — anh
        # cuoi va anh luu ra van dung tung byte nhu truoc.
        try:
            nhanh = _hien_nhanh(context.scene)
        except Exception:                                    # noqa: BLE001
            nhanh = False
        if nhanh:
            xin_ve_lai()
        else:
            ve_lai(context.scene)
        mo_cua_so(context, anh_ket_qua())
        return {'FINISHED'}


class DPOPT_PT_vfb(bpy.types.Panel):
    bl_label = "DP Optimize"
    bl_space_type = 'IMAGE_EDITOR'
    bl_region_type = 'UI'
    bl_category = "DP Optimize"

    @classmethod
    def poll(cls, context):
        img = getattr(context.space_data, "image", None)
        if img is None:
            return False
        if img.name == TEN_ANH_KQ:
            return True
        # Trong luc render, cua so VFB tro vao `Render Result` (xem
        # `hien_anh_dang_render`). Khong nhan ca truong hop nay thi thanh
        # ben cua VFB BIEN MAT suot lan render, roi hien lai luc xong —
        # nhin nhu addon vua hong xong lai lanh.
        # ⛔ Nhan theo DAU CUA SO, khong nhan moi khung anh dang xem
        # `Render Result`: bang cua DP khong duoc moc vao cua so anh cua
        # nguoi dung.
        try:
            return (img.type == 'RENDER_RESULT'
                    and DAU_VFB in context.screen.keys())
        except Exception:                                    # noqa: BLE001
            return False

    def draw(self, context):
        t = TRANG_THAI
        lo = self.layout
        if t['dang_chay']:
            # ⛔ PHAI DUNG O DAY. Ve tiep la bay ra nut "Render with Glass
            # Boost" va ca danh sach camera ngay giua luot chay — bam vao la
            # chong hai lenh len nhau.
            lo.label(text=t['buoc'] or "Working…", icon='TIME')
            lo.label(text="Esc in the main window stops it.")
            return
        box = lo.box()
        if t['camera']:
            box.label(text="Camera: %s" % t['camera'], icon='CAMERA_DATA')
            box.label(text="Image: %d x %d px" % (t['rong'], t['cao']),
                      icon='IMAGE_DATA')
            box.label(text="Samples: %d, glass %d" % (t['mau'], t['mau_kinh']),
                      icon='SHADERFX')
            if t['so_vung']:
                box.label(text="Glass areas: %d (%.0f%% of the frame)"
                               % (t['so_vung'], 100 * t['dien_tich']),
                          icon='SELECT_SET')
            box.label(text="Time: %s" % _dong_gio(t['giay']), icon='TIME')
            if t['giay_cuoi'] or t['giay_vung']:
                box.label(text="   frame %s, glass %s"
                               % (_dong_gio(t['giay_cuoi']),
                                  _dong_gio(t['giay_mask'] + t['giay_vung'])))
            if t['thiet_bi']:
                box.label(text=t['thiet_bi'], icon='MEMORY')
        elif bpy.app.is_job_running('RENDER'):
            # Dang chay: khung anh ben canh la `Render Result` hien dan ra.
            box.label(text="Rendering…", icon='TIME')
            box.label(text="Blender is drawing straight into this window.")
        else:
            box.label(text="Nothing rendered yet.", icon='INFO')

        if _KHO:
            box = lo.box()
            box.label(text="Rendered cameras", icon='OUTLINER_OB_CAMERA')
            col = box.column(align=True)
            for ten in sorted(_KHO):
                row = col.row(align=True)
                row.alert = (ten == t['camera'])
                row.operator("dpopt.vfb_camera", text=ten,
                             icon='RESTRICT_RENDER_OFF').camera = ten

        if _KHO:
            row = box.row(align=True)
            row.operator("dpopt.vfb_save_all", icon='FILE_TICK')

        # MAU: cac o nay la CUA SCENE, khong phai cua addon. De o day de khoi
        # phai chay sang cua so chinh moi doi duoc mot nac phoi sang — va de
        # thay ro VFB dang dung dung bo mau nao.
        sc = context.scene
        theo_doi_mau(sc)
        box = lo.box()
        box.label(text="Color management", icon='COLOR')
        col = box.column(align=True)
        col.prop(sc.display_settings, "display_device", text="Display")
        col.prop(sc.view_settings, "view_transform", text="View")
        col.prop(sc.view_settings, "look", text="Look")
        # ⛔ Camera dang xem co bo mau rieng cua DP Camera thi o Exposure /
        # White Balance o day la CUA CAMERA DO — anh VFB va file luu ra deu
        # dung bo do, chinh o Scene se khong thay gi doi.
        cam = sc.objects.get(_camera_dang_xem(sc) or "")
        cam_ev = cam is not None and getattr(cam, "my_cam_use_ev", False)
        cam_wb = cam is not None and getattr(cam, "my_cam_use_wb", False)
        # ⛔ Dang batch: Scene dang mang bo mau cua camera DANG RENDER —
        # sua o day la sua giua chung mot luot render (ra soat 21/09/2026).
        dang_batch = _batch_dp_cam_dang_chay()
        # Camera khac dang day EV/WB cua no len Scene: so cua Scene luc nay
        # la CUA CAMERA DO; so ma anh nay dung la so DA CAT (`_bo_mau_goc`).
        ev_cat = getattr(sc, "my_cam_ev_applied", False)
        wb_cat = getattr(sc, "my_cam_wb_applied", False)
        col = box.column(align=True)
        col.enabled = not dang_batch
        if cam_ev:
            col.prop(cam, "my_cam_ev", text="Exposure (%s)" % cam.name)
        elif ev_cat:
            col.prop(sc, "my_cam_saved_exposure", text="Exposure (scene)")
        else:
            col.prop(sc.view_settings, "exposure")
        col.prop(sc.view_settings, "gamma")
        if cam_wb:
            col = box.column(align=True)
            col.enabled = not dang_batch
            col.label(text="White Balance (%s)" % cam.name)
            col.prop(cam, "my_cam_wb_temp", text="Temperature")
            col.prop(cam, "my_cam_wb_tint", text="Tint")
        elif wb_cat:
            col = box.column(align=True)
            col.enabled = not dang_batch
            col.prop(sc, "my_cam_saved_use_wb", text="White Balance (scene)")
            sub = col.column(align=True)
            sub.active = sc.my_cam_saved_use_wb
            sub.prop(sc, "my_cam_saved_wb_temp", text="Temperature")
            sub.prop(sc, "my_cam_saved_wb_tint", text="Tint")
        elif hasattr(sc.view_settings, "use_white_balance"):
            col = box.column(align=True)
            col.enabled = not dang_batch
            col.prop(sc.view_settings, "use_white_balance")
            sub = col.column(align=True)
            sub.active = sc.view_settings.use_white_balance
            sub.prop(sc.view_settings, "white_balance_temperature",
                     text="Temperature")
            sub.prop(sc.view_settings, "white_balance_tint", text="Tint")
        box.prop(sc.view_settings, "use_curve_mapping", text="Use Curves")

        st = sc.dpopt
        box = lo.box()
        box.label(text="Quick adjustments", icon='SHADERFX')
        col = box.column(align=True)
        col.prop(st, "vfb_exposure")
        col.prop(st, "vfb_sharpen")
        col.prop(st, "vfb_bloom")
        col.prop(st, "vfb_bloom_threshold")
        col.prop(st, "vfb_glare")
        sub = col.column(align=True)
        sub.active = st.vfb_glare > 0.0
        sub.prop(st, "vfb_glare_blades")
        sub.prop(st, "vfb_glare_angle")
        row = box.row(align=True)
        row.enabled = co_anh_goc()
        row.operator("dpopt.vfb_reset", icon='LOOP_BACK')
        if not co_anh_goc():
            box.label(text="Render once to use these.", icon='INFO')

        col = lo.column(align=True)
        col.operator("dpopt.render_glass_boost", icon='RENDER_STILL')
        col.operator("dpopt.vfb_save", icon='FILE_TICK')


def _ve_menu_render(self, _context):
    """Mot dong trong menu Render, canh "View Render" cua Blender.

    ⛔ DAY LA CUA DUY NHAT MO DUOC DP VFB KHI KHONG RENDER va khi bang
    trong Properties khong hien (bang do chi hien voi Cycles, nen tren EEVEE
    truoc day khong co cua nao mo VFB ca). Ducphan dat 21/09/2026: *"bo sung
    1 nut goi DP VFB khi khong render"*. Khong dung phim tat — keymap goc
    cua Blender khong duoc dung toi.
    """
    self.layout.operator("dpopt.render_window", icon='WINDOW')


# ============================================== CHO BATCH CUA DP CAM GOI VAO
#
# DP Cam (du an Blender-Camerasetting) chay batch tung camera. Bat DP VFB thi
# no goi hai ham nay thay cho `render.render(write_still=True)`:
#   1. `bat_dau_render_batch` — canh co kinh thi Glass Boost (kinh TRUOC, anh
#      day du SAU CUNG, Ducphan chot 21/09/2026), khong thi render thuong.
#   2. `luu_ket_qua` — xong camera thi luu DUNG CAI VFB HIEN: anh da ghep kinh,
#      da ap Quick adjustments, theo dinh dang file cua scene. Ghi thang
#      `Render Result` thi mat phan kinh (luot cuoi cua Glass Boost la anh day
#      du CHUA ghep).
_BATCH_CHO = [""]    # camera batch dang cho anh
_MOI_BATCH = {}      # ten camera -> mang 32 bit cua DUNG luot batch vua xong


def bat_dau_render_batch(context):
    """Bat dau render MOT camera cho batch. Tra ve tap ket qua cua lenh."""
    if TRANG_THAI['dang_chay'] or bpy.app.is_job_running('RENDER'):
        return {'CANCELLED'}
    # ⛔ QUEN ANH CU TRUOC KHI RENDER. Luot nay huy / loi ma `luu_ket_qua`
    # lay anh cung ten camera trong kho la GHI ANH CU vao file cua batch moi,
    # khong mot loi bao (ra soat 21/09/2026).
    _MOI_BATCH.clear()
    _BATCH_CHO[0] = context.scene.camera.name if context.scene.camera else ""
    TRANG_THAI['ket_qua'] = ""
    if not vi_sao_khong(context.scene):
        # `_TU_BATCH`: Glass Boost chan khi batch DP Cam dang chay (`vi_sao_ban`)
        # — tru chinh luot batch goi vao day. Ha co trong `finally`.
        _TU_BATCH[0] = True
        try:
            return bpy.ops.dpopt.render_glass_boost('INVOKE_DEFAULT')
        finally:
            _TU_BATCH[0] = False
    return bpy.ops.render.render('INVOKE_DEFAULT', write_still=False)


def luu_ket_qua(scene, ten_cam, duong):
    """Luu anh VFB cua `ten_cam` ra `duong` (them duoi file neu thieu).
    Tra ve duong da ghi, hay "" neu camera do chua co anh CUA LUOT NAY.

    ⛔ CHI LUU ANH CUA DUNG LUOT VUA RENDER, ban 32 bit. Ban cu lay kho
    (float16, co the la anh cu cung ten): EXR 32 bit ra thuc chat nua do
    chinh xac, diem sang > 65504 thanh inf; luot bi huy thi ghi anh cu.
    """
    a = _MOI_BATCH.pop(ten_cam, None)
    _BATCH_CHO[0] = ""
    if a is None:
        print("[%s] VFB: %s has no finished image in this batch step (%s)"
              % (TEN, ten_cam, TRANG_THAI.get('ket_qua') or "no render"))
        return ""
    dat_anh_goc(a)
    kq = hieu_ung(scene.dpopt)
    if kq is None:
        return ""
    return _luu_mot(scene, kq, duong, ten_cam)


# ================================================== F12 KHI DP VFB DANG BAT
#
# ⛔ NGOAI LE CO CHU DICH CUA LUAT "KHONG DUNG PHIM GOC". Ducphan 21/09/2026:
# *"bat dp vfb len thi chiem f12 cua blender, tat di thi tra lai cho
# blender"*. Ly do: F12 cua Blender render ANH DAY DU TRUOC, nen Glass Boost
# chi con cach chay SAU (them mot luot, Render Result ket thuc bang man
# kinh) — nguoc thu tu Ducphan chot ("kinh truoc, anh day du sau cung").
#
# CACH TRA LAI: phim nam trong keyconfig ADDON (khong sua keymap goc), va
# `poll` chi dung khi o tick DP VFB bat. Tick tat thi `poll` sai, Blender
# bo qua muc nay va chay dung F12 goc — khong phai go/dang ky lai phim.
_PHIM = []           # (keymap, keymap item) de go luc tat addon


class DPOPT_OT_render_f12(bpy.types.Operator):
    """Render with DP VFB: glass areas first, then the full frame.

    Only active while DP VFB is on — otherwise F12 is Blender's own render
    """
    bl_idname = "dpopt.render_f12"
    bl_label = "Render (DP VFB)"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        st = getattr(context.scene, "dpopt", None)
        return bool(st is not None and getattr(st, "vfb_bat", False))

    def invoke(self, context, event):
        if TRANG_THAI['dang_chay'] or bpy.app.is_job_running('RENDER'):
            self.report({'INFO'}, "DP VFB: a render is already running")
            return {'CANCELLED'}
        # ⛔ F12 giua batch DP Cam (khe 0,1 s giua hai camera) chen mot lan
        # render vao batch — chan nhu Glass Boost (ra soat 21/09/2026).
        ly_do = vi_sao_ban()
        if ly_do:
            self.report({'INFO'}, "DP VFB: %s" % ly_do)
            return {'CANCELLED'}
        if not vi_sao_khong(context.scene):
            kq = bpy.ops.dpopt.render_glass_boost('INVOKE_DEFAULT')
        else:
            # Canh khong co kinh / khong phai Cycles: render thuong, DP VFB
            # hien anh dang render dan ra (xem `bat_dau`).
            kq = bpy.ops.render.render('INVOKE_DEFAULT', use_viewport=True)
        return {'FINISHED'} if kq & {'RUNNING_MODAL', 'FINISHED'} else {'CANCELLED'}


def _gan_phim():
    """Gan F12 vao keyconfig ADDON. Chay nen thi khong co keyconfig — bo qua."""
    kc = getattr(bpy.context.window_manager.keyconfigs, "addon", None)
    if kc is None or _PHIM:
        return len(_PHIM)
    km = kc.keymaps.new(name="Screen", space_type='EMPTY')
    kmi = km.keymap_items.new(DPOPT_OT_render_f12.bl_idname, 'F12', 'PRESS')
    _PHIM.append((km, kmi))
    return len(_PHIM)


def _go_phim():
    for km, kmi in _PHIM:
        try:
            km.keymap_items.remove(kmi)
        except Exception:                                    # noqa: BLE001
            pass
    _PHIM.clear()


CLASSES = (DPOPT_OT_render_f12, DPOPT_OT_render_glass_boost, DPOPT_OT_render_window,
           DPOPT_OT_vfb_reset, DPOPT_OT_vfb_save, DPOPT_OT_vfb_save_all,
           DPOPT_OT_vfb_camera, DPOPT_PT_vfb)


def chuan_bi_canh(canh):
    """Viec theo tung Scene: tra lai cai dat bi muon do dang, roi ap lai tac
    dung cua o tick DP VFB.

    ⛔ CHI GOI KHI `bpy.data` DA MO. Luc Blender khoi dong no con la
    `_RestrictData`. Cho goi that su la `__init__._prepare` — cho duy nhat
    da co duong lui va bo dem gio thu lai cho den khi du lieu mo xong.
    """
    # File dang mo san co the con mang khoa "dang muon" tu mot lan chay chet
    # giua chung — tra lai ngay, dung doi den lan mo file sau.
    for sc in canh:
        # ⛔ `try` PHAI NAM TRONG VONG LAP. Boc ca vong thi scene dau tien
        # hong la nhung scene CON LAI khong bao gio duoc tra cai dat, va im
        # lang — dung cai ma ham nay sinh ra de tranh.
        try:
            tra_lai_cai_dat(sc)
        except Exception as e:                               # noqa: BLE001
            print("[%s] cannot put back the borrowed settings of scene '%s' "
                  "(%s)" % (TEN, sc.name, e))
    # O tick DP VFB nam trong file dang mo — ap lai tac dung cua no.
    co_bat = False
    for sc in canh:
        try:
            co_bat = dong_bo_tick(sc) or co_bat
        except Exception as e:                               # noqa: BLE001
            print("[%s] cannot apply the DP VFB tick of scene '%s' (%s)"
                  % (TEN, sc.name, e))
    # ⛔ KHONG MOT SCENE NAO BAT THI PHAI TRA LAI KIEU HIEN ANH RENDER.
    # `dong_bo_tick` chi biet BAT, no `return False` ngay khi tick tat — nen
    # mo mot file KHAC (tick tat) sau khi da bat VFB o file truoc thi
    # `render_display_type` nam lai o 'NONE': bam F12 o file moi khong thay
    # gi ca, ma khong mot dong nao noi vi sao.
    if not co_bat:
        tra_lai_cua_so_render()


def dang_ky():
    """Bat addon: dang ky lop + thanh dau, roi moi den viec cua dia.

    ⛔ KHONG CHAM `bpy.data` TRONG HAM NAY. Addon bat san trong
    Preferences thi `register()` chay NGAY LUC BLENDER KHOI DONG, luc do
    `bpy.data` moi la `_RestrictData`:

        '_RestrictData' object has no attribute 'scenes'

    Ban truoc duyet `bpy.data.scenes` ngay dau ham. Loi nem ra tai chinh
    dong `for` — NGOAI moi `try` ben trong — nen ca `register()` chet theo
    va ADDON KHONG BAT DUOC: khong mot lop nao, khong bang DP VFB, khong
    chot render. Dung cai Ducphan gap 20-21/09/2026: bat tick DP VFB ma luc
    render khong co gi hien ra. Viec theo Scene nay nam o `chuan_bi_canh`,
    do `__init__._prepare` goi khi du lieu da mo.
    """
    for c in CLASSES:
        try:
            # ⛔ DON LOP CU CUNG TEN TRUOC (nhu `__init__._register_class`).
            # Tat-bat lai addon la nap lai module: lop moi la doi tuong moi,
            # lop cu van dang ky duoi cung ten, va `register_class` bao
            # "already registered" — bang DP VFB mat, chi con mot dong log.
            cu = getattr(bpy.types, c.__name__, None)
            if cu is not None and cu is not c:
                try:
                    bpy.utils.unregister_class(cu)
                except Exception:                            # noqa: BLE001
                    pass
            bpy.utils.register_class(c)
        except Exception as e:                               # noqa: BLE001
            # ⛔ DUNG NUOT. Nuot thi nut bien mat ma khong mot dong log nao,
            # va nguoi dung tuong ban cai bi hong.
            print("[%s] cannot register %s (%s)" % (TEN, c.__name__, e))
    # ⛔ MOI MUC MOT `try`. Gop ba lenh vao mot khoi thi hong cai dau la
    # HAI CAI SAU khong bao gio chay — mat luon dong "Open DP VFB" trong
    # menu Render — ma cau bao in ra lai chi noi ve thanh dau.
    # ⛔ VA DUNG NUOT: nuot thi nut bien mat khong mot dong log nao, nguoi
    # dung tuong ban cai bi hong.
    for mo_ta, gan in (
            ("the DP VFB window name", lambda: bpy.types.IMAGE_HT_header
             .prepend(_ve_ten)),
            ("the DP VFB header", lambda: bpy.types.IMAGE_HT_header
             .append(_ve_dau)),
            ("the Render menu entry", lambda: bpy.types.TOPBAR_MT_render
             .append(_ve_menu_render)),
            ("the F12 key for DP VFB", _gan_phim),
    ):
        try:
            gan()
        except Exception as e:                               # noqa: BLE001
            print("[%s] cannot add %s (%s)" % (TEN, mo_ta, e))
    # File khoa + don rac cua nhung ban Blender da chet. Bat buoc phai boc:
    # o dia hong hay bi chan quyen thi cung KHONG duoc chan viec bat addon.
    try:
        _mo_khoa()
        n = don_rac_cu()
        if n:
            print("[%s] cleaned %d leftover file(s) from Blender sessions "
                  "that are no longer running" % (TEN, n))
    except Exception as e:                                   # noqa: BLE001
        print("[%s] cannot sweep the cache folder (%s)" % (TEN, e))


def go():
    global _CAN_VE
    _CAN_VE = False
    if bpy.app.timers.is_registered(_nhip_ve):
        try:
            bpy.app.timers.unregister(_nhip_ve)
        except Exception:                                    # noqa: BLE001
            pass
    _go_nhip_phu()
    _go_chot()
    _go_phim()
    tra_lai_cua_so_render()
    _tra_poll_tab()
    don_tam()
    _dong_khoa()
    for fn in (_ve_ten, _ve_dau):
        try:
            bpy.types.IMAGE_HT_header.remove(fn)
        except Exception:                                    # noqa: BLE001
            pass
    try:
        bpy.types.TOPBAR_MT_render.remove(_ve_menu_render)
    except Exception:                                        # noqa: BLE001
        pass
    for c in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(c)
        except Exception:                                    # noqa: BLE001
            pass
