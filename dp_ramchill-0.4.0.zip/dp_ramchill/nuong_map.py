# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
"""BAKE MAP — ghi ban da thu nho ra FILE MOI roi tro anh sang do.

=========================================================================
VI SAO CO LOP NAY — va no KHAC hoan toan voi lop render (`doi_co.py`)
=========================================================================
Ducphan 12/09/2026: *"phai de nguyen px anh map nhu file goc chu, them
chuc nang bake map vao dp-ramchill la dc r"*. Bo nhap .max giu nguyen co
anh cua file goc; muon nhe thi nguoi dung BAM NUT o day.

`doi_co` chi ha co trong luc render roi tra lai — viewport va RAM luc dung
van giu ca map goc. Bake la duong con lai: ke hoach cua che do dang chon
(Auto hoac Force) duoc GHI RA FILE, va tam anh tro sang file nho. Viewport,
RAM, VRAM deu nhe di, khong can quet lai luc render.

⛔ BON LUAT, deu la cho de hong im lang:

  1. KHONG BAO GIO GHI DE FILE GOC. Ban nho nam trong mot thu muc rieng
     (mac dinh `//DP_RAMchill_maps`), ten mang dau vet cua duong dan goc
     nen hai tam `wood.jpg` o hai thu muc khong the de len nhau. Duong dan
     goc duoc cat vao chinh tam anh (`KHOA_GOC`), va `Restore Original Maps`
     tra no ve nguyen chuoi.

  2. MOI FILE VUA GHI PHAI DOC LAI VA SO TUNG PIXEL truoc khi tam anh duoc
     tro sang no. Do duoc 12/09/2026 tren Blender 5.2: PNG/TIFF 16 bit CO
     KENH ALPHA bi Blender ghi SAI MAU — lech toi 0,50 tren thang 0..1,
     ngay ca khi chi luu lai ma khong thu nho. PNG 8 bit, PNG 16 bit khong
     alpha va EXR thi dung tung pixel. Khong co cua doc lai thi tam anh bi
     doi mau, va nguoi dung khong bao gio doan ra la do nut Bake.

  3. ANH NAO KHONG LAM DUOC THI GIU NGUYEN VA DEM RA BANG — anh lien ket
     tu file khac, file goc mat, file ghi ra khong khop.

  4. ANH PACKED (map nam trong .blend — PN4.blend cua Ducphan co ca 73 tam
     deu packed): goi goc duoc GHI RA DIA dung tung byte truoc khi thay
     ruot, de Restore con cho lay lai. Xem `_nguon_packed`.

MOT TAM MOT LUC: nap ban tam o co goc, thu nho, ghi, doc lai, tha. RAM di
xuong theo tung tam chu khong vot len.
"""

import hashlib
import os

import bpy
import numpy as np

from . import chinh_sach

KHOA_GOC = "dp_ramchill_goc"          # duong dan goc, NGUYEN CHUOI tho
KHOA_CO_GOC = "dp_ramchill_co_goc"    # [w, h] truoc khi bake
KHOA_GOI_GOC = "dp_ramchill_goi_goc"  # anh PACKED: goi goc giu lai tren dia
KHOA_GOI_SHA = "dp_ramchill_goi_sha"  # ... va sha256 cua no
THU_MUC_MAC_DINH = "//DP_RAMchill_maps"

# Cua doc lai: mot buoc cua thang 8 bit. Moi duong dung do duoc 12/09/2026
# lech <= 0,0003 (PNG 16 bit / EXR) hoac 0 (PNG 8 bit); duong hong lech
# 0,29 .. 0,60. Mot buoc 8 bit la muc mat nguoi khong phan biet duoc tren
# man hinh 8 bit — khong phai so chinh theo mau.
DUNG_SAI = 1.0 / 255.0

# DINH DANG BAN BAKE (Ducphan 18/09/2026: "Convert texture to: jpeg, jpg").
# JPG va JPEG la CUNG MOT dinh dang, chi khac duoi file — nguoi dung chon
# duoi nao thi ghi duoi do.
#
# ⛔ JPG KHONG BOT MOT BYTE RAM/VRAM NAO: Blender giai nen ve cung bo dem
# 8 bit nhu PNG (do 12/09/2026). No chi lam nhe FILE tren dia va goi packed
# trong .blend. Bot RAM thi phai giam CO anh. Bang bao cao noi ca hai so
# (RAM va file) de nguoi dung khong doc nham.
DD_GIU = "GIU"        # khong mat du lieu: PNG, EXR giu EXR — nhu truoc
DD_JPG = "JPG"
DD_JPEG = "JPEG"
CHAT_LUONG_MAC_DINH = 90

# Cua doc lai cho JPG. JPG KHONG BAO GIO khop tung pixel, nen cua 1/255 o
# tren se tu choi moi tam. Cai can bat van la loi DOI MAU (duong hong lech
# 0,29 .. 0,60 tren ca tam): nhieu cua JPG xoay quanh 0 nen lech TRUNG BINH
# CO DAU cua tung kenh gan 0, con doi mau thi khong. Them tran lech tuyet
# doi trung binh cho anh bi nat.
# Do 18/09/2026 tren 120 map that (E:/DP_MatPro, E:/DP_Tiles: go, da, gach,
# vai, normal, bump...), Blender 5.2: 256 px chat luong 90 lech mau lon nhat
# 0,75/255, lech TB 9,2/255 (gach 8K); o muc tan cung 64 px chat luong 50
# lech mau 2,8/255, 256 px chat luong 50 lech TB 12,7/255. Cua dat tren
# muc tan cung do; duong hong (dao mau) lech hang tram.
JPG_LECH_KENH = 4.0 / 255.0
JPG_LECH_TB = 20.0 / 255.0

# Nut Bake Selected: "Keep size" = chi doi dinh dang, khong thu nho.
CANH_GIU = 0


def da_nuong(img):
    return KHOA_GOC in img.keys()


def dem_da_nuong():
    return sum(1 for i in bpy.data.images if KHOA_GOC in i.keys())


def _dinh_dang(tam, muon=DD_GIU):
    """Dinh dang cho ban nho: (file_format, duoi).

    Hoi tren ban NAP TAM chu khong hoi tam anh dang song: hoi `is_float`
    cua tam anh dang song la nap ca tam anh goc vao RAM.

    Mac dinh (`DD_GIU`) KHONG MAT DU LIEU: JPG goc cung ra PNG — nen JPG
    them mot doi la mat them chi tiet, trong khi RAM cua tam anh (bo dem
    8 bit) y het nhau. Anh float (EXR / HDR / PNG 16 bit / TIFF 16 bit):
    EXR giu EXR, con lai ra PNG — Blender tu ghi PNG 16 bit tu bo dem float.

    Nguoi dung chon JPG thi ra JPG — TRU anh float: JPG la 8 bit, va bo dem
    float cua Blender la mau TUYEN TINH trong khi JPG doc lai la mau sRGB,
    nen cua doc lai khong so duoc. Anh 16 bit thuong la displacement /
    normal, dung la loai JPG lam hong. Giu khong mat du lieu va dem ra.
    Anh co trong suot thi `nuong_mot` lui ve PNG sau khi doc duoc pixel.
    """
    if tam.is_float:
        if tam.file_format in ("OPEN_EXR", "OPEN_EXR_MULTILAYER", "HDR"):
            return "OPEN_EXR", ".exr"
        return "PNG", ".png"
    if muon == DD_JPG:
        return "JPEG", ".jpg"
    if muon == DD_JPEG:
        return "JPEG", ".jpeg"
    return "PNG", ".png"


def co_theo_canh(w, h, canh):
    """Co moi khi ep canh lon xuong `canh` — giu ti le, KHONG phong to.

    ⛔ KHONG qua san 512 (`chinh_sach.SAN_TUYET_DOI`) — co y. San do chan
    cac che do TU LAP ke hoach cho ca scene. Nut Bake Selected la nguoi
    dung CHI TAY vao tung vat va chon co bang tay — Ducphan 18/09/2026:
    *"co nhung doi tuong rat nho can giam map toi da"*.
    """
    canh = int(canh)
    if canh <= 0 or max(w, h) <= canh:
        return int(w), int(h)
    k = canh / float(max(w, h))
    return max(1, int(round(w * k))), max(1, int(round(h * k)))


def _co_trong_suot(mau, so_kenh, alpha_mode):
    """Anh co pixel nao KHONG dac? JPG khong co kenh alpha."""
    if so_kenh != 4 or alpha_mode == "NONE":
        return False
    return float(mau[3::4].min()) < 1.0 - 0.5 / 255.0


def _sach(ten):
    ten = "".join(c if (c.isalnum() or c in "-_.") else "_" for c in ten)
    return ten[:60] or "map"


def _sha(b):
    return hashlib.sha256(b).hexdigest()


def _ten_file(img, vet_nguon, stem, w, h, duoi):
    # Dau vet om CA mau lan che do alpha: cung mot file goc nhung khai hai
    # colorspace khac nhau thi ra hai bo dem khac nhau.
    vet = hashlib.sha1(("%s|%s|%s" % (vet_nguon,
                                      img.colorspace_settings.name,
                                      img.alpha_mode)).encode("utf-8")
                       ).hexdigest()[:8]
    return "%s_%dx%d_%s%s" % (_sach(stem), w, h, vet, duoi)


def _doc_px(img):
    w, h = img.size
    a = np.empty(w * h * img.channels, dtype=np.float32)
    img.pixels.foreach_get(a)
    return a


def _khop(a, b):
    if a.shape != b.shape:
        return False, float("inf")
    # Anh float co the vuot 1.0 (HDR): so theo ti le khi gia tri lon.
    lech = np.abs(a - b) / np.maximum(1.0, np.abs(a))
    m = float(lech.max()) if lech.size else 0.0
    return m <= DUNG_SAI, m


def _khop_jpg(a, b, so_kenh):
    """Cua doc lai cho ban JPG — xem `JPG_LECH_KENH`. So RGB, bo alpha."""
    if a.shape != b.shape or so_kenh < 3:
        return False, float("inf")
    d = (b - a).reshape(-1, so_kenh)[:, :3]
    if not d.size:
        return True, 0.0
    lech_kenh = float(np.abs(d.mean(axis=0)).max())
    lech_tb = float(np.abs(d).mean())
    return (lech_kenh <= JPG_LECH_KENH and lech_tb <= JPG_LECH_TB,
            max(lech_kenh, lech_tb))


def thu_muc_that(thu_muc):
    """Duong dan tuyet doi cua thu muc bake, hoac None neu chua xac dinh
    duoc (duong dan `//` ma file .blend chua luu)."""
    thu_muc = (thu_muc or THU_MUC_MAC_DINH).strip()
    if thu_muc.startswith("//") and not bpy.data.filepath:
        return None
    return os.path.normpath(bpy.path.abspath(thu_muc))


def _duong(duong, tuong_doi):
    return bpy.path.relpath(duong) if tuong_doi else duong


def _ghi(tam, dich, dinh_dang, chat_luong=CHAT_LUONG_MAC_DINH):
    """Ghi bo dem cua `tam` ra `dich`. Tach rieng de phep do chot nghich
    thay duoc bang mot ham ghi hong."""
    tam.file_format = dinh_dang
    if dinh_dang == "JPEG":
        tam.save(filepath=dich, quality=int(chat_luong), save_copy=True)
    else:
        tam.save(filepath=dich, save_copy=True)


def _nguon_packed(img, thu_muc_abs, tuong_doi):
    """Tam PACKED: GIU LAI goi goc ra dia, dung tung byte, de Restore.

    Sau khi bake, goi packed trong .blend la ban NHO — luu .blend la goi
    goc mat khoi file. Nen truoc khi dung toi, ghi goi goc ra thu muc bake
    (`..._original.<duoi>`) va cat sha256 cua no vao tam anh. Tam da bake
    roi thi goi goc da nam san o do.

    Tra ve (file_goc_tren_dia, (duong_luu, sha) hoac None, vua_tao).
    (None, None, False) neu goi goc khong con nguyen ven. `vua_tao` de
    lan bake bi tu choi don dung file CHINH NO vua ghi — file da co san co
    the dang la goi goc cua mot tam khac mang cung ruot.
    """
    if KHOA_GOI_GOC in img.keys():
        f = bpy.path.abspath(img[KHOA_GOI_GOC])
        if not os.path.isfile(f) or _sha(open(f, "rb").read()) != img.get(
                KHOA_GOI_SHA):
            return None, None, False
        return f, None, False
    B = bytes(img.packed_file.data)
    sha = _sha(B)
    duoi = os.path.splitext(img.filepath)[1] or ".img"
    stem = os.path.splitext(os.path.basename(img.filepath))[0] or img.name
    f = os.path.join(thu_muc_abs, "%s_%s_original%s" % (_sach(stem), sha[:8],
                                                        _sach(duoi)))
    vua_tao = False
    if not (os.path.isfile(f) and _sha(open(f, "rb").read()) == sha):
        with open(f, "wb") as fh:
            fh.write(B)
        vua_tao = True
        if _sha(open(f, "rb").read()) != sha:
            return None, None, False
    return f, (_duong(f, tuong_doi), sha), vua_tao


def _don(f):
    if f is None:
        return
    try:
        os.remove(f)
    except OSError as e:
        print("[DP_RAMchill] khong xoa duoc file:", f, e)


def nuong_mot(img, moi_w, moi_h, thu_muc_abs, tuong_doi, muon=DD_GIU,
              chat_luong=CHAT_LUONG_MAC_DINH, canh=None, dem=None):
    """Bake mot tam. Tra ve (True, duong_dan) hoac (False, ly_do).

    `muon` — dinh dang ban bake (`DD_GIU` / `DD_JPG` / `DD_JPEG`).
    `canh` — khac None thi BO QUA `moi_w, moi_h` va tinh co tu co goc cua
        chinh ban nap tam (`co_theo_canh`): nut Bake Selected khong phai hoi
        `img.size` cua tam anh dang song (hoi la nap ca anh goc vao RAM).
    `dem` — dict dem: cong them `ram_truoc/ram_sau` (byte bo dem anh),
        `dia_truoc/dia_sau` (byte file) va so tam JPG phai lui ve dinh dang
        khong mat du lieu (`jpg_alpha`, `jpg_float`).

    Khong co gi de lam (co da nho hon muc, dinh dang da dung) thi tra
    (False, "da_nho") / (False, "da_la_jpg") — khong ghi file nao.

    Tam DA bake roi ma ke hoach doi co (vi du Force 1024 -> 512) thi bake
    lai TU BAN GOC chu khong tu ban nho: thu nho hai lan la lay mau hai
    lan, va dau `KHOA_GOC` phai luon chi ve ban goc that de Restore tra
    dung cho.

    ⛔ TAM PACKED DI DUONG RIENG, do 12/09/2026:
      * thay ruot bang `img.pack(data=...)` — duong dan giu nguyen chuoi,
        goi doi thanh ban nho, `file_format` tu doi theo ruot;
      * TUYET DOI KHONG `reload()`: reload tren anh packed doc `filepath`
        roi PACK LAI tu dia (LESSONS §11) — file goc con tren dia la ban
        nho bi thay nguoc bang ban goc, im lang. Dung `buffers_free()`.
    """
    packed = img.packed_file is not None
    raw_goc = img[KHOA_GOC] if KHOA_GOC in img.keys() else img.filepath
    goi_moi, vua_tao = None, False
    if packed:
        nguon, goi_moi, vua_tao = _nguon_packed(img, thu_muc_abs, tuong_doi)
        if nguon is None:
            return False, "mat_file"
        vet_nguon = os.path.basename(nguon)
        stem = os.path.splitext(os.path.basename(img.filepath))[0] or img.name
    else:
        nguon = bpy.path.abspath(raw_goc, library=img.library)
        if not os.path.isfile(nguon):
            return False, "mat_file"
        vet_nguon = os.path.normcase(nguon)
        stem = os.path.splitext(os.path.basename(nguon))[0]
    cs = img.colorspace_settings.name
    am = img.alpha_mode
    lai = KHOA_GOC in img.keys()
    ghi_chu = {}
    tam = bpy.data.images.load(nguon, check_existing=False)
    try:
        tam.colorspace_settings.name = cs
        tam.alpha_mode = am
        w0, h0 = tam.size
        if canh is not None:
            moi_w, moi_h = co_theo_canh(w0, h0, canh)
        cung_co = (int(moi_w), int(moi_h)) == (int(w0), int(h0))
        dinh_dang, duoi = _dinh_dang(tam, muon)
        if muon != DD_GIU and dinh_dang != "JPEG":
            ghi_chu["jpg_float"] = 1
        # Khong thu nho, khong doi dinh dang: ghi ra chi la mot ban sao.
        # Tam DA bake thi van lam — no dang tro vao mot ban khac muc nay.
        if cung_co and not lai:
            ly = None
            if dinh_dang != "JPEG":
                ly = "da_nho"
            elif tam.file_format == "JPEG":
                ly = "da_la_jpg"
            if ly:
                _don(nguon if vua_tao else None)
                return False, ly
        tam.scale(moi_w, moi_h)
        mau = _doc_px(tam)
        if dinh_dang == "JPEG" and _co_trong_suot(mau, tam.channels, am):
            dinh_dang, duoi = "PNG", ".png"
            ghi_chu["jpg_alpha"] = 1
            if cung_co and not lai:
                _don(nguon if vua_tao else None)
                return False, "da_nho"
        mat_du_lieu = dinh_dang == "JPEG"
        if mat_du_lieu:
            # chat luong nam trong ten: doi chat luong thi ra file khac,
            # khong de len ban dang co tam anh khac tro vao
            duoi = "_q%d%s" % (int(chat_luong), duoi)
        so_kenh = tam.channels
        ram_truoc = chinh_sach.byte_anh(w0, h0, 4, 4 if tam.is_float else 1)
        ram_sau = chinh_sach.byte_anh(moi_w, moi_h, 4,
                                      4 if tam.is_float else 1)
        dich = os.path.join(thu_muc_abs,
                            _ten_file(img, vet_nguon, stem, moi_w, moi_h,
                                      duoi))
        if os.path.normcase(os.path.abspath(dich)) == os.path.normcase(
                os.path.abspath(nguon)):
            _don(nguon if vua_tao else None)
            return False, "trung_goc"         # luat 1 — day la cho gay hai
        _ghi(tam, dich, dinh_dang, chat_luong=chat_luong)
    finally:
        bpy.data.images.remove(tam)
    if not os.path.isfile(dich):
        _don(nguon if vua_tao else None)
        return False, "khong_ghi_duoc"

    # Luat 2 — doc lai file vua ghi, CUNG colorspace va alpha, so tung pixel
    # (JPG: so lech mau, xem `_khop_jpg`)
    kt = bpy.data.images.load(dich, check_existing=False)
    try:
        kt.colorspace_settings.name = cs
        kt.alpha_mode = am
        if tuple(kt.size) != (moi_w, moi_h):
            ok, lech = False, float("inf")
        elif mat_du_lieu:
            ok, lech = _khop_jpg(mau, _doc_px(kt), so_kenh)
        else:
            ok, lech = _khop(mau, _doc_px(kt))
    finally:
        bpy.data.images.remove(kt)
    del mau
    if not ok:
        _don(dich)
        _don(nguon if vua_tao else None)
        print("[DP_RAMchill] bake bi tu choi (doc lai lech %.4f): %s"
              % (lech, img.name))
        return False, "doc_lai_lech"

    if dem is not None:
        for k, v in ghi_chu.items():
            dem[k] = dem.get(k, 0) + v
        dem["ram_truoc"] = dem.get("ram_truoc", 0) + ram_truoc
        dem["ram_sau"] = dem.get("ram_sau", 0) + ram_sau
        dem["dia_truoc"] = dem.get("dia_truoc", 0) + os.path.getsize(nguon)
        dem["dia_sau"] = dem.get("dia_sau", 0) + os.path.getsize(dich)

    if KHOA_GOC not in img.keys():
        img[KHOA_GOC] = raw_goc
        img[KHOA_CO_GOC] = [int(w0), int(h0)]
        if goi_moi is not None:
            img[KHOA_GOI_GOC], img[KHOA_GOI_SHA] = goi_moi
    if packed:
        du_lieu = open(dich, "rb").read()
        img.pack(data=du_lieu, data_len=len(du_lieu))
        img.colorspace_settings.name = cs
        img.alpha_mode = am
        img.buffers_free()
    else:
        img.filepath = _duong(dich, tuong_doi)
        # Doi filepath co the lam Blender doan lai colorspace theo file moi
        # (vi du EXR). Tra ve dung cai nguoi dung da khai.
        img.colorspace_settings.name = cs
        img.alpha_mode = am
        img.reload()
    return True, dich


def _mo_thu_muc(thu_muc):
    thu_muc_abs = thu_muc_that(thu_muc)
    if thu_muc_abs is None:
        raise ValueError("save the .blend first, or pick an absolute folder")
    tuong_doi = (thu_muc or THU_MUC_MAC_DINH).strip().startswith("//")
    os.makedirs(thu_muc_abs, exist_ok=True)
    dem = {"da_bake": 0, "byte_truoc": 0, "byte_sau": 0, "packed": 0,
           "lien_ket": 0, "bake_lai": 0, "mat_file": 0,
           "doc_lai_lech": 0, "khong_ghi_duoc": 0, "trung_goc": 0,
           "thu_muc": thu_muc_abs}
    return thu_muc_abs, tuong_doi, dem


def nuong_ke_hoach(ket_qua, thu_muc, bao_tien_do=None, muon=DD_GIU,
                   chat_luong=CHAT_LUONG_MAC_DINH):
    """Bake moi tam ma ke hoach bao `doi`. Tra ve dict dem."""
    thu_muc_abs, tuong_doi, dem = _mo_thu_muc(thu_muc)
    dem["muon"] = muon
    viec = [k for k in ket_qua if k.get("doi")]
    for i, k in enumerate(viec):
        if bao_tien_do is not None:
            bao_tien_do(i, len(viec))
        img = bpy.data.images.get(k["ten"])
        if img is None or img.source != "FILE" or img.is_dirty:
            continue
        if img.library is not None:
            dem["lien_ket"] += 1
            continue
        lai = da_nuong(img)
        ok, ly_do = nuong_mot(img, k["moi_w"], k["moi_h"], thu_muc_abs,
                              tuong_doi, muon=muon, chat_luong=chat_luong,
                              dem=dem)
        if ok:
            dem["da_bake"] += 1
            dem["bake_lai"] += int(lai)
            dem["packed"] += int(img.packed_file is not None)
            dem["byte_truoc"] += k["byte_truoc"]
            dem["byte_sau"] += k["byte_sau"]
        else:
            dem[ly_do] = dem.get(ly_do, 0) + 1
    return dem


# ---------------------------------------------------------------------------
# BAKE SELECTED (Ducphan 18/09/2026)
# ---------------------------------------------------------------------------
# Ducphan 18/09/2026: *"bake selected k cho map dung chung nhe, selected la
# make unique dam map trong vat the do luon"*. Map vat dang chon dung CHUNG
# voi vat khac thi KHONG thu nho ban chung (vat lon khong chon se mo theo),
# ma TACH mot ban rieng cho vat dang chon roi thu nho ban rieng do.
KHOA_TACH_TU = "dp_ramchill_tach_tu"   # ban tach rieng: ten datablock goc


def _cay_con(cay):
    """Cac nhom node ma `cay` goi toi (mot tang)."""
    for nut in cay.nodes:
        if nut.bl_idname == "ShaderNodeGroup" and nut.node_tree is not None:
            yield nut.node_tree


def _di_cay(goc):
    """Moi cay (ke ca nhom long nhau) tu danh sach cay goc — moi cay mot
    lan, theo `as_pointer`."""
    da, ra, cho = set(), [], [c for c in goc if c is not None]
    while cho:
        c = cho.pop()
        if c.as_pointer() in da:
            continue
        da.add(c.as_pointer())
        ra.append(c)
        cho.extend(_cay_con(c))
    return ra


def _anh_cua_cay(cay):
    for nut in cay.nodes:
        if nut.bl_idname == "ShaderNodeTexImage" and nut.image is not None:
            yield nut


def _vl_cua_vat(vat_chon):
    ra, da = [], set()
    for ob in vat_chon:
        for sl in getattr(ob, "material_slots", ()):
            m = sl.material
            if m is not None and m.as_pointer() not in da:
                da.add(m.as_pointer())
                ra.append(m)
    return ra


def tach_rieng(vat_chon):
    """Tach cho cac vat dang chon moi thu ho dung CHUNG voi phan con lai.

    Ba tang, tu tren xuong:
      1. VAT LIEU vat khong chon cung dung -> `copy()` roi gan ban moi vao
         khe cua vat dang chon. Khe gan vao LUOI (`link == "DATA"`) ma luoi
         do vat khong chon cung dung -> doi khe sang `OBJECT` truoc: gan
         vao luoi la doi luon vat lieu cua vat kia.
      2. NHOM NODE vua nam trong vat lieu cua vat chon vua duoc cho khac
         goi toi, va co chua anh -> `copy()` cho rieng phia vat chon.
      3. ANH ma bat cu cho nao ngoai phia vat chon cung dung -> `copy()`,
         tro cac node anh phia vat chon sang ban moi.

    "Cho khac" = vat lieu con nguoi dung ma khong nam tren vat chon, World,
    den, cay compositor, moi nhom node con nguoi dung ma phia vat chon
    khong goi toi (nhom Geometry Nodes...). Anh con nguoi dung ngoai node
    (`users` lon hon so node phia vat chon tro vao) cung tinh la chung.

    Tra ve (anh_phia_chon, ban_anh, dem): `ban_anh` = {ptr ban moi: anh goc}
    de `nuong_vat_chon` tra lai neu ban moi khong bake duoc.
    """
    chon = {ob.as_pointer() for ob in vat_chon}
    vl_ngoai, luoi_ngoai = set(), set()
    for ob in bpy.data.objects:
        if ob.users == 0 or ob.as_pointer() in chon:
            continue
        if ob.data is not None:
            luoi_ngoai.add(ob.data.as_pointer())
        for sl in getattr(ob, "material_slots", ()):
            if sl.material is not None:
                vl_ngoai.add(sl.material.as_pointer())
    dem = {"tach_vl": 0, "tach_nhom": 0, "tach_anh": 0}

    # 1. vat lieu
    ban_vl = {}
    for ob in vat_chon:
        for sl in getattr(ob, "material_slots", ()):
            m = sl.material
            if m is None or m.as_pointer() not in vl_ngoai:
                continue
            m2 = ban_vl.get(m.as_pointer())
            if m2 is None:
                m2 = m.copy()
                m2[KHOA_TACH_TU] = m.name
                ban_vl[m.as_pointer()] = m2
                dem["tach_vl"] += 1
            if (sl.link == "DATA" and ob.data is not None
                    and ob.data.as_pointer() in luoi_ngoai):
                sl.link = "OBJECT"
            sl.material = m2

    # 2 + 3. phia vat chon sau khi da tach vat lieu
    vl_chon = _vl_cua_vat(vat_chon)
    goc_chon = [m.node_tree for m in vl_chon if m.node_tree is not None]
    cay_chon = {c.as_pointer() for c in _di_cay(goc_chon)}
    vl_chon_ptr = {m.as_pointer() for m in vl_chon}
    goc_ngoai = [m.node_tree for m in bpy.data.materials
                 if m.users and m.as_pointer() not in vl_chon_ptr]
    goc_ngoai += [w.node_tree for w in bpy.data.worlds if w.users]
    goc_ngoai += [getattr(la, "node_tree", None) for la in bpy.data.lights
                  if la.users]
    goc_ngoai += [getattr(sc, "compositing_node_group", None)
                  or getattr(sc, "node_tree", None)
                  for sc in bpy.data.scenes]
    goc_ngoai += [g for g in bpy.data.node_groups
                  if g.users and g.as_pointer() not in cay_chon]
    cay_ngoai = _di_cay(goc_ngoai)
    nhom_ngoai = {c.as_pointer() for c in cay_ngoai}
    anh_ngoai = {n.image.as_pointer() for c in cay_ngoai
                 for n in _anh_cua_cay(c)}
    # nguoi dung ngoai node (vd modifier Displace, brush, fake user)
    so_node = {}
    for c in _di_cay(goc_chon) + cay_ngoai:
        for n in _anh_cua_cay(c):
            k = n.image.as_pointer()
            so_node[k] = so_node.get(k, 0) + 1

    def chung_anh(img):
        k = img.as_pointer()
        return (k in anh_ngoai
                or img.users - int(img.use_fake_user) > so_node.get(k, 0))

    def co_anh(cay):
        return any(True for c in _di_cay([cay]) for _ in _anh_cua_cay(c))

    ban_nhom, ban_anh, goc_cua, da = {}, {}, {}, set()

    def lam_rieng(cay):
        if cay.as_pointer() in da:
            return
        da.add(cay.as_pointer())
        for nut in list(cay.nodes):
            if nut.bl_idname == "ShaderNodeTexImage" and nut.image:
                img = nut.image
                if img.library is not None or not chung_anh(img):
                    continue
                img2 = ban_anh.get(img.as_pointer())
                if img2 is None:
                    img2 = img.copy()
                    img2[KHOA_TACH_TU] = img.name
                    ban_anh[img.as_pointer()] = img2
                    goc_cua[img2.as_pointer()] = img
                    dem["tach_anh"] += 1
                nut.image = img2
            elif nut.bl_idname == "ShaderNodeGroup" and nut.node_tree:
                g = nut.node_tree
                if (g.as_pointer() in nhom_ngoai and g.library is None
                        and co_anh(g)):
                    g2 = ban_nhom.get(g.as_pointer())
                    if g2 is None:
                        g2 = g.copy()
                        g2[KHOA_TACH_TU] = g.name
                        ban_nhom[g.as_pointer()] = g2
                        dem["tach_nhom"] += 1
                    nut.node_tree = g2
                    g = g2
                lam_rieng(g)

    for c in goc_chon:
        if c.library is None:
            lam_rieng(c)

    anh, dap = [], set()
    for c in _di_cay([m.node_tree for m in vl_chon]):
        for n in _anh_cua_cay(c):
            if n.image.as_pointer() not in dap:
                dap.add(n.image.as_pointer())
                anh.append(n.image)
    return anh, goc_cua, dem


def _bo_ban_tach(img2, goc, vat_chon):
    """Ban tach rieng khong bake duoc (da nho, doc lai lech...) -> tro node
    phia vat chon ve anh goc va XOA ban tach: ban tach cua mot anh PACKED
    mang ca goi goc, de lai la .blend phinh them dung bang do."""
    vl = _vl_cua_vat(vat_chon)
    for c in _di_cay([m.node_tree for m in vl]):
        for n in _anh_cua_cay(c):
            if n.image == img2:
                n.image = goc
    if img2.users == 0:
        bpy.data.images.remove(img2)


def nuong_vat_chon(vat_chon, canh, thu_muc, muon=DD_GIU,
                   chat_luong=CHAT_LUONG_MAC_DINH, bao_tien_do=None):
    """Ep moi map cua cac vat dang chon ve canh lon `canh` (0 = giu co,
    chi doi dinh dang). Map dung chung duoc TACH RIENG truoc (`tach_rieng`).
    Tra ve dict dem, cung khoa voi `nuong_ke_hoach` cong them `tach_vl`,
    `tach_nhom`, `tach_anh`, `da_nho`, `da_la_jpg`, `khong_sua`, `vat`,
    `anh`."""
    thu_muc_abs, tuong_doi, dem = _mo_thu_muc(thu_muc)
    lam, goc_cua, dem_tach = tach_rieng(vat_chon)
    dem.update(dem_tach)
    dem.update(muon=muon, vat=len(vat_chon), anh=len(lam), ram_truoc=0,
               ram_sau=0, dia_truoc=0, dia_sau=0)
    for i, img in enumerate(lam):
        if bao_tien_do is not None:
            bao_tien_do(i, len(lam))
        goc = goc_cua.get(img.as_pointer())
        if img.source != "FILE" or img.is_dirty:
            ly_do = "khong_sua"
        elif img.library is not None:
            ly_do = "lien_ket"
        else:
            lai = da_nuong(img)
            kw = dict(muon=muon, chat_luong=chat_luong, dem=dem)
            w = h = 0
            if canh or not lai:
                kw["canh"] = canh
            else:
                # "Keep size" tren tam DA bake: giu co HIEN TAI cua no (ban
                # nho), khong phai co goc — nguoi dung chi doi dinh dang.
                w, h = img.size
                if not (w and h):          # ban bake mat tren dia
                    kw["canh"], w, h = CANH_GIU, 0, 0
            ok, ly_do = nuong_mot(img, w, h, thu_muc_abs, tuong_doi, **kw)
            if ok:
                dem["da_bake"] += 1
                dem["bake_lai"] += int(lai)
                dem["packed"] += int(img.packed_file is not None)
                continue
        dem[ly_do] = dem.get(ly_do, 0) + 1
        if goc is not None:
            _bo_ban_tach(img, goc, vat_chon)
            dem["tach_anh"] -= 1
    dem["byte_truoc"], dem["byte_sau"] = dem["ram_truoc"], dem["ram_sau"]
    return dem


def tra_ve_goc():
    """Tro moi tam da bake ve ban goc. File bake de lai tren dia.

    Tra ve (so_tra_duoc, so_khong_tra_duoc). Tam packed ma goi goc giu lai
    tren dia da mat hoac bi sua (sha256 khong khop) thi KHONG dung toi va
    dem ra — thay mot goi khong phai goc vao la hong im lang.
    """
    so, hong = 0, 0
    for img in bpy.data.images:
        if KHOA_GOC not in img.keys():
            continue
        cs = img.colorspace_settings.name
        am = img.alpha_mode
        if img.packed_file is not None:
            if KHOA_GOI_GOC in img.keys():
                f = bpy.path.abspath(img[KHOA_GOI_GOC])
            else:
                # tam FILE da bake roi nguoi dung bam Pack Resources: ban
                # goc la file tren dia o duong dan cu
                f = bpy.path.abspath(img[KHOA_GOC], library=img.library)
            B = open(f, "rb").read() if os.path.isfile(f) else None
            if B is None or (KHOA_GOI_SHA in img.keys()
                             and _sha(B) != img[KHOA_GOI_SHA]):
                hong += 1
                print("[DP_RAMchill] khong tra lai duoc (mat goi goc):",
                      img.name, f)
                continue
            if img.filepath != img[KHOA_GOC]:
                img.filepath_raw = img[KHOA_GOC]
            img.pack(data=B, data_len=len(B))
            img.colorspace_settings.name = cs
            img.alpha_mode = am
            img.buffers_free()
        else:
            img.filepath = img[KHOA_GOC]
            img.colorspace_settings.name = cs
            img.alpha_mode = am
            img.reload()
        for k in (KHOA_GOC, KHOA_CO_GOC, KHOA_GOI_GOC, KHOA_GOI_SHA):
            if k in img.keys():
                del img[k]
        so += 1
    return so, hong


def dong_bao_cao(dem):
    """Cac dong cho bang — dong nao cung vua be rong thanh ben."""
    d = ["baked %d maps" % dem["da_bake"]]
    if dem.get("bake_lai"):
        d.append("(%d re-baked from originals)" % dem["bake_lai"])
    if dem.get("packed"):
        d.append("(%d packed: .blend shrinks)" % dem["packed"])
    if dem["da_bake"]:
        d.append("%s  ->  %s" % (chinh_sach.doc_byte(dem["byte_truoc"]),
                                 chinh_sach.doc_byte(dem["byte_sau"])))
        # So FILE rieng mot dong: doi sang JPG thi RAM dung yen ma file nhe
        # han — chi mot con so RAM se doc thanh "JPG khong co tac dung".
        # Dong tren giu NGUYEN VAN: so tay doi chieu no (`lam_huong_dan`).
        if dem.get("muon", DD_GIU) != DD_GIU and dem.get("dia_truoc"):
            d.append("files %s -> %s" % (
                chinh_sach.doc_byte(dem["dia_truoc"]),
                chinh_sach.doc_byte(dem["dia_sau"])))
    if "vat" in dem and not dem.get("anh"):
        d.append("! no maps on selection")
    for khoa, chu in (("da_nho", "%d already small, left"),
                      ("da_la_jpg", "%d already JPG, left")):
        if dem.get(khoa):
            d.append(chu % dem[khoa])
    if dem.get("tach_anh"):
        d.append("%d shared maps made unique" % dem["tach_anh"])
    for khoa, chu in (                      ("jpg_alpha", "! %d with alpha: PNG"),
                      ("jpg_float", "! %d 16-bit/HDR: lossless"),
                      ("khong_sua", "! %d UDIM/generated kept"),
                      ("lien_ket", "! %d linked maps kept"),
                      ("mat_file", "! %d missing files kept"),
                      ("doc_lai_lech", "! %d failed read-back, kept"),
                      ("khong_ghi_duoc", "! %d could not be written"),
                      ("trung_goc", "! %d would overwrite source")):
        if dem.get(khoa):
            d.append(chu % dem[khoa])
    return "\n".join(d)
