# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
"""Chuyen viec cua handler render sang LUONG CHINH va cho no xong.

=========================================================================
VI SAO CO FILE NAY
=========================================================================
Bam F12 / batch render co cua so thi `render_init`, `render_pre`,
`render_complete`, `render_cancel` chay tren LUONG RENDER, khong phai luong
chinh. Handler cua addon nay quet ca scene (`evaluated_depsgraph_get`, doc
luoi tung vat) roi `scale()` / `reload()` anh, doi `hide_render` — ngay luc
luong chinh dang ve khung nhin bang CHINH nhung du lieu do. Blender vang
SEGV.

Do 17/09/2026, Blender 5.2.2, may Duc-KAS: hai coredump (PID 210167,
218879), luong render deu dang o `doi_co._truoc_render` ->
`do_canh.quet_scene`, luong chinh vang trong luc ve. Chay nen (`-b`) thi
render DONG BO tren luong chinh nen cac bai do cu khong bao gio thay.

=========================================================================
CACH LAM
=========================================================================
Handler goi `chay(ham, ...)`. Dang o luong chinh (chay nen, save_pre,
load_post) thi goi thang. O luong khac thi xep viec vao hang, luong render
DUNG CHO; timer `_nhip` tren luong chinh lay viec ra lam, xong bao lai, luong
render moi di tiep. Nho vay anh van duoc ha co TRUOC khi Cycles doc — giu
nguyen tac dung cua addon.

Cho qua `CHO_NHAN` giay ma luong chinh chua NHAN viec (bi treo o dau do) thi
bo viec do, render nhu khong co addon — khong bao gio treo ca lan render.
Luong chinh da nhan roi thi cho toi khi xong: bo giua chung la hai luong lai
cung dung du lieu.
"""

import threading

import bpy

CHO_NHAN = 30.0
NHIP = 0.05

_HANG = []
_KHOA = threading.Lock()


class _Viec:
    __slots__ = ("ham", "doi", "xong", "dang_lam", "bo")

    def __init__(self, ham, doi):
        self.ham = ham
        self.doi = doi
        self.xong = threading.Event()
        self.dang_lam = False
        self.bo = False


def o_luong_chinh():
    return threading.current_thread() is threading.main_thread()


def chay(ham, *doi):
    """Chay `ham(*doi)` tren luong chinh; goi tu luong khac thi cho no xong."""
    if o_luong_chinh():
        ham(*doi)
        return True
    viec = _Viec(ham, doi)
    with _KHOA:
        _HANG.append(viec)
    if viec.xong.wait(CHO_NHAN):
        return True
    with _KHOA:
        if not viec.dang_lam:
            viec.bo = True
            print("[DP_RAMchill] main thread busy for %.0f s, skipped %s for "
                  "this render" % (CHO_NHAN, getattr(ham, "__name__", ham)))
            return False
    viec.xong.wait()
    return True


def _nhip():
    while True:
        with _KHOA:
            if not _HANG:
                break
            viec = _HANG.pop(0)
            if viec.bo:
                continue
            viec.dang_lam = True
        try:
            viec.ham(*viec.doi)
        except Exception as e:                           # noqa: BLE001
            print("[DP_RAMchill] %s failed: %s"
                  % (getattr(viec.ham, "__name__", viec.ham), e))
        finally:
            viec.xong.set()
    return NHIP


def dang_ky():
    if not bpy.app.timers.is_registered(_nhip):
        bpy.app.timers.register(_nhip, first_interval=NHIP, persistent=True)


def go():
    if bpy.app.timers.is_registered(_nhip):
        bpy.app.timers.unregister(_nhip)
    # Con ai dang cho thi tha ra, dung de luong render treo vinh vien.
    with _KHOA:
        for viec in _HANG:
            viec.bo = True
            viec.xong.set()
        _HANG.clear()
