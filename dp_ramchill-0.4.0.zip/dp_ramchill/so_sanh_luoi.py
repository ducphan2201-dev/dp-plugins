# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
"""BANG BAO CAO CUA OPTIMIZE MESHES — render thu TRUOC va SAU, do:

  * bo nho render dinh (Cycles tu bao, dong "Mem:" trong trang thai render —
    render bang card thi day la VRAM, bang CPU la RAM);
  * thoi gian render;
  * anh khac bao nhieu: % diem anh khac THAY DUOC (lech > 16/255 o mot kenh)
    va lech trung binh. Nguong 3% la cua Ducphan 18/09/2026: *"render ket qua
    khong thay doi qua 3% ma ram giam dang ke la duoc"*.

Ducphan 18/09/2026: *"lam bang bao cao cho chuc nang optimize mesh xem do
duoc bao nhieu vram khi render va anh sai khac bao nhieu %"*.

⛔ HAI LAN RENDER PHAI CUNG DIEU KIEN, khong thi con so noi doi:
  * cung co anh (phan tram cua co khach dat), cung so mau, CUNG SEED, tat
    adaptive sampling (seed khac / adaptive -> nhieu khac -> anh "khac" o moi
    diem du hinh khong doi);
  * TAT Persistent Data trong luc do: bat thi lan sau dung lai du lieu lan
    truoc, dinh bo nho lan sau khong phai cua canh sau;
  * moi thiet lap doi tam deu TRA LAI (try/finally) — file khach khong mang
    dau vet cua phep do.
Khu nhieu giu nhu khach dat: day la anh khach se nhin.

DOI CHIEU VOI CARD THAT (18/09/2026, bantest, RTX 3060, OptiX, 50%):
bang bao 3.839 -> 3.109 MB (-730); nvidia-smi dinh ca card 5.586 -> 4.972
(-614, lay mau 1 giay, co ~1,1 GB cua ung dung khac). So Cycles tu dem thap
hon tong tren card ~0,6 GB (phan trinh dieu khien) — phan TIET KIEM khop.

⚠ Dinh bo nho lay tu CO ANH THU (mac dinh 50%): phan luoi va map khong phu
thuoc co anh, chi phan bo dem anh nho hon. Phan TIET KIEM la cua luoi nen
dung; con so tuyet doi thap hon lan render that mot chut.

Anh ghi vao `//DP_RAMchill_meshes/compare/` (before / after / difference)
va nap thanh ba anh `DPRC Before` / `DPRC After` / `DPRC Difference` de mo
trong Image Editor.
"""

import os
import re
import time

import bpy
import numpy as np

NGUONG_THAY = 16.0 / 255.0     # lech mot kenh qua muc nay = mat thay duoc
NGUONG_DAT = 3.0               # % diem anh — nguong cua Ducphan
TEN_ANH = {"truoc": "DPRC Before", "sau": "DPRC After",
           "khac": "DPRC Difference"}
_MEM = re.compile(r"Mem:\s*([\d.]+)\s*([KMGT]?)")
_DON_VI = {"": 1.0 / 2**20, "K": 1.0 / 1024, "M": 1.0, "G": 1024.0,
           "T": 1024.0 ** 2}


def thiet_bi(sc):
    """Chu ngan: render tren gi — de biet con so bo nho la VRAM hay RAM."""
    if sc.render.engine != "CYCLES":
        return sc.render.engine.title(), False
    if sc.cycles.device != "GPU":
        return "CPU", False
    try:
        pr = bpy.context.preferences.addons["cycles"].preferences
        loai = pr.compute_device_type
        co_cpu = any(d.use and d.type == "CPU" for d in pr.devices)
        return ("GPU %s%s" % (loai, " + CPU" if co_cpu else ""), True)
    except Exception:                                      # noqa: BLE001
        return "GPU", True


def _dat(obj, ten, gia_tri, cu):
    cu.append((obj, ten, getattr(obj, ten)))
    setattr(obj, ten, gia_tri)


# True CHI trong luc `render_thu` render. ⛔ DP-Optimize doc co nay (qua
# `sys.modules`) de KHONG cat anh thu vao kho DP VFB duoi ten camera that
# (ra soat 21/09/2026). Doi ten la DP VFB lai lan anh thu voi anh that.
DANG_RENDER_THU = False


def render_thu(sc, duong_png, phan_tram=50, mau_toi_da=64):
    """Render mot anh thu ra `duong_png`. Tra {mem_mb, giay}; mem_mb None
    neu engine khong bao."""
    global DANG_RENDER_THU
    dinh = [0.0]

    def nghe(stats, *a):
        for so, dv in _MEM.findall(str(stats)):
            try:
                dinh[0] = max(dinh[0], float(so) * _DON_VI.get(dv, 1.0))
            except ValueError:
                pass

    r, cu = sc.render, []
    try:
        _dat(r, "resolution_percentage",
             max(1, int(round(r.resolution_percentage * phan_tram / 100.0))),
             cu)
        _dat(r, "use_persistent_data", False, cu)
        _dat(r, "filepath", duong_png, cu)
        _dat(r.image_settings, "file_format", "PNG", cu)
        _dat(r.image_settings, "color_mode", "RGB", cu)
        _dat(r.image_settings, "color_depth", "8", cu)
        if r.engine == "CYCLES":
            c = sc.cycles
            _dat(c, "samples", min(c.samples, mau_toi_da), cu)
            _dat(c, "use_adaptive_sampling", False, cu)
            _dat(c, "seed", 0, cu)
            _dat(c, "use_animated_seed", False, cu)
            if hasattr(c, "time_limit"):
                _dat(c, "time_limit", 0.0, cu)
        bpy.app.handlers.render_stats.append(nghe)
        t = time.time()
        DANG_RENDER_THU = True
        bpy.ops.render.render(write_still=True, scene=sc.name)
        giay = time.time() - t
    finally:
        DANG_RENDER_THU = False
        if nghe in bpy.app.handlers.render_stats:
            bpy.app.handlers.render_stats.remove(nghe)
        for obj, ten, v in reversed(cu):
            try:
                setattr(obj, ten, v)
            except Exception:                              # noqa: BLE001
                pass
    return {"mem_mb": dinh[0] or None, "giay": giay}


def _doc(duong):
    im = bpy.data.images.load(duong, check_existing=False)
    try:
        w, h = im.size
        a = np.empty(w * h * im.channels, np.float32)
        im.pixels.foreach_get(a)
        return a.reshape(h, w, im.channels)[:, :, :3], (w, h)
    finally:
        bpy.data.images.remove(im)


def so_anh(png_truoc, png_sau, png_khac):
    """(% diem anh khac thay duoc, % lech trung binh). Ghi anh ban do khac:
    nen xam mo, cho khac to do."""
    a, co = _doc(png_truoc)
    b, co2 = _doc(png_sau)
    if co != co2:
        return None, None
    d = np.abs(a - b)
    px = float((d.max(axis=2) > NGUONG_THAY).mean() * 100.0)
    tb = float(d.mean() * 100.0)
    nen = a.mean(axis=2) * 0.35
    do = np.clip(d.max(axis=2) * 4.0, 0.0, 1.0)
    rgba = np.stack([np.maximum(nen, do), nen, nen, np.ones_like(nen)], 2)
    im = bpy.data.images.new("DPRC_tam_khac", co[0], co[1])
    try:
        im.pixels.foreach_set(rgba.astype(np.float32).ravel())
        im.filepath_raw = png_khac
        im.file_format = "PNG"
        im.save()
    finally:
        bpy.data.images.remove(im)
    return px, tb


def nap_anh(thu):
    """Nap / nap lai ba anh so sanh de mo trong Image Editor."""
    for k, ten in TEN_ANH.items():
        f = os.path.join(thu, {"truoc": "before.png", "sau": "after.png",
                               "khac": "difference.png"}[k])
        if not os.path.isfile(f):
            continue
        im = bpy.data.images.get(ten)
        if im is None:
            im = bpy.data.images.load(f, check_existing=False)
            im.name = ten
        else:
            im.filepath = f
            im.reload()


def ghi_bao_cao(p, truoc, sau, px, tb, dem, tb_thiet_bi):
    p.bc_co = True
    p.bc_thiet_bi = tb_thiet_bi
    p.bc_mem_truoc = truoc["mem_mb"] or 0.0
    p.bc_mem_sau = sau["mem_mb"] or 0.0
    p.bc_giay_truoc = truoc["giay"]
    p.bc_giay_sau = sau["giay"]
    p.bc_tg_truoc = float(dem.get("tg_truoc", 0))
    p.bc_tg_sau = float(dem.get("tg_sau", 0))
    p.bc_px_khac = -1.0 if px is None else px
    p.bc_tb_khac = -1.0 if tb is None else tb
