# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
"""Bang ben phai — View3D > N > DP_RAMchill.

BON LUAT CUA BANG, ca bon deu da tra gia o cac addon truoc:
  * MOI HANG MOT NUT CHU. Thanh ben rong ~420 px; nhet hai nut mot hang la
    chia doi va cat chu.
  * KHONG `scale_y` cho hang chu.
  * O KHONG DUNG THI LAM MO (`active = False`), KHONG AN. An di la nguoi
    dung bao "tinh nang bien mat".
  * NHOM IT DUNG THI `DEFAULT_CLOSED`. Bang dai qua man hinh = nguoi dung
    bao "khong co tinh nang do".

Chu tren bang la TIENG ANH — addon ban ra.
"""

import bpy
from bpy.types import Panel

from . import bo_nho
from . import chinh_sach
from . import doi_co
from . import nha_ram
from . import nuong_map
from . import so_sanh_luoi
from . import toi_uu_luoi


class _Nen:
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "DP_RAMchill"


class DPRAMCHILL_PT_chinh(_Nen, Panel):
    bl_idname = "DPRAMCHILL_PT_chinh"
    bl_label = "DP_RAMchill"

    def draw(self, context):
        lo = self.layout
        p = context.scene.dp_ramchill

        lo.prop(p, "che_do", text="")

        if p.che_do == chinh_sach.CHE_DO_EP_CO:
            lo.prop(p, "canh_ep")
        elif p.che_do == chinh_sach.CHE_DO_TU_DONG:
            k = lo.box()
            k.label(text="1 - Distance rings", icon="CON_DISTLIMIT")
            k.prop(p, "moc_tu_dong")
            c = k.column(align=True)
            # O KHONG DUNG THI LAM MO, KHONG AN — an di la nguoi dung bao
            # "tinh nang bien mat".
            c.active = not p.moc_tu_dong
            c.prop(p, "moc_1")
            c.prop(p, "moc_2")
            c.prop(p, "moc_3")
            c.prop(p, "moc_4")
            hang = k.row()
            hang.active = not p.moc_tu_dong
            hang.operator("dpramchill.moc_tu_scene",
                          icon="DRIVER_DISTANCE")

            k = lo.box()
            k.label(text="2 - Screen area", icon="MOD_UVPROJECT")
            c = k.column(align=True)
            c.prop(p, "du_phong")
            c.prop(p, "nguong_to")

        lo.separator()
        lo.operator("dpramchill.quet", icon="VIEWZOOM")

        # ⛔ LUAT Ducphan chot 22/08/2026: TU DONG LA CHO ANH TINH. Ke
        # hoach lap MOT LAN, o khung hinh dang dung, nen camera bay qua ca
        # can phong thi khung 250 van dung bo tri cua khung 1. Duong cho
        # animation la EP CO — nguoi dung tu chon mot co, va no dung cho
        # moi khung hinh.
        #
        # Cho nay CO Y khong tu doan xem lan render la tinh hay dong:
        # `frame_start != frame_end` KHONG phai dau hieu cua animation —
        # gan nhu moi file .blend deu de san dai 1-250 du nguoi dung chi
        # bam Render Image. Tu tat Tu dong theo dau hieu do la addon chet
        # lang voi gan nhu moi nguoi dung.
        if (p.che_do == chinh_sach.CHE_DO_TU_DONG
                and context.scene.frame_start != context.scene.frame_end):
            k = lo.box()
            # ⛔ HAI DONG NAY PHAI NGAN. Ban dau chung la "Animation:
            # measured at the first frame only" / "Moving camera - check
            # the last frame too", va anh chup lo ra ca hai deu bi CAT
            # CUT giua chung. Bo do 26 phep khong thay — ban ve gia doc
            # duoc NOI DUNG chu khong do duoc BE RONG.
            k.label(text="Auto is for stills", icon="ERROR")
            k.label(text="Animation: use Force")

        if p.bao_cao:
            k = lo.box()
            for dong in p.bao_cao.split("\n"):
                k.label(text=dong,
                        icon="ERROR" if dong.startswith("!") else "NONE")

        if doi_co.dang_ra_tay():
            lo.separator()
            k = lo.box()
            k.label(text="Maps are shrunk right now", icon="ERROR")
            k.operator("dpramchill.tra_lai", icon="FILE_REFRESH")

        # BAKE — ghi ke hoach ra file moi (Ducphan 12/09/2026). Che do Off
        # thi nut LAM MO, khong an: an di la nguoi dung bao "mat tinh nang".
        lo.separator()
        k = lo.box()
        k.label(text="Bake to smaller files", icon="IMAGE_DATA")
        k.prop(p, "thu_muc_nuong", text="")
        hang = k.row()
        hang.active = p.che_do != chinh_sach.CHE_DO_TAT
        hang.operator("dpramchill.nuong", icon="RENDER_STILL")
        so = nuong_map.dem_da_nuong()
        if so:
            k.label(text="%d maps use baked files" % so, icon="INFO")
            k.operator("dpramchill.bo_nuong", icon="LOOP_BACK")


class DPRAMCHILL_PT_nuong_chon(_Nen, Panel):
    """Dinh dang ban bake + Bake Selected (Ducphan 18/09/2026).

    ⛔ BANG CON, KHONG NHET VAO BANG CHINH: them hai o Format / Quality vao
    khoi Bake cua bang chinh la bang dai 24 hang, qua tran `do_bang` (duoi
    24) — dai qua man hinh thi khach bao "khong co tinh nang do". Bang con
    nay ve ngay duoi khoi Bake. Format dung cho CA HAI nut Bake.
    Bake Selected khong phu thuoc che do Off/Auto/Force, nen khong lam mo
    theo che do.
    """
    bl_idname = "DPRAMCHILL_PT_nuong_chon"
    bl_parent_id = "DPRAMCHILL_PT_chinh"
    bl_label = "Bake Options"

    def draw(self, context):
        lo = self.layout
        p = context.scene.dp_ramchill
        lo.prop(p, "dinh_dang_nuong")
        hang = lo.row()
        hang.active = p.dinh_dang_nuong != nuong_map.DD_GIU
        hang.prop(p, "chat_luong")

        k = lo.box()
        k.label(text="Selected objects only", icon="RESTRICT_SELECT_OFF")
        # Co map chon trong HOP THOAI hien ra khi bam (Ducphan 18/09/2026).
        so = len(context.selected_objects)
        hang = k.row()
        hang.active = so > 0
        hang.operator("dpramchill.nuong_chon", icon="RENDER_STILL")
        k.label(text="%d objects selected" % so)


def _phan_tram_doi(truoc, sau):
    if truoc <= 0:
        return "-"
    return "%+.0f%%" % (100.0 * (sau - truoc) / truoc)


def _so_gon(n):
    if n >= 1e6:
        return "%.1fM" % (n / 1e6)
    if n >= 1e3:
        return "%.0fk" % (n / 1e3)
    return "%d" % n


def _ve_bang_so_sanh(lo, p):
    """BANG BAO CAO Optimize Meshes: truoc / sau / doi. Moi o chu ngan —
    thanh ben ~420 px chia bon cot."""
    k = lo.box()
    k.label(text="Test render (%s)" % p.bc_thiet_bi, icon="RENDER_RESULT")
    vram = p.bc_thiet_bi.startswith("GPU")
    hang = [("VRAM" if vram else "RAM", "%.0f MB" % p.bc_mem_truoc,
             "%.0f MB" % p.bc_mem_sau,
             _phan_tram_doi(p.bc_mem_truoc, p.bc_mem_sau))
            if p.bc_mem_truoc > 0 else ("Memory", "n/a", "n/a", "-"),
            # ⛔ KHONG co hang THOI GIAN: lan render thu "truoc" la lan DAU
            # nen phai nap chuong trinh len card — bantest 18/09 bang card:
            # 35,8 s -> 21,3 s ma phan lon la nap, khong phai nho toi uu.
            ("Tris*", _so_gon(p.bc_tg_truoc), _so_gon(p.bc_tg_sau),
             _phan_tram_doi(p.bc_tg_truoc, p.bc_tg_sau))]
    cot = k.column(align=True)
    for dong in [("", "Before", "After", "Change")] + hang:
        r = cot.row(align=True)
        for chu in dong:
            r.label(text=chu)
    if p.bc_px_khac >= 0:
        dat = p.bc_px_khac <= so_sanh_luoi.NGUONG_DAT
        k.label(text="Pixels changed: %.2f%%" % p.bc_px_khac,
                icon="CHECKMARK" if dat else "ERROR")
        k.label(text="Mean difference: %.2f%%" % p.bc_tb_khac)
        k.label(text="Looks the same (under 3%)" if dat
                else "! Over 3%: check the images")
    k.label(text="*triangles of the reduced meshes")
    k.operator("dpramchill.xem_so_sanh", icon="IMAGE_DATA")


class DPRAMCHILL_PT_luoi(_Nen, Panel):
    """TOI UU LUOI (Ducphan 18/09/2026) — bang con RIENG, nut rieng, bao cao
    rieng (`bao_cao_luoi`): khong phu thuoc che do map, khong lam mo theo no.
    Xem `toi_uu_luoi.py`."""
    bl_idname = "DPRAMCHILL_PT_luoi"
    bl_parent_id = "DPRAMCHILL_PT_chinh"
    bl_label = "Mesh Optimize"

    def draw(self, context):
        lo = self.layout
        p = context.scene.dp_ramchill
        lo.operator("dpramchill.toi_uu_luoi", icon="MOD_DECIM")
        n, s = toi_uu_luoi.da_toi_uu()
        if n or s:
            lo.label(text="%d meshes, %d subdivisions" % (n, s), icon="INFO")
            lo.operator("dpramchill.tra_luoi", icon="LOOP_BACK")
        if p.bao_cao_luoi:
            k = lo.box()
            for dong in p.bao_cao_luoi.split("\n"):
                k.label(text=dong,
                        icon="ERROR" if dong.startswith("!") else "NONE")
        if p.bc_co:
            _ve_bang_so_sanh(lo, p)
        else:
            # Bang bao cao chi co SAU khi bam — noi ra cho khach biet no o day.
            lo.label(text="Report: after Optimize Meshes", icon="INFO")


class DPRAMCHILL_PT_them(_Nen, Panel):
    bl_idname = "DPRAMCHILL_PT_them"
    bl_parent_id = "DPRAMCHILL_PT_chinh"
    bl_label = "More"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        lo = self.layout
        p = context.scene.dp_ramchill
        lo.active = p.che_do != chinh_sach.CHE_DO_TAT
        lo.prop(p, "san_duoi")
        # ⛔ NHAN RIENG MOT HANG. `lo.prop(p, "bo_qua")` chia doi hang cho
        # nhan va o nhap chu, va anh chup (22/08 lan 14/09/2026) deu ra
        # "Keep a..." - nhan bi cat, trong khi so tay goi dung ten o do.
        lo.label(text="Keep at full size:")
        lo.prop(p, "bo_qua", text="")
        lo.operator("dpramchill.tra_lai", icon="FILE_REFRESH")


class DPRAMCHILL_PT_cycles(_Nen, Panel):
    """Bo vat ngoai khung khi render (Ducphan 13/09/2026).

    Khong phu thuoc che do Off/Auto/Force o tren - nen o day, trong mot bang
    con rieng, chu khong lam mo theo che do.

    ⛔ KHOI "TEXTURE CACHE" DA BO (0.3.2, Ducphan 13/09/2026 23h: *"chuc nang
    nao gay vot ram va ton ram thi bo"*). Do cung mot canh 16 anh 4K
    (`tools/chay_so_sanh_ram.py`): lan ve DAU sau khi bat Auto Generate, RAM
    MAY vot tu 1,6 len 6,8 GB (Blender tao file .tx cho moi anh cung luc) va
    ghi 208 MB file .tx canh thu muc anh cua khach. Moi chuc nang con lai deu
    lam RAM may THAP hon ban goc. Dung ve lai hai o ay vao bang.
    Luat `doi_co.tx_dang_bat` VAN GIU: khach tu bat bo dem cua Blender thi
    addon thoi ha anh FILE (ha roi bo dem khong doc duoc - LESSONS §15), va
    bang noi ra ngay duoi day de "0/40 maps shrink" khong doc thanh hong.
    """
    bl_idname = "DPRAMCHILL_PT_cycles"
    bl_parent_id = "DPRAMCHILL_PT_chinh"
    bl_label = "Cycles Memory"

    def draw(self, context):
        lo = self.layout
        sc = context.scene
        p = sc.dp_ramchill

        k = lo.box()
        k.label(text="Off-screen objects", icon="HIDE_ON")
        k.prop(p, "bo_ngoai_khung")
        hang = k.row()
        hang.active = p.bo_ngoai_khung
        hang.prop(p, "giu_gan")

        # TU NHA RAM (chep tu DP_Optimize 18/09/2026) — PHAI NHIN THAY DUOC.
        # Ben DP_Optimize ban dau no chay im lang, Ducphan hoi "the cai tu
        # nha ram dau?". Dong so cua lan render gan nhat la bang chung.
        # ⛔ TREN WINDOWS PHAI DAN CA HAI SO: day trang khoi working set lam
        # Task Manager tut ma khong giai phong byte nao (xem `bo_nho.py`).
        k = lo.box()
        k.prop(p, "nha_ram")
        hang = k.row()
        hang.active = p.nha_ram
        hang.prop(p, "tha_persistent")
        c = k.column()
        c.active = p.nha_ram
        if nha_ram.dp_optimize_dang_lam():
            # chi mot addon lam viec nay - xem `nha_ram.py`
            c.label(text="Done by DP_Optimize for now", icon="INFO")
        elif p.nha_ram and not bo_nho.dang_bat():
            c.label(text="Hand-back is not running", icon="ERROR")
        don = bo_nho.lan_cuoi()
        if don:
            if don.get("giam_mb") is not None:
                c.label(text="Last render: -%.0f MB resident"
                             % don["giam_mb"])
            if don.get("giam_cam_ket_mb") is not None:
                c.label(text="  %.0f MB actually released"
                             % don["giam_cam_ket_mb"])
            if don.get("tha_persistent"):
                c.label(text="  kept render data freed")
            if don.get("anh_da_tha"):
                c.label(text="  %d image buffers dropped"
                             % don["anh_da_tha"])
            r = don.get("ram_sau") or {}
        else:
            c.label(text="Nothing rendered yet")
            r = bo_nho.ram_may()
        if "con_mb" in r and r.get("tong_mb"):
            c.label(text="RAM free: %.0f / %.0f MB"
                         % (r["con_mb"], r["tong_mb"]))

        if doi_co.tx_dang_bat(sc):
            k = lo.box()
            k.label(text="Blender Texture Cache is on", icon="ERROR")
            k.label(text="File maps are left to it")
            k.label(text="1st render uses a lot of RAM")


_LOP = (DPRAMCHILL_PT_chinh, DPRAMCHILL_PT_nuong_chon, DPRAMCHILL_PT_luoi,
        DPRAMCHILL_PT_them,
        DPRAMCHILL_PT_cycles)


def dang_ky():
    for c in _LOP:
        bpy.utils.register_class(c)


def go():
    for c in reversed(_LOP):
        bpy.utils.unregister_class(c)
