# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
"""TOI UU LUOI CA CANH — it tam giac hon, anh render gan nhu y het.

Ducphan 18/09/2026: *"viec toi uu model k phai chi cho moi vat xa ma cho
toan canh, giam poly nhung render ket qua khong thay doi qua 3% ma ram giam
dang ke la duoc"*.

MODULE DOC LAP: khong gan chot render nao, khong doc o nao cua cac tinh nang
khac. Chi chay khi nguoi dung bam nut, va `tra_ve_goc` tra lai het.

=========================================================================
DO TRUOC KHI XAY (18/09/2026, Blender 5.2, render CPU, dinh RAM tien trinh)
=========================================================================
bantest_v21 (16,1 trieu tam giac, 378 map, du map), 1000x1000, 32 mau:

    goc                               12.145 MB   —
    hoa mat phang                     -9%         0,07% px khac thay duoc
    hoa mat phang + giam 50%          -23%        0,90% px   (nhin: khong phan biet)
    giam con 25%                      -28%        3,53% px   SAN GO VO VAN — LOAI
PN4 (chia min tren goi/chan): ha 1 bac chia min luc render -24%, 0,51% px.

⛔ BA DUONG DA THU VA LOAI:
  * Gan Decimate lam MODIFIER (du o dau hay cuoi chong): dinh RAM TANG
    (bantest 7,6 -> 11,3..12,3 GB khong map; PN4 4,5 -> 6,2 GB). Blender giu
    luoi goc + ban giam + bo nho lam viec. Phai NUONG vao luoi.
  * Giu luoi goc TRONG file (fake user) de tra lai: moi datablock trong file
    deu nap vao RAM khi mo. Luoi goc phai ra FILE RIENG.
  * Nuong "Smooth by Angle" + gop vat giong het: anh y het nhung dinh RAM
    render khong doi (Cycles van dung luoi rieng cho moi vat co modifier).

=========================================================================
CACH LAM
=========================================================================
  1. Chia min (Subdivision): `render_levels` - 1, bac cu cat vao modifier
     (`KHOA_BAC`). Khong dung luoi.
  2. Luoi day (>= `nguong` tam giac, tinh tren luoi GOC): hoa mat phang
     (Decimate DISSOLVE 1 do, giu ranh UV / vat lieu / seam / canh sac) roi
     giam con `ti_le` (Decimate COLLAPSE), NUONG bang `new_from_object`, cac
     modifier khac TAT trong luc nuong (van nguyen tren vat).
  3. Luoi goc ghi ra `//DP_RAMchill_meshes/<file>_originals.blend` (ban
     sao KHONG vat lieu — `libraries.write` keo theo moi thu luoi tro toi,
     ke ca anh packed), roi XOA khoi file dang mo. Ten vat lieu cat vao ban
     moi de tra lai dung khe.

⛔ BO QUA (va dem ra): luoi co shape key (Decimate khong giu duoc), luoi
lien ket tu file khac, luoi ma sau khi giam hop bao lech > `LECH_TOI_DA`
duong cheo (bi an mon hinh). Luoi dung chung voi vat NGOAI pham vi (che do
Selected) thi vat trong pham vi nhan ban moi, vat ngoai giu luoi goc.
"""

import os
import time

import bpy
import numpy as np
from mathutils import Vector

# tren VAT (modifier khong nhan du lieu rieng): {ten modifier: bac render cu}
KHOA_BAC = "dp_ramchill_bac_render"
KHOA_FILE = "dp_ramchill_luoi_file"     # tren luoi moi: file chua luoi goc
KHOA_TEN = "dp_ramchill_luoi_ten"       # ... ten luoi goc trong file do
KHOA_VL = "dp_ramchill_luoi_vl"         # ... ten vat lieu theo khe
KHOA_TRONG = "dp_ramchill_luoi_trong"   # luoi goc con NAM TRONG file (Selected)
THU_MUC_MAC_DINH = "//DP_RAMchill_meshes"
GOC_PHANG = 1.0                         # do — hoa mat phang
LECH_TOI_DA = 0.01                      # 1% duong cheo hop bao


def _tam_giac(me):
    n = len(me.polygons)
    if not n:
        return 0
    a = np.empty(n, np.int32)
    me.polygons.foreach_get("loop_total", a)
    return int(a.sum()) - 2 * n


def _hop(me):
    n = len(me.vertices)
    if not n:
        return None
    a = np.empty(n * 3, np.float32)
    me.vertices.foreach_get("co", a)
    a = a.reshape(-1, 3)
    return Vector(a.min(0).tolist()), Vector(a.max(0).tolist())


def _lech_hop(a, b):
    """Hop bao lech bao nhieu, theo ti le duong cheo hop goc."""
    ha, hb = _hop(a), _hop(b)
    if ha is None or hb is None:
        return 1.0
    cheo = max((ha[1] - ha[0]).length, 1e-9)
    return max((ha[0] - hb[0]).length, (ha[1] - hb[1]).length) / cheo


def _dat_vat_lieu(dich, nguon_vl):
    """Dat vat lieu cua `dich` theo TUNG KHE bang `nguon_vl` (danh sach).

    ⛔ KHONG DUNG `materials.clear()`: do 18/09/2026 (Blender 5.2) no XOA LUON
    chi so vat lieu cua tung mat (thuoc tinh `material_index`) — bantest 29
    luoi nhieu vat lieu thanh mot vat lieu, san ra van khac han, 6,4% diem anh
    khac. Chi so mat phai giu nguyen; chi doi cai khe tro toi.
    """
    n = len(dich.polygons)
    mi = np.zeros(n, np.int32)
    if n:
        dich.polygons.foreach_get("material_index", mi)
    while len(dich.materials) < len(nguon_vl):
        dich.materials.append(None)
    while len(dich.materials) > len(nguon_vl):
        dich.materials.pop()
    for i, m in enumerate(nguon_vl):
        dich.materials[i] = m
    if n:
        dich.polygons.foreach_set("material_index", mi)


def da_toi_uu():
    """(so luoi da giam, so modifier chia min da ha)."""
    n = sum(1 for me in bpy.data.meshes
            if KHOA_TEN in me.keys() or KHOA_TRONG in me.keys())
    s = sum(len(ob[KHOA_BAC]) for ob in bpy.data.objects
            if KHOA_BAC in ob.keys())
    return n, s


def thu_muc_that(thu_muc=THU_MUC_MAC_DINH):
    thu_muc = (thu_muc or THU_MUC_MAC_DINH).strip()
    if thu_muc.startswith("//") and not bpy.data.filepath:
        return None
    return os.path.normpath(bpy.path.abspath(thu_muc))


def _ha_chia_min(vat, dem):
    for ob in vat:
        cu = dict(ob[KHOA_BAC]) if KHOA_BAC in ob.keys() else {}
        for m in ob.modifiers:
            if m.type != "SUBSURF" or m.render_levels <= 0:
                continue
            if m.name in cu:
                continue                   # da ha roi — khong ha chong
            cu[m.name] = m.render_levels
            m.render_levels -= 1
            dem["chia_min"] += 1
        if cu:
            ob[KHOA_BAC] = cu


def _nuong_mot(ob, dg_lay, ti_le, goc_phang):
    """Luoi moi da giam cua `ob` (chi ap hai Decimate, modifier khac tat)."""
    tat = []
    for m in ob.modifiers:
        if m.show_viewport:
            m.show_viewport = False
            tat.append(m)
    them = []
    try:
        d = ob.modifiers.new("DP_RAMchill_phang", "DECIMATE")
        d.decimate_type = "DISSOLVE"
        d.angle_limit = goc_phang
        d.delimit = {"NORMAL", "MATERIAL", "SEAM", "SHARP", "UV"}
        them.append(d)
        if ti_le < 1.0:
            d = ob.modifiers.new("DP_RAMchill_giam", "DECIMATE")
            d.ratio = ti_le
            d.use_collapse_triangulate = False
            them.append(d)
        dg = dg_lay()
        return bpy.data.meshes.new_from_object(
            ob.evaluated_get(dg), preserve_all_data_layers=True, depsgraph=dg)
    finally:
        for d in them:
            ob.modifiers.remove(d)
        for m in tat:
            m.show_viewport = True


def toi_uu(vat, ti_le=0.5, nguong=20000, ha_chia_min=True, giam_luoi=True,
           thu_muc=THU_MUC_MAC_DINH, bao_tien_do=None):
    """Toi uu luoi cua cac vat `vat`. Tra ve dict dem."""
    import math
    dem = {"chia_min": 0, "luoi": 0, "tg_truoc": 0, "tg_sau": 0,
           "shape_key": 0, "lien_ket": 0, "lech_hinh": 0, "khong_giam": 0,
           "file": ""}
    if ha_chia_min:
        _ha_chia_min(vat, dem)
    if not giam_luoi:
        return dem
    thu_abs = thu_muc_that(thu_muc)
    if thu_abs is None:
        raise ValueError("save the .blend first")
    tuong_doi = (thu_muc or THU_MUC_MAC_DINH).strip().startswith("//")

    trong = {ob.as_pointer() for ob in vat}
    ngoai = {}                               # luoi -> co vat NGOAI pham vi
    for ob in bpy.data.objects:
        if ob.type == "MESH" and ob.data is not None \
                and ob.as_pointer() not in trong and ob.users:
            ngoai[ob.data.as_pointer()] = True
    # ⛔ LUOI NAM DUOI CHIA MIN THI KHONG GIAM (do 18/09/2026, PN4): giam
    # luoi long ra tam giac / mat nhieu canh, chia min dung tren do cuc ton —
    # khung nhin 89 s, dinh RAM 4,5 -> 14,2 GB. Vat co chia min chi ha bac.
    co_chia_min = {o.data.as_pointer() for o in bpy.data.objects
                   if o.type == "MESH" and o.data is not None
                   and any(m.type in ("SUBSURF", "MULTIRES")
                           for m in o.modifiers)}
    viec, da = [], set()
    for ob in vat:
        me = ob.data if ob.type == "MESH" else None
        if (me is None or me.as_pointer() in da or KHOA_TEN in me.keys()
                or KHOA_TRONG in me.keys()):
            continue
        da.add(me.as_pointer())
        if _tam_giac(me) < nguong:
            continue
        if me.library is not None or ob.library is not None:
            dem["lien_ket"] += 1
            continue
        if me.shape_keys is not None:
            dem["shape_key"] += 1
            continue
        if me.as_pointer() in co_chia_min:
            dem["chia_min_luoi"] = dem.get("chia_min_luoi", 0) + 1
            continue
        viec.append((ob, me))

    ten_blend = os.path.splitext(os.path.basename(bpy.data.filepath))[0]
    file_goc = os.path.join(thu_abs, "%s_originals_%s.blend" % (
        ten_blend or "scene", time.strftime("%Y%m%d_%H%M%S")))
    ghi_ra, xoa, doi_ten = set(), [], []

    def dg_lay():
        # evaluated_depsgraph_get cap nhat lai theo modifier vua doi
        return bpy.context.evaluated_depsgraph_get()

    for i, (ob, me) in enumerate(viec):
        if bao_tien_do is not None:
            bao_tien_do(i, len(viec))
        moi = _nuong_mot(ob, dg_lay, ti_le, math.radians(GOC_PHANG))
        tg0, tg1 = _tam_giac(me), _tam_giac(moi)
        if tg1 >= tg0 * 0.98:
            bpy.data.meshes.remove(moi)
            dem["khong_giam"] += 1
            continue
        if _lech_hop(me, moi) > LECH_TOI_DA:
            bpy.data.meshes.remove(moi)
            dem["lech_hinh"] += 1
            continue
        # ⛔ GIU KHONG GIAN TEXTURE CUA LUOI GOC (do 18/09/2026, bantest:
        # 118/125 luoi moi tu tinh lai hop bao -> vat lieu dung toa do
        # Generated truot van, san go ra van KHAC han, 6,4% diem anh khac).
        loc, co = me.texspace_location.copy(), me.texspace_size.copy()
        moi.use_auto_texspace = False
        moi.texspace_location, moi.texspace_size = loc, co
        _dat_vat_lieu(moi, list(me.materials))
        moi[KHOA_VL] = [m.name if m else "" for m in me.materials]
        ten = me.name
        if ngoai.get(me.as_pointer()):
            # luoi dung chung voi vat ngoai pham vi: chi vat TRONG doi luoi
            for o in vat:
                if o.data == me:
                    o.data = moi
            moi[KHOA_TRONG] = ten
            moi.name = ten + "_opt"
        else:
            # ban sao KHONG vat lieu de ghi ra file rieng
            sao = me.copy()
            # khe de TRONG (khong keo vat lieu/anh ra file), chi so mat giu
            _dat_vat_lieu(sao, [None] * len(me.materials))
            sao.name = "DPRC_" + ten
            ghi_ra.add(sao)
            moi[KHOA_FILE] = _duong(file_goc, tuong_doi)
            moi[KHOA_TEN] = sao.name
            me.user_remap(moi)
            xoa.append(me)
            doi_ten.append((moi, ten))
        dem["luoi"] += 1
        dem["tg_truoc"] += tg0
        dem["tg_sau"] += tg1
    if ghi_ra:
        os.makedirs(thu_abs, exist_ok=True)
        bpy.data.libraries.write(file_goc, ghi_ra, fake_user=True,
                                 compress=True)
        dem["file"] = file_goc
    for s in ghi_ra:
        bpy.data.meshes.remove(s)
    for me in xoa:
        if me.users == 0:
            bpy.data.meshes.remove(me)
    for moi, ten in doi_ten:               # ten goc da trong: tra lai ten
        moi.name = ten
    return dem


def _duong(duong, tuong_doi):
    return bpy.path.relpath(duong) if tuong_doi else duong


def tra_ve_goc():
    """Tra lai chia min + luoi goc. (so_luoi, so_chia_min, so_hong)."""
    so_s = 0
    for ob in bpy.data.objects:
        if KHOA_BAC not in ob.keys():
            continue
        for ten, bac in dict(ob[KHOA_BAC]).items():
            m = ob.modifiers.get(ten)
            if m is not None and m.type == "SUBSURF":
                m.render_levels = int(bac)
                so_s += 1
        del ob[KHOA_BAC]
    so, hong = 0, 0
    theo_file = {}
    for me in list(bpy.data.meshes):
        if KHOA_TEN in me.keys() and KHOA_FILE in me.keys():
            theo_file.setdefault(bpy.path.abspath(me[KHOA_FILE]),
                                 []).append(me)
        elif KHOA_TRONG in me.keys():
            goc = bpy.data.meshes.get(me[KHOA_TRONG])
            if goc is None:
                hong += 1
                continue
            me.user_remap(goc)
            bpy.data.meshes.remove(me)
            so += 1
    for f, ds in theo_file.items():
        if not os.path.isfile(f):
            hong += len(ds)
            print("[DP_RAMchill] khong con file luoi goc:", f)
            continue
        can = [me[KHOA_TEN] for me in ds]
        with bpy.data.libraries.load(f, link=False) as (tu, toi):
            co = [t for t in can if t in set(tu.meshes)]
            toi.meshes = list(co)
        # sau khi nap, `toi.meshes` la datablock that, cung thu tu da xin
        nap = dict(zip(co, toi.meshes))
        for me in ds:
            goc = nap.get(me[KHOA_TEN])
            if goc is None:
                hong += 1
                continue
            goc.use_fake_user = False
            _dat_vat_lieu(goc, list(me.materials))
            ten = me.name
            me.user_remap(goc)
            bpy.data.meshes.remove(me)
            goc.name = ten
            so += 1
    return so, so_s, hong


def dong_bao_cao(dem):
    d = []
    if dem.get("luoi"):
        d.append("optimized %d meshes" % dem["luoi"])
        d.append("%s -> %s tris" % (format(dem["tg_truoc"], ",d"),
                                    format(dem["tg_sau"], ",d")))
    if dem.get("chia_min"):
        d.append("%d subdivisions -1 level" % dem["chia_min"])
    if not d:
        d.append("nothing to optimize")
    for khoa, chu in (("khong_giam", "%d meshes already light"),
                      ("chia_min_luoi", "%d under subdivision: level only")):
        if dem.get(khoa):
            d.append(chu % dem[khoa])
    for khoa, chu in (("shape_key", "! %d with shape keys kept"),
                      ("lien_ket", "! %d linked meshes kept"),
                      ("lech_hinh", "! %d would lose shape, kept")):
        if dem.get(khoa):
            d.append(chu % dem[khoa])
    return "\n".join(d)
