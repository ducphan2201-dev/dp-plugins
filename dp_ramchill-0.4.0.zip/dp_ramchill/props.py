# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
"""O nhap cua DP_RAMchill.

CHU TREN BANG LA TIENG ANH — addon ban ra. Ngoai le duy nhat la tooltip
cua o nhap: song ngu, tieng Anh truoc, tieng Viet CO DAU sau.

BON MOC KHOANG CACH DUNG `subtype="DISTANCE"`, va do la mot quyet dinh co
y. Nha DP co ba quy uoc don vi khac nhau — CAD la 1 unit = 1 mm, SketchUp
mang vao la 1 unit = 1 m, DP_sketch la 1 unit = 1 unit. Addon nay lat len
scene cua nguoi khac nen no KHONG DUOC DOAN. `DISTANCE` de Blender tu hien
so theo he don vi cua chinh file do; con muon dat cho dung thi bam nut
`Fit To Scene`, no DO chu khong doan.
"""

import bpy
from bpy.props import (BoolProperty, EnumProperty, FloatProperty,
                       IntProperty,
                       PointerProperty, StringProperty)
from bpy.types import PropertyGroup

from . import chinh_sach

# ⛔ DANH SACH NAY BAT DAU TU 512, khong phai tu 128. San cung cua Ducphan
# (`chinh_sach.SAN_TUYET_DOI`) chan o lop quyet dinh roi, nhung mot o chon
# van bay ra "256" thi nguoi dung chon 256, addon tra ve 512, va ho doc
# len la addon hong. Chan hai cua, va cua nay la cua nguoi dung nhin thay.
_CO_EP = tuple(
    (str(n), str(n), "%d px" % n)
    for n in (512, 1024, 2048, 4096)
    if n >= chinh_sach.SAN_TUYET_DOI
)


def _co_tuong_doi():
    """Co bao Blender o duong dan hieu tien to `//` (canh file .blend).

    ⛔ THIEU CO NAY THI O `Bake folder` LUON DO (do 14/09/2026, Blender 5.2,
    chup that bon ca): khong co -> `//DP_RAMchill_maps` DO ca khi thu muc da
    co, co hay khong dau `/` cuoi; duong dan tuyet doi khong do. Co co ->
    ca `//khong_co_thu_muc_nay` cung KHONG do. Tuc mau do KHONG phai "thu
    muc chua co" ma la Blender canh bao "o nay khong hieu `//`" - trong khi
    addon giai `//` dung (`nuong_map.thu_muc_that`). Mot o do ngay tu luc
    cai doc len la addon hong.
    Addon khai ho tro tu 4.2 - ban nao chua co co thi bo qua, o van dung
    duoc (chi to do nhu cu).
    """
    try:
        StringProperty(subtype="DIR_PATH",
                       options={"PATH_SUPPORTS_BLEND_RELATIVE"})
        return {"PATH_SUPPORTS_BLEND_RELATIVE"}
    except (TypeError, ValueError):
        return set()


class DPRAMCHILL_Props(PropertyGroup):

    che_do: EnumProperty(
        name="Mode",
        items=(
            (chinh_sach.CHE_DO_TAT, "Off",
             "Do nothing. Render uses every map at full size.\n"
             "Khong lam gi. Render dung moi map o co goc"),
            (chinh_sach.CHE_DO_TU_DONG, "Auto (distance + screen area)",
             "STILL IMAGES. Shrink each map by 1/2, 1/4, 1/6 or 1/8 - the "
             "step must be allowed by BOTH the distance ring AND the "
             "screen area it covers. Planned once, from the frame you are "
             "on.\n"
             "ANH TINH. Thu nho tung map theo bac 1/2, 1/4, 1/6, 1/8 - "
             "bac nao cung phai duoc CA HAI dieu kien cho phep: vanh "
             "khoang cach VA dien tich no chiem tren khung hinh. Ke hoach "
             "lap mot lan, o khung hinh dang dung"),
            (chinh_sach.CHE_DO_EP_CO, "Force one size",
             "Every map in the scene down to one size. This is the mode "
             "for ANIMATION: one size, every frame. Maps already smaller "
             "are left alone.\n"
             "Ep moi map trong scene ve mot co. Day la che do danh cho "
             "ANIMATION: mot co, dung cho moi khung hinh. Map von nho hon "
             "thi de yen"),
        ),
        default=chinh_sach.CHE_DO_TAT,
    )

    moc_tu_dong: BoolProperty(
        name="Fit rings to the scene", default=True,
        description="Measure how deep the scene actually is and place the "
                    "four rings on that spread, every scan. Turn off to "
                    "type your own distances.\n"
                    "Do xem canh sau bao nhieu roi tu dat bon moc theo do, "
                    "moi lan quet. Tat di de tu go so cua minh")

    moc_1: FloatProperty(
        name="1/2 beyond", default=chinh_sach.MOC_MAC_DINH[0], min=0.0,
        subtype="DISTANCE",
        description="Past this distance from the camera a map may drop to "
                    "1/2.\nQua khoang cach nay tinh tu camera, map duoc "
                    "phep ha xuong 1/2")
    moc_2: FloatProperty(
        name="1/4 beyond", default=chinh_sach.MOC_MAC_DINH[1], min=0.0,
        subtype="DISTANCE",
        description="Past this distance a map may drop to 1/4.\n"
                    "Qua khoang cach nay, map duoc phep ha xuong 1/4")
    moc_3: FloatProperty(
        name="1/6 beyond", default=chinh_sach.MOC_MAC_DINH[2], min=0.0,
        subtype="DISTANCE",
        description="Past this distance a map may drop to 1/6.\n"
                    "Qua khoang cach nay, map duoc phep ha xuong 1/6")
    moc_4: FloatProperty(
        name="1/8 beyond", default=chinh_sach.MOC_MAC_DINH[3], min=0.0,
        subtype="DISTANCE",
        description="Past this distance a map may drop to 1/8, the "
                    "smallest step.\nQua khoang cach nay, map duoc phep ha "
                    "xuong 1/8, bac nho nhat")

    du_phong: FloatProperty(
        name="Texels per pixel", default=chinh_sach.DU_PHONG_MAC_DINH,
        min=0.25, max=8.0, soft_min=1.0, soft_max=4.0, step=25, precision=2,
        description="Second condition: how many texels to keep for each "
                    "rendered pixel. 1.0 is exactly enough; raise it if "
                    "surfaces look soft.\n"
                    "Dieu kien thu hai: giu bao nhieu texel cho moi pixel "
                    "render. 1,0 la vua khit; thay be mat nhoe thi tang len")

    nguong_to: FloatProperty(
        name="Big on screen", default=chinh_sach.NGUONG_TO_MAC_DINH,
        min=0.01, max=1.0, subtype="FACTOR", precision=2,
        description="A map covering at least this much of the frame is "
                    "never shrunk past 1/2, whatever the two conditions "
                    "say.\n"
                    "Map phu tu ngan nay khung hinh tro len thi khong bao "
                    "gio bi ha qua 1/2, du hai dieu kien co dong y den may")

    san_duoi: IntProperty(
        name="Never below", default=chinh_sach.SAN_TUYET_DOI,
        min=chinh_sach.SAN_TUYET_DOI, max=4096,
        description="A map's long edge is never taken below this. A step "
                    "that would go under it backs off one step. 512 is a "
                    "hard floor - this can only be raised.\n"
                    "Canh lon cua map khong bao gio bi ha duoi muc nay. Bac "
                    "nao vuot qua thi lui lai mot bac. 512 la san cung - o "
                    "nay chi chinh LEN duoc")

    canh_ep: EnumProperty(
        name="Force to", items=_CO_EP, default="1024",
        description="Long edge every map is forced down to.\n"
                    "Canh lon ma moi map bi ep xuong")

    bo_qua: StringProperty(
        name="Keep at full size", default="",
        description="Image names to leave alone, separated by commas.\n"
                    "Ten cac anh de nguyen, cach nhau bang dau phay")

    thu_muc_nuong: StringProperty(
        name="Bake folder", default="//DP_RAMchill_maps", subtype="DIR_PATH",
        options=_co_tuong_doi(),
        description="Where Bake Smaller Maps writes the new files. // means "
                    "next to this .blend. Original files are never "
                    "overwritten.\n"
                    "Noi nut Bake ghi file moi. // la canh file .blend nay. "
                    "File goc khong bao gio bi ghi de")

    # DINH DANG BAN BAKE (Ducphan 18/09/2026) — dung cho CA HAI nut Bake.
    dinh_dang_nuong: EnumProperty(
        name="Format",
        items=(
            ("GIU", "Lossless (PNG)",
             "Keep every pixel: PNG, EXR stays EXR. Default.\n"
             "Giu tung pixel: PNG, EXR giu EXR. Mac dinh"),
            ("JPG", "JPG (.jpg)",
             "Write JPG files, much smaller on disk and in a packed .blend. "
             "RAM and VRAM stay the SAME - only a smaller size saves RAM. "
             "Maps with transparency and 16-bit/HDR maps stay lossless.\n"
             "Ghi file JPG, nhe hon nhieu tren dia va trong .blend packed. "
             "RAM va VRAM KHONG doi - chi giam co moi bot RAM. Map co trong "
             "suot va map 16 bit/HDR van giu khong mat du lieu"),
            ("JPEG", "JPEG (.jpeg)",
             "Same as JPG, with the .jpeg file extension.\n"
             "Giong JPG, duoi file .jpeg"),
        ),
        default="GIU")
    chat_luong: IntProperty(
        name="JPG Quality", default=90, min=50, max=100, subtype="PERCENTAGE",
        description="JPG quality. 90 looks the same as the original; lower "
                    "makes smaller files and blurrier maps.\n"
                    "Chat luong JPG. 90 nhin nhu ban goc; thap hon thi file "
                    "nho hon va map nhoe hon")

    # BAKE SELECTED (Ducphan 18/09/2026: "co nhung doi tuong rat nho can
    # giam map toi da"). ⛔ Co y DI DUOI san 512 cua Auto/Force — xem
    # `nuong_map.co_theo_canh`.
    canh_chon: EnumProperty(
        name="Max Size",
        items=tuple((str(n), "%d px" % n,
                     "Long edge of each map of the selected objects.\n"
                     "Canh lon cua moi map tren cac vat dang chon")
                    for n in (64, 128, 256, 512, 1024, 2048)) + (
            ("0", "Keep size",
             "Do not shrink - only change the file format.\n"
             "Khong thu nho - chi doi dinh dang file"),),
        default="256")

    # BO VAT NGOAI KHUNG (Ducphan 13/09/2026) - xem `ngoai_khung.py`. TAT SAN:
    # no ap cho MOI vat, ke ca tuong sau lung camera. 0.3.1: vat co bong co
    # the roi vao khung thi giu (`bong_khung.py`); cai gia con lai - phan
    # chieu - duoc noi thang trong tooltip.
    bo_ngoai_khung: BoolProperty(
        name="Leave Out Off-screen Objects", default=False,
        description="At render time, leave out every object that is outside "
                    "the camera frame AND farther than Keep Within - Cycles "
                    "does not build it and its maps are not loaded. An object "
                    "whose shadow could fall into the frame (lights, glowing "
                    "objects, sky, HDRI) is kept. Cost: a left-out object "
                    "shows in no reflection. Lights, glowing objects, scatter "
                    "sources and moving objects are always kept. Nothing is "
                    "left out when the camera or a light is animated.\n"
                    "Luc render, bo moi vat nam NGOAI khung camera VA xa hon "
                    "Keep Within - Cycles khong dung no, map cua no khong duoc "
                    "nap. Vat co bong co the roi vao khung (den, vat phat sang, "
                    "troi, HDRI) thi duoc giu. Cai gia: vat bi bo khong con "
                    "phan chieu. Den, vat phat sang, nguon ban rai va vat "
                    "chuyen dong luon duoc giu. Camera hay den co hoat hoa thi "
                    "khong bo vat nao")
    giu_gan: FloatProperty(
        name="Keep Within", default=10.0, min=0.0, subtype="DISTANCE",
        description="Objects nearer the camera than this are always rendered, "
                    "even outside the frame, so their reflections stay "
                    "(shadows are checked on their own).\n"
                    "Vat gan camera hon khoang nay luon duoc render, du ngoai "
                    "khung, de giu phan chieu cua no (bong da duoc hoi rieng)")

    # TU NHA RAM (chep tu DP_Optimize 18/09/2026) - xem `nha_ram.py`.
    nha_ram: BoolProperty(
        name="Hand Memory Back After Render", default=True,
        description="After every render, hand the memory Blender no longer "
                    "uses back to the system. In background renders, or "
                    "when the machine is low on RAM, image buffers are "
                    "dropped too (reloaded when needed). Nothing in the "
                    "scene changes.\n"
                    "Sau moi lan render, tra phan bo nho Blender khong con "
                    "dung ve cho he dieu hanh. Render nen, hoac may dang "
                    "thieu RAM, thi tha ca bo dem anh (can thi nap lai). "
                    "Khong doi gi trong scene")

    tha_persistent: BoolProperty(
        name="Free Kept Render Data", default=True,
        description="When Persistent Data is on, Blender keeps the whole "
                    "render scene in memory after a render (measured: 2.9 GB "
                    "on a real interior). Free it right after the render; "
                    "Persistent Data stays on. Cost: the NEXT render builds "
                    "the scene again. One animation render is not affected.\n"
                    "Khi bat Persistent Data, Blender giu ca canh render "
                    "trong bo nho sau khi render (do: 2,9 GB tren canh noi "
                    "that that). Tha no ngay sau render; o Persistent Data "
                    "van bat. Cai gia: lan render SAU dung lai canh. Mot lan "
                    "render hoat hinh khong bi anh huong")

    bao_cao: StringProperty(name="", default="")
    # bao cao RIENG cua Mesh Optimize — khong ghi de bao cao map (doc lap)
    bao_cao_luoi: StringProperty(name="", default="")
    # BANG BAO CAO Optimize Meshes (render thu truoc / sau) — `so_sanh_luoi`
    bc_co: BoolProperty(default=False)
    bc_thiet_bi: StringProperty(default="")
    bc_mem_truoc: FloatProperty(default=0.0)
    bc_mem_sau: FloatProperty(default=0.0)
    bc_giay_truoc: FloatProperty(default=0.0)
    bc_giay_sau: FloatProperty(default=0.0)
    bc_tg_truoc: FloatProperty(default=0.0)
    bc_tg_sau: FloatProperty(default=0.0)
    bc_px_khac: FloatProperty(default=-1.0)
    bc_tb_khac: FloatProperty(default=-1.0)


def dang_ky():
    bpy.utils.register_class(DPRAMCHILL_Props)
    bpy.types.Scene.dp_ramchill = PointerProperty(type=DPRAMCHILL_Props)


def go():
    del bpy.types.Scene.dp_ramchill
    bpy.utils.unregister_class(DPRAMCHILL_Props)
