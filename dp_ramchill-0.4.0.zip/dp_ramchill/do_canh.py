# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
"""Lop DO — quet scene ra so lieu cho `chinh_sach.py`.

Day la lop duy nhat biet ve hinh hoc. Voi moi tam anh no tra loi DUNG HAI
cau hoi, dung hai dieu kien Ducphan chot:

    1. Cho GAN NHAT ma tam anh nay xuat hien, cach ong kinh bao nhieu?
    2. O cho DOI HOI DO NET CAO NHAT, no trai bao nhieu texel len bao
       nhieu pixel man hinh?

Ca hai deu do tren TAM GIAC, khong phai tren hop bao vat the. Hop bao la
sai o dung cai truong hop hay gap nhat cua noi that: mot san go trai ca
phong thi hop bao cua no cham ong kinh, nhung goc xa cua no thi khong.

=========================================================================
BON DIEU LOP NAY CO Y LAM SAI VE MOT PHIA
=========================================================================
Doan sai theo huong GIU NHIEU hon la an toan (chi ton VRAM). Doan sai theo
huong HA NHIEU hon la anh mo, va nguoi dung khong bao gio doan ra thu phai
la addon nay. Nen o bon cho khong chac, no luon nga ve phia giu:

  ⛔ 0.3.3 (14/09/2026): dieu 1-3 ben duoi CHI con dung cho cac so "dinh"
  va khoang cach gan nhat. So QUYET DINH cua dieu kien 2 (`px_tong`,
  `texel_tong`) nay lay tu BAN DO NHIN THAY (`nhin_thay.py`): cat tam giac
  theo khung va theo mat phang gan, CO che khuat. Do tren canh that: map
  tuong PN4 "phu 45.751% khung" -> 0,0%; san da phong khach 82% -> 4,6%.
  Map khuat HET giu so cu. Camera khong phai phoi canh: van cach cu.

  1. Tam giac chi HE mot goc vao khung hinh van duoc tinh TRON dien tich.
     Cat cho dung thi phai xen da giac, dat ma loi it.
  2. Tam giac co MOT dinh sau ong kinh thi bo qua ca tam giac — vat the
     kieu do gan sat ong kinh, giu nguyen la dung.
  3. KHONG tinh che khuat. Tam anh nam sau buc tuong van duoc giu nguyen.
  4. Vat the AN TRONG VIEWPORT nhung HIEN khi render thi khong do duoc
     hinh hoc cua no — moi anh cua no bi danh dau "khong do duoc" va giu
     nguyen co. So luong duoc BAO CAO ra bang, khong nuot lang.

Va mot cho thu nam, la cho co the an tien nhat nhung chua dam lam: anh chi
nam tren vat the NGOAI KHUNG HINH van duoc giu nguyen co. Ly do la GUONG
va PHAN XA — mot cai tu sau lung ong kinh van hien trong mat kinh ban an.
So luong cung duoc dem va bao ra (`anh_ngoai_khung`).

=========================================================================
CACH CHIEU — VA VI SAO KHONG DUNG `world_to_camera_view`
=========================================================================
`bpy_extras.object_utils.world_to_camera_view` chay tren TUNG diem mot.
Mot scene noi that 2 trieu tam giac la 6 trieu lan goi python. O day dung
`Object.calc_matrix_camera()` lay thang ma tran chieu roi nhan ca mang
bang numpy — cung mot phep toan, mot lan goi.
"""

import numpy as np

import bpy

from . import nhin_thay

# Ten khong gian mau Blender dung cho map DU LIEU (khong phai mau nhin
# thay). Doc theo TEN chu khong theo `is_float`: mot map bump 8-bit cung
# la map noi.
_PHI_MAU = {"Non-Color", "Raw", "Linear", "Generic Data", "Data"}


def _ma_tran(scene, depsgraph, cam_obj, rw, rh):
    """(PV, V) — PV doi sang toa do cat, V doi sang toa do ONG KINH.

    Can ca hai: PV de biet mat nam dau tren khung hinh, V de biet no cach
    ong kinh bao xa (trong toa do ong kinh, ong kinh nam o goc toa do).

    ⛔ `calc_matrix_camera` nam tren OBJECT, khong nam tren Camera data.
    Go `cam.data.calc_matrix_camera(...)` chay tron loi cu phap, tron ca
    bo kiem python tran, va chi chet luc render tren may khach.
    """
    r = scene.render
    P = np.array(cam_obj.calc_matrix_camera(
        depsgraph, x=rw, y=rh,
        scale_x=r.pixel_aspect_x, scale_y=r.pixel_aspect_y),
        dtype=np.float64)
    V = np.array(cam_obj.matrix_world.inverted(), dtype=np.float64)
    return P @ V, V


def _do_phan_giai(scene):
    r = scene.render
    k = r.resolution_percentage / 100.0
    return max(1, int(r.resolution_x * k)), max(1, int(r.resolution_y * k))


# ---------------------------------------------------------------------------
# Vat lieu -> nhung tam anh no dung, kem he so keo UV cua node Mapping
# ---------------------------------------------------------------------------
def _he_so_mapping(nut, sau=0):
    """Di nguoc tu o Vector cua node anh, tim node Mapping gan nhat.

    Tra ve (sx, sy). Mapping keo UV len k lan thi tren MOT MAT co ngan ay
    lan lap map, tuc so texel trai ra tren mat do nhan len k*k. Bo qua khau
    nay la doc mot san go lat 20 vien thanh mot vien.
    """
    if sau > 8:
        return 1.0, 1.0
    o = nut.inputs.get("Vector")
    if o is None or not o.is_linked:
        return 1.0, 1.0
    tu = o.links[0].from_node
    if tu.bl_idname == "ShaderNodeMapping":
        s = tu.inputs.get("Scale")
        if s is not None and not s.is_linked:
            v = s.default_value
            return abs(v[0]) or 1.0, abs(v[1]) or 1.0
        return 1.0, 1.0
    return _he_so_mapping(tu, sau + 1)


def _anh_cua_cay(cay, da_qua, ra):
    if cay is None or cay in da_qua:
        return
    da_qua.add(cay)
    for nut in cay.nodes:
        if nut.bl_idname == "ShaderNodeTexImage" and nut.image is not None:
            ra.append((nut.image, _he_so_mapping(nut)))
        elif nut.bl_idname == "ShaderNodeGroup":
            _anh_cua_cay(nut.node_tree, da_qua, ra)


def anh_cua_vat_lieu(mat):
    """[(image, (sx, sy)), ...] — ke ca anh nam trong node group."""
    if mat is None or mat.node_tree is None:
        return []
    ra = []
    _anh_cua_cay(mat.node_tree, set(), ra)
    return ra


# ---------------------------------------------------------------------------
# Quet mot vat the
# ---------------------------------------------------------------------------
def _dien_tich_tam_giac(diem, chi_so):
    """Dien tich tung tam giac tu mang diem 2 chieu. chi_so: (n, 3)."""
    a = diem[chi_so[:, 0]]
    b = diem[chi_so[:, 1]]
    c = diem[chi_so[:, 2]]
    return 0.5 * np.abs((b[:, 0] - a[:, 0]) * (c[:, 1] - a[:, 1]) -
                        (c[:, 0] - a[:, 0]) * (b[:, 1] - a[:, 1]))


def _hop_bao_ngoai_khung(ob, mtx, PV, rw, rh):
    """Tam dinh hop bao co nam TRON ngoai khung hinh khong.

    Tra ve False khi khong dam chac — day la mot cua sang loc, va mot cua
    sang loc doan bua la mot vat the bien mat khoi phep do trong im lang.
    """
    try:
        bb = ob.bound_box
    except (AttributeError, RuntimeError):
        return False
    M = np.array(mtx, dtype=np.float64)
    d = np.ones((8, 4), dtype=np.float64)
    d[:, :3] = np.array(bb, dtype=np.float64)
    cat = d @ (PV @ M).T
    w = cat[:, 3]
    if not (w > 1e-9).all():
        return False                    # co dinh sau ong kinh -> khong dam
    x = ((cat[:, 0] / w) * 0.5 + 0.5) * rw
    y = ((cat[:, 1] / w) * 0.5 + 0.5) * rh
    return bool(x.max() < 0 or x.min() > rw or y.max() < 0 or y.min() > rh)


def _doc_thuoc_tinh(me, ten, mien, kieu, truong, ra):
    """Doc thuoc tinh `ten` cua luoi vao mang `ra` (dung kich thuoc).

    False = khong co / khac mien, khac kieu, khac so phan tu — nguoi goi doc
    kieu cu."""
    at = me.attributes.get(ten)
    if (at is None or at.domain != mien or at.data_type != kieu
            or len(at.data) * (3 if kieu == "FLOAT_VECTOR" else 1)
            != len(ra)):
        return False
    at.data.foreach_get(truong, ra)
    return True


def _mang_luoi(me):
    """Mang numpy cua mot luoi: (dinh thuan nhat (n,4), tri_v, tri_l, tri_m,
    uv theo loop hoac None). None neu luoi khong co tam giac.

    Tach ra de `_quet_mesh` va ban do nhin thay (`nhin_thay`) dung CHUNG mot
    lan doc — doc luoi la phan dat nhat cua ca lan quet."""
    try:
        me.calc_loop_triangles()
    except (AttributeError, RuntimeError):
        pass
    n_tri = len(me.loop_triangles)
    if n_tri == 0 or len(me.vertices) == 0:
        return None
    # ⛔ TOC DO (21/09/2026): doc vao mang float32 — DUNG kieu Blender luu
    # — roi moi doi sang float64. `foreach_get` vao mang float64 di duong
    # cham (doi tung phan tu): do tren luoi 550k dinh 48 ms -> 15 ms, uv
    # 49 ms -> 4 ms. float32 -> float64 la chinh xac, ra cung tung bit.
    # Doc dinh qua thuoc tinh `position` (cung du lieu voi `vertices.co`)
    # con nhanh hon: ca file bep khach 0,23 s -> 0,02 s.
    v = np.empty(len(me.vertices) * 3, dtype=np.float32)
    if not _doc_thuoc_tinh(me, "position", "POINT", "FLOAT_VECTOR", "vector",
                           v):
        me.vertices.foreach_get("co", v)
    thuan = np.empty((len(me.vertices), 4), dtype=np.float64)
    thuan[:, :3] = v.reshape(-1, 3)
    thuan[:, 3] = 1.0

    tri_l = np.empty(n_tri * 3, dtype=np.int32)
    me.loop_triangles.foreach_get("loops", tri_l)
    # ⛔ TOC DO (21/09/2026): `loop_triangles` tra `vertices` /
    # `material_index` qua RNA TUNG phan tu. Theo dinh nghia cua Blender
    # dinh tam giac = dinh cua goc (`.corner_vert`) tai `loops`, vat lieu tam
    # giac = vat lieu cua mat (`material_index`) chua no. Doc hai thuoc tinh
    # do (duong nhanh, mot khoi) roi gom bang numpy — do tren ca file bep
    # khach (1428 luoi, 14,4 trieu tam giac): 2,6 s -> 1,4 s va 1,35 s ->
    # 0,38 s, ra GIONG HET tung so tren moi luoi. Thieu thuoc tinh / khac
    # kieu thi doc kieu cu.
    cv = np.empty(len(me.loops), dtype=np.int32)
    if _doc_thuoc_tinh(me, ".corner_vert", "CORNER", "INT", "value", cv):
        tri_v = cv[tri_l]
    else:
        tri_v = np.empty(n_tri * 3, dtype=np.int32)
        me.loop_triangles.foreach_get("vertices", tri_v)
    tri_m = None
    at = me.attributes.get("material_index")
    if at is None:
        tri_m = np.zeros(n_tri, dtype=np.int32)    # Blender: khong co = 0
    else:
        pm = np.empty(len(me.polygons), dtype=np.int32)
        if _doc_thuoc_tinh(me, "material_index", "FACE", "INT", "value", pm):
            tp = np.empty(n_tri, dtype=np.int32)
            me.loop_triangle_polygons.foreach_get("value", tp)
            tri_m = pm[tp]
    if tri_m is None:
        tri_m = np.empty(n_tri, dtype=np.int32)
        me.loop_triangles.foreach_get("material_index", tri_m)

    lop = None
    for u in me.uv_layers:
        if u.active_render:
            lop = u
            break
    if lop is None and len(me.uv_layers):
        lop = me.uv_layers[0]
    uv = None
    if lop is not None:
        uv = np.empty(len(me.loops) * 2, dtype=np.float32)
        lop.uv.foreach_get("vector", uv)
        uv = uv.astype(np.float64).reshape(-1, 2)
    return thuan, tri_v.reshape(-1, 3), tri_l.reshape(-1, 3), tri_m, uv


def _quet_mesh(mang, cat, ong, rw, rh):
    """{chi_so_vat_lieu: (px_dinh, uv_dinh, kc, px_tong, uv_tong)}.

    `mang` = `_mang_luoi(me)`; `cat` / `ong` = dinh da nhan ma tran cat /
    ma tran ong kinh (nguoi goi tinh mot lan, dung chung voi ban do).

    NAM so, va chung tra loi BA cau hoi khac nhau — dung gop lai:

    `px_dinh`, `uv_dinh` — lay tu MOT tam giac: cai co ti so px/uv lon
        nhat, tuc CHO DOI HOI DO NET CAO NHAT. Tra ve ca hai so chu khong
        tra ve ti so, vi so texel con phu thuoc co tung tam anh — phep chia
        lam sau, o `chinh_sach.ti_le_can()`.

    `px_tong`, `uv_tong` — CONG DON tren moi tam giac co gop mat: tong
        dien tich vat lieu do chiem TREN KHUNG HINH, va tong dien tich cua
        chinh TAM ANH ma no bay ra. Ducphan chot 22/08/2026: dieu kien 2
        *"phai tinh toan dua so luong dien tich anh ma vat lieu hien thi
        nua"*. Mot tam giac dinh khong noi duoc chuyen do: mot san go co
        MOT o gan chan ong kinh va nghin o chay ve chan troi thi tam giac
        dinh chi ke ve cai o gan nhat.

    `kc` — dinh GAN NHAT trong so cac tam giac co gop mat.

    Ba nhom so nay co the den tu ba tam giac khac nhau, va do la dung.
    """
    _, tri_v, tri_l, tri_m, uv = mang
    if uv is None:
        return {}
    # = `np.linalg.norm(ong[:, :3], axis=1)` tung bit (cung thu tu cong),
    # khong qua phep rut gon truc dai 3 cham cua numpy
    kc_dinh = np.sqrt(ong[:, 0] * ong[:, 0] + ong[:, 1] * ong[:, 1] +
                      ong[:, 2] * ong[:, 2])

    w = cat[:, 3]
    truoc_ong_kinh = w > 1e-9
    w_an_toan = np.where(truoc_ong_kinh, w, 1.0)
    man = np.empty((cat.shape[0], 2), dtype=np.float64)
    man[:, 0] = ((cat[:, 0] / w_an_toan) * 0.5 + 0.5) * rw
    man[:, 1] = ((cat[:, 1] / w_an_toan) * 0.5 + 0.5) * rh

    # Dieu 2: bo ca tam giac neu co mot dinh sau ong kinh
    t_ok = truoc_ong_kinh[tri_v]
    du_dinh = t_ok[:, 0] & t_ok[:, 1] & t_ok[:, 2]

    # Nam tron ngoai khung hinh thi khong doi hoi gi, cung khong tinh
    # khoang cach — mot cai tu ngoai khung khong duoc ghim cho san trong
    # khung o muc "giu nguyen".
    # ⛔ TOC DO (21/09/2026): lay cot x / y cua dinh ROI moi gom theo tam
    # giac (ban cu gom ca `man[tri_v]` hai lan), va min/max ba cot bang
    # `np.minimum` — giong tung bit `.min(axis=1)` nhung nhanh hon nhieu.
    tx = man[:, 0][tri_v]
    ty = man[:, 1][tri_v]
    trong_khung = ~((nhin_thay._max3(tx) < 0) | (nhin_thay._min3(tx) > rw) |
                    (nhin_thay._max3(ty) < 0) | (nhin_thay._min3(ty) > rh))

    dung = du_dinh & trong_khung
    if not dung.any():
        return {}

    # Tu day chi con tam giac `dung` (giu thu tu cu). Tam giac ngoai `dung`
    # khong bao gio vao `chon` ben duoi, nen argmax / min / tong tren tap
    # con nay ra DUNG cac so cu — chi khoi tinh dien tich cho ca trieu tam
    # giac ngoai khung.
    chi = np.nonzero(dung)[0]
    tx, ty, tri_m = tx[chi], ty[chi], tri_m[chi]
    # = `_dien_tich_tam_giac(man, tri_v)` tren tap con, cung cong thuc
    dt_man = 0.5 * np.abs((tx[:, 1] - tx[:, 0]) * (ty[:, 2] - ty[:, 0]) -
                          (tx[:, 2] - tx[:, 0]) * (ty[:, 1] - ty[:, 0]))
    dt_uv = _dien_tich_tam_giac(uv, tri_l[chi])
    kc_tri = nhin_thay._min3(kc_dinh[tri_v[chi]])

    ok = (dt_uv > 1e-12) & (dt_man > 0.0)
    if not ok.any():
        return {}

    ti = np.where(ok, dt_man / np.maximum(dt_uv, 1e-12), -1.0)
    ra = {}
    for mi in np.unique(tri_m[ok]):
        chon = ok & (tri_m == mi)
        if not chon.any():
            continue
        k = int(np.argmax(np.where(chon, ti, -1.0)))
        # ⛔ HAI CACH DO KHOANG CACH, va chung khac nhau RAT XA tren file
        # that. Xem ghi chu dau file.
        #   `min`  — dinh gan nhat. Mot goc san sat chan ong kinh la ghim
        #            CA tam map san o 1/1, du 99% cai san nam tit dang xa.
        #   `w`    — trung binh CO TRONG SO theo dien tich tren khung hinh:
        #            phan nao chiem nhieu pixel thi tieng noi nang hon.
        dt = dt_man[chon]
        kc = kc_tri[chon]
        ra[int(mi)] = (float(dt_man[k]), float(dt_uv[k]),
                       float(kc.min()), float(dt.sum()),
                       float(dt_uv[chon].sum()),
                       # tra ve TONG kc*dien_tich chu khong tra ve trung
                       # binh: cong don qua nhieu vat the thi phai cong hai
                       # tong roi moi chia, khong duoc trung binh cua
                       # trung binh.
                       float((kc * dt).sum()))
    return ra


_LO = 200000        # tam giac moi lo do vao ban do — gioi han RAM tam
BAN_DO_CUOI = [None]   # (gw, gh, ma vat lieu tung o, ten anh tung ma)


def _cho_ban_do(ban_do, ob, mang, cat, w_gan, khe_anh, vl_ma, vl_anh,
                xuyen_nho):
    """Do MOT vat vao ban do nhin thay (`nhin_thay.BanDo`).

    Moi vat lieu co map mot MA; mot tam anh dung hai lan trong cung vat
    lieu (hai node) chi tinh MOT lan, voi he so Mapping NHO nhat (cho doi
    hoi nhieu texel nhat) — cong hai lan la dem doi pixel cua no.
    """
    _, tri_v, tri_l, tri_m, uv = mang
    so_khe = len(ob.material_slots)
    T = len(tri_m)
    if so_khe:
        ma = np.full(so_khe, -1, dtype=np.int64)
        xu = np.zeros(so_khe, dtype=bool)
        for mi, khe in enumerate(ob.material_slots):
            m = khe.material
            xu[mi] = nhin_thay.nhin_xuyen(m, xuyen_nho)
            ds = khe_anh.get(mi)
            if not ds:
                continue
            k = m.as_pointer()
            if k not in vl_ma:
                bang = {}
                for img, (sx, sy) in ds:
                    k_uv = sx * sy
                    if img.name not in bang or k_uv < bang[img.name]:
                        bang[img.name] = k_uv
                vl_ma[k] = len(vl_anh)
                vl_anh.append(bang)
            ma[mi] = vl_ma[k]
        tm = np.clip(tri_m, 0, so_khe - 1)
        ma_tri, xu_tri = ma[tm], xu[tm]
    else:
        ma_tri = np.full(T, -1, dtype=np.int64)
        xu_tri = np.zeros(T, dtype=bool)
    # ⛔ TOC DO (21/09/2026): bo TRUOC tam giac ca ba dinh truoc mat phang
    # gan ma nam tron ngoai khung. `cat_gan` tra nguyen cac tam giac do, va
    # `BanDo.them` loai chung o buoc dau (`ok`) bang DUNG phep tinh X, Y
    # nay (cung w, cung thu tu phep toan) — chung khong rut so ngau nhien,
    # khong ghi gi. Bo som thi khoi gom (T,3,4) va cat cho ca trieu tam
    # giac ngoai khung. Van cat lo theo DUNG ranh `_LO` cu: so ngau nhien
    # rut theo tung lan goi `them`, doi ranh lo la doi mau.
    rw, rh = ban_do.rw, ban_do.rh
    wv = cat[:, 3]
    truoc = wv >= w_gan
    w1 = np.where(truoc, wv, 1.0)
    xv = (cat[:, 0] / w1 * 0.5 + 0.5) * rw
    yv = (cat[:, 1] / w1 * 0.5 + 0.5) * rh
    for s in range(0, T, _LO):
        e = min(T, s + _LO)
        tv = tri_v[s:e]
        t3 = truoc[tv]
        tx, ty = xv[tv], yv[tv]
        bo = (t3[:, 0] & t3[:, 1] & t3[:, 2]) & (
            (nhin_thay._max3(tx) < 0) | (nhin_thay._min3(tx) > rw) |
            (nhin_thay._max3(ty) < 0) | (nhin_thay._min3(ty) > rh))
        if bo.all():
            continue
        giu = np.nonzero(~bo)[0] + s
        tv = tri_v[giu]
        U = uv[tri_l[giu]] if uv is not None else np.zeros((len(giu), 3, 2))
        C, Ut, goc = nhin_thay.cat_gan(cat[tv], U, w_gan)
        if len(C):
            ban_do.them(C, Ut, ma_tri[giu][goc], xu_tri[giu][goc],
                        uv is not None)


def _co_goc(ten):
    """Co goc (w, h) cua mot tam DANG BI HA boi `doi_co`, hay None."""
    from . import doi_co
    return doi_co._TRUOC.get(ten)


# con tro anh -> (dau anh, (w, h, so_kenh, la_float)) — xem `_thong_so_anh`
_THONG_SO_ANH = {}


def _thong_so_anh(img, da_nap):
    """(w, h, so_kenh, la_float) cua mot tam anh, doc tu chinh tam anh.

    ⛔ TOC DO (21/09/2026): hoi `size` (va `channels` / `is_float`) la
    Blender NAP CA TAM ANH. Quet xong lai tha bo dem (xem duoi), nen MOI lan
    quet nap lai tu dau: do tren file bep khach (256 anh) 7-9 s moi camera
    — gan nua lan quet. Bon so nay chi phu thuoc FILE anh, nen nho lai theo
    dau file cua `doi_co._van_anh` (ten, nguon, duong dan, ngay sua + dung
    luong tren dia, dung luong goi packed — khong nap anh) cong khong gian
    mau / alpha / half. Chi DUNG so nho cho tam CHUA NAP (tam da nap hoi
    thang, re) va chi NHO khi tam khong dang sua. Lan quet dau cua phien van
    nap nhu cu; tu camera thu hai tro di thi khoi.
    """
    from . import doi_co
    try:
        k = (doi_co._van_anh(img), img.colorspace_settings.name,
             img.alpha_mode, bool(getattr(img, "use_half_precision", False)))
    except (AttributeError, TypeError, ValueError, ReferenceError):
        k = None
    p = img.as_pointer()
    if k is not None and not da_nap:
        nho = _THONG_SO_ANH.get(p)
        if nho is not None and nho[0] == k:
            return nho[1]
    so = (img.size[0], img.size[1], img.channels or 4, img.is_float)
    if k is not None and not img.is_dirty:
        _THONG_SO_ANH[p] = (k, so)
    return so


# ---------------------------------------------------------------------------
def quet_scene(context):
    """Quet ca scene. Tra ve (danh_sach_anh, ghi_chu).

    `danh_sach_anh` la dau vao dung khuon cua `chinh_sach.quyet_dinh()`.
    `ghi_chu` dem nhung cho phep do PHAI BO QUA — bang se noi ra, khong
    nuot lang.
    """
    scene = context.scene
    ghi_chu = {"khong_co_camera": False, "an_viewport_hien_render": 0,
               "vat_the_da_quet": 0, "tam_giac": 0,
               "anh_khong_tren_mat": 0, "anh_ngoai_khung": 0,
               "bo_qua_khong_map": 0, "bo_qua_ngoai_khung": 0}

    doi_hoi = {}          # ten anh -> [px_man, uv_hieu_dung, khoang_cach]
    tren_mat = set()      # ten anh -> co nam tren mot vat the nao khong
    thay = {}             # ten anh -> [px nhin thay, dt UV, tong sau*px]

    px_khung = None
    cam = scene.camera
    if cam is None or cam.type != "CAMERA":
        ghi_chu["khong_co_camera"] = True
    else:
        depsgraph = context.evaluated_depsgraph_get()
        rw, rh = _do_phan_giai(scene)
        px_khung = rw * rh
        ghi_chu["khung_px"] = px_khung
        PV, V = _ma_tran(scene, depsgraph, cam, rw, rh)

        # Dieu 4: vat the an trong viewport ma van render thi khong co
        # hinh hoc da danh gia de do -> bao ve moi anh cua no.
        hien = {inst.object.original for inst in depsgraph.object_instances
                if inst.object is not None}
        can_bao_ve = set()
        for ob in scene.objects:
            if ob.type != "MESH" or ob.hide_render or ob in hien:
                continue
            ghi_chu["an_viewport_hien_render"] += 1
            for khe in ob.material_slots:
                for img, _ in anh_cua_vat_lieu(khe.material):
                    can_bao_ve.add(img.name)

        # BAN DO NHIN THAY (0.3.3, `nhin_thay.py`): chi cho camera PHOI
        # CANH — ong kinh truc giao / toan canh thi do sau khong phai w, va
        # lop nay lui ve cach do cu.
        ban_do = None
        w_gan = 1e-6
        if getattr(cam.data, "type", "") == "PERSP":
            ban_do = nhin_thay.BanDo(rw, rh)
            w_gan = max(1e-6, float(cam.data.clip_start))
        vl_ma = {}            # con tro vat lieu -> ma tren ban do
        vl_anh = []           # ma -> {ten anh: k_uv}
        xuyen_nho = {}

        for inst in depsgraph.object_instances:
            ob = inst.object
            if ob is None or ob.type != "MESH" or ob.original.hide_render:
                continue
            me = ob.data
            if me is None or not len(me.polygons):
                continue

            # ⛔ HAI CUA SANG LOC RE, DAT TRUOC MOI PHEP TINH DAT.
            # Chung khong lam ket qua khac di mot chut nao — chung chi
            # khong lam nhung viec cho ra so 0. Ducphan render BATCH, moi
            # tam anh mot lan quet, nen giay o day nhan len hang tram lan.
            #
            # Cua 1: vat lieu khong co tam anh nao thi hinh hoc cua no
            # khong tra loi cau hoi nao ca — TRU cau "no che cai gi": vat
            # khong map (tuong son, tran) van phai vao ban do nhin thay.
            khe_anh = {}
            co_anh = False
            for mi, khe in enumerate(ob.material_slots):
                khe_anh[mi] = anh_cua_vat_lieu(khe.material)
                if khe_anh[mi]:
                    co_anh = True
                for img, _ in khe_anh[mi]:
                    tren_mat.add(img.name)
            if not co_anh:
                ghi_chu["bo_qua_khong_map"] += 1
                if ban_do is None:
                    continue

            # Cua 2: hop bao nam tron ngoai khung hinh. Tam giac trong mot
            # hop bao ngoai khung thi cung ngoai khung — nen tam giac nao
            # cung se bi loai o `trong_khung`, chi la loai SAU khi da chieu
            # het ca trieu dinh. Tam dinh cua hop bao la du de biet truoc.
            #
            # Chi dam ket luan khi CA TAM dinh deu truoc ong kinh: mot dinh
            # sau ong kinh la phep chia cho w doi dau, va hop bao "ngoai
            # khung" co the dang om lay ca man hinh.
            if _hop_bao_ngoai_khung(ob, inst.matrix_world, PV, rw, rh):
                if co_anh:
                    ghi_chu["bo_qua_ngoai_khung"] += 1
                continue

            mang = _mang_luoi(me)
            if mang is None:
                continue
            M = np.array(inst.matrix_world, dtype=np.float64)
            cat = mang[0] @ (PV @ M).T                # toa do cat

            if ban_do is not None and getattr(ob.original, "visible_camera",
                                              True):
                _cho_ban_do(ban_do, ob, mang, cat, w_gan, khe_anh, vl_ma,
                            vl_anh, xuyen_nho)
            if not co_anh:
                continue

            ghi_chu["vat_the_da_quet"] += 1
            ghi_chu["tam_giac"] += len(mang[3])

            ong = mang[0] @ (V @ M).T                 # toa do ong kinh
            for mi, (px, uv_dt, kc, px_t, uv_t, kcdt) in _quet_mesh(
                    mang, cat, ong, rw, rh).items():
                for img, (sx, sy) in khe_anh.get(mi, ()):
                    # Mapping keo UV k lan -> mat trai ra k*k lan so texel
                    k_uv = sx * sy
                    uv_hd = uv_dt * k_uv
                    cu = doi_hoi.get(img.name)
                    if cu is None:
                        doi_hoi[img.name] = [px, uv_hd, kc,
                                             px_t, uv_t * k_uv, kcdt]
                    else:
                        # doi hoi do net: giu tam giac co px/uv lon nhat
                        if px * cu[1] > cu[0] * uv_hd:
                            cu[0], cu[1] = px, uv_hd
                        # khoang cach gan nhat: giu cho GAN NHAT
                        if kc < cu[2]:
                            cu[2] = kc
                        # tong dien tich va tong kc*dien_tich: CONG DON
                        cu[3] += px_t
                        cu[4] += uv_t * k_uv
                        cu[5] += kcdt

        if ban_do is not None:
            # de `tools/soi_auto.py` ve lai ban do canh anh render (chi luoi
            # ma vat lieu ~1 MB, thay o lan quet sau)
            BAN_DO_CUOI[0] = (ban_do.gw, ban_do.gh, ban_do.zk.copy(),
                              [sorted(b) for b in vl_anh])
            for ma, (so_o, tong_md, tong_d) in ban_do.ket_qua().items():
                for ten, k_uv in vl_anh[ma].items():
                    x = thay.setdefault(ten, [0.0, 0.0, 0.0])
                    x[0] += so_o * ban_do.px_o            # pixel nhin thay
                    x[1] += tong_md * ban_do.px_o * k_uv  # dien tich UV tren do
                    x[2] += tong_d * ban_do.px_o          # tong do sau * pixel
            ghi_chu["ban_do"] = "%dx%d" % (ban_do.gw, ban_do.gh)

        for ten in can_bao_ve:
            doi_hoi.pop(ten, None)
            thay.pop(ten, None)

    ra = []
    for img in bpy.data.images:
        if img.type != "IMAGE":
            continue
        # ⛔ HOI CO ANH LA NAP CA TAM ANH VAO RAM, va neu khong tha ra thi
        # mot lan quet giu MOI tam o co goc cung luc. Do 12/09/2026 tren
        # canh nhap tu .max (381 anh, 1,67 ti diem anh): quet cu vuot tran
        # 6 GB roi Blender chet giua chung; tha bo dem cua tam nao TRUOC DO
        # CHUA NAP thi ca lan quet dung yen o 1,5 GB, het 17 giay. Tam da
        # nap san (viewport dang dung, dang sua) thi de nguyen.
        da_nap = img.has_data
        # ⛔ TAM DANG BI HA (giu qua cac lan render lien nhau — xem
        # `doi_co._hen_tra`) PHAI TINH THEO CO GOC. Hoi `img.size` luc nay ra
        # co NHO, ke hoach tinh texel tren co nho va lan ha sau con ha tiep.
        # `scale()` con bat co `is_dirty`, nen phai coi no la "sua duoc".
        goc = _co_goc(img.name)
        w, h, so_kenh, la_float = _thong_so_anh(img, da_nap)
        if goc is not None:
            w, h = goc
        if (not da_nap and not img.is_dirty
                and getattr(img, "buffers_free", None) is not None):
            img.buffers_free()
        if w <= 0 or h <= 0:
            continue
        # Anh PACKED sua duoc: `doi_co._tra_lai_packed` tra no ve bang
        # `buffers_free()`, tuc nap lai tu chinh GOI PACKED chu khong tu
        # dia. Dieu kien duy nhat la Blender phai co ham do.
        sua_duoc = (img.source == "FILE"
                    and (goc is not None or not img.is_dirty)
                    and not (img.packed_file
                             and getattr(img, "buffers_free", None) is None))
        d = doi_hoi.get(img.name)
        t = thay.get(img.name)
        so_texel = w * h
        nguon_do = None
        if d is None and not (t and t[0] > 0):
            px_man = texel_co = kc = px_tong = texel_tong = kc_w = None
            if img.name in tren_mat:
                ghi_chu["anh_ngoai_khung"] += 1
            else:
                ghi_chu["anh_khong_tren_mat"] += 1
        else:
            if d is not None:
                px_man = d[0]
                texel_co = d[1] * so_texel
                kc = d[2]
                px_tong = d[3]
                texel_tong = d[4] * so_texel
                # trung binh co trong so theo dien tich: cong hai TONG roi
                # chia
                kc_w = (d[5] / d[3]) if d[3] > 0 else d[2]
                nguon_do = "tam_giac"
            if t and t[0] > 0:
                # ⛔ BAN DO NHIN THAY THANG: pixel THAT (cat theo khung, co
                # che khuat) va texel tren chinh cac pixel do. Map khuat HET
                # (t rong) giu so cu o tren — khong doi hanh vi cua no.
                px_tong = t[0]
                texel_tong = t[1] * so_texel
                kc_w = t[2] / t[0]
                if d is None:
                    # mat chi co tam giac chay ra sau lung ong kinh — cach
                    # cu khong do duoc, ban do do duoc
                    px_man = texel_co = None
                    kc = kc_w
                nguon_do = "ban_do"
        ra.append({
            "nguon_do": nguon_do,
            "ten": img.name,
            "w": w,
            "h": h,
            "so_kenh": so_kenh,
            "byte_kenh": 4 if la_float else 1,
            # `khoang_cach` la cai dung de xep vanh: trung binh CO TRONG SO
            # theo dien tich. `khoang_cach_min` giu lai de doi chieu.
            "khoang_cach": kc_w,
            "khoang_cach_min": kc,
            # cho doi hoi do net cao nhat — MOT tam giac
            "px_man": px_man,
            "texel_co": texel_co,
            # tong tren moi tam giac co gop mat vao khung hinh
            "px_tong": px_tong,
            "texel_tong": texel_tong,
            # de tinh "map nay phu bao nhieu phan khung hinh"
            "px_khung": px_khung,
            # map NOI (bump/normal/roughness) — Blender danh dau bang
            # colorspace "Non-Color". Xem `chinh_sach.TRAN_PHI_MAU`.
            "phi_mau": img.colorspace_settings.name in _PHI_MAU,
            "sua_duoc": sua_duoc,
            # UDIM: `img.size` chi la co MOT o, Cycles nap moi o.
            "so_o": (len(img.tiles) if img.source == "TILED"
                     and len(img.tiles) else 1),
            # bo dem anh cua Cycles khong an anh packed - xem
            # `chinh_sach.quyet_dinh(de_cho_tx=...)`
            "packed": bool(img.packed_file),
        })
    return ra, ghi_chu
