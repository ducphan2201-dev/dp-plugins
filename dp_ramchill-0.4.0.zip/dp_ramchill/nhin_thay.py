# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
"""BAN DO NHIN THAY — o nao cua khung hinh thay mat nao (0.3.3).

=========================================================================
VI SAO CO LOP NAY
=========================================================================
Ducphan 14/09/2026: *"toi uu tiep viec auto resize map theo cam"*.

Dieu kien 2 cua Auto (`chinh_sach`) hoi: map nay trai bao nhieu texel len
bao nhieu PIXEL cua khung hinh. Ban cu (`do_canh._quet_mesh`) cong dien
tich man hinh cua TUNG tam giac, va do 13/09/2026 tren hai canh that cua
Ducphan thi con so do SAI XA:

  * tam giac chi he mot goc vao khung van tinh TRON dien tich — mat gan ong
    kinh (tuong, san, o cua) chieu ra man hinh rong gap tram lan khung:
    map tuong PN4 "phu 45.751% khung", mat tu 859%, anh thanh pho ngoai
    cua so 212%. Map "phu kin khung" thi bi GIU NGUYEN (tran 1/1);
  * KHONG tinh che khuat: san da phong khach "phu 82%" trong khi tam tham
    long che gan het (do lai: 4,6%);
  * tam giac co MOT dinh sau lung ong kinh bi bo CA tam — san, tuong chay
    ra sau lung khong duoc do.

Hau qua: Auto khong ha duoc tam nao o phong khach (0/28), trong khi ve that
cho thay ha duoc ma mat khong phan biet.

=========================================================================
CACH LAM — ban do do sau o do phan giai thap, tinh bang numpy
=========================================================================
Luoi `LUOI_NGANG` o theo chieu ngang (480 -> moi o 6x6 px o 2880x1620).
Moi o giu mat GAN NHAT. Tam giac:
  * cat theo mat phang gan (w >= clip_start) — noi suy tuyen tinh trong
    khong gian cat la dung, khong bo tam giac nao;
  * nho / vua: lay mau ngau nhien (hat giong co dinh -> hai lan quet ra
    cung mot so), ~`MAU_MOI_O` mau moi o;
  * to (> `TO` o): ve dung tung o trong hop bao giao khung.
Vat lieu NHIN XUYEN (kinh, alpha, khuc xa) khong che — thu phia sau van
duoc dem la thay. Khong gap duoc gia tri thi coi la nhin xuyen: nga ve
phia GIU map, khong bao gio ve phia ha.

MAT DO TEXEL TUNG DIEM: tren mot mat phang, texel/pixel ti le voi d^3 (d =
do sau). Trung binh cua d^3 tren dien tich MAN HINH cua tam giac (1/d
tuyen tinh tren man hinh) BANG DUNG d0*d1*d2 — nen
    mat_do(p) = (dt_uv / dt_man) * d(p)^3 / (d0*d1*d2)
khong xap xi, va cong lai tren ca tam giac ra dung dt_uv.

RAM: bo dem cong DON theo tung vat (moi o chi giu mat gan nhat), khong giu
moi mau — RAM them co dinh theo so o (~130.000 o), khong theo so tam giac.
Chi mau cua vat lieu nhin xuyen duoc giu lai den cuoi (thuong it: kinh).

⛔ LOP NAY KHONG DOI LUAT. Luat chon bac van la `chinh_sach.quyet_dinh`
(TONG, du_phong, tran map noi, tran "to tren khung", san 512). Lop nay chi
thay HAI SO dau vao: `px_tong` (pixel NHIN THAY that) va `texel_tong` (so
texel tren chinh cac pixel do). Map khuat HET thi `do_canh` giu so cu.
"""

import numpy as np

LUOI_NGANG = 480
MAU_MOI_O = 4.0
TO = 64.0

# ---------------------------------------------------------------------------
# Vat lieu nhin xuyen — tinh cho TIA CAMERA
# ---------------------------------------------------------------------------
_XUYEN = {"ShaderNodeBsdfTransparent", "ShaderNodeBsdfGlass",
          "ShaderNodeBsdfRefraction", "ShaderNodeHoldout"}

# ⛔ LIGHT PATH TINH DUNG CHO TIA CAMERA. Nhom `Max_Material` cua bo nhap
# .max tron Principled voi Transparent bang he so
# `max(Is Shadow Ray, Is Diffuse Ray) * Refract Level` — tia camera thi he
# so = 0, mat DAC. Ban thu dau coi moi nhom la "khong biet -> nhin xuyen" va
# 604/612 mat PN4 thanh trong suot: anh thanh pho ngoai cua so "thang" ca
# tuong, rem, tu ao (13/09/2026, xem LESSONS §21).
_TIA_CAMERA = {"Is Camera Ray": 1.0, "Is Shadow Ray": 0.0,
               "Is Diffuse Ray": 0.0, "Is Glossy Ray": 0.0,
               "Is Singular Ray": 0.0, "Is Reflection Ray": 0.0,
               "Is Transmission Ray": 0.0, "Is Volume Scatter Ray": 0.0,
               "Ray Depth": 0.0, "Diffuse Depth": 0.0, "Glossy Depth": 0.0,
               "Transparent Depth": 0.0, "Transmission Depth": 0.0}
_SAU_TOI_DA = 40


def _lien(sock):
    """(node, o ra) noi vao o nay, xuyen reroute. None = khong noi."""
    if not sock.is_linked:
        return None
    l = sock.links[0]
    if l.is_muted:
        return None
    n, s = l.from_node, l.from_socket
    while n.type == "REROUTE":
        if not n.inputs[0].is_linked:
            return None
        l = n.inputs[0].links[0]
        n, s = l.from_node, l.from_socket
    return n, s


def _ra_nhom(cay):
    ra = [n for n in cay.nodes if n.bl_idname == "NodeGroupOutput"]
    return next((n for n in ra if n.is_active_output), ra[0] if ra else None)


def _o_ngoai(nhom, ra):
    """O vao cua node group ben ngoai ung voi mot o ra cua Group Input."""
    if not nhom:
        return None
    return next((i for i in nhom[-1].inputs if i.identifier == ra.identifier),
                None)


def _so(sock, nhom, sau=0):
    """Gia tri HANG cua mot o vao duoi tia camera; None = khong gap duoc."""
    if sau > _SAU_TOI_DA:
        return None
    x = _lien(sock)
    if x is None:
        if sock.is_linked and not sock.links[0].is_muted:
            return None                  # reroute cut dau: khong biet
        v = getattr(sock, "default_value", None)
        if v is None:
            return None
        try:
            return float(v)
        except TypeError:
            try:
                return float(sum(v[:3])) / 3.0
            except TypeError:
                return None
    n, ra = x
    b = n.bl_idname
    if b == "NodeGroupInput":
        o = _o_ngoai(nhom, ra)
        return None if o is None else _so(o, nhom[:-1], sau + 1)
    if b == "ShaderNodeValue":
        return float(ra.default_value)
    if b == "ShaderNodeLightPath":
        return _TIA_CAMERA.get(ra.name)
    if b == "ShaderNodeGroup" and n.node_tree is not None:
        go = _ra_nhom(n.node_tree)
        i = None if go is None else next(
            (s for s in go.inputs if s.identifier == ra.identifier), None)
        return None if i is None else _so(i, nhom + [n], sau + 1)
    if b == "ShaderNodeMath":
        a = _so(n.inputs[0], nhom, sau + 1)
        c = _so(n.inputs[1], nhom, sau + 1) if len(n.inputs) > 1 else None
        op = n.operation
        if op == "MULTIPLY" and (a == 0.0 or c == 0.0):
            v = 0.0
        elif a is None or (c is None and op != "ABSOLUTE"):
            return None
        elif op == "ADD":
            v = a + c
        elif op == "SUBTRACT":
            v = a - c
        elif op == "MULTIPLY":
            v = a * c
        elif op == "DIVIDE":
            v = a / c if c else 0.0
        elif op == "MAXIMUM":
            v = max(a, c)
        elif op == "MINIMUM":
            v = min(a, c)
        elif op == "GREATER_THAN":
            v = 1.0 if a > c else 0.0
        elif op == "LESS_THAN":
            v = 1.0 if a < c else 0.0
        elif op == "ABSOLUTE":
            v = abs(a)
        else:
            return None
        return min(1.0, max(0.0, v)) if n.use_clamp else v
    return None


def _shader_xuyen(x, nhom, sau=0):
    """Shader (node, o ra) nay co cho TIA CAMERA di xuyen khong."""
    if x is None or sau > _SAU_TOI_DA:
        return False
    n, ra = x
    b = n.bl_idname
    if b in _XUYEN:
        return True
    if b == "NodeGroupInput":
        o = _o_ngoai(nhom, ra)
        if o is None:
            return True                  # khong biet: nga ve phia giu map
        return _shader_xuyen(_lien(o), nhom[:-1], sau + 1)
    if b == "ShaderNodeGroup":
        if n.node_tree is None:
            return False
        go = _ra_nhom(n.node_tree)
        i = None if go is None else next(
            (s for s in go.inputs if s.identifier == ra.identifier), None)
        return i is not None and _shader_xuyen(_lien(i), nhom + [n], sau + 1)
    if b == "ShaderNodeBsdfPrincipled":
        for ten, nguong, lon in (("Transmission Weight", 0.01, True),
                                 ("Alpha", 0.99, False)):
            s = n.inputs.get(ten)
            if s is None:
                continue
            v = _so(s, nhom)
            if v is None or (lon and v > nguong) or (not lon and v < nguong):
                return True
        return False
    if b == "ShaderNodeMixShader":
        f = _so(n.inputs[0], nhom)
        a = _shader_xuyen(_lien(n.inputs[1]), nhom, sau + 1)
        c = _shader_xuyen(_lien(n.inputs[2]), nhom, sau + 1)
        if f is None:
            return a or c
        return (a and f < 0.99) or (c and f > 0.01)
    if b == "ShaderNodeAddShader":
        return (_shader_xuyen(_lien(n.inputs[0]), nhom, sau + 1)
                or _shader_xuyen(_lien(n.inputs[1]), nhom, sau + 1))
    return False


def nhin_xuyen(mat, bo_nho=None):
    """Tia camera co di xuyen mat mang vat lieu nay khong (kinh, alpha...).

    `bo_nho`: dict dung chung trong MOT lan quet (khong giu qua lan quet —
    nguoi dung sua vat lieu giua hai lan render)."""
    if mat is None:
        return False
    k = mat.as_pointer()
    if bo_nho is not None and k in bo_nho:
        return bo_nho[k]
    ra = False
    if mat.use_nodes and mat.node_tree is not None:
        outs = [n for n in mat.node_tree.nodes
                if n.bl_idname == "ShaderNodeOutputMaterial"
                and n.target in ("ALL", "CYCLES")]
        out = next((n for n in outs if n.is_active_output),
                   outs[0] if outs else None)
        if out is not None and "Surface" in out.inputs:
            ra = _shader_xuyen(_lien(out.inputs["Surface"]), [])
    if bo_nho is not None:
        bo_nho[k] = ra
    return ra


# ---------------------------------------------------------------------------
# Cat tam giac theo mat phang gan
# ---------------------------------------------------------------------------
def cat_gan(C, U, w_gan):
    """C: (T,3,4) toa do cat, U: (T,3,2) uv. Bo phan w < w_gan.

    Tra ve (C, U, goc) — `goc` la chi so tam giac goc cua tung manh."""
    trong = C[:, :, 3] >= w_gan
    # ⛔ TOC DO (21/09/2026): `sum(axis=1)` tren truc dai 3 cua numpy CHAM
    # hon cong ba cot nhieu lan; ket qua nguyen giong het (so nguyen).
    n = (trong[:, 0].astype(np.int64) + trong[:, 1]) + trong[:, 2]
    goc = np.arange(C.shape[0])
    giu = n == 3
    if giu.all():
        # tam giac nao cung truoc mat phang gan (truong hop thuong gap
        # nhat): tra thang, khong chep lai — cung gia tri, cung thu tu
        return C, U, goc
    Cs, Us, Gs = [C[giu]], [U[giu]], [goc[giu]]

    def cat(Pa, Pb, Ua, Ub):
        t = ((Pa[:, 3] - w_gan) / (Pa[:, 3] - Pb[:, 3]))[:, None]
        return Pa + t * (Pb - Pa), Ua + t * (Ub - Ua)

    for k in (1, 2):
        chon = np.nonzero(n == k)[0]
        if not len(chon):
            continue
        c, u, t_in = C[chon], U[chon], trong[chon]
        # dinh "le": k=1 -> dinh trong duy nhat, k=2 -> dinh ngoai duy nhat
        le = np.argmax(t_in if k == 1 else ~t_in, axis=1)
        r = np.arange(len(chon))
        i1, i2 = (le + 1) % 3, (le + 2) % 3
        A, B, D = c[r, le], c[r, i1], c[r, i2]
        UA, UB, UD = u[r, le], u[r, i1], u[r, i2]
        if k == 1:
            AB, UAB = cat(A, B, UA, UB)
            AD, UAD = cat(A, D, UA, UD)
            Cs.append(np.stack([A, AB, AD], 1))
            Us.append(np.stack([UA, UAB, UAD], 1))
            Gs.append(goc[chon])
        else:
            # A ngoai, B va D trong: tu giac B, D, DA', BA'
            BA, UBA = cat(B, A, UB, UA)
            DA, UDA = cat(D, A, UD, UA)
            Cs += [np.stack([B, D, DA], 1), np.stack([B, DA, BA], 1)]
            Us += [np.stack([UB, UD, UDA], 1), np.stack([UB, UDA, UBA], 1)]
            Gs += [goc[chon], goc[chon]]
    return np.concatenate(Cs), np.concatenate(Us), np.concatenate(Gs)


def _min3(A):
    """`A.min(axis=1)` cho mang (T,3) — giong tung bit, nhanh hon nhieu."""
    return np.minimum(np.minimum(A[:, 0], A[:, 1]), A[:, 2])


def _max3(A):
    """`A.max(axis=1)` cho mang (T,3) — giong tung bit, nhanh hon nhieu."""
    return np.maximum(np.maximum(A[:, 0], A[:, 1]), A[:, 2])


def _dt(X, Y):
    return 0.5 * np.abs((X[:, 1] - X[:, 0]) * (Y[:, 2] - Y[:, 0]) -
                        (X[:, 2] - X[:, 0]) * (Y[:, 1] - Y[:, 0]))


# ---------------------------------------------------------------------------
class BanDo:
    """Ban do do sau GW x GH. Moi o: do sau, ma vat lieu, mat do texel."""

    def __init__(self, rw, rh, gw=LUOI_NGANG):
        self.rw, self.rh = int(rw), int(rh)
        self.gw = max(1, min(int(gw), self.rw))
        self.gh = max(1, int(round(self.gw * self.rh / float(self.rw))))
        self.sx = self.rw / float(self.gw)
        self.sy = self.rh / float(self.gh)
        self.px_o = self.sx * self.sy
        n = self.gw * self.gh
        self.zb = np.full(n, np.inf)
        self.zk = np.full(n, -1, dtype=np.int64)
        self.zm = np.zeros(n)
        self.rng = np.random.default_rng(0)
        self._xuyen = []            # mau cua vat lieu nhin xuyen
        self.so_tam_giac = 0

    def them(self, C, U, khe, xuyen, co_uv=True):
        """Mot vat. C: (T,3,4) toa do cat DA cat gan; U: (T,3,2) uv;
        khe: (T,) ma vat lieu (-1 = khong co map, chi de che);
        xuyen: (T,) bool — vat lieu nhin xuyen."""
        rw, rh = self.rw, self.rh
        w = C[:, :, 3]
        X = (C[:, :, 0] / w * 0.5 + 0.5) * rw
        Y = (C[:, :, 1] / w * 0.5 + 0.5) * rh
        # ⛔ TOC DO (21/09/2026): `X.min(1)` / `X.max(1)` tren truc dai 3 la
        # ~20% ca lan quet (do bang lay mau, file bep khach). min/max cua
        # BA cot bang `np.minimum` cho dung tung bit — phep so sanh khong
        # lam tron.
        xmin, xmax = _min3(X), _max3(X)
        ymin, ymax = _min3(Y), _max3(Y)
        ok = ~((xmax < 0) | (xmin > rw) | (ymax < 0) | (ymin > rh))
        a_px = _dt(X, Y)
        ok &= a_px > 1e-9
        if not ok.any():
            return
        X, Y, w, khe, xuyen, a_px = X[ok], Y[ok], w[ok], khe[ok], xuyen[ok], \
            a_px[ok]
        xmin, xmax, ymin, ymax = xmin[ok], xmax[ok], ymin[ok], ymax[ok]
        if co_uv:
            Uo = U[ok]
            a_uv = _dt(Uo[:, :, 0], Uo[:, :, 1])
        else:
            a_uv = np.zeros(len(a_px))
        T = len(a_px)
        self.so_tam_giac += T
        # mat do tai diem p = (a_uv/a_px) * d(p)^3 / (d0 d1 d2)
        # (w0*w1)*w2 = dung thu tu nhan cua `np.prod(w, axis=1)` (do tren
        # numpy 2.3.4 cua Blender 5.2: giong tung bit), nhanh hon nhieu
        K = (a_uv / a_px) / (w[:, 0] * w[:, 1] * w[:, 2])
        inv_w = 1.0 / w
        o_toan = a_px / self.px_o

        vua = o_toan <= TO
        n_mau = np.where(vua, np.maximum(1, np.ceil(o_toan * MAU_MOI_O)),
                         0).astype(np.int64)
        tong = int(n_mau.sum())
        if tong:
            ti = np.repeat(np.arange(T), n_mau)
            mot = (n_mau == 1)[ti]
            r1 = self.rng.random(tong)
            r2 = self.rng.random(tong)
            s1 = np.sqrt(r1)
            b0, b1, b2 = 1.0 - s1, s1 * (1.0 - r2), s1 * r2
            b0[mot] = b1[mot] = b2[mot] = 1.0 / 3.0
            self._ghi(ti, b0, b1, b2, X, Y, inv_w, K, khe, xuyen)
        to = np.nonzero(~vua)[0]
        if len(to):
            self._ve_to(to, xmin, xmax, ymin, ymax, X, Y, inv_w, K, khe,
                        xuyen)

    # so o toi da gom lai truoc mot lan `_ghi` (gioi han RAM tam)
    _O_MOT_LAN = 1000000

    def _ve_to(self, to, xmin, xmax, ymin, ymax, X, Y, inv_w, K, khe, xuyen):
        """Ve dung tung o cho cac tam giac TO (chi so `to`, tang dan).

        ⛔ TOC DO (21/09/2026): ban cu dung meshgrid tren ca hop bao roi tinh
        he so tren TUNG o (px - x2, py - y2 ... ~40 luot qua mang), va goi
        `_ghi` (lexsort) rieng cho moi tam giac — ~2 s moi lan quet file bep
        khach. Ban nay tinh `a0*(px-x2)` mot lan moi COT, `c0*(py-y2)` mot
        lan moi HANG, roi cong theo luoi (ny, nx): moi o van la tong CUA
        DUNG HAI SO DO, chia cung `den` — ra giong tung bit. Thu tu o giu
        nhu meshgrid (hang gy roi cot gx), tam giac tang dan. Cac o gom lai
        roi `_ghi` mot lan: `_ghi` giu mau GAN NHAT, bang nhau thi giu mau
        DEN TRUOC — gom hay tung tam mot lan deu ra cung ban do.
        """
        rw, rh, sx, sy = self.rw, self.rh, self.sx, self.sy
        bx0 = np.clip(xmin[to], 0, rw)
        bx1 = np.clip(xmax[to], 0, rw)
        by0 = np.clip(ymin[to], 0, rh)
        by1 = np.clip(ymax[to], 0, rh)
        gx0 = np.maximum(0, np.floor(bx0 / sx)).astype(np.int64)
        gx1 = np.minimum(self.gw - 1, np.floor(bx1 / sx)).astype(np.int64)
        gy0 = np.maximum(0, np.floor(by0 / sy)).astype(np.int64)
        gy1 = np.minimum(self.gh - 1, np.floor(by1 / sy)).astype(np.int64)
        x0, x1, x2 = X[to, 0], X[to, 1], X[to, 2]
        y0, y1, y2 = Y[to, 0], Y[to, 1], Y[to, 2]
        den = (y1 - y2) * (x0 - x2) + (x2 - x1) * (y0 - y2)
        con = (gx1 >= gx0) & (gy1 >= gy0) & ~(np.abs(den) < 1e-12)
        # he so tung tam giac — dung cac hieu cua ban vong lap cu
        a0, c0 = y1 - y2, x2 - x1
        a1, c1 = y2 - y0, x0 - x2
        gom, so = [], 0
        for i in np.nonzero(con)[0]:
            px = (np.arange(gx0[i], gx1[i] + 1) + 0.5) * sx
            py = (np.arange(gy0[i], gy1[i] + 1) + 0.5) * sy
            dx = px - x2[i]
            dy = (py - y2[i])[:, None]
            b0 = ((a0[i] * dx + c0[i] * dy) / den[i]).ravel()
            b1 = ((a1[i] * dx + c1[i] * dy) / den[i]).ravel()
            b2 = 1.0 - b0 - b1
            trong = (b0 >= 0) & (b1 >= 0) & (b2 >= 0)
            n = int(np.count_nonzero(trong))
            if not n:
                continue
            gom.append((np.full(n, to[i]), b0[trong], b1[trong], b2[trong]))
            so += n
            if so >= self._O_MOT_LAN:
                self._ghi_gom(gom, X, Y, inv_w, K, khe, xuyen)
                gom, so = [], 0
        if gom:
            self._ghi_gom(gom, X, Y, inv_w, K, khe, xuyen)

    def _ghi_gom(self, gom, X, Y, inv_w, K, khe, xuyen):
        if len(gom) == 1:
            ti, b0, b1, b2 = gom[0]
        else:
            ti, b0, b1, b2 = (np.concatenate(c) for c in zip(*gom))
        self._ghi(ti, b0, b1, b2, X, Y, inv_w, K, khe, xuyen)

    def _ghi(self, ti, b0, b1, b2, X, Y, inv_w, K, khe, xuyen):
        x = b0 * X[ti, 0] + b1 * X[ti, 1] + b2 * X[ti, 2]
        y = b0 * Y[ti, 0] + b1 * Y[ti, 1] + b2 * Y[ti, 2]
        gx = np.floor(x / self.sx).astype(np.int64)
        gy = np.floor(y / self.sy).astype(np.int64)
        trong = (gx >= 0) & (gx < self.gw) & (gy >= 0) & (gy < self.gh)
        if not trong.any():
            return
        ti, gx, gy = ti[trong], gx[trong], gy[trong]
        iw = (b0[trong] * inv_w[ti, 0] + b1[trong] * inv_w[ti, 1] +
              b2[trong] * inv_w[ti, 2])
        d = 1.0 / iw
        o = gy * self.gw + gx
        # ⛔ TOC DO (21/09/2026): bo NGAY mau khong gan hon o hien co.
        # `zb` chi giam dan, nen mau d >= zb[o] luc nay khong bao gio
        # thang — ca mau che (so `tot` ben duoi) lan mau nhin xuyen (so
        # `thay` trong `ket_qua`). Bo truoc khi sap xep: cung ket qua, it
        # mau phai lexsort han nhieu (vat ve sau phan lon bi che).
        gan = d < self.zb[o]
        if not gan.all():
            ti, o, d = ti[gan], o[gan], d[gan]
        md = K[ti] * d ** 3
        k = khe[ti]
        xu = xuyen[ti]
        if xu.any():
            self._xuyen.append((o[xu], d[xu], k[xu], md[xu]))
        chan = ~xu
        if not chan.any():
            return
        o, d, k, md = o[chan], d[chan], k[chan], md[chan]
        # mau gan nhat moi o trong LO nay, roi so voi ban do chung
        thu_tu = np.lexsort((d, o))
        o, d, k, md = o[thu_tu], d[thu_tu], k[thu_tu], md[thu_tu]
        dau = np.ones(len(o), dtype=bool)
        dau[1:] = o[1:] != o[:-1]
        o, d, k, md = o[dau], d[dau], k[dau], md[dau]
        tot = d < self.zb[o]
        o, d, k, md = o[tot], d[tot], k[tot], md[tot]
        self.zb[o] = d
        self.zk[o] = k
        self.zm[o] = md

    def ket_qua(self):
        """{ma_vat_lieu: (so_o_thay, tong_mat_do, tong_do_sau)} — cho moi
        vat lieu CO map (ma >= 0)."""
        ra = {}
        co = self.zk >= 0
        o_lst = [np.nonzero(co)[0]]
        k_lst = [self.zk[co]]
        m_lst = [self.zm[co]]
        d_lst = [self.zb[co]]
        if self._xuyen:
            o = np.concatenate([t[0] for t in self._xuyen])
            d = np.concatenate([t[1] for t in self._xuyen])
            k = np.concatenate([t[2] for t in self._xuyen])
            md = np.concatenate([t[3] for t in self._xuyen])
            thay = (d < self.zb[o]) & (k >= 0)
            o, d, k, md = o[thay], d[thay], k[thay], md[thay]
            # moi (o, vat lieu) dem MOT lan
            _, dau = np.unique(o * (int(k.max()) + 2 if len(k) else 1) + k,
                               return_index=True)
            o_lst.append(o[dau])
            k_lst.append(k[dau])
            m_lst.append(md[dau])
            d_lst.append(d[dau])
        k = np.concatenate(k_lst)
        if not len(k):
            return ra
        m = np.concatenate(m_lst)
        d = np.concatenate(d_lst)
        so = np.bincount(k)
        tm = np.bincount(k, weights=m)
        td = np.bincount(k, weights=d)
        for i in np.nonzero(so)[0]:
            ra[int(i)] = (int(so[i]), float(tm[i]), float(td[i]))
        return ra
