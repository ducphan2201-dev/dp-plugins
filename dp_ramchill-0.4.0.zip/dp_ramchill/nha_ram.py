# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
"""TU NHA RAM SAU MOI LAN RENDER — chot gan `bo_nho.sau_render` vao Blender.

Ducphan 18/09/2026: *"chuyen tinh nang tu dong nha ram cua dp-optimize sang
addon nay"*. Phan lam viec (`bo_nho.py`) chep nguyen van tu DP_Optimize; file
nay chi la cai chot, khuon theo `dp_optimize/__init__._sau_render`.

⛔ BA LUAT, deu da tra gia ben DP_Optimize hoac o day:

  * `@persistent` — chot khong persistent bi go sach moi lan mo file khac,
    va addon im lang khong nha RAM nua ma khong ai biet.
  * DI QUA `luong_chinh.chay` — F12 / batch render co cua so goi chot nay
    tren LUONG RENDER (xem `luong_chinh.py`, LESSONS phien 7). `tha_anh()`
    goi `buffers_free()` tren moi anh: lam tren luong render la dung du lieu
    luc luong chinh dang ve -> vang.
  * DANG KY SAU `doi_co` — `doi_co._xong_render` tra map ve co goc
    (`reload`) trong cung cai hang cua luong chinh; nha RAM phai chay SAU no,
    khong thi vua tha xong lai nap lai ban day du.

⛔ TEN HAM `_nha_ram` LA HOP DONG: `bo_nho.dang_bat()` tim chot theo ten nay.
Dung dat `_sau_render` — `ngoai_khung._sau_render` da mang ten do, va
`dang_bat()` se bao "dang chay" ngay ca khi chot nay da bi go.

Tat bang o `Hand Memory Back After Render` (bang Cycles Memory). MAC DINH BAT
— ben DP_Optimize no chay ngam khong co o tat.

⛔ CHI MOT ADDON DUOC LAM VIEC NAY (Ducphan 18/09/2026: *"tao chi can 1
addon co chuc nang do thoi de tranh xung dot khi dung chung"*). May khach con
ban DP_Optimize CU (chot `_sau_render` cua module `dp_optimize` con gan) thi
chot nay NHUONG — khong nha lan hai. DP_Optimize ban moi bo tinh nang nay
thi chot kia bien mat va chot nay tu lam. Xem `dp_optimize_dang_lam`.
"""

import bpy

from . import bo_nho
from . import luong_chinh


def dp_optimize_dang_lam():
    """Ban DP_Optimize con tu nha RAM sau render khong — hoi THAT danh
    sach chot cua Blender, theo ten module + ten ham cua ben do."""
    try:
        for h in bpy.app.handlers.render_complete:
            mo = getattr(h, "__module__", "") or ""
            if ("dp_optimize" in mo
                    and getattr(h, "__name__", "") == "_sau_render"):
                return True
    except Exception:                                      # noqa: BLE001
        pass
    return False


def tha_persistent(sc):
    """Render xong ma Persistent Data dang BAT: tha khoi du lieu render ma
    Blender giu lai cho lan sau, roi BAT LAI o — lua chon cua khach khong doi.

    ⛔ DAY LA CHO NHA DUOC NHIEU NHAT, do 18/09/2026 (PN4.blend, Blender 5.2
    co cua so, Windows, CPU): mo file 1.720 MB cam ket; render xong co
    Persistent Data 4.676 MB; `bo_nho.sau_render` chi nha 50 MB (khoi do la
    du lieu DANG SONG, bo cap phat khong co gi de tra); tat o Persistent Data
    -> 1.757 MB NGAY. Blender tha phien render khi o nay chuyen sang tat
    (ham cap nhat cua o). Tat Persistent Data san tu dau thi render xong
    1.800 MB — tuc nha RAM thuong da ve sat day, chi ca nay la con 2,9 GB.

    Cai gia: lan F12 SAU phai dung lai canh tu dau (nhu khi khong co
    Persistent Data). Trong MOT lan render hoat hinh thi khong mat gi —
    `render_complete` chi no khi het ca doan phim. Khach can giu (bam F12
    lien tuc tren canh nang) thi tat o `Free Kept Render Data`.
    """
    r = sc.render
    if not getattr(r, "use_persistent_data", False):
        return False
    r.use_persistent_data = False
    r.use_persistent_data = True
    return True


_CHO = [""]      # ten scene dang cho het chuoi render de nha


def _nhip_cho():
    from . import doi_co
    if bpy.app.is_job_running("RENDER") or doi_co._chuoi_dang_chay():
        return 0.5
    ten, _CHO[0] = _CHO[0], ""
    _lam(bpy.data.scenes.get(ten), cho=False)
    return None


def _lam(scene=None, cho=True):
    if dp_optimize_dang_lam():
        return
    # ⛔ DOI HET CHUOI RENDER. Glass Boost cua DP-Optimize la NHIEU luot
    # render cho MOT anh, batch DP Cam la nhieu camera: tha Persistent Data
    # (bat-tat o) giua chuoi la dung lai canh o luot ke, va co the dung luc
    # luong render chua dong han (ra soat 21/09/2026). Cung luat voi
    # `doi_co._nhip_tra`. Chay nen thi van lam NGAY nhu cu.
    if cho and not bpy.app.background:
        try:
            from . import doi_co
            if bpy.app.is_job_running("RENDER") or doi_co._chuoi_dang_chay():
                sc0 = scene if scene is not None else bpy.context.scene
                _CHO[0] = getattr(sc0, "name", "")
                if not bpy.app.timers.is_registered(_nhip_cho):
                    bpy.app.timers.register(_nhip_cho, first_interval=0.5)
                return
        except Exception:                                  # noqa: BLE001
            pass
    sc, p = None, None
    try:
        sc = scene if scene is not None else bpy.context.scene
        p = getattr(sc, "dp_ramchill", None)
        if p is not None and not p.nha_ram:
            return
    except Exception:                                      # noqa: BLE001
        pass
    # Viec don dep chay sau lung mot lan render DA XONG — khong duoc nem loi.
    truoc = bo_nho.so_do()
    da_tha = False
    try:
        if sc is not None and p is not None and p.tha_persistent:
            da_tha = tha_persistent(sc)
    except Exception:                                      # noqa: BLE001
        pass
    try:
        ket = bo_nho.sau_render()
    except Exception:                                      # noqa: BLE001
        return
    # `sau_render` chup moc SAU khi da tha phien render — so cua no khong om
    # phan vua tha. Tinh lai tu moc cua minh, khong thi bang bao it hon that.
    if da_tha and ket:
        sau = ket.get("sau") or {}
        if "cam_ket" in truoc and "cam_ket" in sau:
            ket["giam_cam_ket_mb"] = truoc["cam_ket"] - sau["cam_ket"]
        a, b = bo_nho._so_chinh(truoc), bo_nho._so_chinh(sau)
        if a is not None and b is not None:
            ket["giam_mb"] = a - b
        ket["tha_persistent"] = True
        bo_nho._LAN_CUOI.clear()
        bo_nho._LAN_CUOI.update(ket)
        print("[DP_RAMchill] tha du lieu render giu lai (Persistent Data): "
              "cam ket -%.0f MB" % ket.get("giam_cam_ket_mb", 0.0))


@bpy.app.handlers.persistent
def _nha_ram(scene=None, *a):
    luong_chinh.chay(_lam, scene)


_CAP = (
    ("render_complete", _nha_ram),
    ("render_cancel", _nha_ram),
)


def dang_ky():
    for ten, ham in _CAP:
        ds = getattr(bpy.app.handlers, ten)
        if ham not in ds:
            ds.append(ham)


def go():
    for ten, ham in _CAP:
        ds = getattr(bpy.app.handlers, ten)
        if ham in ds:
            ds.remove(ham)
    try:
        if bpy.app.timers.is_registered(_nhip_cho):
            bpy.app.timers.unregister(_nhip_cho)
    except Exception:                                      # noqa: BLE001
        pass
