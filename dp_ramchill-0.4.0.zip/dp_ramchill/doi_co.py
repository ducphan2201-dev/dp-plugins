# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
"""Lop RA TAY — ha co map ngay truoc khi render, tra lai ngay sau.

=========================================================================
CO CHE, VA SO DO CHUNG MINH NO
=========================================================================
`bpy.types.Image.scale()` doi co tam anh TRONG BO NHO. File tren dia khong
bi dong toi mot byte, va `.blend` chi giu duong dan chu khong giu pixel —
nen `reload()` la du de tra lai nguyen trang.

Do that, Blender 5.2, RTX 3090, 8 tam 4096x4096, render OptiX
(`tools/do_vram.py`, hai vong ra so giong nhau den tung byte):

    khong dung gi        Cycles bao  512,13 MB   (dinh 512,23 MB)
    ha xuong 256         Cycles bao    2,13 MB   (dinh  24,07 MB)

Sau render, ca 8 tam doc lai la 4096x4096.

=========================================================================
DAT MOC O DAU — VA VI SAO KHONG PHAI `render_init`
=========================================================================
`render_pre` / `render_post` no MOI KHUNG HINH; `render_init` /
`render_complete` no mot lan cho ca cong viec render. Nghe thi
init/complete moi la cap dung cho anh doi.

Nhung so do o tren la do bang `render_pre`, va do la cap DA CHUNG MINH.
Nen o day dung `render_pre` de RA TAY, kem mot cai chot "da ra tay roi"
cho no thanh viec vo hai tu khung hinh thu hai tro di, va tra lai o
`render_complete` / `render_cancel`. Duoc ca hai: duong da do, va anh doi
khong bi thao ra lap lai 250 lan.

⛔ BA CAI CHOT AN TOAN, ca ba deu tra loi mot cau: *neu Blender chet giua
render thi map co ket lai o co nho khong?*

  1. `save_pre` — tra lai truoc khi ghi file. Anh nguon FILE thi `.blend`
     khong giu pixel, nhung tra lai truoc khi ghi la mot dong code de
     khoi phai chung minh dieu do lai moi lan Blender doi.
  2. `load_post` — don so ghi chep khi doi file, khong thi ten anh cua
     file cu se di theo sang file moi.
  3. CHI DUNG TOI anh nguon FILE va khong dang sua (`is_dirty`). Anh
     PACKED thi VAN dung toi duoc — nhung tra lai bang duong RIENG, xem
     `_tra_lai_packed` ngay duoi day. Anh dang sua thi khong: pixel cua no
     chi con trong bo nho, khong o dia ma cung khong o goi packed.
"""

import os

import bpy

from . import chinh_sach
from . import do_canh
from . import luong_chinh

# ten anh -> (w, h) truoc khi ha. Rong = dang khong ra tay.
_TRUOC = {}
_BAO_CAO = {"so_anh": 0, "byte_truoc": 0, "byte_sau": 0, "loi": "",
            "quet_lai": True}

# ⛔ DAU VAN CUA CANH — de RENDER BATCH khong quet di quet lai.
#
# Ducphan render hang loat anh mot lot, va moi lan render la mot lan quet.
# Do duoc tren scene 2,1 trieu tam giac: quet het 2,64 s. Nhan len mot tram
# tam anh la gan nam phut chi de tra loi lai dung cau hoi cu.
#
# Nen truoc khi quet, hoi mot cau RE hon nhieu: co gi doi khong? Neu khong
# thi dung lai ke hoach lan truoc, khong dung toi mot tam giac nao.
#
# ⛔ DAU VAN PHAI OM DU MOI THU LAM DOI KET QUA, va thieu mot thu la addon
# dung ke hoach cu cho mot canh moi — tuc anh ra sai ma khong ai keu. Nen
# no om: ma tran camera, ong kinh, do phan giai, va CA BO SO cua nguoi
# dung. Cai nao khong chac thi cu cho vao: mot dau van rong tay chi ton
# them mot lan quet, con mot dau van thieu la mot tam anh hong.
_VAN = [None]
_KE_HOACH = [None]


def _dau_van(context):
    sc = context.scene
    p = sc.dp_ramchill
    cam = sc.camera
    if cam is None:
        return None
    r = sc.render
    return (
        tuple(round(v, 6) for hang in cam.matrix_world for v in hang),
        getattr(cam.data, "lens", 0.0), getattr(cam.data, "type", ""),
        getattr(cam.data, "sensor_width", 0.0),
        getattr(cam.data, "sensor_fit", ""),
        getattr(cam.data, "shift_x", 0.0), getattr(cam.data, "shift_y", 0.0),
        getattr(cam.data, "ortho_scale", 0.0),
        r.resolution_x, r.resolution_y, r.resolution_percentage,
        r.pixel_aspect_x, r.pixel_aspect_y,
        p.che_do, p.moc_tu_dong,
        # ⛔ BON O MOC CHI VAO DAU VAN KHI NGUOI DUNG TU GO. Bat `moc_tu_dong`
        # thi ke hoach do tu canh, bon o nay khong tham gia mot phep tinh
        # nao — de chung trong dau van la moi lan bang ghi so vua do NGUOC
        # lai vao o (de nguoi dung nhin thay so THAT thay vi so mac dinh)
        # lai lam dau van doi, va lan render ngay sau do quet lai tu dau.
        (0, 0, 0, 0) if p.moc_tu_dong
        else (p.moc_1, p.moc_2, p.moc_3, p.moc_4),
        p.du_phong, p.san_duoi, p.canh_ep, p.bo_qua, p.nguong_to,
        # Tran co anh cua Cycles: doi tran la ke hoach doi (`tran_cycles`).
        tran_cycles(sc),
        len(sc.objects),
        # Bat/tat bo dem anh doi han ke hoach: anh FILE thuong thoi ha.
        tx_dang_bat(sc),
        # Dau cua tung tam anh: doi mot tam la ke hoach cu het dung.
        # ⛔ CO `packed_file` VA `is_dirty` TRONG DAY. Ca hai khong lam doi
        # mot pixel nao, nhung chung quyet dinh tam anh do CO DUOC DUNG TOI
        # hay khong. Khach bam Pack Resources giua hai lan render ma dau
        # van khong doi la addon dung lai ke hoach cu — tuc bo qua dung
        # nhung tam vua moi tro thanh dung duoc.
        tuple(sorted(_van_anh(i)
                     for i in bpy.data.images if i.type == "IMAGE")),
        # ⛔ TRANG THAI TUNG VAT (14/09/2026). Dau van cu chi dem SO vat: doi
        # cho mot vat (sofa lai sat ong kinh), an no khoi render, hay doi vat
        # lieu - so vat khong doi - la lan render sau dung lai ke hoach cu,
        # map co the dang 1/4 cho mot mat vua ra sat camera. Tu 0.3.3 ban do
        # nhin thay tinh ca che khuat, nen vat nao dich di cung doi ket qua
        # cua vat khac. `tools/do_bang.py::do_dau_van_om_canh` do ca ba ca.
        tuple(_van_vat(o) for o in sc.objects),
        tuple(sorted(_van_vat_lieu(m)
                     for m in bpy.data.materials if m.users)),
    )


def _van_vat(ob):
    """Dau cua MOT vat — chi doc so, khong danh gia luoi (re: PN4 637 vat)."""
    k = [ob.name, ob.type, ob.hide_render,
         bool(getattr(ob, "visible_camera", True)),
         ob.data.name if ob.data is not None else "",
         tuple(round(v, 6) for hang in ob.matrix_world for v in hang),
         tuple((m.name, m.type, m.show_render) for m in ob.modifiers),
         tuple(s.material.name if s.material else "" for s in ob.material_slots)]
    if ob.type == "MESH" and ob.data is not None:
        k += [len(ob.data.vertices), len(ob.data.polygons)]
    return tuple(k)


def _van_vat_lieu(m):
    """Nhung tam anh vat lieu dung + he so Mapping: chinh la dau vao cua phep
    tinh texel (`do_canh.anh_cua_vat_lieu`)."""
    return (m.name, tuple((i.name, s) for i, s in do_canh.anh_cua_vat_lieu(m)))


def _van_anh(i):
    """Dau cua MOT tam anh — KHONG NAP ANH.

    ⛔ BAN CU HOI `i.size` CHO MOI TAM, va hoi co la Blender NAP CA TAM ANH
    (LESSONS §14, §20). Dau van chay o `render_pre`, nen moi anh cua canh bi
    nap nguyen co va NAM LAI SUOT LAN VE: do 13/09/2026 tren phong khach
    that (28 anh), RAM may 0,76 -> 1,85 GB ngay truoc khi ve, dinh lan ve
    2,39 -> 3,43 GB — Auto lam RAM may TANG 1 GB du khong ha tam nao.
    Nay nhan ra anh doi bang DAU FILE (ngay sua + dung luong tren dia, dung
    luong goi packed, co anh tu tao) — khong tam nao phai nap. Co chi hoi
    khi anh DA NAP va DANG SUA (co the doi ma file khong doi).
    """
    pf = i.packed_file
    sua = bool(i.is_dirty) if i.has_data else False
    if i.name in _TRUOC:
        # Tam do CHINH addon dang ha (giu qua cac lan render lien nhau):
        # `scale()` bat `is_dirty` va doi co — tinh la chua sua, khong thi
        # dau van doi sau moi lan ha va lan render ke QUET LAI tu dau.
        sua = False
    k = [i.name, i.source, i.filepath_raw, pf.size if pf else 0, sua]
    if i.source == "GENERATED":
        k += [i.generated_width, i.generated_height]
    elif pf is None and i.source in ("FILE", "TILED", "SEQUENCE"):
        try:
            st = os.stat(bpy.path.abspath(i.filepath_raw, library=i.library))
            k += [st.st_mtime_ns, st.st_size]
        except (OSError, ValueError):
            k.append(None)
    if sua:
        k += [i.size[0], i.size[1]]
    return tuple(k)


def dang_ra_tay():
    return bool(_TRUOC)


def tx_dang_bat(scene):
    """BO DEM ANH cua Cycles (5.2+) that su chay: CA HAI o deu bat.

    `use_texture_cache` BAT SAN tu Blender 5.2 nhung `Auto Generate` TAT san
    - khong co file .tx thi Cycles van nap nguyen tam, y nhu chua co bo dem.
    Nen chi coi la "dang bat" khi ca hai o cung bat; mot minh o dau thi addon
    van ha co nhu truoc (khong doi hanh vi cua ai chua dung toi bo dem).
    """
    r = scene.render
    return bool(r.engine == "CYCLES"
                and getattr(r, "use_texture_cache", False)
                and getattr(r, "use_auto_generate_texture_cache", False))


def tran_cycles(scene):
    """Tran co anh Cycles ap cho RENDER (px), 0 = khong co tran.

    Cycles chi ap `texture_limit_render` khi BAT Simplify (nut Optimize cua
    DP-Optimize bat ca hai: "Simplify on (it carries the texture size
    limit)"). Xem `chinh_sach.quyet_dinh(tran_cycles=...)`.
    """
    try:
        r = scene.render
        if r.engine != "CYCLES" or not getattr(r, "use_simplify", False):
            return 0
        v = getattr(scene.cycles, "texture_limit_render", "OFF")
        return int(v) if str(v).isdigit() else 0
    except Exception:                                # noqa: BLE001
        return 0


def bao_cao_lan_cuoi():
    return dict(_BAO_CAO)


# ---------------------------------------------------------------------------
def lap_ke_hoach(context, dung_van=False, cho_tx=True):
    """Quet scene + hoi lop quyet dinh. Tra ve (ket_qua, ghi_chu).

    `dung_van=True` cho phep dung lai ke hoach lan truoc khi dau van cua
    canh khong doi — duong nay danh cho RENDER BATCH. Nut `Scan Scene`
    KHONG di duong nay: nguoi dung bam Scan la ho muon do lai that.

    `cho_tx=False` cho nut BAKE: bake la ghi file nho hon theo lenh nguoi
    dung, bo dem anh luc render khong lien quan.
    """
    if dung_van:
        van = _dau_van(context)
        if van is not None and van == _VAN[0] and _KE_HOACH[0] is not None:
            _BAO_CAO["quet_lai"] = False
            return _KE_HOACH[0], {"dung_lai_ke_hoach_cu": True}
    p = context.scene.dp_ramchill
    anh, ghi_chu = do_canh.quet_scene(context)

    # BON MOC: do tu chinh canh nay, hay lay so nguoi dung go?
    moc = (p.moc_1, p.moc_2, p.moc_3, p.moc_4)
    if p.moc_tu_dong:
        m = chinh_sach.moc_tu_canh(
            [a.get("khoang_cach") for a in anh])
        if m is not None:
            moc = m
            ghi_chu["moc_da_do"] = m
        else:
            ghi_chu["moc_khong_do_duoc"] = True

    ket_qua = chinh_sach.quyet_dinh(
        anh,
        che_do=p.che_do,
        moc=moc,
        canh_ep=int(p.canh_ep),
        san_duoi=int(p.san_duoi),
        du_phong=p.du_phong,
        nguong_to=p.nguong_to,
        bo_qua=set(t.strip() for t in p.bo_qua.split(",") if t.strip()),
        de_cho_tx=bool(cho_tx and tx_dang_bat(context.scene)),
        # Bake (`cho_tx=False`) ghi FILE theo lenh nguoi dung — tran render
        # khong lien quan. Render thi ap tran Cycles.
        tran_cycles=tran_cycles(context.scene) if cho_tx else 0,
    )
    if dung_van:
        _VAN[0] = _dau_van(context)
        _KE_HOACH[0] = ket_qua
        _BAO_CAO["quet_lai"] = True
    return ket_qua, ghi_chu


def _co_tx(img):
    """Tam nay khung nhin dang ve bang texture GPU (co `bindcode`)?"""
    try:
        return not bpy.app.background and img.bindcode != 0
    except Exception:                                # noqa: BLE001
        return False


def _nap_tx(img):
    """Dung lai texture GPU cua tam anh NGAY tren luong chinh.

    ⛔ SAP 21/09/2026 (dung lai duoc bang `thu_sap_batch.py`, file khach bep,
    ban cu sap ngay camera dau, RAMchill Tat thi 6 camera khong sap): doi co
    (`scale`) hay tra lai (`reload`) la Blender BO texture GPU cua tam do.
    Luong render duoc tha ra di tiep, Cycles doc anh tren luong render, CUNG
    LUC khung nhin Solid/Texture dung lai texture tu chinh bo dem do tren
    luong chinh -> `GLStateManager::texture_bind` con tro rong. Dung san
    texture o day (luong render con dang CHO) thi khung nhin chi ve texture co
    san — nhu luc chua co RAMchill. Chi tam nao TRUOC DO da co texture: tam
    khung nhin khong ve thi khong ton VRAM cua Cycles vo ich.
    """
    try:
        img.gl_load()
    except Exception:                                # noqa: BLE001
        pass


def _tra_mot(img, nap=False):
    co_tx = nap and _co_tx(img)
    if img.packed_file:
        _tra_lai_packed(img)
    else:
        img.reload()
    if co_tx:
        img.size[0]
        _nap_tx(img)
    if nap:
        # ⛔ TRA LAI NGAY TRUOC KHI CYCLES DOC THI PHAI NAP LAI PIXEL O DAY
        # (crash 21/09/2026, file khach bep, batch 3 camera + Glass Boost).
        # `reload()` / `buffers_free()` de tam anh o trang thai CHUA NAP
        # (`has_data` False). Cycles gap anh chua nap thi tu nap tren LUONG
        # RENDER roi tu giai phong bo dem — ke ca texture GPU cua khung nhin —
        # ngay luc luong chinh dang ve Solid/Texture bang chinh texture do:
        # `GLStateManager::texture_bind` doc con tro rong. Doc `size` la
        # Blender nap lai ngay tren luong chinh (do: has_data False -> True,
        # `is_dirty` van tat), nen Cycles thay anh da nap va khong dung toi.
        img.size[0]


def _ha_co(ket_qua):
    """Dua moi tam ve dung co cua ke hoach. Tra ve so tam dang o co nho.

    ⛔ CHI LAM LAI TAM NAO CAN CO KHAC (21/09/2026). Tam co the con dang ha
    tu lan render ngay truoc (`_hen_tra` chua tra): Glass Boost cua
    DP-Optimize chay 3-4 luot lien nhau, batch DP Cam chay tung camera. Do
    tren file khach bep: ha lai tu dau MOI luot ton 8,7-11,3 s, ma da so tam
    van dung co cu. Tam can co khac thi tra ve co goc roi ha tu co goc —
    khong ha tiep tu co nho (hai lan lay mau lai la mo them).
    """
    muon = {}
    for k in ket_qua:
        if not k["doi"]:
            continue
        img = bpy.data.images.get(k["ten"])
        if img is None or img.source != "FILE":
            continue
        # `is_dirty` cua tam DANG HA la do chinh `scale()` bat len.
        if img.is_dirty and img.name not in _TRUOC:
            continue
        # ⛔ ANH PACKED CHI TRA LAI DUOC BANG `buffers_free()` — xem
        # `_tra_lai_packed`. Hoi TRUOC KHI HA: ha co xong moi phat hien
        # khong co duong tra lai la map ket lai o co nho.
        if img.packed_file and getattr(img, "buffers_free", None) is None:
            continue
        muon[img.name] = (k["moi_w"], k["moi_h"])
    # Tam dang ha ma ke hoach moi khong can (hay can co khac): tra ve goc.
    for ten in list(_TRUOC):
        img = bpy.data.images.get(ten)
        if img is None:
            del _TRUOC[ten]
            continue
        if muon.get(ten) == (img.size[0], img.size[1]):
            continue                     # dung co roi — giu nguyen
        try:
            _tra_mot(img, nap=True)
        except RuntimeError:
            pass
        del _TRUOC[ten]
    so = 0
    for ten, (w, h) in muon.items():
        so += 1
        if ten in _TRUOC:
            continue
        img = bpy.data.images[ten]
        _TRUOC[ten] = (img.size[0], img.size[1])
        co_tx = _co_tx(img)
        img.scale(w, h)
        if co_tx:
            _nap_tx(img)             # xem `_nap_tx`: truoc khi tha luong render
    return so


def _tra_lai_packed(img):
    """Tra mot tam PACKED ve nguyen ven — KHONG di qua file tren dia.

    ⛔ HAI CAI BAY, ca hai deu IM LANG, ca hai deu do duoc bang
    `tools/do_map_pack.py`:

      1. `reload()` tren anh packed KHONG doc goi packed. No doc `filepath`
         roi PACK LAI theo cai vua doc. Pack mot tam, sua file tren dia
         thanh ban khac, roi `reload()` — goi packed doi tu 16.130 byte
         sang 16.649 byte va pixel thanh ban tren dia. Anh khach da goi
         vao file bi thay ruot, khong ai keu mot tieng nao.

      2. GAN `filepath_raw` MOT GIA TRI KHAC cung lam Blender pack lai y
         het nhu vay. Nen ca cai meo "tro duong dan vao mot file tam mang
         dung goi packed roi tra duong dan cu ve" CUNG HONG: chinh cai
         dong tra duong dan cu ve la cai pack lai tu dia. (Gan lai DUNG
         GIA TRI CU thi khong sao — Blender thay khong doi thi khong lam
         gi.)

    Duong dung la `buffers_free()`: vut bo dong pixel dang giu, khong dung
    toi `filepath`, khong dung toi goi packed. Lan sau ai hoi toi tam anh
    thi Blender tu nap lai — tu GOI PACKED, vi goi packed van con do. Do
    duoc tren ca bon kieu (packed mat file / packed ma dia khac ruot /
    packed ve tay khong co duong dan / file thuong): dung tung pixel, goi
    packed khong doi mot byte, `filepath` nguyen chuoi cu, `is_dirty` tat.

    ⛔ `buffers_free` KHONG LO RA TREN LOP: `hasattr(bpy.types.Image,
    "buffers_free")` tra ve False trong khi `img.buffers_free()` chay
    binh thuong. Hoi phai hoi TAM ANH, dung hoi cai lop.
    """
    ham = getattr(img, "buffers_free", None)
    if ham is None:
        # Blender khong co ham nay: khong co duong tra lai nao an toan cho
        # anh packed. `_ha_co` da hoi cau nay truoc khi ha nen duong nay
        # gan nhu khong bao gio chay — nhung neu co thi tha de nguyen con
        # hon pack de len goi cua khach bang mot file tren dia.
        print("[DP_RAMchill] Blender khong co buffers_free(), giu nguyen "
              "anh packed:", img.name)
        return
    ham()


def tra_lai(nap=False):
    """Tra moi tam ve co goc. Goi duoc nhieu lan, lan thu hai vo hai.

    `nap=True` khi goi NGAY TRUOC render (xem `_tra_mot`). Bo dem gio ranh
    va `save_pre` thi khong nap (nap 111 map o day la dung hinh vai giay),
    chi ghi ten vao `_CHUA_NAP` — lan render ke `_nap_truoc_render` nap.
    """
    _go_hen_tra()
    for ten in list(_TRUOC):
        img = bpy.data.images.get(ten)
        if img is not None:
            try:
                # Hoi TAM ANH DANG SONG chu khong hoi so ghi chep: giua hai
                # lan goi, nguoi dung co the vua pack hoac vua go pack.
                if not nap and _co_tx(img):
                    _CO_TX.add(ten)
                _tra_mot(img, nap=nap)
            except RuntimeError:
                pass
            if not nap:
                _CHUA_NAP.add(ten)
    _TRUOC.clear()


# ⛔ TEN ANH DA TRA LAI MA CHUA NAP (bo dem gio ranh, `save_pre`). DP Cam batch
# GHI FILE ROI RENDER NGAY (crash 21/09/2026: "Project saved" -> "Starting
# Batch Render" -> sap): `save_pre` tra lai, anh chua nap, Cycles nap/giai
# phong tren luong render trong luc khung nhin dang ve. Nen truoc moi render
# nap lai tam nao trong so nay con chua nap — tren LUONG CHINH.
_CHUA_NAP = set()
# Trong so do: tam nao LUC TRA LAI dang co texture khung nhin (xem `_nap_tx`).
_CO_TX = set()


def _nap_truoc_render():
    for ten in list(_CHUA_NAP):
        img = bpy.data.images.get(ten)
        try:
            if img is not None and not img.has_data:
                img.size[0]              # doc `size` = Blender nap lai
            if img is not None and ten in _CO_TX and not _co_tx(img):
                _nap_tx(img)
        except Exception:                            # noqa: BLE001
            pass
    _CHUA_NAP.clear()
    _CO_TX.clear()


# ---------------------------------------------------------------------------
# Handler
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# Giu map da ha qua nhung lan render LIEN NHAU (21/09/2026)
# ---------------------------------------------------------------------------
# ⛔ VI SAO. Ban truoc tra map ve co goc NGAY khi mot lan render xong, roi lan
# render ke lai ha tu dau. Do tren file khach bep (111 map): moi lan ha 8,7-
# 11,3 s tren LUONG CHINH — Blender dung hinh. Glass Boost cua DP-Optimize
# chay 3-4 luot lien nhau, batch DP Cam chay tung camera: nhan len la batch 3
# camera 169 s thay vi 43 s. Nay: xong render thi HEN tra, khi Blender ranh
# han `CHO_TRA` giay (khong con render, khong con chuoi cua DP-Optimize / DP
# Cam) moi tra. Lan render ke den truoc thi `_ha_co` chi lam tam can co khac.
CHO_TRA = 1.5
_LUOT_MOI = [True]     # `render_init` bat: mot CONG VIEC render moi bat dau


def _module(ten):
    import sys
    return sys.modules.get(ten)


def _chuoi_dang_chay():
    """DP-Optimize (Glass Boost) hay DP Cam (batch) con render tiep khong."""
    tk = _module("dp_optimize.tang_kinh")
    try:
        if tk is not None and tk.TRANG_THAI.get("dang_chay"):
            return True
    except Exception:                            # noqa: BLE001
        pass
    # ⛔ BAN BAN CUA DP CAM GIAU `batch_render_state` TRONG `dp_camera.core`
    # (dong goi cat `__init__.py` con mot dong `from .core import ...`). Chi
    # doc `dp_camera` thi o may khach luon False — tra map giua hai camera
    # cua batch. Bat duoc 24/09/2026 bang goi dung kieu ban ban.
    for ten in ("dp_camera.core", "dp_camera"):
        cam = _module(ten)
        try:
            st = getattr(cam, "batch_render_state", None)
            if isinstance(st, dict):
                return bool(st.get("is_rendering"))
        except Exception:                        # noqa: BLE001
            pass
    return False


def _luot_do_kinh():
    """Luot DO VUNG KINH cua Glass Boost (1 mau, 1/8 do phan giai).

    ⛔ DUNG HA MAP O LUOT NAY. No chi doc pass Transmission Color, khong can
    map net — va ke hoach lap theo 1/8 do phan giai se ha map xuong rat nho,
    roi luot vung kinh / anh day du ngay sau phai tra ve va ha lai.
    """
    tk = _module("dp_optimize.tang_kinh")
    try:
        return bool(tk is not None and tk.TRANG_THAI.get("dang_chay")
                    and tk.TRANG_THAI.get("luot") == "MASK")
    except Exception:                            # noqa: BLE001
        return False


def _nhip_tra():
    if bpy.app.is_job_running("RENDER") or _chuoi_dang_chay():
        return 0.5
    tra_lai()
    return None


def _hen_tra():
    if not _TRUOC:
        return
    if bpy.app.background:
        # Chay nen: render DONG BO, bo dem gio khong chay cho toi khi script
        # xong — hen la map o co nho luon. Khong co giao dien de giat, tra ngay.
        tra_lai()
        return
    try:
        if bpy.app.timers.is_registered(_nhip_tra):
            bpy.app.timers.unregister(_nhip_tra)
        bpy.app.timers.register(_nhip_tra, first_interval=CHO_TRA)
    except Exception:                            # noqa: BLE001
        tra_lai()                    # khong hen duoc thi tra ngay nhu cu


def _go_hen_tra():
    try:
        if bpy.app.timers.is_registered(_nhip_tra):
            bpy.app.timers.unregister(_nhip_tra)
    except Exception:                            # noqa: BLE001
        pass


@bpy.app.handlers.persistent
def _bat_dau_render(scene, *a):
    # LUONG RENDER — chi gan mot gia tri.
    _LUOT_MOI[0] = True


@bpy.app.handlers.persistent
def _truoc_render(scene, *a):
    # Luong render -> nho luong chinh lam va cho (xem `luong_chinh.py`).
    luong_chinh.chay(_ha_truoc_render, scene)


def _ha_truoc_render(scene):
    # Khung hinh thu hai tro di cua CUNG mot cong viec render: khong lam gi.
    if not _LUOT_MOI[0]:
        return
    _LUOT_MOI[0] = False
    _go_hen_tra()
    # Truoc ca luot do kinh: luot do kinh Cycles cung nap texture.
    _nap_truoc_render()
    if _luot_do_kinh():
        return
    p = getattr(scene, "dp_ramchill", None)
    if p is None or p.che_do == chinh_sach.CHE_DO_TAT:
        tra_lai(nap=True)  # vua tat giua chuoi: map con giu tu lan truoc
        return
    _BAO_CAO["loi"] = ""
    try:
        # `dung_van=True`: render batch thi khong quet lai canh khong doi
        ket_qua, _ = lap_ke_hoach(bpy.context, dung_van=True)
    except Exception as e:                       # noqa: BLE001
        # ⛔ MOT NGOAI LE O DAY LA HONG CA LAN RENDER. Nuot no, ghi lai, va
        # de scene nguyen ven — mat VRAM con hon mat ban render. Ducphan
        # render batch qua dem; mot lan quet hong khong duoc phep lam dut
        # ca me anh.
        _BAO_CAO["loi"] = "%s: %s" % (type(e).__name__, e)
        print("[DP_RAMchill] quet that bai, giu nguyen scene:",
              _BAO_CAO["loi"])
        return
    truoc, sau, _ = chinh_sach.tong_ket(ket_qua)
    try:
        so = _ha_co(ket_qua)
    except Exception as e:                       # noqa: BLE001
        # Cung ly do nhu tren, va o day con nang hon: `_ha_co` da doi mot
        # so tam anh roi moi chet giua chung. Tra lai het truoc khi bo cuoc.
        _BAO_CAO["loi"] = "%s: %s" % (type(e).__name__, e)
        print("[DP_RAMchill] ha co that bai, tra lai het:", _BAO_CAO["loi"])
        tra_lai(nap=True)
        return
    _BAO_CAO.update(so_anh=so, byte_truoc=truoc, byte_sau=sau)
    if so:
        print("[DP_RAMchill] ha %d map: %s -> %s" % (
            so, chinh_sach.doc_byte(truoc), chinh_sach.doc_byte(sau)))


@bpy.app.handlers.persistent
def _xong_render(scene, *a):
    # HEN tra chu khong tra ngay — xem `_hen_tra`.
    luong_chinh.chay(_hen_tra)


@bpy.app.handlers.persistent
def _truoc_khi_ghi(*a):
    tra_lai()


@bpy.app.handlers.persistent
def _sau_khi_mo(*a):
    _go_hen_tra()
    _TRUOC.clear()
    _CHUA_NAP.clear()
    _CO_TX.clear()
    _LUOT_MOI[0] = True


_CAP = (
    ("render_init", _bat_dau_render),
    ("render_pre", _truoc_render),
    ("render_complete", _xong_render),
    ("render_cancel", _xong_render),
    ("save_pre", _truoc_khi_ghi),
    ("load_post", _sau_khi_mo),
)


def dang_ky():
    for ten, ham in _CAP:
        ds = getattr(bpy.app.handlers, ten)
        if ham not in ds:
            ds.append(ham)


def go():
    tra_lai()
    for ten, ham in _CAP:
        ds = getattr(bpy.app.handlers, ten)
        if ham in ds:
            ds.remove(ham)
