# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
"""GIU VAT CO BONG ROI VAO KHUNG HINH - phep hoi di kem "bo vat ngoai khung".

Ducphan 13/09/2026: *"phai can than phan proxy quanh camera, neu co anh sang
gay bong do ma k render thi sao?"*. Dung: bo mot vat ngoai khung la mat luon
BONG cua no - cay sau lung camera, nang chieu tu sau lung, bong do dai vao
khung. Ban dau (4.17.11) bai do "anh y het" chi dat vi mat troi chieu huong
khac. Nay mot vat ngoai khung chi duoc bo khi qua ca ba cau:

  1. HOP BAO nam ngoai khung (nhu cu - phep cua nguoi goi).
  2. VUNG GAN - hop bao noi rong them `K_GAN` lan canh dai nhat - khong cham
     mot HINH NAO THAY DUOC trong khung (mat dat, tuong... nam trong khung).
     Day la bong MEM cua bau troi va anh sang doi len vat ben canh, thu phep
     hinh hoc tia duoi day khong bat duoc.
  3. Voi TUNG nguon sang do bong: khoi "vat + bong cua no" nam ngoai khung.
     Khoi ay la bao loi cua 8 goc hop bao va 8 diem cuoi - moi goc keo theo
     tia sang toi khi RA KHOI HOP BAO CUA CAC HINH THAY DUOC (bong chi hien
     ra khi roi len mot hinh trong khung; tia khong cham hop ay thi khong
     keo) - noi them do nhoe cua bong (mat troi co goc, den co ban kinh).
     Do 13/09/2026: chi chan o mat dat thi den dat ngang tam vat (vat phat
     sang, den ban) keo bong CHECH LEN troi toi khi cham phan khung nhin len
     troi xa - giu oan; chan o hop ca canh van giu oan vi mot cay cao sau
     lung day tran len 10 m. Canh co he hat rai vat thi lui ve hop ca canh.

Ca ba la phep "chac chan ngoai": mot mat phang khung tach duoc khoi loi ra
khoi khung thi khoi ay chac chan khong thay; khong tach duoc thi GIU (co the
giu thua, khong bao gio bo nham).

NGUON SANG (DO trong Blender 5.2, 13/09/2026 - render qua cau, tim huong sang):
  - den SUN: tia di theo -Z cua den; nua goc nhoe = angle/2.
  - den POINT / SPOT / AREA: tia tu vi tri den qua tung goc; ban kinh den lam
    bong nhoe. SPOT: vat ngoai non chieu thi den ay khong tinh. AREA: vat nam
    SAU mat den thi khong tinh (den mat chi chieu mot phia).
  - vat PHAT SANG: coi nhu den tron dat o tam hop bao cua no.
  - Sky Texture Single/Multiple Scattering: huong TOI mat troi =
    (cos e * sin r, cos e * cos r, sin e)  [do: r=0 -> +Y, r=90 do -> +X].
    Preetham / Hosek-Wilkie: `sun_direction`; troi khong co dia mat troi,
    bong mem -> nua goc `NUA_SKY_MEM`.
  - HDRI (Environment Texture, equirect): doc anh bang OpenImageIO co san
    trong Blender, tung dai hang (khong nap ca anh), thu ve luoi 512 x 256,
    tim toi `SO_DOM` dom sang, moi dom mang >= `PHAN_DOM` anh sang ca bau
    troi. Diem anh (u, v; v tinh tu DUOI) -> huong TOI nguon =
    (cos el cos az, cos el sin az, sin el), az = (0,5 - u) * 2pi,
    el = (v - 0,5) * pi  [do: lech < 1,5 do]. Node Mapping quay HDRI:
    huong the gioi = R^T * huong trong anh [do]. Ket qua nho theo tep (duong
    dan + co + gio sua) nen chi doc MOT lan moi phien.
    Doc khong duoc (khong co OpenImageIO, tep hong, noi node la) -> coi mat
    troi co the o MOI huong cao tu `GOC_MO` tro len ("MO").
  - den / troi / vat phat sang CHUYEN DONG -> tra None: khong bo vat nao, vi
    `render_init` chay MOT lan cho ca doan phim.

⛔ KHONG LO: PHAN CHIEU (guong, kinh, mat nuoc trong khung thay vat sau lung)
va anh sang doi o xa. Hai cai do van nho o "giu gan" cua nguoi goi.

BAN SAO: tep nay co mot ban GIONG HET trong DP_MaxImporter va DP_RAMchill;
sua mot ben thi chep sang ben kia (moi du an giu ban cua no).
"""

import math
import os

import bpy
import numpy as np
from mathutils import Euler, Matrix, Vector

K_GAN = 1.0                        # vung gan = 1 lan canh dai nhat cua vat
GOC_MO = math.radians(10.0)        # HDRI khong doc duoc: mat troi cao >= 10 do
NUA_SKY_MEM = math.radians(20.0)   # troi khong dia mat troi: bong rat mem
PHAN_DOM = 0.03                    # dom mang >= 3% anh sang -> nguon do bong
SO_DOM = 4                         # toi da 4 dom (anh studio nhieu hop den)
NGUONG_DOM = 0.1                   # o thuoc dom khi sang >= 10% dinh dom
DOM_TOI_DA = 0.05                  # dom rong hon 5% bau troi -> may/troi dam
LUOI_W, LUOI_H = 512, 256
LOAI_HINH = {"MESH", "CURVE", "SURFACE", "META", "FONT", "CURVES",
             "POINTCLOUD", "VOLUME"}

_HDRI = {}                         # khoa tep -> list dom | None


# ---------------------------------------------------------------------------
# vat chuyen dong / vat phat sang
# ---------------------------------------------------------------------------
def dong(ob):
    """Vat (hay mot vat cha cua no) co the doi cho theo khung hinh."""
    while ob is not None:
        ad = ob.animation_data
        if ad is not None and (ad.action is not None or len(ad.drivers)
                               or len(ad.nla_tracks)):
            return True
        if len(ob.constraints):
            return True
        ob = ob.parent
    return False


def _id_dong(idb):
    ad = getattr(idb, "animation_data", None) if idb is not None else None
    return ad is not None and (ad.action is not None or len(ad.drivers)
                               or len(ad.nla_tracks))


def _cay_phat_sang(cay, da_qua):
    if cay is None or cay in da_qua:
        return False
    da_qua.add(cay)
    for nd in cay.nodes:
        if nd.type == "EMISSION":
            return True
        if nd.type == "BSDF_PRINCIPLED":
            s = nd.inputs.get("Emission Strength")
            c = nd.inputs.get("Emission Color")
            if s is not None and c is not None:
                co_s = s.is_linked or s.default_value > 0.0
                co_c = c.is_linked or any(v > 0.0 for v in c.default_value[:3])
                if co_s and co_c:
                    return True
        if nd.type == "GROUP" and _cay_phat_sang(nd.node_tree, da_qua):
            return True
    return False


def vat_phat_sang(ob, nho):
    """Vat co vat lieu phat sang. `nho`: dict ten vat lieu -> bool (dung lai)."""
    for khe in ob.material_slots:
        m = khe.material
        if m is None:
            continue
        if m.name not in nho:
            nho[m.name] = bool(getattr(m, "use_nodes", True)
                               and _cay_phat_sang(m.node_tree, set()))
        if nho[m.name]:
            return True
    return False


# ---------------------------------------------------------------------------
# khung hinh (he toa do THE GIOI) va phep "chac chan ngoai"
# ---------------------------------------------------------------------------
def mat_phang_khung(scene, cam, le=0.0):
    """Sau mat phang khung hinh, the gioi, da chuan hoa, huong VAO trong:
    mang (6, 4) [nx, ny, nz, d] - diem p trong khung khi n.p - d >= 0.
    None neu camera toan canh (thay het)."""
    cd = cam.data
    if cd.type == "PANO":
        return None
    # Camera khong an theo ti le cua vat (Blender chuan hoa ma tran camera).
    M = cam.matrix_world.normalized()
    o = M.translation.copy()
    f = (M.to_3x3() @ Vector((0.0, 0.0, -1.0))).normalized()
    fr = [v.copy() for v in cd.view_frame(scene=scene)]
    cx = sum(v.x for v in fr) / 4.0
    cy = sum(v.y for v in fr) / 4.0
    for v in fr:
        v.x = cx + (v.x - cx) * (1.0 + le)
        v.y = cy + (v.y - cy) * (1.0 + le)
    w = [M @ v for v in fr]
    tam = M @ Vector((cx, cy, fr[0].z))
    mp = []
    for i in range(4):
        a, b = w[i], w[(i + 1) % 4]
        if cd.type == "ORTHO":
            n = (b - a).cross(f)
        else:
            n = (a - o).cross(b - o)
        if n.length < 1e-12:
            return None
        n.normalize()
        d = n.dot(a)
        if n.dot(tam) - d < 0.0:
            n, d = -n, -d
        mp.append((n.x, n.y, n.z, d))
    mp.append((f.x, f.y, f.z, f.dot(o) + cd.clip_start))
    mp.append((-f.x, -f.y, -f.z, -(f.dot(o) + cd.clip_end)))
    return np.array(mp, dtype=np.float64)


def ngoai(P, diem, le=None, le_ngang=None):
    """(N,) True khi bao loi cua cac diem (N, K, 3) - moi diem noi mot cau ban
    kinh `le` (N, K) va mot dia NGANG ban kinh `le_ngang` (N, K) - nam han
    ve phia ngoai cua CUNG mot mat phang khung."""
    s = diem @ P[:, :3].T - P[:, 3]                      # (N, K, 6)
    if le is not None:
        s = s + le[..., None]
    if le_ngang is not None:
        s = s + le_ngang[..., None] * np.hypot(P[:, 0], P[:, 1])
    return np.any(np.all(s < 0.0, axis=1), axis=1)


def khung_hinh(scene, cam, le=0.0):
    """Khung hinh the gioi: {"P": 6 mat phang, "V": 8 dinh (8, 3), "canh": 6
    huong canh (6, 3)}. None neu camera toan canh."""
    P = mat_phang_khung(scene, cam, le)
    if P is None:
        return None
    cd = cam.data
    M = cam.matrix_world.normalized()
    fr = [v.copy() for v in cd.view_frame(scene=scene)]
    cx = sum(v.x for v in fr) / 4.0
    cy = sum(v.y for v in fr) / 4.0
    V, canh = [], []
    for v in fr:
        v.x = cx + (v.x - cx) * (1.0 + le)
        v.y = cy + (v.y - cy) * (1.0 + le)
        if cd.type == "ORTHO":
            a = M @ Vector((v.x, v.y, -cd.clip_start))
            b = M @ Vector((v.x, v.y, -cd.clip_end))
        else:
            u = v / max(1e-12, -v.z)                     # diem o do sau 1
            a, b = M @ (u * cd.clip_start), M @ (u * cd.clip_end)
        V += [tuple(a), tuple(b)]
        canh.append(tuple((b - a).normalized()))
    R = M.to_3x3()
    canh += [tuple(R @ Vector((1.0, 0.0, 0.0))), tuple(R @ Vector((0.0, 1.0, 0.0)))]
    return {"P": P, "V": np.array(V, np.float64), "canh": np.array(canh, np.float64)}


_XYZ = np.eye(3)


def _sat(K, diem, le, le_ngang, them):
    """Phep TRUC TACH (SAT) giua bao loi cac diem va khung: thu ca phap tuyen
    mat khung, truc the gioi (mat hop bao thang truc) va tich co huong cua
    cac huong canh - tim duoc truc tach nao la CHAC CHAN khong cham. Phep mat
    phang khung (`ngoai`) chi la 6 truc dau, nen no giu thua nhung vat nam
    cheo goc khung, hay khoi bong di sat ong kinh (do 13/09/2026: cay 5 m sau
    lung, bong dung truoc khoang dat thay duoc, van bi giu)."""
    N = len(diem)
    goc = np.concatenate([K["P"][:, :3], _XYZ,
                          np.cross(K["canh"][:, None, :], _XYZ[None]).reshape(-1, 3)])
    A = np.broadcast_to(goc, (N,) + goc.shape)
    if them is not None:
        t = np.broadcast_to(them, (N, 3)) if them.ndim == 1 else them
        A = np.concatenate([A, np.cross(t[:, None, :], _XYZ[None]),
                            np.cross(t[:, None, :], K["canh"][None])], 1)
    dai = np.linalg.norm(A, axis=-1, keepdims=True)
    A = np.where(dai > 1e-9, A / np.maximum(dai, 1e-12), 0.0)
    pr = np.einsum("nkj,nmj->nkm", diem, A)
    r = np.zeros(diem.shape[:2] + (1,))
    if le is not None:
        r = r + le[..., None]
    if le_ngang is not None:
        r = r + le_ngang[..., None] * np.hypot(A[..., 0], A[..., 1])[:, None, :]
    lo, hi = (pr - r).min(1), (pr + r).max(1)
    fv = np.einsum("vj,nmj->nvm", K["V"], A)
    return np.any((hi < fv.min(1)) | (lo > fv.max(1)), axis=1)


def ngoai_khung(K, diem, le=None, le_ngang=None, them=None):
    """(N,) True khi bao loi cac diem (co le) CHAC CHAN nam ngoai khung.
    Mat phang khung truoc (re), truc tach cho phan con lai. `them`: huong
    canh rieng cua khoi (tia sang) - (3,) chung hoac (N, 3) tung vat."""
    out = ngoai(K["P"], diem, le, le_ngang)
    con = np.nonzero(~out)[0]
    if len(con):
        th = None if them is None else (them if them.ndim == 1 else them[con])
        out[con] = _sat(K, diem[con], None if le is None else le[con],
                        None if le_ngang is None else le_ngang[con], th)
    return out


_CHON = np.array([(a, b, c) for a in (0, 1) for b in (0, 1) for c in (0, 1)],
                 bool)


def goc_hop(lo, hi):
    """Hop thang truc (N, 3), (N, 3) -> 8 goc (N, 8, 3)."""
    return np.where(_CHON[None], hi[:, None, :], lo[:, None, :])


def hop_the_gioi(ob):
    """8 goc hop bao (the gioi, thang truc) cua vat: mang (8, 3)."""
    mw = ob.matrix_world
    g = np.array([tuple(mw @ Vector(c)) for c in ob.bound_box], np.float64)
    return goc_hop(g.min(0)[None], g.max(0)[None])[0]


# ---------------------------------------------------------------------------
# hop bao cua MOI hinh se render (ke ca trong collection instance): mat dat
# (bong khong roi thap hon diem thap nhat) va VAT NHAN (hinh trong khung - noi
# bong mem / anh sang doi co cho de roi len)
# ---------------------------------------------------------------------------
def _hop_py(obs, M=None, sau=0, ra=None):
    ra = [] if ra is None else ra
    for ob in obs:
        if ob.hide_render:
            continue
        mw = ob.matrix_world if M is None else M @ ob.matrix_world
        if ob.type in LOAI_HINH:
            g = np.array([tuple(mw @ Vector(c)) for c in ob.bound_box])
            ra.append((g.min(0), g.max(0)))
        if (ob.instance_type == "COLLECTION" and ob.instance_collection
                is not None and sau < 4):
            col = ob.instance_collection
            goc = Matrix.Translation(-Vector(col.instance_offset))
            _hop_py(col.all_objects, mw @ goc, sau + 1, ra)
    return ra


def hop_canh(scene):
    """(lo, hi) - mang (N, 3) hop bao the gioi cua moi hinh se render."""
    ds = scene.objects
    n = len(ds)
    lo, hi = [np.zeros((0, 3))], [np.zeros((0, 3))]
    try:
        S = np.empty(n * 16, np.float32)
        ds.foreach_get("matrix_world", S)
        B = np.empty(n * 24, np.float32)
        ds.foreach_get("bound_box", B)
        H = np.empty(n, bool)
        ds.foreach_get("hide_render", H)
        S, B = S.reshape(n, 4, 4), B.reshape(n, 8, 3)
        m = np.fromiter((o.type in LOAI_HINH for o in ds), bool, n) & ~H
        if m.any():
            # foreach_get tra ma tran theo COT: p = c @ S[:3, :3] + S[3, :3]
            C = (np.einsum("nkj,nji->nki", B[m].astype(np.float64),
                           S[m, :3, :3].astype(np.float64))
                 + S[m, 3, :3][:, None, :])
            lo.append(C.min(1))
            hi.append(C.max(1))
        ra = _hop_py([o for o in ds if o.instance_type == "COLLECTION"
                      and o.instance_collection is not None])
    except Exception as e:                               # noqa: BLE001
        print("[bong_khung] fast bounding-box read failed (%s: %s) - reading "
              "one object at a time" % (type(e).__name__, e))
        lo, hi = [np.zeros((0, 3))], [np.zeros((0, 3))]
        ra = _hop_py(ds)
    if ra:
        lo.append(np.array([a for a, _b in ra]))
        hi.append(np.array([b for _a, b in ra]))
    return np.concatenate(lo), np.concatenate(hi)


def mat_dat(scene, hop=None):
    lo, _hi = hop_canh(scene) if hop is None else hop
    return float(lo[:, 2].min()) if len(lo) else 0.0


def vat_nhan(K, hop):
    """Hop bao cua cac hinh KHONG nam han ngoai khung (co the thay)."""
    lo, hi = hop
    if not len(lo):
        return lo, hi
    thay = ~ngoai_khung(K, goc_hop(lo, hi))
    return lo[thay], hi[thay]


def _gan_nhan(K, lo, hi, m, nhan):
    """(N,) True khi hop (lo, hi) noi rong m CHAM mot vat nhan o phan cua vat
    nhan nam trong khung."""
    nlo, nhi = nhan
    N = len(lo)
    kq = np.zeros(N, bool)
    if not N or not len(nlo):
        return kq
    a, b = lo - m[:, None], hi + m[:, None]
    buoc = max(1, 2000000 // len(nlo))
    for s in range(0, N, buoc):
        A, B = a[s:s + buoc], b[s:s + buoc]
        cham = np.all((A[:, None, :] <= nhi[None]) & (B[:, None, :] >= nlo[None]),
                      axis=2)
        ii, rr = np.nonzero(cham)
        if not len(ii):
            continue
        vao = ~ngoai_khung(K, goc_hop(np.maximum(A[ii], nlo[rr]),
                                      np.minimum(B[ii], nhi[rr])))
        kq[s + ii[vao]] = True
    return kq


# ---------------------------------------------------------------------------
# HDRI: tim dom sang (mat troi, hop den studio) bang OpenImageIO
# ---------------------------------------------------------------------------
def _lan(mask, j, i, gioi_han):
    gh, gw = mask.shape
    thay = {(j, i)}
    hang = [(j, i)]
    while hang:
        y, x = hang.pop()
        for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            yy = y + dy
            if yy < 0 or yy >= gh:
                continue
            xx = (x + dx) % gw                  # anh equirect vong quanh ngang
            if (yy, xx) in thay or not mask[yy, xx]:
                continue
            thay.add((yy, xx))
            hang.append((yy, xx))
            if len(thay) > gioi_han:
                return None
    return (np.fromiter((p[0] for p in thay), np.int64, len(thay)),
            np.fromiter((p[1] for p in thay), np.int64, len(thay)))


def tim_dom(lum):
    """lum (gh, gw): do sang equirect, HANG 0 LA TREN CUNG. Tra list
    (huong TOI nguon (3,), nua goc, phan anh sang) - toi da `SO_DOM`."""
    gh, gw = lum.shape
    v = 1.0 - (np.arange(gh) + 0.5) / gh
    el = (v - 0.5) * math.pi
    az = (0.5 - (np.arange(gw) + 0.5) / gw) * 2.0 * math.pi
    ce = np.cos(el)
    E = lum * ce[:, None]                                # nhan dien tich goc
    tong = float(E.sum())
    if not tong > 0.0:
        return []
    X = ce[:, None] * np.cos(az)[None, :]
    Y = ce[:, None] * np.sin(az)[None, :]
    Z = np.repeat(np.sin(el)[:, None], gw, 1)
    o_goc = max(math.pi / gh, 2.0 * math.pi / gw)
    con = lum.copy()
    ra = []
    for _ in range(SO_DOM):
        j, i = np.unravel_index(int(np.argmax(con)), con.shape)
        dinh = float(con[j, i])
        if not dinh > 0.0:
            break
        dom = _lan(con >= NGUONG_DOM * dinh, j, i, int(DOM_TOI_DA * gh * gw))
        if dom is None:
            break               # dom qua rong: may sang / troi dam - het nguon ro
        jj, ii = dom
        e = E[jj, ii]
        phan = float(e.sum()) / tong
        if phan < PHAN_DOM:
            break
        h = np.array([(e * X[jj, ii]).sum(), (e * Y[jj, ii]).sum(),
                      (e * Z[jj, ii]).sum()])
        dai = float(np.linalg.norm(h))
        if dai <= 0.0:
            break
        h /= dai
        c = X[jj, ii] * h[0] + Y[jj, ii] * h[1] + Z[jj, ii] * h[2]
        nua = math.acos(float(np.clip(c.min(), -1.0, 1.0))) + o_goc
        ra.append((h, nua, phan))
        con[jj, ii] = 0.0
    return ra


def _doc_luoi(duong):
    import OpenImageIO as oiio
    inp = oiio.ImageInput.open(duong)
    if inp is None:
        raise RuntimeError(oiio.geterror() or "cannot open")
    try:
        sp = inp.spec()
        W, H, C = sp.width, sp.height, sp.nchannels
        bx, by = max(1, W // LUOI_W), max(1, H // LUOI_H)
        gw, gh = W // bx, H // by
        nc = min(C, 3)
        lum = np.zeros((gh, gw), np.float64)
        buoc = max(1, 64 // by)          # ~64 hang anh moi lan doc: RAM nho
        for g0 in range(0, gh, buoc):
            g1 = min(gh, g0 + buoc)
            a = inp.read_scanlines(0, 0, sp.y + g0 * by, sp.y + g1 * by, 0,
                                   0, nc, oiio.FLOAT)
            if a is None:
                raise RuntimeError(inp.geterror() or "cannot read")
            a = np.asarray(a, np.float32).reshape((g1 - g0) * by, W, nc)
            if nc >= 3:
                y = 0.2126 * a[..., 0] + 0.7152 * a[..., 1] + 0.0722 * a[..., 2]
            else:
                y = a[..., 0]
            y = np.nan_to_num(y[:, :gw * bx], nan=0.0, posinf=0.0, neginf=0.0)
            np.maximum(y, 0.0, out=y)
            lum[g0:g1] = y.reshape(g1 - g0, by, gw, bx).mean(axis=(1, 3))
        return lum
    finally:
        inp.close()


def doc_hdri(img, log=print):
    """Dom sang cua mot anh HDRI (huong TRONG anh). None = khong doc duoc."""
    if img is None or img.source != "FILE":
        return None
    tam = None
    try:
        if img.packed_file is not None:
            import tempfile
            khoa = ("packed", img.name, img.packed_file.size)
            if khoa in _HDRI:
                return _HDRI[khoa]
            duoi = os.path.splitext(img.filepath)[1] or ".hdr"
            fd, tam = tempfile.mkstemp(prefix="dp_hdri_", suffix=duoi)
            with os.fdopen(fd, "wb") as f:
                f.write(img.packed_file.data)
            duong = tam
        else:
            duong = os.path.normpath(bpy.path.abspath(img.filepath,
                                                      library=img.library))
            st = os.stat(duong)
            khoa = (duong, st.st_size, st.st_mtime_ns)
            if khoa in _HDRI:
                return _HDRI[khoa]
        kq = tim_dom(_doc_luoi(duong))
        _HDRI[khoa] = kq
        log("off-screen: HDRI %r read for shadows - %d light spot(s)%s"
            % (img.name, len(kq), "".join(
                ", %.0f%% at %.0f deg up" % (p * 100, math.degrees(
                    math.asin(max(-1.0, min(1.0, h[2]))))) for h, _n, p in kq)))
        return kq
    except Exception as e:                               # noqa: BLE001
        log("off-screen: cannot read HDRI %r (%s) - assuming a sun could be "
            "anywhere above %.0f deg" % (img.name, e, math.degrees(GOC_MO)))
        return None
    finally:
        if tam:
            try:
                os.remove(tam)
            except OSError as e:
                log("off-screen: could not delete the temporary HDRI copy %s: "
                    "%s" % (tam, e))


def _theo_reroute(s):
    """(node, socket) that su noi vao o `s`, bo qua reroute. None neu ho."""
    while True:
        if not s.is_linked:
            return None
        l = s.links[0]
        if l.is_muted:
            return None
        n = l.from_node
        if n.type != "REROUTE":
            return n, l.from_socket
        s = n.inputs[0]


def ma_tran_env(nd):
    """Ma tran 3x3: huong the gioi = M @ huong trong anh. None neu noi la."""
    if getattr(nd, "projection", "EQUIRECTANGULAR") != "EQUIRECTANGULAR":
        return None
    s = nd.inputs.get("Vector")
    if s is None or not s.is_linked:
        return Matrix.Identity(3)
    ns = _theo_reroute(s)
    if ns is None:
        return None
    n, so = ns
    if n.type == "TEX_COORD":
        return Matrix.Identity(3) if so.identifier == "Generated" else None
    if n.type != "MAPPING" or n.mute:
        return None
    ns = _theo_reroute(n.inputs["Vector"])
    if ns is None or ns[0].type != "TEX_COORD" or ns[1].identifier != "Generated":
        return None
    for k in ("Location", "Rotation", "Scale"):
        o = n.inputs.get(k)
        if o is not None and o.enabled and o.is_linked:
            return None
    kieu = n.vector_type
    R = Euler(tuple(n.inputs["Rotation"].default_value), "XYZ").to_matrix()
    o = n.inputs.get("Scale")
    if o is not None and o.enabled:
        s3 = tuple(o.default_value)
        if not (s3[0] > 0.0 and abs(s3[0] - s3[1]) < 1e-6 * s3[0]
                and abs(s3[0] - s3[2]) < 1e-6 * s3[0]):
            return None
    o = n.inputs.get("Location")
    if (kieu in ("POINT", "TEXTURE") and o is not None and o.enabled
            and Vector(tuple(o.default_value)).length > 1e-9):
        return None
    return R if kieu == "TEXTURE" else R.transposed()


# ---------------------------------------------------------------------------
# nguon sang
# ---------------------------------------------------------------------------
def _moi_nut(cay, da_qua):
    if cay is None or cay in da_qua:
        return []
    da_qua.add(cay)
    kq = list(cay.nodes)
    for nd in cay.nodes:
        if nd.type == "GROUP":
            kq += _moi_nut(nd.node_tree, da_qua)
    return kq


def _nut_thuong_nguon(cay):
    """Moi node noi (qua cac duong) toi World Output dang dung."""
    ra = [n for n in cay.nodes if n.type == "OUTPUT_WORLD"]
    if not ra:
        return []
    ra = [n for n in ra if n.is_active_output] or ra
    tren = {}
    for l in cay.links:
        if not l.is_muted:
            tren.setdefault(l.to_node.name, []).append(l.from_node)
    thay, hang, kq, nhom = set(), list(ra), [], set()
    while hang:
        n = hang.pop()
        if n.name in thay:
            continue
        thay.add(n.name)
        kq.append(n)
        hang.extend(tren.get(n.name, ()))
        if n.type == "GROUP":
            kq += _moi_nut(n.node_tree, nhom)
    return kq


def _nguon_troi(scene, log):
    """(list nguon, ly do dong). Troi co hoat hoa -> (None, ten)."""
    w = scene.world
    if w is None:
        return [], None
    cay = w.node_tree if getattr(w, "use_nodes", True) else None
    if cay is None:
        return [], None
    if _id_dong(w) or _id_dong(cay):
        return None, "world %r" % w.name
    ds = []
    for nd in _nut_thuong_nguon(cay):
        if nd.type == "TEX_SKY":
            if nd.sky_type in ("PREETHAM", "HOSEK_WILKIE"):
                t = Vector(tuple(nd.sun_direction))
                if t.length > 0.0:
                    t.normalize()
                    ds.append(("HUONG", -np.array(t), math.tan(NUA_SKY_MEM),
                               "sky %r" % nd.name))
                continue
            e, r = nd.sun_elevation, nd.sun_rotation
            if nd.sun_disc and getattr(nd, "sun_intensity", 1.0) <= 0.0:
                continue
            nua = (max(nd.sun_size * 0.5, math.radians(0.3))
                   if nd.sun_disc else NUA_SKY_MEM)
            if e < -nua:
                continue                    # mat troi duoi chan troi
            t = np.array([math.cos(e) * math.sin(r), math.cos(e) * math.cos(r),
                          math.sin(e)])
            ds.append(("HUONG", -t, math.tan(nua) + 1e-3, "sky %r" % nd.name))
        elif nd.type == "TEX_ENVIRONMENT" and nd.image is not None:
            M = ma_tran_env(nd)
            dom = doc_hdri(nd.image, log) if M is not None else None
            if M is None:
                log("off-screen: HDRI %r is wired through nodes the shadow "
                    "check cannot follow - assuming a sun could be anywhere "
                    "above %.0f deg" % (nd.image.name, math.degrees(GOC_MO)))
            if dom is None:
                ds.append(("MO", math.tan(GOC_MO), "HDRI %r" % nd.image.name))
                continue
            for h, nua, _p in dom:
                t = M @ Vector(tuple(h))
                ds.append(("HUONG", -np.array(t.normalized()),
                           math.tan(min(nua, math.radians(80.0))) + 1e-3,
                           "HDRI %r" % nd.image.name))
    return ds, None


def nguon_sang(scene, log=print):
    """Moi nguon do bong cua canh: (list, None), hoac (None, ten) khi co mot
    nguon CHUYEN DONG (khi ay nguoi goi khong duoc bo vat nao).

      ("HUONG", d (3,), tan nua goc, ten)        - tia song song, huong d
      ("DIEM", L (3,), ban kinh, ten, loai, truc (3,) | None, nua non | None)
      ("MO", tan goc thap nhat, ten)             - mat troi o dau khong ro
    """
    ds = []
    nho = {}
    for ob in scene.objects:
        if ob.hide_render:
            continue
        if ob.type == "LIGHT":
            ld = ob.data
            if (ld.energy <= 0.0 or max(ld.color) <= 0.0
                    or not getattr(ld, "use_shadow", True)):
                continue
            if dong(ob):
                return None, "light %r" % ob.name
            mw = ob.matrix_world
            truc = (mw.to_3x3() @ Vector((0.0, 0.0, -1.0))).normalized()
            if ld.type == "SUN":
                ds.append(("HUONG", np.array(truc),
                           math.tan(min(ld.angle, 3.0) * 0.5) + 1e-3, ob.name))
                continue
            ti = max(abs(v) for v in mw.to_scale())
            if ld.type == "AREA":
                sy = ld.size_y if ld.shape in ("RECTANGLE", "ELLIPSE") else ld.size
                rho = 0.5 * math.hypot(ld.size, sy) * ti
            else:
                rho = ld.shadow_soft_size * max(1.0, ti)
            nua = (min(math.pi, ld.spot_size * 0.5 + 0.05)
                   if ld.type == "SPOT" else None)
            ds.append(("DIEM", np.array(mw.translation), rho, ob.name, ld.type,
                       np.array(truc), nua))
        elif ob.type in LOAI_HINH and vat_phat_sang(ob, nho):
            if dong(ob):
                return None, "glowing object %r" % ob.name
            g = hop_the_gioi(ob)
            tam = g.mean(0)
            rho = 0.5 * float(np.linalg.norm(g.max(0) - g.min(0)))
            ds.append(("DIEM", tam, rho, ob.name, "VAT", None, None))
    troi, dg = _nguon_troi(scene, log)
    if troi is None:
        return None, dg
    return ds + troi, None


# ---------------------------------------------------------------------------
# phep hoi chinh
# ---------------------------------------------------------------------------
def bien_canh(hop):
    """Hop bao CA CANH (lo (3,), hi (3,)) tu hop_canh(scene)."""
    lo, hi = hop
    if not len(lo):
        return None
    return lo.min(0), hi.max(0)


def _co_hat_rai(scene):
    """Canh co he HAT rai vat / collection: hop bao cua vat phat khong bao cac
    ban rai, nen hop cac vat nhan khong con dang tin."""
    for ob in scene.objects:
        if ob.hide_render:
            continue
        for ps in getattr(ob, "particle_systems", ()):
            if ps.settings.render_type in ("OBJECT", "COLLECTION"):
                return True
    return False


def vung_nhan(scene, K, hop=None):
    """(nhan, canh): hop bao cua cac hinh THAY DUOC trong khung, va hop bao
    chung cua chung - noi duy nhat bong co the hien ra. Khong hinh nao thay
    duoc -> canh suy bien (tia khong cham -> khong bong nao dang ke)."""
    hop = hop_canh(scene) if hop is None else hop
    nhan = vat_nhan(K, hop)
    if _co_hat_rai(scene):
        canh = bien_canh(hop)
    else:
        canh = bien_canh(nhan)
    if canh is None:
        o = K["V"][0]
        canh = (o - 1e9, o - 1e9)
    return nhan, canh


def _t_ra(G, u, canh, T):
    """Quang duong tia G + t*u (N, 8, 3) di toi khi RA KHOI hop `canh` (hop
    cac hinh thay duoc) - qua do khong con hinh nao de bong hien len. Tia
    khong bao gio cham hop -> 0 (khong keo). Khong qua T."""
    blo, bhi = canh
    song = np.abs(u) < 1e-12
    trong = (G >= blo) & (G <= bhi)
    with np.errstate(divide="ignore", invalid="ignore"):
        t1 = (blo - G) / u
        t2 = (bhi - G) / u
    tmin = np.where(song, np.where(trong, -np.inf, np.inf), np.minimum(t1, t2))
    tmax = np.where(song, np.where(trong, np.inf, -np.inf), np.maximum(t1, t2))
    t_vao, t_ra = tmin.max(-1), tmax.min(-1)
    t = np.where(t_ra >= np.maximum(t_vao, 0.0), t_ra, 0.0)
    return np.clip(t, 0.0, T[:, None])


def _keo_huong(G, d, tn, canh, T):
    """Keo 8 goc theo tia song song d toi khi ra khoi hop bao ca canh."""
    t = _t_ra(G, np.broadcast_to(d, G.shape), canh, T)
    return G + t[..., None] * d, t * tn


def _keo_diem(G, L, rho, canh, T):
    """Keo 8 goc theo tia tu diem L toi khi ra khoi hop bao ca canh."""
    v = G - L
    r = np.maximum(np.linalg.norm(v, axis=-1), 1e-9)
    u = v / r[..., None]
    t = _t_ra(G, u, canh, T)
    return G + u * t[..., None], rho * t / r


def giu_vi_bong(K, goc, kich, bong, nguon, vi_tri_cam, xa_cam, canh=None,
                nhan=None):
    """Cho cac vat co HOP BAO ngoai khung: vat nao phai GIU vi bong / anh sang
    gan cua no co the roi vao khung.

      K                khung_hinh(...)
      goc    (N, 8, 3) goc hop bao the gioi
      kich   (N,)      canh dai nhat
      bong   (N,) bool vat co do bong (visible_shadow)
      nguon            nguon_sang(...)[0]
      canh             vung_nhan(scene, K)[1] - hop bao chung cua cac hinh
                       THAY DUOC: tia bong chi keo toi khi ra khoi hop nay,
                       tia khong cham hop thi khong keo. None: lay hop bao
                       cua chinh cac vat dang xet
      nhan             vung_nhan(scene, K)[0] - hinh co the thay. None:
                       coi nhu MOI cho trong khung deu co hinh (giu nhieu hon)

    Tra (giu (N,) bool, dem {"near": n, ten nguon: n, ...})."""
    N = len(goc)
    giu = np.zeros(N, bool)
    dem = {}
    if N == 0:
        return giu, dem
    # VUNG GAN chi tinh khi no cham mot HINH THAY DUOC: cay 10 m sau lung noi
    # rong 10 m thi cham khoang KHONG truoc ong kinh, nhung khong co gi o do
    # de bong mem roi len (do 13/09/2026: noi thang theo khung thi cay cao nao
    # gan camera cung bi giu, du nang chieu nguoc).
    m = K_GAN * kich
    if nhan is None:
        gan = ~ngoai_khung(K, goc, np.repeat(m[:, None], 8, 1))
    else:
        gan = _gan_nhan(K, goc.min(1), goc.max(1), m, nhan)
    giu |= gan
    if gan.any():
        dem["near"] = int(gan.sum())
    lo, hi = goc.min(1), goc.max(1)
    tam = 0.5 * (lo + hi)
    rb = 0.5 * np.linalg.norm(hi - lo, axis=1)
    T = np.linalg.norm(tam - vi_tri_cam, axis=1) + xa_cam + kich
    if canh is None:
        canh = (lo.min(0), hi.max(0))
    g = canh[0][2]
    z0 = np.zeros((N, 8))
    for ng in nguon:
        con = np.nonzero(~giu & bong)[0]
        if not len(con):
            break
        G = goc[con]
        le_ng = None
        chieu = None
        bao = None
        them = None
        if ng[0] == "HUONG":
            cuoi, le = _keo_huong(G, ng[1], ng[2], canh, T[con])
            them = ng[1]
        elif ng[0] == "MO":
            cuoi = G.copy()
            cuoi[..., 2] = np.minimum(G[..., 2], g)
            le = z0[con]
            le_ng = np.concatenate(
                [z0[con], np.clip((G[..., 2] - g) / ng[1], 0.0,
                                  T[con][:, None])], 1)
        else:
            L, rho, _ten, loai, truc, nua = ng[1:]
            # den nam trong vat (bong den, chup den) -> vat chan sang moi phia
            bao = np.all((lo[con] - rho <= L) & (L <= hi[con] + rho), axis=1)
            if loai == "SPOT":
                v = tam[con] - L
                dd = np.maximum(np.linalg.norm(v, axis=1), 1e-9)
                goc_v = np.arccos(np.clip(v @ truc / dd, -1.0, 1.0))
                goc_r = np.arcsin(np.clip((rb[con] + rho) / dd, 0.0, 1.0))
                chieu = (dd <= rb[con] + rho) | (goc_v - goc_r <= nua)
            elif loai == "AREA":
                chieu = ((G - L) @ truc).max(1) > -rho * 1e-3
            cuoi, le = _keo_diem(G, L, rho, canh, T[con])
            u = tam[con] - L
            them = u / np.maximum(np.linalg.norm(u, axis=1), 1e-9)[:, None]
        vao = ~ngoai_khung(K, np.concatenate([G, cuoi], 1),
                           np.concatenate([z0[con], le], 1), le_ng, them)
        if chieu is not None:
            vao &= chieu
        if bao is not None:
            vao |= bao
        if vao.any():
            giu[con[vao]] = True
            ten = ng[2] if ng[0] == "MO" else ng[3]
            dem[ten] = dem.get(ten, 0) + int(vao.sum())
    return giu, dem
