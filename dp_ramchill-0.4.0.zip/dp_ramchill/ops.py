# SPDX-FileCopyrightText: 2026 Ducphan
#
# SPDX-License-Identifier: GPL-2.0-only
"""Nut bam cua DP_RAMchill.

⛔ TIEN TO `dpramchill.` TREN `bl_idname`, KHONG DUOC RUT NGAN. Hai addon
dat trung mot `bl_idname` thi cai bat sau DE LEN cai truoc trong im lang,
va bo kiem nao goi thang vao ham python se khong bao gio bat duoc. Nha DP
da tra gia chuyen do voi khach that.

BA NUT, VA CA BA DEU KHONG DUNG TOI SCENE:
  * `quet`       — do va bao cao. Khong doi mot pixel nao.
  * `moc_tu_scene` — DO khoang cach that trong scene roi dat bon moc. Do,
                     khong doan. Xem ghi chu trong `props.py`.
  * `tra_lai`    — cai chot tay, cho truong hop Blender chet giua render
                   va map ket lai o co nho.
"""

import os

import bpy
from bpy.props import BoolProperty, EnumProperty, IntProperty
from bpy.types import Operator

from . import chinh_sach
from . import do_canh
from . import doi_co
from . import nuong_map
from . import props
from . import so_sanh_luoi
from . import toi_uu_luoi


def _dong_bao_cao(ket_qua, ghi_chu, che_do):
    truoc, sau, doi = chinh_sach.tong_ket(ket_qua)
    d = ["%d/%d maps shrink" % (doi, len(ket_qua)),
         "%s  ->  %s" % (chinh_sach.doc_byte(truoc),
                         chinh_sach.doc_byte(sau))]
    if truoc > 0:
        d.append("saves %s (%.0f%%)" % (
            chinh_sach.doc_byte(truoc - sau),
            100.0 * (truoc - sau) / truoc))

    # ⛔ MOI CHO PHEP DO PHAI BO QUA DEU PHAI NOI RA. Nuot lang la bang doc
    # len thanh "da xet het", trong khi no vua bo qua 40 tam.
    if ghi_chu.get("khong_co_camera"):
        d.append("! no camera - nothing measured")
    for khoa, chu in (("an_viewport_hien_render",
                       "! %d hidden-but-rendered kept"),
                      ("anh_ngoai_khung",
                       "! %d off-screen maps kept"),
                      ("anh_khong_tren_mat",
                       "! %d maps on no surface kept")):
        if ghi_chu.get(khoa):
            d.append(chu % ghi_chu[khoa])
    # Bo dem anh dang bat: noi ra bao nhieu tam de cho no, khong thi dong
    # "0/40 maps shrink" doc len nhu addon hong.
    tx = sum(1 for k in ket_qua if k.get("ly_do") == chinh_sach.LY_DO_TX)
    if tx:
        d.append("%d maps on texture cache" % tx)
    # UDIM / anh tu tao chua pack / anh dang sua: khong co cho nao tra lai
    # nen luon giu nguyen — noi ra, dung de "0/40 maps shrink" doc thanh hong.
    ks = sum(1 for k in ket_qua
             if k.get("ly_do") == chinh_sach.LY_DO_KHONG_SUA)
    if ks:
        d.append("! %d UDIM/generated kept" % ks)
    if che_do == chinh_sach.CHE_DO_TU_DONG:
        d.append("%d objects, %s tris" % (
            ghi_chu.get("vat_the_da_quet", 0),
            format(ghi_chu.get("tam_giac", 0), ",d")))
    return "\n".join(d)


# ⛔ BE RONG THANH BEN LA 420 px, va Blender CAT CUT GIUA CHUNG mot dong
# chu dai hon o do — khong xuong dong, khong bao gi. Anh chup 22/08/2026
# lo ra hai dong bi cat: "! 24 maps onl... kept (mirrors)" va "85 objects /
# 2,415,297 tris scan...". Ca 88 phep do luc do deu xanh: ban ve gia doc
# duoc NOI DUNG mot dong chu chu khong do duoc BE RONG cua no.
#
# So do dem tu chinh anh chup: dong KHONG co icon cat o khoang 34 ky tu,
# dong CO icon (bat dau bang "!") mat them cho nen chi con ~30.
DAI_TOI_DA = 34
DAI_TOI_DA_CO_ICON = 30


def do_dai_dong(dong):
    """Dong bao cao nay co vua be rong bang khong?"""
    han = DAI_TOI_DA_CO_ICON if dong.startswith("!") else DAI_TOI_DA
    return len(dong) <= han


def _ghi_moc_da_do(p, ghi_chu):
    """GHI BON MOC VUA DO NGUOC LAI VAO BON O — moi nut co lap ke hoach.

    ⛔ Khi `moc_tu_dong` bat, bon o do bi lam mo va van hien SO MAC DINH
    (5 / 15 / 30 / 60 m). Trong mot can phong 8 met, bon con so do doc len
    la addon dang tinh sai — Ducphan da bao dung cau do 22/08/2026 khi nhin
    bang. Chung khong tham gia phep tinh nao o che do tu dong, nen ghi de len
    la an toan; va `_dau_van` da co y bo qua chung o che do nay nen viec ghi
    KHONG lam ke hoach vua lap bi vut di.
    ⛔ BAKE CUNG PHAI GHI (14/09/2026): anh chup so tay sau khi bam Bake tren
    PN4 hien 5000 / 15000 / 30000 / 60000 mm trong khi Scan cung canh do ra
    310 / 464 / 619 / 735 mm — chi Scan ghi, Bake thi khong.
    """
    m = ghi_chu.get("moc_da_do")
    if m:
        p.moc_1, p.moc_2, p.moc_3, p.moc_4 = m


class DPRAMCHILL_OT_quet(Operator):
    bl_idname = "dpramchill.quet"
    bl_label = "Scan Scene"
    bl_description = ("Measure the scene and report what render would use. "
                      "Changes nothing.\n"
                      "Do scene va bao cao render se dung bao nhieu. Khong "
                      "doi gi ca")
    bl_options = {"REGISTER"}

    def execute(self, context):
        p = context.scene.dp_ramchill
        try:
            ket_qua, ghi_chu = doi_co.lap_ke_hoach(context)
        except Exception as e:                    # noqa: BLE001
            p.bao_cao = "scan failed: %s" % e
            self.report({"ERROR"}, "DP_RAMchill: %s" % e)
            return {"CANCELLED"}
        _ghi_moc_da_do(p, ghi_chu)
        p.bao_cao = _dong_bao_cao(ket_qua, ghi_chu, p.che_do)
        truoc, sau, doi = chinh_sach.tong_ket(ket_qua)
        self.report({"INFO"}, "DP_RAMchill: %d maps, %s -> %s" % (
            doi, chinh_sach.doc_byte(truoc), chinh_sach.doc_byte(sau)))
        return {"FINISHED"}


class DPRAMCHILL_OT_moc_tu_scene(Operator):
    bl_idname = "dpramchill.moc_tu_scene"
    bl_label = "Fit Rings To Scene"
    bl_description = ("Measure how far the textured surfaces actually are "
                      "and place the four rings on that spread. Works in "
                      "whatever unit the file uses.\n"
                      "Do xem cac mat co map thuc su nam xa bao nhieu roi "
                      "dat bon moc theo do. Dung duoc voi moi don vi")
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        p = context.scene.dp_ramchill
        try:
            anh, ghi_chu = do_canh.quet_scene(context)
        except Exception as e:                    # noqa: BLE001
            self.report({"ERROR"}, "DP_RAMchill: %s" % e)
            return {"CANCELLED"}
        kc = sorted(a["khoang_cach"] for a in anh
                    if a.get("khoang_cach") is not None)
        if len(kc) < 2:
            self.report({"WARNING"},
                        "DP_RAMchill: not enough measured surfaces "
                        "(%d) - rings unchanged" % len(kc))
            return {"CANCELLED"}
        # Bon moc o phan vi 20/40/60/80 cua chinh cac khoang cach do duoc.
        # Khong phai con so "gu": no la phan bo THAT cua scene nay.
        moc = [kc[min(len(kc) - 1, int(len(kc) * q))]
               for q in (0.2, 0.4, 0.6, 0.8)]
        for i in range(1, 4):
            if moc[i] <= moc[i - 1]:
                moc[i] = moc[i - 1] * 1.5 + 1e-4
        p.moc_1, p.moc_2, p.moc_3, p.moc_4 = moc
        self.report({"INFO"}, "DP_RAMchill: rings fitted on %d surfaces "
                              "(%.3f .. %.3f)" % (len(kc), kc[0], kc[-1]))
        return {"FINISHED"}


class DPRAMCHILL_OT_tra_lai(Operator):
    bl_idname = "dpramchill.tra_lai"
    bl_label = "Restore Full Size"
    bl_description = ("Reload every map at full size, from disk or from "
                      "the packed block. Only needed "
                      "if a render was interrupted hard.\n"
                      "Nap lai moi map o co goc, tu dia hoac tu goi "
                      "packed. Chi can toi khi mot "
                      "lan render bi dut giua chung")
    bl_options = {"REGISTER"}

    def execute(self, context):
        doi_co.tra_lai()
        self.report({"INFO"}, "DP_RAMchill: maps restored")
        return {"FINISHED"}


class DPRAMCHILL_OT_nuong(Operator):
    """⛔ NUT DUY NHAT CUA ADDON DUOC PHEP GHI RA DIA — va chi ghi FILE MOI.

    Ducphan 12/09/2026: bo nhap .max giu nguyen co anh goc, con viec lam
    nhe thi dat vao day. Xem luat trong `nuong_map.py`.
    """
    bl_idname = "dpramchill.nuong"
    bl_label = "Bake Smaller Maps"
    bl_description = ("Write the plan of the current mode (Auto or Force) "
                      "to NEW smaller image files and point the maps at "
                      "them. Viewport, RAM and render all get lighter. The "
                      "original files are never touched - Restore Original "
                      "Maps brings them back.\n"
                      "Ghi ke hoach cua che do dang chon ra FILE ANH MOI nho "
                      "hon roi tro map sang do. Viewport, RAM va render deu "
                      "nhe di. File goc khong bi dong toi - bam Restore "
                      "Original Maps de tra lai")
    bl_options = {"REGISTER"}

    def execute(self, context):
        p = context.scene.dp_ramchill
        if p.che_do == chinh_sach.CHE_DO_TAT:
            self.report({"WARNING"},
                        "DP_RAMchill: pick Auto or Force first")
            return {"CANCELLED"}
        if nuong_map.thu_muc_that(p.thu_muc_nuong) is None:
            self.report({"ERROR"}, "DP_RAMchill: save the .blend first, "
                                   "or pick an absolute folder")
            return {"CANCELLED"}
        # Map dang bi thu nho boi mot lan render dut giua chung thi tra ve
        # co goc truoc — bake phai doc tu file, khong tu bo dem da ha.
        doi_co.tra_lai()
        try:
            ket_qua, ghi_chu = doi_co.lap_ke_hoach(context, cho_tx=False)
        except Exception as e:                    # noqa: BLE001
            self.report({"ERROR"}, "DP_RAMchill: %s" % e)
            return {"CANCELLED"}
        _ghi_moc_da_do(p, ghi_chu)
        wm = context.window_manager
        viec = sum(1 for k in ket_qua if k.get("doi"))
        wm.progress_begin(0, max(1, viec))
        try:
            dem = nuong_map.nuong_ke_hoach(
                ket_qua, p.thu_muc_nuong,
                bao_tien_do=lambda i, n: wm.progress_update(i),
                muon=p.dinh_dang_nuong, chat_luong=p.chat_luong)
        except Exception as e:                    # noqa: BLE001
            self.report({"ERROR"}, "DP_RAMchill: bake failed: %s" % e)
            return {"CANCELLED"}
        finally:
            wm.progress_end()
        p.bao_cao = nuong_map.dong_bao_cao(dem)
        self.report({"INFO"}, "DP_RAMchill: baked %d maps into %s" % (
            dem["da_bake"], dem["thu_muc"]))
        return {"FINISHED"}


class DPRAMCHILL_OT_nuong_chon(Operator):
    """BAKE SELECTED (Ducphan 18/09/2026) — ep map cua CAC VAT DANG CHON
    ve mot co, doc lap voi che do Off/Auto/Force.

    Cung duong ghi voi `Bake Smaller Maps` (`nuong_map.nuong_mot`): file
    MOI, doc lai so pixel, packed giu goi goc, `Restore Original Maps` tra
    lai. Map vat khong chon cung dung thi TACH RIENG truoc
    (`nuong_map.tach_rieng`, Ducphan 18/09/2026: "make unique").
    """
    bl_idname = "dpramchill.nuong_chon"
    bl_label = "Bake Selected Objects"
    bl_description = ("Write every map of the selected objects to NEW "
                      "files at Max Size (and Format), then point the maps "
                      "at them. For small objects that need very little "
                      "texture. A map shared with unselected objects is "
                      "copied first, so only the selected objects get the "
                      "small copy. Restore Original "
                      "Maps brings everything back.\n"
                      "Ghi moi map cua cac vat dang chon ra FILE MOI o co "
                      "Max Size (va dinh dang Format) roi tro map sang do. "
                      "Danh cho vat nho can rat it texture. Map ma vat khong "
                      "chon cung dung thi tach ban rieng truoc, chi vat dang "
                      "chon nhan ban nho. Restore Original Maps tra lai tat ca")
    bl_options = {"REGISTER"}

    # HOP THOAI (Ducphan 18/09/2026: "can cho chon co map khi bake selected
    # (dialog hien ra khi bam)"). Ba o nay CHEP khai bao cua o scene cung ten
    # (`props`) de khong co hai danh sach co phai giu khop bang tay. Bam OK thi
    # ghi nguoc vao scene — lan sau hop thoai mo ra dung lua chon cu.
    canh: EnumProperty(
        **props.DPRAMCHILL_Props.__annotations__["canh_chon"].keywords)
    dinh_dang: EnumProperty(
        **props.DPRAMCHILL_Props.__annotations__["dinh_dang_nuong"].keywords)
    chat_luong: IntProperty(
        **props.DPRAMCHILL_Props.__annotations__["chat_luong"].keywords)

    def invoke(self, context, event):
        if not context.selected_objects:
            self.report({"WARNING"}, "DP_RAMchill: select objects first")
            return {"CANCELLED"}
        p = context.scene.dp_ramchill
        self.canh = p.canh_chon
        self.dinh_dang = p.dinh_dang_nuong
        self.chat_luong = p.chat_luong
        return context.window_manager.invoke_props_dialog(self, width=320)

    def draw(self, context):
        lo = self.layout
        lo.label(text="%d objects selected" % len(context.selected_objects),
                 icon="RESTRICT_SELECT_OFF")
        lo.prop(self, "canh")
        lo.prop(self, "dinh_dang")
        hang = lo.row()
        hang.active = self.dinh_dang != nuong_map.DD_GIU
        hang.prop(self, "chat_luong")
        lo.label(text="Shared maps get their own copy", icon="INFO")

    def _lay(self, p, o_op, o_scene):
        """Goi tu script khong truyen o nao thi lay o cua scene."""
        if self.properties.is_property_set(o_op):
            v = getattr(self, o_op)
            setattr(p, o_scene, v)
            return v
        return getattr(p, o_scene)

    def execute(self, context):
        p = context.scene.dp_ramchill
        canh_chon = self._lay(p, "canh", "canh_chon")
        dinh_dang = self._lay(p, "dinh_dang", "dinh_dang_nuong")
        chat_luong = self._lay(p, "chat_luong", "chat_luong")
        vat = [ob for ob in context.selected_objects
               if getattr(ob, "material_slots", None)]
        if not context.selected_objects:
            self.report({"WARNING"}, "DP_RAMchill: select objects first")
            return {"CANCELLED"}
        if nuong_map.thu_muc_that(p.thu_muc_nuong) is None:
            self.report({"ERROR"}, "DP_RAMchill: save the .blend first, "
                                   "or pick an absolute folder")
            return {"CANCELLED"}
        canh = int(canh_chon)
        if (canh == nuong_map.CANH_GIU
                and dinh_dang == nuong_map.DD_GIU):
            self.report({"WARNING"}, "DP_RAMchill: Keep size + Lossless "
                                     "changes nothing - pick a size or JPG")
            return {"CANCELLED"}
        # Map dang bi ha boi mot lan render dut giua chung: tra ve co goc
        # truoc, nhu nut Bake chinh.
        doi_co.tra_lai()
        wm = context.window_manager
        wm.progress_begin(0, 100)
        try:
            dem = nuong_map.nuong_vat_chon(
                vat, canh, p.thu_muc_nuong, muon=dinh_dang,
                chat_luong=chat_luong,
                bao_tien_do=lambda i, n: wm.progress_update(
                    int(100 * i / max(1, n))))
        except Exception as e:                    # noqa: BLE001
            self.report({"ERROR"}, "DP_RAMchill: bake failed: %s" % e)
            return {"CANCELLED"}
        finally:
            wm.progress_end()
        p.bao_cao = nuong_map.dong_bao_cao(dem)
        self.report({"INFO"}, "DP_RAMchill: baked %d maps of %d objects "
                              "into %s" % (dem["da_bake"], dem["vat"],
                                           dem["thu_muc"]))
        return {"FINISHED"}


class DPRAMCHILL_OT_bo_nuong(Operator):
    bl_idname = "dpramchill.bo_nuong"
    bl_label = "Restore Original Maps"
    bl_description = ("Point every baked map back at its original file, at "
                      "full size. The baked files stay on disk.\n"
                      "Tro moi map da bake ve file goc, o co goc. File bake "
                      "van nam tren dia")
    bl_options = {"REGISTER"}

    def execute(self, context):
        doi_co.tra_lai()
        so, hong = nuong_map.tra_ve_goc()
        bc = "restored %d maps" % so
        if hong:
            bc += "\n! %d originals missing, kept" % hong
        context.scene.dp_ramchill.bao_cao = bc
        self.report({"WARNING"} if hong else {"INFO"},
                    "DP_RAMchill: %d maps back to the originals%s" % (
                        so, (", %d could not be restored" % hong)
                        if hong else ""))
        return {"FINISHED"}


class DPRAMCHILL_OT_toi_uu_luoi(Operator):
    """TOI UU LUOI CA CANH (Ducphan 18/09/2026) — xem `toi_uu_luoi.py`.

    Doc lap voi moi tinh nang khac: khong doc `che_do`, khong gan chot render.
    """
    bl_idname = "dpramchill.toi_uu_luoi"
    bl_label = "Optimize Meshes"
    bl_description = ("Fewer triangles for the whole scene (or the selected "
                      "objects): subdivisions render one level lower, flat "
                      "faces are merged and dense meshes are reduced. "
                      "Measured on a real interior: render RAM -23%, under 1% "
                      "of pixels visibly different. Original meshes are saved "
                      "to a separate file - Restore Original Meshes brings "
                      "them back.\n"
                      "Giam tam giac cho ca canh (hoac vat dang chon): chia "
                      "min render thap mot bac, gop mat phang, giam luoi day. "
                      "Do tren canh noi that that: RAM render -23%, duoi 1% "
                      "diem anh khac thay duoc. Luoi goc cat ra file rieng - "
                      "bam Restore Original Meshes de tra lai")
    bl_options = {"REGISTER"}

    pham_vi: EnumProperty(
        name="Apply to",
        items=(("SCENE", "Whole scene", "Every mesh object in this scene.\n"
                "Moi vat luoi trong scene nay"),
               ("SELECTED", "Selected objects", "Only the selected objects.\n"
                "Chi cac vat dang chon")),
        default="SCENE")
    ha_chia_min: BoolProperty(
        name="Subdivision one level lower", default=True,
        description="Render levels of every Subdivision modifier minus one. "
                    "Measured: render RAM -24%, 0.5% of pixels different.\n"
                    "Bac render cua moi modifier Subdivision tru mot. Do: RAM "
                    "render -24%, 0,5% diem anh khac")
    giam_luoi: BoolProperty(
        name="Reduce dense meshes", default=True,
        description="Merge flat faces and reduce meshes above the triangle "
                    "limit.\nGop mat phang va giam cac luoi tren nguong tam "
                    "giac")
    ti_le: EnumProperty(
        name="Keep",
        items=(("0.5", "50% of faces", "Measured: render RAM -23%, 0.9% of "
                "pixels different, not visible.\nDo: RAM render -23%, 0,9% "
                "diem anh khac, nhin khong ra"),
               ("0.75", "75% of faces", "Safer, less saving.\n"
                "An toan hon, tiet kiem it hon"),
               ("1.0", "Flat faces only", "Only merge faces lying in one "
                "plane - the shape does not change. Measured: -9%.\n"
                "Chi gop mat nam cung mat phang - hinh khong doi. Do: -9%")),
        default="0.5")
    nguong: IntProperty(
        name="Meshes over", default=20000, min=1000, soft_max=200000,
        description="Only meshes with at least this many triangles are "
                    "reduced.\nChi giam luoi co tu ngan nay tam giac tro len")
    so_sanh: BoolProperty(
        name="Test renders + report", default=True,
        description="Render a test image before and after, then show how "
                    "much render memory (VRAM on a GPU) was saved and how "
                    "many pixels changed. Takes two test renders.\n"
                    "Render thu mot anh truoc va sau, roi bao bo nho render "
                    "(VRAM neu render bang card) do duoc bao nhieu va bao "
                    "nhieu diem anh khac. Ton hai lan render thu")
    phan_tram: IntProperty(
        name="Test size", default=50, min=10, max=100, subtype="PERCENTAGE",
        description="Size of the test renders, of your render size. "
                    "Samples are capped at 64.\n"
                    "Co anh render thu, so voi co render cua ban. So mau "
                    "toi da 64")

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=340)

    def draw(self, context):
        lo = self.layout
        lo.prop(self, "pham_vi")
        lo.prop(self, "ha_chia_min")
        lo.prop(self, "giam_luoi")
        c = lo.column()
        c.active = self.giam_luoi
        c.prop(self, "ti_le")
        c.prop(self, "nguong")
        lo.prop(self, "so_sanh")
        hang = lo.row()
        hang.active = self.so_sanh
        hang.prop(self, "phan_tram")
        lo.label(text="Originals are saved to a file", icon="INFO")

    def execute(self, context):
        p = context.scene.dp_ramchill
        if self.pham_vi == "SELECTED":
            vat = list(context.selected_objects)
        else:
            vat = list(context.scene.objects)
        if not vat:
            self.report({"WARNING"}, "DP_RAMchill: no objects")
            return {"CANCELLED"}
        if self.giam_luoi and toi_uu_luoi.thu_muc_that() is None:
            self.report({"ERROR"}, "DP_RAMchill: save the .blend first - "
                                   "original meshes are kept next to it")
            return {"CANCELLED"}
        sc = context.scene
        so_sanh = self.so_sanh and sc.camera is not None
        # ⛔ KHONG IM LANG: khong camera thi khong render thu duoc — noi ra,
        # khong thi bang bao cao khong hien ma khach khong biet vi sao.
        khong_cam = self.so_sanh and sc.camera is None
        thu = None
        if so_sanh:
            thu_goc = toi_uu_luoi.thu_muc_that()
            if thu_goc is None:
                self.report({"ERROR"}, "DP_RAMchill: save the .blend first "
                                       "- test renders are kept next to it")
                return {"CANCELLED"}
            thu = os.path.join(thu_goc, "compare")
            os.makedirs(thu, exist_ok=True)
            try:
                truoc = so_sanh_luoi.render_thu(
                    sc, os.path.join(thu, "before.png"), self.phan_tram)
            except Exception as e:                # noqa: BLE001
                self.report({"ERROR"}, "DP_RAMchill: test render failed: %s"
                            % e)
                return {"CANCELLED"}
        wm = context.window_manager
        wm.progress_begin(0, 100)
        try:
            dem = toi_uu_luoi.toi_uu(
                vat, ti_le=float(self.ti_le), nguong=self.nguong,
                ha_chia_min=self.ha_chia_min, giam_luoi=self.giam_luoi,
                bao_tien_do=lambda i, n: wm.progress_update(
                    int(100 * i / max(1, n))))
        except Exception as e:                    # noqa: BLE001
            self.report({"ERROR"}, "DP_RAMchill: optimize failed: %s" % e)
            return {"CANCELLED"}
        finally:
            wm.progress_end()
        p.bao_cao_luoi = toi_uu_luoi.dong_bao_cao(dem)
        if khong_cam:
            p.bao_cao_luoi += "\n! no camera: no test render"
        p.bc_co = False
        if so_sanh:
            try:
                sau = so_sanh_luoi.render_thu(
                    sc, os.path.join(thu, "after.png"), self.phan_tram)
                px, tb = so_sanh_luoi.so_anh(
                    os.path.join(thu, "before.png"),
                    os.path.join(thu, "after.png"),
                    os.path.join(thu, "difference.png"))
                so_sanh_luoi.ghi_bao_cao(p, truoc, sau, px, tb, dem,
                                         so_sanh_luoi.thiet_bi(sc)[0])
                so_sanh_luoi.nap_anh(thu)
            except Exception as e:                # noqa: BLE001
                self.report({"WARNING"}, "DP_RAMchill: meshes optimized, "
                                         "but the report failed: %s" % e)
                return {"FINISHED"}
        self.report({"INFO"}, "DP_RAMchill: %d meshes optimized, %d "
                              "subdivisions lowered" % (dem["luoi"],
                                                        dem["chia_min"]))
        return {"FINISHED"}


class DPRAMCHILL_OT_tra_luoi(Operator):
    bl_idname = "dpramchill.tra_luoi"
    bl_label = "Restore Original Meshes"
    bl_description = ("Bring back the original meshes and subdivision "
                      "levels.\n"
                      "Tra lai luoi goc va bac chia min")
    bl_options = {"REGISTER"}

    def execute(self, context):
        so, so_s, hong = toi_uu_luoi.tra_ve_goc()
        bc = "restored %d meshes, %d subdivisions" % (so, so_s)
        if hong:
            bc += "\n! %d originals missing" % hong
        context.scene.dp_ramchill.bao_cao_luoi = bc
        context.scene.dp_ramchill.bc_co = False     # bang so sanh het dung
        self.report({"WARNING"} if hong else {"INFO"}, "DP_RAMchill: " +
                    bc.replace("\n", ", "))
        return {"FINISHED"}


class DPRAMCHILL_OT_xem_so_sanh(Operator):
    bl_idname = "dpramchill.xem_so_sanh"
    bl_label = "Show Test Image"
    bl_description = ("Open the test render in a new Image Editor window.\n"
                      "Mo anh render thu trong mot cua so Image Editor moi")
    bl_options = {"REGISTER"}

    anh: EnumProperty(items=(("khac", "Difference", "Changed pixels in red"),
                             ("truoc", "Before", ""), ("sau", "After", "")),
                      default="khac")

    def execute(self, context):
        ten = so_sanh_luoi.TEN_ANH[self.anh]
        im = bpy.data.images.get(ten)
        if im is None:
            self.report({"WARNING"}, "DP_RAMchill: no test image yet")
            return {"CANCELLED"}
        cu = set(context.window_manager.windows[:])
        bpy.ops.wm.window_new()
        moi = [w for w in context.window_manager.windows if w not in cu]
        if not moi:
            self.report({"INFO"}, "DP_RAMchill: open an Image Editor and "
                                  "pick '%s'" % ten)
            return {"FINISHED"}
        a = moi[0].screen.areas[0]
        a.type = "IMAGE_EDITOR"
        a.spaces[0].image = im
        return {"FINISHED"}


_LOP = (DPRAMCHILL_OT_quet, DPRAMCHILL_OT_moc_tu_scene,
        DPRAMCHILL_OT_tra_lai, DPRAMCHILL_OT_nuong, DPRAMCHILL_OT_nuong_chon,
        DPRAMCHILL_OT_bo_nuong, DPRAMCHILL_OT_toi_uu_luoi,
        DPRAMCHILL_OT_tra_luoi, DPRAMCHILL_OT_xem_so_sanh)


def dang_ky():
    for c in _LOP:
        bpy.utils.register_class(c)


def go():
    for c in reversed(_LOP):
        bpy.utils.unregister_class(c)
